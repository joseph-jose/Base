﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabLib
{
    public partial class frmVwXY : Form
    {
        private IHookHelper __vHookHelper = null;

        public IHookHelper __HookHelper { set { __vHookHelper = value; } } 

        public frmVwXY()
        {
            InitializeComponent();
        }

        ~frmVwXY()
        {
            //MessageBox.Show ("destroyed"); 
        }

        public void loadFrm()
        {
            IActiveView vActiveView = __vHookHelper.ActiveView;
            IMap vCurrMap = __vHookHelper.FocusMap;
            IEnumLayer vEnmLyr = vCurrMap.get_Layers(null, true);
            try
            {

                ILayer vLyr = null;
                vLyr = vEnmLyr.Next();
                while (!(vLyr == null))
                {
                    if (vLyr is IFeatureLayer)
                    {
                        cmbLyrs.Items.Add(vLyr.Name.ToString());
                        //MessageBox.Show(vLyr.Name);
                    }
                    vLyr = vEnmLyr.Next();
                }


                vActiveView.PartialRefresh(esriViewDrawPhase.esriViewGraphics, null, null);
            }
            finally
            {
                Marshal.ReleaseComObject(vEnmLyr); 
            }
        }

        public ILayer getLayerByName(string inLyrName)
        {
            IEnumLayer vLyrsInToc = __vHookHelper.FocusMap.get_Layers()   ;
            try
            {
                ILayer vCurrLyr = null;

                vLyrsInToc.Reset();
                vCurrLyr = vLyrsInToc.Next();
                while (!(vCurrLyr == null))
                {
                    if (vCurrLyr is IFeatureLayer)
                    {
                        if (vCurrLyr.Name == inLyrName)
                        {
                            break;
                        }
                    }
                    vCurrLyr = vLyrsInToc.Next();
                }
                return vCurrLyr;
            }
            finally
            {
                Marshal.ReleaseComObject(vLyrsInToc);
            }
        }

        private void fillHeader(IFeature inFeat)
        {
            IRow vRow;
            if (!(inFeat == null))
            {
                vRow = inFeat ;
                dtGrdFtrVals.ColumnCount = vRow .Fields.FieldCount ;
                for (int vI = 0; vI< vRow.Fields.FieldCount ; vI++)
                {
                    dtGrdFtrVals.Columns[vI].HeaderText = vRow.Fields.Field[vI].Name;
                }
                if (inFeat.Shape.GeometryType == esriGeometryType.esriGeometryPoint)
                {
                    dtGrdFtrVals.Columns.Add("colX", "X");
                    dtGrdFtrVals.Columns.Add("colY", "Y");
                }
            }
        }

        private void fillRowItem(IFeature inFeat)
        {
            IRow vRow;
            if (!(inFeat == null))
            {
                vRow = inFeat ;
                IPoint vCurrPnt = null;
                dtGrdFtrVals.RowCount = dtGrdFtrVals.RowCount + 1;

                for (int vI = 0; vI< vRow.Fields.FieldCount ; vI++)
                {
                    if (vRow.Fields.Field[vI].Name.ToUpper() == "SHAPE")
                        dtGrdFtrVals.Rows[dtGrdFtrVals.RowCount - 1].Cells[vI].Value = inFeat.Shape.GeometryType.ToString(); 
                    else
                        dtGrdFtrVals.Rows[dtGrdFtrVals.RowCount - 1].Cells[vI].Value = vRow.get_Value(vI);
                }
                if (inFeat.Shape.GeometryType == esriGeometryType.esriGeometryPoint)
                {
                    vCurrPnt = (IPoint)inFeat.Shape;
                    //MessageBox.Show(vCurrPnt.X.ToString() + "," + vCurrPnt.Y.ToString());
                    dtGrdFtrVals.Rows[dtGrdFtrVals.RowCount - 1].Cells["colX"].Value = vCurrPnt.X.ToString();
                    dtGrdFtrVals.Rows[dtGrdFtrVals.RowCount - 1].Cells["colY"].Value = vCurrPnt.Y.ToString();
                }
            }
        }

        private void btnVw_Click(object sender, EventArgs e)
        {
            int vCurrRowIdx = 0;

            dtGrdFtrVals.Rows.Clear();
            dtGrdFtrVals.RowCount = 0;
            IFeatureLayer vCurrLyr = getLayerByName(cmbLyrs.Text) as IFeatureLayer ;
            //if vCurrLyr.FeatureClass.FeatureType is esriFeatureType 
            IFeatureCursor vFeatCur = vCurrLyr.FeatureClass.Search(null, true );
            IFeature vCurrFeat = vFeatCur.NextFeature();
            if (!(vCurrFeat == null))
            {
                fillHeader(vCurrFeat );
                while (!(vCurrFeat == null ))
                {
                    fillRowItem(vCurrFeat);
                    vCurrFeat = vFeatCur.NextFeature();

                    vCurrRowIdx = vCurrRowIdx + 1;
                    if (vCurrRowIdx > 1000)
                        break;
                }
            }
        }

        private void frmVwXY_Load(object sender, EventArgs e)
        {
            loadFrm();

        }
    }
}
