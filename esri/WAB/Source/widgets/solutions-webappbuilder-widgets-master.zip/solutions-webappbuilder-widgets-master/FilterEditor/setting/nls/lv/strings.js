﻿define(
   ({
    enableUndoRedo: "Iespējot Atsaukt/Atatsaukt",
    toolbarVisible: "Rīkjosla redzama",
    toolbarOptions: "Rīkjoslas opcijas",
    mergeVisible: "Apvienot",
    cutVisible: "Izgriezt",
    reshapeVisible: "Pārveidot",
    back: "Atpakaļ",
    label: "Slānis",
    edit: "Rediģējams",
    update: "Atspējot Atjaunināt ģeometriju",
    fields: "Lauki",
    actions: "Darbības",
    editpageName: "Nosaukums",
    editpageAlias: "Aizstājvārds",
    editpageVisible: "Redzams",
    editpageEditable: "Rediģējams",
    noLayers: "Nav pieejams neviens rediģējams elementu slānis",
    configureFields: "Konfigurēt slāņa laukus"
  })
);