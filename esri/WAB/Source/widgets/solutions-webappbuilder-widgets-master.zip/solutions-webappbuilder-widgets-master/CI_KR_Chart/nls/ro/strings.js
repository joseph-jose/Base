﻿define({
    select: "Ă_Select_ș",
    results: "Ă_Results_ș",
    selectLayer: "Ă_Select from layer:_ș",
    selectDrawtool: "Ă_Select draw tool:_ș",
    result: "Ă_Result:_ș",
    noresult: "Ă_No query results to display chart._ș",
    nomedia: "Ă_There's no media in configuration!_ș",
    envelop: "Ă_Draw Rectangle_ș",
    circle: "Ă_Draw Circle_ș",
    ellipse: "Ă_Draw Ellipse_ș",
    polygon: "Ă_Draw Polygon_ș",
    freehand: "Ă_Draw Freehand Polygon_ș",
    clear:"Ă_Clear_ș"
});