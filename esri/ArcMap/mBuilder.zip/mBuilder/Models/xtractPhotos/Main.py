import arcpy 
import arcpy.da 
from arcpy import da
import os 

try:

	FCs = arcpy.GetParameterAsText(0)
        fileLocation = arcpy.GetParameterAsText(1)
	arcpy.env.workspace = FCs

	inFeature = "ObservePoints__ATTACH"
	fieldname = "REL_GLOBALID"
	jointable = "ObservePoints"
	joinField = "GLOBALID"
	chkfieldname = "UniqueId"



        def addRelate():
	        arcpy.JoinField_management(inFeature, fieldname, jointable, joinField)
	        print "Join created successfully"


        def chkIfFldXsts():
            vFldNames = arcpy.ListFields(inFeature, chkfieldname)        
            if len(vFldNames) > 0:
                return True
            else:
                return False

        def xtrctPhotos():
            with da.SearchCursor(inFeature, ['DATA', 'ATT_NAME', 'REL_GLOBALID', 'UniqueId']) as cursor:
                for item in cursor:
                    attachment = item[0]
                    filenum = str(item[3]) + "_"
                    filename = filenum + str(item[1])
                    open(fileLocation + os.sep + filename, 'wb').write(attachment.tobytes())
                    #del item
                    #del filenum
                    #del filename
                    #del attachment

        if (not(chkIfFldXsts())):
            print "Join does not exists"
            addRelate()
        else:
            print "Join already eXists"


        xtrctPhotos()
        print "Photos extracted"
except Exception as err:
	arcpy.AddError(err)
	print err