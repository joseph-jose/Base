# WebAppBuilderEnhancedDrawWidget
This is a WIP version of a JavaScript Enhanced Draw Widget. Specifically for Esri Web App Builder
Based on work by Tim Witt
Uses Esri Draw Widget as the starting point (copied into folder, edited, put into Github)

I plugged code in from Esri and Tim's work and only added where I saw fit.

This IS NOT a complete port of Tim's work. I only added what I needed to use in a current project.
The project is a "what is possible demo". If you want more please Clone/Fork this and add as you see fit.
