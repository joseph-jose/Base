﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class CreateAlbum : System.Web.UI.Page
{
    public string connectString = "Data Source=nsmagallery.db.8879692.hostedresource.com; Initial Catalog=nsmagallery; User ID=nsmagallery; Password=Bobenantony07";
    
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    protected void btnCreate_Click(object sender, EventArgs e)
    {
        
        try
        {
            //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            SqlConnection con = new SqlConnection(connectString);
            
            con.Open();
            string query = "Insert into Album (AlbumName) values ('" + txtAlbumName.Text + "');SELECT ident_Current('Album') AS 'AlbumID'";
            SqlCommand com = new SqlCommand(query, con);
            object obj = com.ExecuteScalar();
            int res = int.Parse(obj.ToString());
            Response.Write("<script>alert('Album Created!!')</script>");
            HttpContext.Current.Items.Add("AlbumID", res);
            Server.Transfer("ImageUpload.aspx");
             
        }
        catch (Exception ex)
        {
            lberror.Text = ex.Message.ToString();
       
        }
        
    }

    protected void txtAlbumName_TextChanged(object sender, EventArgs e)
    {

    }

}
