import arcpy
import os
import datetime
from arcpy import env

#in_path = r"C:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication20180819.gdb"
#out_path = r"c:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication-Water.gdb"
#in_FC = r"swBridge"
in_path = arcpy.GetParameterAsText(0)
out_path = arcpy.GetParameterAsText(1)
in_FC = arcpy.GetParameterAsText(2)

arcpy.env.workspace = in_path


has_m = "DISABLED"
has_z = "DISABLED"

desc = arcpy.Describe(in_path + r"\\" + in_FC)
if hasattr(desc, "spatialReference"):
    spaRef = desc.spatialReference
    geometry_type = desc.shapeType
    print geometry_type

arcpy.CreateFeatureclass_management(out_path, in_FC, geometry_type, in_FC, has_m, has_z, spaRef)



