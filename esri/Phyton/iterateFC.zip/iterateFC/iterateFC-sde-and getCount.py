import arcpy
import os
import datetime

FCs = r"C:\Users\jejyjose1\AppData\Roaming\ESRI\Desktop10.5\ArcCatalog\PROD atalgissdbp01.AT.sde"
FCName = r""
#FCs = r"C:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication20180819.gdb"
arcpy.env.workspace = FCs
fcList = arcpy.ListFeatureClasses()
print(datetime.datetime.now())
for fc in fcList:
    #print(fc)
    fullName = arcpy.ParseTableName(fc)    
    nameList = fullName.split(",")
    
    #print ( nameList[0] )
    #print ( nameList[1] )
    #fcName = nameList[2]
    #fcStr = str(fcName)
    #print(fullName)
    #fcStr = fcStr.strip()
    #print(fcStr)

    FCName = nameList[0].strip()
    FCName = FCName + "." + nameList[1].strip()
    FCName = FCName + "." + nameList[2].strip()
    #print(FCName)
    
    result = arcpy.GetCount_management(FCName)
    print('{} has {} records'.format(FCName, result[0]))
    
print(datetime.datetime.now())


