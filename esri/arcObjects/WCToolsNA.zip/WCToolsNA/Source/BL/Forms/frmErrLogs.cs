﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCToolsNA.BL.Classes;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ADF; 
using System.Runtime.InteropServices; 

namespace WCToolsNA.BL.Forms
{
    public partial class frmErrLogs : Form
    {
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }
        private string __LogSessId = "";
        public string __LogSession { set { __LogSessId = value; } }
        //private IFeatureLayer __FeatLyr;
        //private IList __Lst;

        WCToolsNA.BL.Classes.cUtilGIS __GISUtil;
        WCToolsNA.BL.Classes.cUtilFile __UtilFile;
        WCToolsNA.BL.Classes.cDbFile __DbFile;

        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

        public frmErrLogs()
        {
            InitializeComponent();
        }



        public void helpersActivate()
        {
            __DbFile = new WCToolsNA.BL.Classes.cDbSqlFile();
            __UtilFile = new WCToolsNA.BL.Classes.cUtilFile();
            __GISUtil = new WCToolsNA.BL.Classes.cUtilGIS();
            __GISUtil.vAppMap = __App;

            connDB();
            logNtry("WCTools", "ViewLogs", "Start", __LogSessId, "TRC");
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "ViewLogs", "End", __LogSessId, "TRC");
            __DbFile.Dispose();
            __DbFile = null;
            __GISUtil.Dispose();
            __GISUtil = null;

        }
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            __UtilFile.logNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public bool validateOnLoad()
        {
            bool vResFn = false;

            vResFn = true;
            return vResFn;
        }	

        #region "fileUtiliites"
        private string getFilename(string inPath)
        {
            string vRetStr = "";
            string[] dirFlNames;
            dirFlNames = Directory.GetFiles(inPath);

            foreach (string vFlName in dirFlNames)
            {
                if (!(vFlName.IndexOf("ErrorLogs") == -1))
                {
                    vRetStr = vFlName;
                    break;
                }
            }
            return vRetStr;
        }

        private void xtrctVals(string invStr, int inStrtIdx, int inLn, int inColIdx)
        {
            string subStr = "";
            subStr = invStr.Substring(inStrtIdx, inLn);
            dtGrdLyrVals.Rows[dtGrdLyrVals.RowCount - 1].Cells[inColIdx].Value = subStr;
        }

        private void procLine(string inStr)
        {
            dtGrdLyrVals.Rows.Add();

            xtrctVals(inStr, 0, 10, 0);
            xtrctVals(inStr, 11, 2, 1);
            xtrctVals(inStr, 14, 10, 2);
            xtrctVals(inStr, 25, 2, 3);
            xtrctVals(inStr, 28, 10, 4);
            xtrctVals(inStr, 39, 12, 5);
            xtrctVals(inStr, 51, 12, 6);
            xtrctVals(inStr, 63, 12, 7);
            xtrctVals(inStr, 76, 200, 8);
        }

        private void procFile(string inFile)
        {
            bool vStrtRead = false;
            //bool vEndRead = false;
            using (StreamReader stRdr = new StreamReader(inFile))
            {
                string vLnStr = "";
                while ((vLnStr = stRdr.ReadLine()) != null)
                {
                    if ((vLnStr.Trim() == "") && vStrtRead)
                    {
                        break;
                    }

                    if (vStrtRead)
                    {
                        procLine(vLnStr);
                    }
                    if (vLnStr.IndexOf("---------- -- ----------") > -1)
                    {
                        vStrtRead = true;
                    }
                }
            }
        }
        #endregion

        private void btnUpdAttr_Click(object sender, EventArgs e)
        {
            if (!(dtGrdLyrVals.SelectedRows.Count > 0))
            {
                MessageBox.Show("Select an item in grid");
                return;
            }
            if (cmbLyrs.Text.Trim() == "")
            {
                MessageBox.Show("Select the layer");
                cmbLyrs.Focus();
                return;
            }

            string vGisId = "";
            vGisId = dtGrdLyrVals.SelectedRows[0].Cells[0].Value.ToString();
            bool vFtrFnd = false;
            if (cmbLyrs.Text.ToUpper() == "ALL..")
            {
                this.Cursor = Cursors.WaitCursor;
                try
                {
                    for (int vI = 1; vI < cmbLyrs.Items.Count; vI++)
                    {
                        tStripStatusLabel.Text = "Searching..." + cmbLyrs.Items[vI].ToString();
                        System.Threading.Thread.Sleep(50);
                        Application.DoEvents();
                        vFtrFnd = findFeatInLyr(cmbLyrs.Items[vI].ToString(), vGisId);
                        if (vFtrFnd) { break; }
                    }
                }
                finally
                {
                    this.Cursor = Cursors.Default;
                    tStripStatusLabel.Text = "";
                }
            }
            else
                vFtrFnd = findFeatInLyr(cmbLyrs.Text, vGisId);

            if (!(vFtrFnd))
                MessageBox.Show ("Feature not found"); 
        }

        private void frmErrLogs_Load(object sender, EventArgs e)
        {
            txtErrFlName.Text = getFilename("G:\\Admin\\Logs");
            loadMapLayers();
            button1_Click(this, null);
        }

        private void btnBrw_Click(object sender, EventArgs e)
        {
            //btnBrw
        }

        #region "UI Functions"
        private void addAllUsers()
        {
            string vUsr = "";
            for (int vI = 0; vI < dtGrdLyrVals.RowCount - 1; vI++)
            {
                vUsr = dtGrdLyrVals.Rows[vI].Cells[6].Value.ToString();
                if (cmbFltrBy.Items.IndexOf(vUsr) == -1)
                    cmbFltrBy.Items.Add(vUsr);
            }
        }

        private void loadMapLayers()
        {
            IEnumLayer vLyrsInToc = __GISUtil.getLyrsInTOC();
            try
            {
                ILayer vCurrLyr = null;

                cmbLyrs.Items.Add("All..");
                vLyrsInToc.Reset();
                vCurrLyr = vLyrsInToc.Next();
                while (!(vCurrLyr == null))
                {
                    if (vCurrLyr is IFeatureLayer)
                    {
                        cmbLyrs.Items.Add(vCurrLyr.Name.ToString());
                    }
                    vCurrLyr = vLyrsInToc.Next();
                }
                cmbLyrs.SelectedIndex = 0;
            }
            finally
            {
                Marshal.ReleaseComObject(vLyrsInToc);
            }
        }	

        private bool findFeatInLyr(string inLyrName, string inFltrCond)
        {
            //string vObjIdWhrStr;
            bool vBoolRes = false;
            ILayer vCurrLyr = null;
            vCurrLyr = __GISUtil.getLayerByName(inLyrName);
            IFeatureLayer vFeatLyr = vCurrLyr as IFeatureLayer;

            inFltrCond = "GIS_ID=" + inFltrCond;

            int vFfdIdx = -1;
            vFfdIdx = __GISUtil.getFieldIdx(vFeatLyr, "GIS_ID");
            if (vFfdIdx == -1)
            {
                return vBoolRes;
            }

            IFeature vFeat = null;
            IFeatureCursor vFeatCur = __GISUtil.getFeaturesForCond(__GISUtil.vAppDoc, vFeatLyr, inFltrCond);
            try
            {
                //vEnmFeat.Reset();
                vFeat = vFeatCur.NextFeature();
                if (!(vFeat == null))
                {
                    __GISUtil.ZoomToFeature(vFeat, __GISUtil.vAppDoc);
                    __GISUtil.SelectOnMap(__GISUtil.vAppDoc, vFeatLyr, inFltrCond);
                    vBoolRes = true;
                }
            }
            finally
            {
                //Marshal.ReleaseComObject(vEnmFeat);
                Marshal.ReleaseComObject(vFeatCur);
                Marshal.ReleaseComObject(vCurrLyr);
            }
            return vBoolRes;

        }


        #endregion

        private void btnRef_Click(object sender, EventArgs e)
        {
            string vUsr = "";
            for (int vI = 0; vI < dtGrdLyrVals.RowCount - 1; vI++)
            {
                vUsr = dtGrdLyrVals.Rows[vI].Cells[6].Value.ToString();
                if (!(cmbFltrBy.Text == vUsr))
                    dtGrdLyrVals.Rows[vI].Visible = false;
                else
                    dtGrdLyrVals.Rows[vI].Visible = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            //this.helpersDeActivate(); 
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            procFile(txtErrFlName.Text);
            addAllUsers();
        }
    }
}
