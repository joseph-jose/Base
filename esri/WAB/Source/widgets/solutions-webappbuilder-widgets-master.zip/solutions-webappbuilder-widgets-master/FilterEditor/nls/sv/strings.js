﻿define(
   ({
    _widgetLabel: "Redigera",
    title: "Välj en mall för att skapa geoobjekt",
    pressStr: "Tryck på ",
    ctrlStr: " CTRL ",
    snapStr: " när du vill aktivera snappning"
  })
);