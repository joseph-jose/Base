﻿define({
    unit: "須_Unit_鷗",
    style: "須_Style_鷗"
});