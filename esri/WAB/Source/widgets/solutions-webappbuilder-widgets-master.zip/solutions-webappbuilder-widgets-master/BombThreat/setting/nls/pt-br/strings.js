﻿define({
    left: "ã_LEFT_Ç",
    right: "ã_RIGHT_Ç",
    arrangement: "Disposição",
    autoUpdate: "Atualização Automática",
    respectCurrentMapScale: "Respeitar Escala de Mapa Atual"
});