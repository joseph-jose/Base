This .zip file contains resources for using the Add Feature Class Indexes script tool in ArcGIS for Desktop. The Python script was written by Stephen Lambert of Esri, and the tool was created by Aileen Buckley of Esri. 

The Add Feature Class Indexes script tool adds attribute indexes to an existing feature class or overwrites existing indexes. The indexes will be single column/field indexes, with default characteristics of UNIQUE and ASCENDING. The field list is extracted from the feature class. Index naming will follow the recommended naming convention for attribute indexes, that is, FieldName_IDX. 

The field name in the index will be truncated since the length of an index name is limited to 10 characters, including the _IDX suffix. Vowels will be removed and names will be reduced to 6 characters, plus _IDX. For example, the index name for a field named Spacing will be SPCING_IDX.

Duplicate index names may result because of this truncation. If this happens, the index will only be created for the last field with a duplicate name. For example, two fields named Control and Central will both be truncated to CNTRL_, resulting in duplicate index names of CNTRL_IDX. If the first field in the attribute table is Control and the second is Central, an index will be added for the Control field , then it will be deleted when the index is added for the Central field. 

You can add additional indexes for any fields for which indexes were not created using this tool. To learn more about adding attribute indexes, see:
http://desktop.arcgis.com/en/arcmap/latest/manage-data/tables/creating-attribute-indexes.htm.

When the file is unzipped the Tools folder will contain the following:

Add_Feature_Class_Indexes.py -- The Python script that is the source for the Add Feature Class Indexes script tool.

Add_Feature_Class_Indexes_Item_Description.txt -- The content used to udpate the Item Description for the tool.

readme.txt -- This readme file.

Aileen Buckley, Esri
June 2015

