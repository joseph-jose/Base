import arcpy
import os

FCs = arcpy.GetParameterAsText(0)

arcpy.env.workspace = FCs

tablename = "ObservePoints__ATTACH"
fieldname = "UniqueIDR"

if len(arcpy.ListFields(tablename, fieldname))>0:
	print "Field exist"
else:
	delimitedfield = arcpy.AddField_management(tablename, fieldname, "string")
	print "Field created"