﻿define({
    left: "左",
    right: "右",
    arrangement: "排列",
    autoUpdate: "自动更新",
    respectCurrentMapScale: "符合当前地图比例"
});