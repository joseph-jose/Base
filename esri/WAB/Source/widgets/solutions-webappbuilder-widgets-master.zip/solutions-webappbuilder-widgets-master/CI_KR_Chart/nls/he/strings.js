﻿define({
    select: "כן_Select_ש",
    results: "כן_Results_ש",
    selectLayer: "כן_Select from layer:_ש",
    selectDrawtool: "כן_Select draw tool:_ש",
    result: "כן_Result:_ש",
    noresult: "כן_No query results to display chart._ש",
    nomedia: "כן_There's no media in configuration!_ש",
    envelop: "כן_Draw Rectangle_ש",
    circle: "כן_Draw Circle_ש",
    ellipse: "כן_Draw Ellipse_ש",
    polygon: "כן_Draw Polygon_ש",
    freehand: "כן_Draw Freehand Polygon_ש",
    clear:"כן_Clear_ש"
});