﻿define({
    select: "ã_Select_Ç",
    results: "ã_Results_Ç",
    selectLayer: "ã_Select from layer:_Ç",
    selectDrawtool: "ã_Select draw tool:_Ç",
    result: "ã_Result:_Ç",
    noresult: "ã_No query results to display chart._Ç",
    nomedia: "ã_There's no media in configuration!_Ç",
    envelop: "ã_Draw Rectangle_Ç",
    circle: "ã_Draw Circle_Ç",
    ellipse: "ã_Draw Ellipse_Ç",
    polygon: "ã_Draw Polygon_Ç",
    freehand: "ã_Draw Freehand Polygon_Ç",
    clear:"ã_Clear_Ç"
});