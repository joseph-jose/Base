﻿define(
   ({
    enableUndoRedo: "Habilitar Desfazer/Refazer",
    toolbarVisible: "Barra de Ferramentas Visível",
    toolbarOptions: "Opções da Barra de Ferramentas",
    mergeVisible: "Juntar",
    cutVisible: "Cortar",
    reshapeVisible: "Redefinir",
    back: "Voltar",
    label: "Camada",
    edit: "Editável",
    update: "DisableUpdateGeometry",
    fields: "Campos",
    actions: "Ações",
    editpageName: "Nome",
    editpageAlias: "Nome Alternativo",
    editpageVisible: "Visível",
    editpageEditable: "Editável",
    noLayers: "Nenhuma camada de feição editável está disponível",
    configureFields: "Configurar Campos da Camada"
  })
);