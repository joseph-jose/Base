﻿define({
    select: "é_Select_È",
    results: "é_Results_È",
    selectLayer: "é_Select from layer:_È",
    selectDrawtool: "é_Select draw tool:_È",
    result: "é_Result:_È",
    noresult: "é_No query results to display chart._È",
    nomedia: "é_There's no media in configuration!_È",
    envelop: "é_Draw Rectangle_È",
    circle: "é_Draw Circle_È",
    ellipse: "é_Draw Ellipse_È",
    polygon: "é_Draw Polygon_È",
    freehand: "é_Draw Freehand Polygon_È",
    clear:"é_Clear_È"
});