﻿define({
    left: "يسار",
    right: "يمين",
    arrangement: "ترتيب",
    autoUpdate: "تحديث تلقائي",
    respectCurrentMapScale: "مراعاة مقياس رسم الخريطة الحالي"
});