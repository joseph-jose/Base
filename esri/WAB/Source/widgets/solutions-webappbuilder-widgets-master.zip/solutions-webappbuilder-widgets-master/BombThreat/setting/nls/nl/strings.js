﻿define({
    left: "LINKS",
    right: "RECHTS",
    arrangement: "Ordening",
    autoUpdate: "Automatisch bijwerken",
    respectCurrentMapScale: "Huidige schaal van de kaart aanhouden"
});