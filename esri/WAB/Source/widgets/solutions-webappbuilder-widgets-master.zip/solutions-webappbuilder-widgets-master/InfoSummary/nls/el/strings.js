﻿define(
   ({
    title: "InfoSummary Widget",
    helpText: "Κείμενο βοήθειας TODO InfoSummary",
    labels: {
      status: "Κατάσταση",
      result: "Αποτέλεσμα"
    },
    _widgetLabel: "Σύνοψη πληροφοριών (Beta)"
  })
);