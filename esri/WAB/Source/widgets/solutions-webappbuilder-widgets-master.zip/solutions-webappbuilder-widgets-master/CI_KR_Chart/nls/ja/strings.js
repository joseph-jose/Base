﻿define({
    select: "須_Select_鷗",
    results: "須_Results_鷗",
    selectLayer: "須_Select from layer:_鷗",
    selectDrawtool: "須_Select draw tool:_鷗",
    result: "須_Result:_鷗",
    noresult: "須_No query results to display chart._鷗",
    nomedia: "須_There's no media in configuration!_鷗",
    envelop: "須_Draw Rectangle_鷗",
    circle: "須_Draw Circle_鷗",
    ellipse: "須_Draw Ellipse_鷗",
    polygon: "須_Draw Polygon_鷗",
    freehand: "須_Draw Freehand Polygon_鷗",
    clear:"須_Clear_鷗"
});