// copy from columnlist.js
var TYPE_STRING = 0;
var TYPE_NUMBER = 1;
var TYPE_DATE = 2;
var TYPE_STRING_NO_CASE = 3;
var TYPE_ICON = 4;
var TYPE_FUNCTION = 5;
var TYPE_LINK = 6; //Steve

var controller = new RequestController();

function RequestController() {
    this.ajax = new Ajax('/tp/portal/component/dataselection.xml');
    this.requests = new Array();
    var requestController = this;

    this.ajax.statusAction["200"] = function (responseData) {
        requestController.loadXML(responseData);
        // delay(requestController.loadXML, responseData, 20);
    }
}

function getController() {
    return controller;
}

RequestController.prototype.addRequest = function (requestID, requestInstanceID, jsObject, selectionRequest) {
    this.requests[requestInstanceID] = new Request(requestID, requestInstanceID, jsObject, selectionRequest);
}

RequestController.prototype.getRequest = function (id) {
    return this.requests[id];
}


RequestController.prototype.update = function (elements, attributes) {

    for (var i = 0; i < elements.length; i++) {
        this.requests[elements[i]].update(attributes);
    }

}


RequestController.prototype.generateXML = function (elements, functionID) {

    var xml = '<document>';

    xml += '<requests>';

    for (var i = 0; i < elements.length; i++) {
        xml += this.requests[elements[i]].generateXML(functionID);
    }

    xml += '</requests>';
    xml += '</document>';
    // alert(xml);
    return xml;

}

// for ColumnList to page through
RequestController.prototype.loadPage = function (componentID, page) {

    this.getRequest(componentID).selectionRequest.setCurrentPage(page);

    this.loadData([componentID]);

}


RequestController.prototype.loadXML = function (xml) {

    var xmlDoc = new REXML(xml);

    var response = null;

    for (var i = 0; i < xmlDoc.rootElement.childElements.length; i++) {

        if (xmlDoc.rootElement.childElements[i].name == 'responses') {

            for (var j = 0; j < xmlDoc.rootElement.childElements[i].childElements.length; j++) {

                if (xmlDoc.rootElement.childElements[i].childElements[j].name == 'response') {

                    response = new Response(xmlDoc.rootElement.childElements[i].childElements[j]);
                    response.update();

                } else if (xmlDoc.rootElement.childElements[i].childElements[j].name == 'error-message') {
                    if (xmlDoc.rootElement.childElements[i].childElements[j].text) {
                        alert("An error has occurred.\nYou may have performed an invalid request.\nIf this problem continues, please report to our customer support team.");
                        return;
                    }
                }

            }

        }

    }


}

// main function to load data
// elements: array of componentIDs to update, if not specify, update all
RequestController.prototype.loadData = function (elements, attributes) {

    if (!elements) {

        elements = new Array();

        for (var property in this.requests) {
            elements.push(property);
        }

    }

    if (attributes) {
        this.update(elements, attributes);
    }

    this.ajax.go({'XML': this.generateXML(elements)});

}

RequestController.prototype.countTotal = function (elements) {

    this.ajax.go({'XML': this.generateXML(elements, 'countTotal')});

}

// need to register each Request for each ColumnList to controller by getController().addRequest()
// requestID
// requestInstanceID: componentID
function Request(requestID, requestInstanceID, jsObject, selectionRequest) {

    this.requestHeader = new RequestHeader(requestID, requestInstanceID);
    this.selectionRequest = selectionRequest;
    this.jsObject = jsObject;

}

/**
 Request.prototype.initialiseFilterFields = function() {

 this.filterFieldMappings = new Array();
 var elements = document.forms[0].elements; //todo

 for (var i = 0; i < elements.length; i++) {
 if (elements[i].type == 'text' || elements[i].type.indexOf('select') > -1) { // todo checkbox
 this.filterFieldMappings[elements[i].id] = elements[i].id;
 }
 }

 }
 */

Request.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'header') {
            this.requestHeader = new RequestHeader(element.childElements[i]);
        } else if (element.childElements[i].name == 'body') { //TODO
            this.selectionRequest = new SelectionRequest(null, element.childElements[i].childElements[0]);
        }

    }

}


Request.prototype.update = function (filterFields) {

    this.selectionRequest.startIndex = 0;
    this.selectionRequest.filterFields = new Array();
    // this.selectionRequest.filterFields = this.selectionRequest.filterFields || new Array();

    if (filterFields) {
        addAll(this.selectionRequest.filterFields, filterFields);
    }

//    for (var item in this.selectionRequest.filterFields) {
    //        alert(item + "=" + this.selectionRequest.filterFields[item])
    //    }
    //for custom selection page size
    if (returnElement('selection-page-size') && returnElement('selection-page-size').value > 0) {
        this.selectionRequest.maximum = returnElement('selection-page-size').value;
    }

}

Request.prototype.generateXML = function (functionID) {

    var xml = '<request>';

    xml += this.requestHeader.generateXML();

    xml += '<body>';
    xml += this.selectionRequest.generateXML(functionID);
    xml += '</body>';

    xml += '</request>';

    return xml;

}


function RequestHeader(requestID, requestInstanceID, element) {
    this.requestID = requestID;
    this.requestInstanceID = requestInstanceID;
    if (element) {
        this.initialise(element);
    }
}

RequestHeader.prototype.initialise = function (element) {
    for (var i = 0; i < element.childElements.length; i++) {
        if (element.childElements[i].name == 'request-id') {
            this.requestID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'request-instance-id') {
            this.requestInstanceID = element.childElements[i].getText();
        }
    }
}


RequestHeader.prototype.generateXML = function () {

    var xml = '';

    xml += '<header>';
    xml += formatElement('request-id', this.requestID);
    xml += formatElement('request-instance-id', this.requestInstanceID);
    xml += '</header>';

    return xml;

}


function SelectionRequest(params) {

    this.selectionID = null;
    this.moduleID = null;
    this.actionID = null;
    this.requestURL = null;
    this.credentials = null;
    this.permissionID = null;
    this.scopeAuthority = null;
    this.ownerComponentType = 0;
    this.ownerComponentID = 0;
    this.componentType = 0;
    this.entityID = 0;
    this.scopeComponentType = 0;
    this.scopeComponentID = 0;
    this.scopeComponentEntityID = 0;
    this.startIndex = 0;
    this.maximum = 0;
    this.displayFields = null;
    this.filterFields = new Array();
    this.selectionFilterFields = new Array();
    this.conditions = null;
    this.orderFields = null;
    this.itemIdMask = null;
    this.itemLabelMask = null;
    this.sourceComponentID = null;
    this.displayIcon = true;
    this.calculateTotalSize = false;
    this.useDefaultOrdering = false;

    if (typeof params == 'string') {
        this.parse(params);
    } else if (params) {
        this.initialise(params);
    }

}

SelectionRequest.prototype.parse = function (xml) {

    var xmlDoc = new REXML(xml);

    for (var i = 0; i < xmlDoc.rootElement.childElements.length; i++) {

        if (xmlDoc.rootElement.childElements[i].name == 'selection-id') {
            this.selectionID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'module-id') {
            this.moduleID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'action-id') {
            this.actionID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'request-url') {
            this.requestURL = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'credentials') {
            this.credentials = new Credentials(xmlDoc.rootElement.childElements[i]);
        } else if (xmlDoc.rootElement.childElements[i].name == 'permission-id') {
            this.permissionID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'scope-authority') {
            this.scopeAuthority = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'owner-component-type') {
            this.ownerComponentType = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'owner-component-id') {
            this.ownerComponentID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'component-type') {
            this.componentType = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'entity-id') {
            this.entityID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'scope-component-type') {
            this.scopeComponentType = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'scope-component-id') {
            this.scopeComponentID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'scope-component-entity-id') {
            this.scopeComponentEntityID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'start-index') {
            this.startIndex = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'maximum') {
            this.maximum = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'display-fields') {
            this.displayFields = this.newList(xmlDoc.rootElement.childElements[i], 'DisplayField');
        } else if (xmlDoc.rootElement.childElements[i].name == 'filter-fields') {
            this.filterFields = this.newMap(xmlDoc.rootElement.childElements[i]);
        } else if (xmlDoc.rootElement.childElements[i].name == 'selection-filter-fields') {
            this.selectionFilterFields = this.newMap(xmlDoc.rootElement.childElements[i]);
        } else if (xmlDoc.rootElement.childElements[i].name == 'conditions') {
            this.conditions = this.newList(xmlDoc.rootElement.childElements[i], 'FilterCondition');
        } else if (xmlDoc.rootElement.childElements[i].name == 'order-fields') {
            this.orderFields = this.newList(xmlDoc.rootElement.childElements[i], 'OrderField');
        } else if (xmlDoc.rootElement.childElements[i].name == 'source-component-id') {
            this.sourceComponentID = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'item-id-mask') {
            this.itemIdMask = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'item-label-mask') {
            this.itemLabelMask = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'display-icon') {
            this.displayIcon = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'calculate-total-size') {
            this.calculateTotalSize = xmlDoc.rootElement.childElements[i].getText();
        } else if (xmlDoc.rootElement.childElements[i].name == 'use-default-ordering') {
            this.useDefaultOrdering = xmlDoc.rootElement.childElements[i].getText();
        }

    }

}

SelectionRequest.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'selection-id') {
            this.selectionID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'module-id') {
            this.moduleID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'action-id') {
            this.actionID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'request-url') {
            this.requestURL = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'credentials') {
            this.credentials = new Credentials(element.childElements[i]);
        } else if (element.childElements[i].name == 'permission-id') {
            this.permissionID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'scope-authority') {
            this.scopeAuthority = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'owner-component-type') {
            this.ownerComponentType = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'owner-component-id') {
            this.ownerComponentID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'component-type') {
            this.componentType = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'entity-id') {
            this.entityID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'scope-component-type') {
            this.scopeComponentType = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'scope-component-id') {
            this.scopeComponentID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'scope-component-entity-id') {
            this.scopeComponentEntityID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'start-index') {
            this.startIndex = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'maximum') {
            this.maximum = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'display-fields') {
            this.displayFields = this.newList(element.childElements[i], 'DisplayField');
        } else if (element.childElements[i].name == 'filter-fields') {
            this.filterFields = this.newMap(element.childElements[i]);
        } else if (element.childElements[i].name == 'selection-filter-fields') {
            this.filterFields = this.newMap(element.childElements[i]);
        } else if (element.childElements[i].name == 'conditions') {
            this.conditions = this.newList(element.childElements[i], 'FilterCondition');
        } else if (element.childElements[i].name == 'order-fields') {
            this.orderFields = this.newList(element.childElements[i], 'OrderField');
        } else if (element.childElements[i].name == 'source-component-id') {
            this.sourceComponentID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'item-id-mask') {
            this.itemIdMask = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'item-label-mask') {
            this.itemLabelMask = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'display-icon') {
            this.displayIcon = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'calculate-total-size') {
            this.calculateTotalSize = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'use-default-ordering') {
            this.useDefaultOrdering = element.childElements[i].getText();
        }

    }

}

SelectionRequest.prototype.getColumns = function () {

    var columns = new Array();
    var displayField = null;

    for (var i = 0; i < this.displayFields.length; i++) {

        displayField = this.displayFields[i];

        columns.push([displayField.label, displayField.width, getType(displayField.type)]);

    }

    return columns;

}

SelectionRequest.prototype.newList = function (parent, className) {

    var list = new Array();

    for (var i = 0; i < parent.childElements.length; i++) {
        var item = eval('new ' + className + '()');
        item.initialise(parent.childElements[i])
        list.push(item);
    }

    return list;

}

SelectionRequest.prototype.newMap = function (parent) {

    var map = new Array();

    for (var i = 0; i < parent.childElements.length; i++) {
        map[parent.childElements[i].attribute('key')] = parent.childElements[i].getText();
    }

    return map;

}

SelectionRequest.prototype.setDisplayFields = function (displayFields) {
    this.displayFields = displayFields;
}

SelectionRequest.prototype.setOrderFields = function (orderFields) {
    this.orderFields = orderFields;
}

SelectionRequest.prototype.setConditions = function (conditions) {
    this.conditions = conditions;
}

function formatElement(name, value, attributes) {

    if (value == null) {
        value = '';
    }

    var element = '<' + name;

    if (attributes) {
        for (var property in attributes) {
            element += ' ' + property + '="' + attributes[property] + '"';
        }
    }

    element += '>' + value + '</' + name + '>';

    return element;

}

SelectionRequest.prototype.setCurrentPage = function (page) {
    this.startIndex = (page == 0) ? 0 : ((page - 1) * this.maximum);
}

SelectionRequest.prototype.generateListXML = function (list, tagName) {

    if (!list) return '';

    var xml = '<' + tagName + ' class="java.util.ArrayList">';

    for (var i = 0; i < list.length; i++) {
        xml += list[i].generateXML();
    }

    xml += '</' + tagName + '>';

    return xml;

}

SelectionRequest.prototype.generateMapXML = function (map, tagName) {

    if (!map) return '';

    var xml = '<' + tagName + ' class="java.util.HashMap" version="map2">';

    for (var property in map) {
        var name = property.replace('.', '').toLowerCase();
        xml += formatElement(name, map[property], {'key': property, 'class': "java.lang.String"});
    }

    xml += '</' + tagName + '>';

    return xml;

}

SelectionRequest.prototype.getClassName = function () {
    return "nz.co.touchpoint.touchpoint.core.dataselection.ComponentSelectionRequest";
}

SelectionRequest.prototype.generateSubClassAttributes = function () {
    return "";
}

SelectionRequest.prototype.generateXML = function (functionID) {

    var xml = '<selection-request class="' + this.getClassName() + '">';

    xml += formatElement('selection-id', this.selectionID);
    xml += formatElement('module-id', this.moduleID);
    xml += formatElement('action-id', this.actionID);
    xml += formatElement('permission-id', this.permissionID);
    xml += formatElement('scope-authority', this.scopeAuthority);
    xml += formatElement('owner-component-type', this.ownerComponentType);
    xml += formatElement('owner-component-id', this.ownerComponentID);
    xml += formatElement('scope-component-type', this.scopeComponentType);
    xml += formatElement('scope-component-id', this.scopeComponentID);
    xml += formatElement('scope-component-entity-id', this.scopeComponentEntityID);
    xml += formatElement('component-type', this.componentType);
    xml += formatElement('entity-id', this.entityID);
    xml += formatElement('start-index', this.startIndex);
    xml += formatElement('maximum', this.maximum);
    xml += formatElement('selection-id', this.selectionID);
    xml += formatElement('source-component-id', this.sourceComponentID);
    xml += formatElement('item-id-mask', this.itemIdMask);
    xml += formatElement('item-label-mask', this.itemLabelMask);
    xml += formatElement('display-icon', this.displayIcon);
    xml += formatElement('calculate-total-size', this.calculateTotalSize);
    xml += formatElement('use-default-ordering', this.useDefaultOrdering);

    if (functionID) {
        xml += formatElement('function-id', functionID)
    }

    xml += this.credentials.generateXML();

    xml += this.generateMapXML(this.filterFields, 'filter-fields');

    xml += this.generateMapXML(this.selectionFilterFields, 'selection-filter-fields');

    xml += this.generateListXML(this.displayFields, 'display-fields');

    xml += this.generateListXML(this.conditions, 'conditions');

    xml += this.generateListXML(this.orderFields, 'order-fields');

    xml += this.generateSubClassAttributes();

    xml += '</selection-request>';

    return xml;

}

SelectionRequest.prototype.getXMLRequest = function () {
    return new XMLRequest(this.requestURL, this.generateXML());
}

// ComponentTreeData
function ComponentTreeSelectionRequest(params) {
    this.startParentNodeID = 0;
    this.startParentNodeAlphaID = null;
    this.parentAttributeID = null;
    this.keyAttributeID = null;
    this.uriAttributeID = null;
    this.pathAttributeID = null;
    this.orderAttributeID = null;
    this.excludedNodeType = 0;
    this.excludedNodeID = 0;
    this.rootLabel = null;
    this.action = null;
    SelectionRequest.call(this, params);
}

ComponentTreeSelectionRequest.prototype = new SelectionRequest;

ComponentTreeSelectionRequest.prototype.getClassName = function () {
    return "nz.co.touchpoint.touchpoint.core.dataselection.ComponentTreeSelectionRequest";
}


ComponentTreeSelectionRequest.prototype.initialise = function (element) {

    SelectionRequest.prototype.initialise(element);

    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'start-parent-node-id') {
            this.startParentNodeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'start-parent-node-alpha-id') {
            this.startParentNodeAlphaID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'parent-attribute-id') {
            this.parentAttributeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'key-attribute-id') {
            this.keyAttributeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'uri-attribute-id') {
            this.uriAttributeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'path-attribute-id') {
            this.pathAttributeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'order-attribute-id') {
            this.orderAttributeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'excluded-node-id') {
            this.excludedNodeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'excluded-node-type') {
            this.excludedNodeType = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'root-label') {
            this.rootLabel = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'action') {
            this.action = element.childElements[i].getText();
        }

    }

}

ComponentTreeSelectionRequest.prototype.generateSubClassAttributes = function () {

    var xml = '';

    xml = formatElement("start-parent-node-id", this.startParentNodeID);
    xml = formatElement("start-parent-node-alpha-id", this.startParentNodeAlphaID);
    xml = formatElement("parent-attribute-id", this.parentAttributeID);
    xml = formatElement("key-attribute-id", this.keyAttributeID);
    xml = formatElement("uri-attribute-id", this.uriAttributeID);
    xml = formatElement("path-attribute-id", this.pathAttributeID);
    xml = formatElement("order-attribute-id", this.orderAttributeID);
    xml = formatElement("excluded-node-type", this.excludedNodeType);
    xml = formatElement("excluded-node-id", this.excludedNodeID);
    xml = formatElement("root-label", this.rootLabel);
    xml = formatElement("action", this.action);

    return xml;

}


// DisplayField
function DisplayField(element) {

    this.fieldID = null;
    this.fieldAttributeID = null;
    this.label = null;
    this.width = null;
    this.type = null;
    this.mask = null;
    this.alignment = null;
    this.isCustomField = false;
    this.dataMask = null;
    this.visible = true;
    this.renderFunction = null;
    this.linkLabel = null;
    this.linkUrl = null;
    this.linkTargetType = null;
    this.linkTargetWidth = 0;
    this.linkTargetHeight = 0;
    this.queryString = null;


    if (element) {
        this.initialise(element);
    }

}

DisplayField.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {
        if (element.childElements[i].name == 'field-id') {
            this.fieldID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'field-attribute-id') {
            this.fieldAttributeID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'label') {
            this.label = unescape(element.childElements[i].getText());
        } else if (element.childElements[i].name == 'width') {
            this.width = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'type') {
            this.type = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'mask') {
            this.mask = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'alignment') {
            this.alignment = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'is-custom-field') {
            this.isCustomField = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'data-mask') {
            this.dataMask = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'is-visible') {
            this.visible = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'link-label') {
            this.linkLabel = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'link-url') {
            this.linkUrl = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'link-target-type') {
            this.linkTargetType = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'link-target-width') {
            this.linkTargetWidth = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'link-target-height') {
            this.linkTargetHeight = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'render-function') {
            this.renderFunction = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'query-string') {
            this.queryString = element.childElements[i].getText();
        }

    }

}

DisplayField.prototype.generateXML = function () {

    var xml = '<item class="nz.co.touchpoint.touchpoint.core.dataselection.DisplayFieldDefinition">';

    xml += formatElement('field-id', this.fieldID);
    xml += formatElement('field-attribute-id', this.fieldAttributeID);
    xml += formatElement('label', escape(this.label));
    xml += formatElement('width', this.width);
    xml += formatElement('type', this.type);
    xml += formatElement('mask', this.mask);
    xml += formatElement('alignment', this.alignment);
    xml += formatElement('is-custom-field', this.isCustomField);
    xml += formatElement('data-mask', this.dataMask);
    xml += formatElement('is-visible', this.visible);
    xml += formatElement('link-label', this.linkLabel);
    xml += formatElement('link-url', this.linkUrl);
    xml += formatElement('link-target-type', this.linkTargetType);
    xml += formatElement('link-target-width', this.linkTargetWidth);
    xml += formatElement('link-target-height', this.linkTargetHeight);
    xml += formatElement('render-function', this.renderFunction);

    xml += '</item>';

    return xml;

}

// FilterCondition
function FilterCondition(element) {

    this.className = null;
    this.attributes = new Array();

    if (element) {
        this.initialise(element);
    }

}

FilterCondition.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {
        this.attributes[element.childElements[i].name] = element.childElements[i].getText();
    }

}

FilterCondition.prototype.generateXML = function () {

    var xml = '<item class="' + this.className + '">';

    for (var property in this.attributes) {
        xml += formatElement(property, this.attributes[property]);
    }

    xml += '</item>';

    return xml;

}

// OrderField
function OrderField(element) {

    this.fieldType = null;
    this.fieldName = null;
    this.ignoreCase = true;
    this.ascendingOrder = true;

    if (element) {
        this.initialise(element);
    }

}

OrderField.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {
        if (element.childElements[i].name == 'field-type') {
            this.fieldType = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'value') {
            this.fieldName = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'ignore-case') {
            this.ignoreCase = element.childElements[i].getText() != 'false';
        } else if (element.childElements[i].name == 'ascending-order') {
            this.ascendingOrder = element.childElements[i].getText() != 'false';
        }
    }

}

OrderField.prototype.generateXML = function () {

    var xml = '<item class="nz.co.touchpoint.touchpoint.model.component.OrderField">';

    xml += formatElement('field-type', this.fieldType);
    xml += formatElement('value', this.fieldName);
    xml += formatElement('ignore-case', this.ignoreCase);
    xml += formatElement('ascending-order', this.ascendingOrder);

    xml += '</item>';

    return xml;

}

// Credentials
function Credentials(element) {

    this.userID = null;
    this.md5Password = null;

    if (element) {
        this.initialise(element);
    }

}

Credentials.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {
        if (element.childElements[i].name == 'user-id') {
            this.userID = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'md5-password') {
            this.md5Password = element.childElements[i].getText();
        }
    }

}

Credentials.prototype.generateXML = function () {

    var xml = '<credentials class="nz.co.touchpoint.touchpoint.model.security.Credentials">';

    xml += formatElement('user-id', this.userID);
    xml += formatElement('md5-password', this.md5Password);

    xml += '</credentials>';

    return xml;

}

function Response(element) {

    this.header = null;
    this.errors = new Array();
    //todo
    this.selectionResponse = null;
    if (element) {

        this.initialise(element);
    }
}

Response.prototype.newSelectionResponse = function (element) {
    if (element.attribute('class')) {
        return eval('new ' + element.attribute('class').substring(element.attribute('class').lastIndexOf('.') + 1) + '(element)');
    } else {
        return new SelectionResponse(element);
    }
}

Response.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'header') {

            this.header = new RequestHeader(null, null, element.childElements[i]);

        } else if (element.childElements[i].name == 'body') {

            for (var j = 0; j < element.childElements[i].childElements.length; j++) {

                if (element.childElements[i].childElements[j].name == 'errors' || element.childElements[i].childElements[j].name == 'error-message') {
                    this.selectionResponse = this.newSelectionResponse(element.childElements[i].childElements[j]);
                } else if (element.childElements[i].childElements[j].name == 'selection-response') { //TODO
                    this.selectionResponse = this.newSelectionResponse(element.childElements[i].childElements[j]);
                }

            }

        }

    }

}

Response.prototype.update = function () {

    var request = getController().getRequest(this.header.requestInstanceID);
    var jsObject = request.jsObject;

    jsObject.updateResponse(request.selectionRequest, this.selectionResponse);

}

// SelectionResponse

function SelectionResponse(params) {

    //this.columns = null;
    this.fields = null;
    this.fieldIDs = null;
    this.data = null;
    this.totalSize = 0;
    this.knownSize = false;
    this.errorMessage = null;
    this.functionID = null;

    if (typeof params == 'string') {
        this.parse(params);
    } else if (params) {
        if (params.name && params.name == 'errors') {
            if (params.childElements[0] && params.childElements[0].name == 'error') {
                this.errorMessage = params.childElements[0].childElement('message').getText();
            }
        } else {
            this.initialise(params);
        }
    }

}

SelectionResponse.prototype.parse = function (xml) {

    var xmlDoc = new REXML(xml);

    // setColumns first
    for (var i = 0; i < xmlDoc.rootElement.childElements.length; i++) {

        if (xmlDoc.rootElement.childElements[i].name == 'field-definitions') {
            this.setColumns(xmlDoc.rootElement.childElements[i]);
        }

    }

    for (var i = 0; i < xmlDoc.rootElement.childElements.length; i++) {

        if (xmlDoc.rootElement.childElements[i].name == 'result') {
            this.setResult(xmlDoc.rootElement.childElements[i]);
        } else if (xmlDoc.rootElement.childElements[i].name == 'error-message') {
            this.errorMessage = xmlDoc.rootElement.childElements[i].text;
        }

    }

}

SelectionResponse.prototype.initialise = function (element) {

    // setColumns first
    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'field-definitions') {
            this.setColumns(element.childElements[i]);
        }

    }

    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'result') {
            this.setResult(element.childElements[i]);
        } else if (element.childElements[i].name == 'error-message') {
            this.errorMessage = element.childElements[i].text;
        } else if (element.childElements[i].name == 'function-id') {
            this.functionID = element.childElements[i].text;
        }

    }

}

function getType(type) {

    if (type) {

        if (type == 'number' || type == 'amount') {
            return TYPE_NUMBER;
        } else if (type == 'date' || type == 'datetime') {
            return TYPE_DATE;
        } else if (type == 'icon') {
            return TYPE_ICON;
        }

    }

    return TYPE_STRING;

}

SelectionResponse.prototype.setColumns = function (element) {

    //var columns = new Array();
    var fieldDefinitions = new Array();
    var fieldIDs = new Array();
    var fieldDefinition = null;

    for (var i = 0; i < element.childElements.length; i++) {

        fieldDefinition = new DisplayField(element.childElements[i]);

        //  columns.push([fieldDefinition.label, fieldDefinition.width, getType(fieldDefinition.type), fieldDefinition.alignment]);
        if (fieldDefinition.type == "6") {
            fieldIDs.push(fieldDefinition.fieldID);
            fieldIDs.push(fieldDefinition.fieldID + 'linkurl');
        } else {
            fieldIDs.push(fieldDefinition.fieldID);
        }

        fieldDefinitions.push(fieldDefinition);

    }

    //this.columns = columns;
    this.fieldIDs = fieldIDs;
    this.fieldDefinitions = fieldDefinitions;

}

SelectionResponse.prototype.setResult = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'total-size') {
            this.totalSize = element.childElements[i].getText();
        } else if (element.childElements[i].name == 'items') {
            this.setData(element.childElements[i]);
        } else if (element.childElements[i].name == 'known-size') {
            this.knownSize = (element.childElements[i].getText() == 'true');
        }

    }

}

SelectionResponse.prototype.getMapValue = function (map, key) {

    for (var i = 0; i < map.childElements.length; i++) {

        if (map.childElements[i].attribute('key') == key) {
            return unescapeHTML(map.childElements[i].getText());
        }

    }

    return '';

}

SelectionResponse.prototype.getErrorMessage = function () {

    var message = '<table cellpadding="0" cellspacing="10" border="0" width="100%"><tr><td align="center">';
    message += '<table cellpadding="0" cellspacing="0" border="0"><tr>';
    message += '<td width="40"><img src="/ui/images/icons/alert.png" width="30" height="30"></td>';
    message += '<td>';
    message += '<table cellpadding="0" cellspacing="0" border="0" width="300px">';
    message += '<tr valign="top">';
    message += '<td>';
    message += '<div class="separator" width="100%">An error has occured</div>';
    message += '</td>';
    message += '</tr>';
    message += '<tr>';
    message += '<td>';

    message += 'Please contact ';
    message += '<a href="mailto:support@touchpoint.co.nz?subject=';
    message += 'Data Selection Error: ' + this.errorMessage;
    message += ' Scope: ' + escape(document.getElementsByName("__event_scope_key")[0].value);
    message += '">support@touchpoint.co.nz</a>.';
    message += ' Thanks!';
    message += '</td>';
    message += '</tr>';
    message += '</table>';
    message += '</td></tr></table>';
    message += '</td></tr></table>';

    var errorMessage = document.createElement('span');
    errorMessage.innerHTML = message;

    _eMessage = document.createElement("div");
    _eMessage.style.textAlign = "center";

    _eMessage.appendChild(errorMessage);

    return _eMessage;

}

SelectionResponse.prototype.setData = function (element) {

    var data = new Array();
    var row = null;
    var item = null;

    for (var i = 0; i < element.childElements.length; i++) {

        row = {};
        item = element.childElements[i];

        row['_id'] = this.getMapValue(item, 'id');
        //row.push(this.getMapValue(item, 'id'));

        for (var j = 0; j < this.fieldIDs.length; j++) {
            row[this.fieldIDs[j]] = this.getMapValue(item, this.fieldIDs[j]);
            //row.push(this.getMapValue(item, this.fieldIDs[j]));
        }
        data.push(row);

    }

    this.data = data;

}

function ComponentTreeSelectionResponse(params) {
    this.tree = null;
    SelectionResponse.call(this, params)
}

ComponentTreeSelectionResponse.prototype = new SelectionResponse;

ComponentTreeSelectionResponse.prototype.initialise = function (element) {

    for (var i = 0; i < element.childElements.length; i++) {

        if (element.childElements[i].name == 'tree') {
            this.setTree(element.childElements[i]);
        } else if (element.childElements[i].name == 'error-message') {
            this.errorMessage = element.childElements[i].text;
        }

    }

}

ComponentTreeSelectionResponse.prototype.setTree = function (element) {
    this.tree = element;
}

