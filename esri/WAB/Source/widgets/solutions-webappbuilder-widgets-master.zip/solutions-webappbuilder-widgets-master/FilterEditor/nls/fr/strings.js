﻿define(
   ({
    _widgetLabel: "Mise à jour",
    title: "Sélectionnez un modèle pour créer des entités",
    pressStr: "Appuyez sur ",
    ctrlStr: " CTRL ",
    snapStr: " pour activer la capture"
  })
);