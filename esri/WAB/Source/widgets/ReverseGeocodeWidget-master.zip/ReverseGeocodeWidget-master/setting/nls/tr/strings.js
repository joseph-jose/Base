﻿define({
    unit: "ı_Unit_İ",
    style: "ı_Style_İ"
});