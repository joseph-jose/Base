jQuery.fn.table2csv = function() {
    var table = this.get(0);
    var tr = table.getElementsByTagName('tr'), i, j, xoff, text, cells, td, array = [], lenr = tr.length, lenc;
    for(i=0; i<lenr; i++) {
        //this row could be initialized by colspan setting in the previous row.
        if(array[i] == null) array[i] = [];
        cells = tr.item(i).cells;
        lenc = cells.length;
        for(j=0; j<lenc; j++) {
            td = cells.item(j);
            //remove tag, replace tab with space, trim both side, wrap double-quote
            //text = td.innerHTML.replace(/<.*?>/mg, '').replace(/\t/g,' ').replace(/(^\s+)|(\s+$)/g, '').replace(/\"/, '""');
            //[TP custom]
            text = retrieveTextFromCell(td);
            //if cell is already used by rowspan setting in the previous row, skip cells by the amount of xoff.
            xoff = 0;
            while(array[i][j+xoff] != null) {
                xoff++;
            }
            array[i][j+xoff] = text;
            for(k=1; k<td.colSpan; k++) {
                //array[i][j+xoff+k] = text; //give same value for rowspan
                array[i][j+xoff+k] = ''; //[TP custom] set empty string for rowspan
            }
            for(l=1; l<td.rowSpan; l++) {
                if(array[i+l] == null) array[i+l] = [];
                for(k=0; k<td.colSpan; k++) {
                    //array[i+l][j+xoff+k] = text; //give same value for colspan
                    array[i+l][j+xoff+k] = '';  //[TP custom] set empty string for colspan
                }
            }
        }
    }
    return convertArray2CSV(array);

    function convertArray2CSV(array) {
        var lenr = array.length,
            lenc = array[0].length,
            csv  = '', csvRow, k, l;
        for(k=0; k<lenr; k++) {
            csvRow = '';
            for(l=0; l<lenc; l++) {
                //csvRow += '\t"'+array[k][l]+'"'; //delimiter is tab, wrapped by double-quote
                csvRow += ',"'+array[k][l]+'"'; //[TP custom] delimiter is comma
            }
            if(csvRow != '') {
                csvRow = csvRow.substring(1,csvRow.length);
            }
            //csv += csvRow+'\n';
            csv += csvRow+'\r\n'; //[TP custom]
        }
        return csv;
    }

    //[TP custom]
    function retrieveTextFromCell(td) {
        //remove hidden item from cell
        var $tdClone = jQuery(td).clone();
        $tdClone.find('div:hidden').each(function(){
            jQuery(this).remove();
        });

        var text = $tdClone.html();

        //remove tag, replace tab with space, trim both side, wrap double-quote
        text = text.replace(/<.*?>/mg, '').replace(/\t/g,' ').replace(/(^\s+)|(\s+$)/g, '').replace(/\"/, '""');
        //remove &nbsp;
        text = text.replace(/&nbsp;/gi,'');

        return text;
    }
};
