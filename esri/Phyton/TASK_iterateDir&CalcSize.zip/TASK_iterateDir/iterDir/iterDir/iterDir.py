import os

top_folder = r"C:\Joseph\Task\TASKAnita_Reliability"


def calcFolderSize(inFolderPath):
    folSize = 0

    for path, dirs, files in os.walk(inFolderPath):
        for f in files:
            fl_path =  os.path.join(path, f)
            folSize += os.path.getsize(fl_path)
            #print (fl_path)

    print(" %s  = %0.1f MB" % (inFolderPath, folSize/(1024*1024)))

calcFolderSize(top_folder)
for path, dirs, files in os.walk(top_folder):
    for d in dirs:
#        if not d.endswith(".gdb"):
#            continue
        gdb_path = os.path.join(path, d)
        calcFolderSize(gdb_path)
#        print (gdb_path)
#        for f in files:
#            fl_path =  os.path.join(path, d, f)
#            print (fl_path)

