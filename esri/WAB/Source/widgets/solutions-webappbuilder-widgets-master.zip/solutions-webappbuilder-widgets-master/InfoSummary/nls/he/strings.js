﻿define(
   ({
    title: "הווידג\'ט \'תקציר מידע\'",
    helpText: "טקסט עזרה של \'תקציר מידע\'",
    labels: {
      status: "סטטוס",
      result: "תוצאה"
    },
    _widgetLabel: "סיכום מידע (בטא)"
  })
);