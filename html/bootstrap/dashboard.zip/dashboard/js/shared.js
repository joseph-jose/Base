// load this function for all websites to enable uniserval functions.
$( document).ready(function() {
	$.ajaxSetup({ cache: false });
	// header and footer load
  	$("#nav").load("/GISWebPage/shared/_nav.html",function(){
  		//sever detection method. Because the <nav> is asynchronous, the server logic needs to run inside the .load 
  		// 		method of the #nav to detect the elements in the header
  		// hostname detection logic starts
		url = window.location.host
		// if DEV
		if(url.indexOf("wsldctdgweb")>= 0){
			// show yellow <hr> devy devy
			$('hr').css("border-top","4px solid #e99a2f");
			// change GIS Portal link to DEV
			$('.portallink').addClass( "wsl-dev" ).attr('href','https://wsldctdgweb/GISPortal/Index.aspx');
		// if TEST
		}else if(url.indexOf("wsldcttgweb")>= 0){
			// show green <hr> HULK SMASH
			$("hr").css("border-top","4px solid #70a144");
			// change GIS Portal link to Test
			$('.portallink').addClass( "wsl-test" ).attr('href','https://wsldcttgweb/GISPortal/Index.aspx');
		// if PROD
		}else if(url.indexOf("wsldctpgweb")>= 0){
			// do jack all....
		}
  	});

  	console.log(window.location.port);

  	$("#footer").load("/GISWebPage/shared/_footer.html"); 
    // enable bootstrap tooltips
	$("body").tooltip({ selector: '[data-toggle=tooltip]' });

});

