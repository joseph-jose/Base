﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class PhotoGallery : System.Web.UI.Page
{
    public string connectString = "Data Source=nsmagallery.db.8879692.hostedresource.com; Initial Catalog=nsmagallery; User ID=nsmagallery; Password=Bobenantony07";
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string albumid = Request.QueryString["AlbumID"];
            hfAlbumID.Value = albumid;
            string query = "SELECT DefaultPhotoID, AlbumName,photo FROM [Album] INNER JOIN PhotoAlbum ON [Album].[DefaultPhotoID] = PhotoAlbum.PhotoID WHERE Album.[AlbumID] =" + hfAlbumID.Value;
            GetAlbumDetails(query);
        }
    }
    public void GetAlbumDetails(string query)
    {
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        SqlConnection con = new SqlConnection(connectString);
        con.Open();
        SqlCommand com = new SqlCommand(query, con);
        SqlDataReader dr = com.ExecuteReader();
        while (dr.Read())
        {
            lblAlbumName.Text = dr["AlbumName"].ToString();
            imAlbumPhoto.ImageUrl = "ThumbNail.ashx?ImURL=" + dr["photo"].ToString();
        }
    }
    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        lblNoofPicz.Text = e.AffectedRows.ToString();
    }
    protected void lbUploadPhotos_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Items.Add("AlbumID", hfAlbumID.Value);
        Server.Transfer("ImageUpload.aspx");
    }
}
