﻿namespace WCToolsHansen.BL.Forms
{
    partial class frmCopyMeterInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCompKey = new System.Windows.Forms.TextBox();
            this.btnGetDet = new System.Windows.Forms.Button();
            this.txtUnitId = new System.Windows.Forms.TextBox();
            this.pnlMsg = new System.Windows.Forms.Panel();
            this.lblMsg = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grpBx = new System.Windows.Forms.GroupBox();
            this.grpBxUnitId = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.grpBxUnitType = new System.Windows.Forms.GroupBox();
            this.chkUnitType = new System.Windows.Forms.CheckBox();
            this.chkUnitId = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUnitTypeX = new System.Windows.Forms.TextBox();
            this.txtUnitIdX = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUnitType = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnConfrm = new System.Windows.Forms.Button();
            this.pnlMsg.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grpBx.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCompKey
            // 
            this.txtCompKey.Location = new System.Drawing.Point(94, 20);
            this.txtCompKey.Name = "txtCompKey";
            this.txtCompKey.ReadOnly = true;
            this.txtCompKey.Size = new System.Drawing.Size(142, 20);
            this.txtCompKey.TabIndex = 0;
            // 
            // btnGetDet
            // 
            this.btnGetDet.Location = new System.Drawing.Point(245, 18);
            this.btnGetDet.Name = "btnGetDet";
            this.btnGetDet.Size = new System.Drawing.Size(75, 23);
            this.btnGetDet.TabIndex = 1;
            this.btnGetDet.Text = "Get details";
            this.btnGetDet.UseVisualStyleBackColor = true;
            this.btnGetDet.Click += new System.EventHandler(this.btnGetDet_Click);
            // 
            // txtUnitId
            // 
            this.txtUnitId.Location = new System.Drawing.Point(279, 42);
            this.txtUnitId.Name = "txtUnitId";
            this.txtUnitId.ReadOnly = true;
            this.txtUnitId.Size = new System.Drawing.Size(142, 20);
            this.txtUnitId.TabIndex = 2;
            // 
            // pnlMsg
            // 
            this.pnlMsg.Controls.Add(this.lblMsg);
            this.pnlMsg.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlMsg.Location = new System.Drawing.Point(0, 194);
            this.pnlMsg.Name = "pnlMsg";
            this.pnlMsg.Size = new System.Drawing.Size(512, 53);
            this.pnlMsg.TabIndex = 20;
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMsg.ForeColor = System.Drawing.Color.Black;
            this.lblMsg.Location = new System.Drawing.Point(22, 24);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(0, 18);
            this.lblMsg.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "CompKey";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Unit Id";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(514, 55);
            this.panel1.TabIndex = 24;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 371);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(514, 22);
            this.statusStrip1.TabIndex = 25;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.grpBx);
            this.panel2.Controls.Add(this.txtCompKey);
            this.panel2.Controls.Add(this.btnGetDet);
            this.panel2.Controls.Add(this.pnlMsg);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(514, 249);
            this.panel2.TabIndex = 26;
            // 
            // grpBx
            // 
            this.grpBx.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.grpBx.Controls.Add(this.grpBxUnitId);
            this.grpBx.Controls.Add(this.label6);
            this.grpBx.Controls.Add(this.grpBxUnitType);
            this.grpBx.Controls.Add(this.chkUnitType);
            this.grpBx.Controls.Add(this.chkUnitId);
            this.grpBx.Controls.Add(this.label4);
            this.grpBx.Controls.Add(this.label5);
            this.grpBx.Controls.Add(this.txtUnitTypeX);
            this.grpBx.Controls.Add(this.txtUnitIdX);
            this.grpBx.Controls.Add(this.label3);
            this.grpBx.Controls.Add(this.txtUnitType);
            this.grpBx.Controls.Add(this.txtUnitId);
            this.grpBx.Controls.Add(this.label2);
            this.grpBx.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.grpBx.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.grpBx.Location = new System.Drawing.Point(0, 67);
            this.grpBx.Name = "grpBx";
            this.grpBx.Size = new System.Drawing.Size(512, 127);
            this.grpBx.TabIndex = 24;
            this.grpBx.TabStop = false;
            // 
            // grpBxUnitId
            // 
            this.grpBxUnitId.Location = new System.Drawing.Point(245, 35);
            this.grpBxUnitId.Name = "grpBxUnitId";
            this.grpBxUnitId.Size = new System.Drawing.Size(28, 23);
            this.grpBxUnitId.TabIndex = 35;
            this.grpBxUnitId.TabStop = false;
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(420, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 23);
            this.label6.TabIndex = 34;
            this.label6.Text = "Update";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // grpBxUnitType
            // 
            this.grpBxUnitType.Location = new System.Drawing.Point(245, 74);
            this.grpBxUnitType.Name = "grpBxUnitType";
            this.grpBxUnitType.Size = new System.Drawing.Size(28, 23);
            this.grpBxUnitType.TabIndex = 33;
            this.grpBxUnitType.TabStop = false;
            // 
            // chkUnitType
            // 
            this.chkUnitType.AutoSize = true;
            this.chkUnitType.Location = new System.Drawing.Point(448, 84);
            this.chkUnitType.Name = "chkUnitType";
            this.chkUnitType.Size = new System.Drawing.Size(15, 14);
            this.chkUnitType.TabIndex = 31;
            this.chkUnitType.UseVisualStyleBackColor = true;
            // 
            // chkUnitId
            // 
            this.chkUnitId.AutoSize = true;
            this.chkUnitId.Location = new System.Drawing.Point(449, 48);
            this.chkUnitId.Name = "chkUnitId";
            this.chkUnitId.Size = new System.Drawing.Size(15, 14);
            this.chkUnitId.TabIndex = 30;
            this.chkUnitId.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(277, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 23);
            this.label4.TabIndex = 29;
            this.label4.Text = "Hansen";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(96, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 23);
            this.label5.TabIndex = 28;
            this.label5.Text = "GIS";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtUnitTypeX
            // 
            this.txtUnitTypeX.Location = new System.Drawing.Point(97, 78);
            this.txtUnitTypeX.Name = "txtUnitTypeX";
            this.txtUnitTypeX.Size = new System.Drawing.Size(142, 20);
            this.txtUnitTypeX.TabIndex = 27;
            // 
            // txtUnitIdX
            // 
            this.txtUnitIdX.Location = new System.Drawing.Point(97, 42);
            this.txtUnitIdX.Name = "txtUnitIdX";
            this.txtUnitIdX.Size = new System.Drawing.Size(142, 20);
            this.txtUnitIdX.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Unit Type";
            // 
            // txtUnitType
            // 
            this.txtUnitType.Location = new System.Drawing.Point(279, 78);
            this.txtUnitType.Name = "txtUnitType";
            this.txtUnitType.ReadOnly = true;
            this.txtUnitType.Size = new System.Drawing.Size(142, 20);
            this.txtUnitType.TabIndex = 24;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnClose);
            this.panel3.Controls.Add(this.btnConfrm);
            this.panel3.Location = new System.Drawing.Point(3, 318);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(511, 50);
            this.panel3.TabIndex = 27;
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(423, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Cancel";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // btnConfrm
            // 
            this.btnConfrm.Location = new System.Drawing.Point(338, 12);
            this.btnConfrm.Name = "btnConfrm";
            this.btnConfrm.Size = new System.Drawing.Size(75, 23);
            this.btnConfrm.TabIndex = 0;
            this.btnConfrm.Text = "Confirm";
            this.btnConfrm.UseVisualStyleBackColor = true;
            this.btnConfrm.Visible = false;
            this.btnConfrm.Click += new System.EventHandler(this.btnConfrm_Click);
            // 
            // frmCopyMeterInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 393);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Name = "frmCopyMeterInfo";
            this.Text = "Extract Meter info";
            this.Load += new System.EventHandler(this.frmCopyMeterInfo_Load);
            this.pnlMsg.ResumeLayout(false);
            this.pnlMsg.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.grpBx.ResumeLayout(false);
            this.grpBx.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCompKey;
        private System.Windows.Forms.Button btnGetDet;
        private System.Windows.Forms.TextBox txtUnitId;
        private System.Windows.Forms.Panel pnlMsg;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnConfrm;
        private System.Windows.Forms.GroupBox grpBx;
        private System.Windows.Forms.GroupBox grpBxUnitType;
        private System.Windows.Forms.CheckBox chkUnitType;
        private System.Windows.Forms.CheckBox chkUnitId;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUnitTypeX;
        private System.Windows.Forms.TextBox txtUnitIdX;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUnitType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox grpBxUnitId;
    }
}