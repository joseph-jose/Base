﻿define({
    select: "ä_Select_Ü",
    results: "ä_Results_Ü",
    selectLayer: "ä_Select from layer:_Ü",
    selectDrawtool: "ä_Select draw tool:_Ü",
    result: "ä_Result:_Ü",
    noresult: "ä_No query results to display chart._Ü",
    nomedia: "ä_There's no media in configuration!_Ü",
    envelop: "ä_Draw Rectangle_Ü",
    circle: "ä_Draw Circle_Ü",
    ellipse: "ä_Draw Ellipse_Ü",
    polygon: "ä_Draw Polygon_Ü",
    freehand: "ä_Draw Freehand Polygon_Ü",
    clear:"ä_Clear_Ü"
});