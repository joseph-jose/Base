﻿define({
    unit: "Į_Unit_š",
    style: "Į_Style_š"
});