﻿define({
    left: "SINISTRA",
    right: "DESTRA",
    arrangement: "Disposizione",
    autoUpdate: "Aggiornamento automatico",
    respectCurrentMapScale: "Rispetta scala mappa corrente"
});