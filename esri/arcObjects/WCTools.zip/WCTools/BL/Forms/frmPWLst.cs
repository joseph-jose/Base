﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCTools.BL.Classes;
using WCTools.BL.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmPWLst : Form
    {
        string __VFrmMode = "";
        string __VPWConnStr = "";
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }
        //private IFeature __SelFeat;

        private string __LogSessId = "";
        public string __LogSessionId { set { __LogSessId = value; } }

        WCTools.BL.Classes.cDbSqlFile __DbFile;
        WCTools.BL.Classes.cUtilFile __UtilFile;
        WCTools.BL.Classes.cUtilGIS __GISUtil;

        public frmPWLst()
        {
            InitializeComponent();
        }


        ~frmPWLst()
        {
            helpersDeActivate();
        }

        public string getPWConnString()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "PW_Connection_RepDb");
            vConnStr = __UtilFile.ConnStrRectPssWrd(vConnStr);
            return vConnStr;
        }

        public bool helpersActivate()
        {
            bool vBRes = true; 
            __DbFile = new cDbSqlFile();
            __UtilFile = new cUtilFile();
            __GISUtil = new cUtilGIS();
            __GISUtil.vAppMap = __App;

            //20170510 Non GISEditor intimation
            //connDB();
            try
            {
                connDB();
            }
            catch (Exception e)
            {
                MessageBox.Show("Access to database couldn't be obtained");
                vBRes = false;
                return vBRes;
            }
            //20170510 Non GISEditor intimation
            logNtry("WCTools", "PWLink", "Start", __LogSessId, "TRC");
            return vBRes;
        }

        public void helpersDeActivate()
        {
            logNtry("WCTools", "PWLink", "End", __LogSessId, "TRC");
            //if (!(__SelFeature == null))
            //{
            //    Marshal.ReleaseComObject(__SelFeature);
            //}
            __DbFile.CleanUpDBConnection();
            __DbFile.Dispose();
            __DbFile = null;
            __GISUtil.Dispose();
            __GISUtil = null;
        }

        public bool validateOnLoad(out string outLnkId)
        {
            bool vResFn = false;
            outLnkId = "";
            //if (!(__GISUtil.getFeatureSelectCount() == 1))
            //{
            //    MessageBox.Show("Select single feature");
            //    return vResFn;
            //}
            //IFeature vFeat;
            //IEnumFeature vEnmFeat = __GISUtil.getSelectedFeatures();
            //vEnmFeat.Reset();
            //vFeat = vEnmFeat.Next();
            //IWorkspaceEdit vWrkSpcEdit = __GISUtil.getWrkSpcFFeature(vFeat);
            //if (!(vWrkSpcEdit.IsBeingEdited()))
            //{
            //    MessageBox.Show("Feature not in edit mode");
            //    return vResFn;
            //}

            //object vObjVal;
            //int vFldIdx;
            //vFldIdx = __GISUtil.getFieldIdx(vFeat, "DMS_LINK");
            //if (!(vFldIdx == -1))
            //{
            //    vObjVal = __GISUtil.getFieldValue(vFeat, "DMS_LINK");
            //    if (vObjVal is System.DBNull)
            //        outLnkId = "";
            //    else
            //        outLnkId = vObjVal.ToString();
            //}
            //else
            //{
            //    MessageBox.Show("Attribute DMS_LINK missing for feature");
            //    return vResFn;
            //}

            ////if (!(valSelFeatures()))
            ////{
            ////    return vResFn ;
            ////}



            __VPWConnStr = getPWConnString();

            vResFn = true;
            return vResFn;
        }


        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            if (!(__UtilFile.logNtry(__DbFile, inCmdType, inMsg, inFld1, inSessId, inLogType)))
            {
                MessageBox.Show("GPF-> Logging failed"); 
            }
        }


        private void refGrd(DataTable vDtTbl)
        {
            string vFldVal = "", vPhLnk = "", vFlType = "";
            foreach (DataRow dr in vDtTbl.Rows)
            {
                dtGrdVwItms.Rows.Add();
                vFldVal = dr["PW_ID"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[0].Value = vFldVal;
                vFldVal = dr["PW_REF"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[1].Value = vFldVal;
                vPhLnk = vFldVal;
                vFldVal = dr["PL_TYPE"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[2].Value = vFldVal;
                vFlType = vFldVal;
                vFldVal = dr["DOC_NO"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[3].Value = vFldVal;
                vFldVal = dr["DOC_TYPE"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[4].Value = vFldVal;

                vFldVal = "";
                vFldVal = dr["COMMENTS"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[5].Value = vFldVal;
                //chgBit
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[6].Value = "N";

                //Column 9 holds the state of the record
                //N= No Change, A=Added, E=Edit
            }
        }

        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }


        private bool ValidateControls()
        {
            bool bretRes = false;

            if (dtGrdVwItms.RowCount == 0)
            {
                MessageBox.Show("No ProjectWise details entered");
                return bretRes;
            }

            //20150110
            if (tbCtrlMod.SelectedIndex == 1)
            {
                if (txtPhLnk.Text.Trim() == "")
                {
                    MessageBox.Show("Enter PH Link# ");
                    txtPhLnk.Focus();
                    return bretRes;
                }
            }
            //20150110

            bretRes = true;
            return bretRes;
        }

        private string getSqlStmnt(string inPWLnk, DataGridViewRow indtGrdRow)
        {
            string vretRes = "", vtmpStr;


            //PH_ID
            string vPhIdStr ; //= indtGrdRow.Cells[0].Value.ToString();
            //PL_TYPE
            string vPlTypeStr = indtGrdRow.Cells[2].Value.ToString();
            //DOC_NO
            string vDocNoStr = indtGrdRow.Cells[3].Value.ToString();
            //DOC Type
            string vDOCTypeStr = indtGrdRow.Cells[4].Value.ToString();
            //COMMENTS
            string vComments = indtGrdRow.Cells[5].Value.ToString();
            if (vComments == "")
            {
                vComments = "";
            }
            
            //Changed Bit
            vtmpStr = indtGrdRow.Cells[6].Value.ToString();
            if (vtmpStr.Trim() == "A")
            {
                vretRes = "Insert into GISWSL.WA_PWLINK (PW_REF, PL_TYPE, DOC_NO, DOC_TYPE, MODIFYBY, MODIFYDATE, COMMENTS) " +
                    " values ('{0}', '{1}', '{2}', '{3}', '{4}', {5}, '{6}')";
                vretRes = string.Format(vretRes, inPWLnk, vPlTypeStr, vDocNoStr, vDOCTypeStr, Environment.UserName, "getdate()", vComments);
            } 
            else if (vtmpStr.Trim() == "E")
            {
                //PH_ID
                vPhIdStr = indtGrdRow.Cells[0].Value.ToString();
                vretRes = "Update GISWSL.WA_PWLINK set PW_REF = '{0}', PL_TYPE = '{1}', DOC_NO = '{2}', DOC_TYPE = '{3}', MODIFYBY = '{4}', MODIFYDATE = {5}, COMMENTS = '{6}' " +
                    " where (PW_ID = '{7}')";
                vretRes = string.Format(vretRes, inPWLnk, vPlTypeStr, vDocNoStr, vDOCTypeStr, Environment.UserName, "getdate()", vComments, vPhIdStr);                
            }


            return vretRes;
        }
        //to be removed 
        //for Assign PWLink
        //validate features
        private bool valFldNullFSelFeatures(IFeatureClass inFeatCls, IFeatureSelection inFeatSel)
        {
            bool vRetRes = true;

            IFeature vFeat = null;
            IEnumIDs vEnmIds = inFeatSel.SelectionSet.IDs ;
            object vFldVal = null;
            int vFId = 0;
            vFId = vEnmIds.Next(); 
            while (!(vFId == -1))
            {
                vFeat = inFeatCls.GetFeature(vFId); 
                vFldVal = __GISUtil.getFieldValue(vFeat, "DMS_LINK"); 
                if (!(vFldVal is System.DBNull ))
                {
                    vRetRes = false;
                    break;
                }
            }
            return vRetRes;
        }
        private bool valSelFeatures()
        {
            bool vRetRes = true;
            IEnumLayer vEnmLyrs = __GISUtil.getLyrsInTOC();

            ILayer vLyr ;
            IFeatureLayer vFeatLyr;
            IFeatureSelection vFeatSel;
            IWorkspaceEdit vWrkSpcEdt;
            int vFldIdx = 0;

            vLyr = vEnmLyrs.Next();
            while (!(vLyr == null))
            {
                if (!(vLyr is IGroupLayer))
                {
                    vFeatLyr = vLyr as IFeatureLayer;

                    vFeatSel = vFeatLyr as IFeatureSelection;
                    if (vFeatSel.SelectionSet.Count > 0)
                    {
                        vWrkSpcEdt = __GISUtil.getWrkSpcFLayer(vFeatLyr);
                        if (!(vWrkSpcEdt.IsBeingEdited()))
                        {
                            MessageBox.Show("Layer not in Edit mode :-" + vFeatLyr.Name.ToString());
                            vRetRes = false;
                            break;
                        }
                        vFldIdx = __GISUtil.getFieldIdx(vFeatLyr, "DMS_LINK");
                        if (vFldIdx == -1)
                        {
                            MessageBox.Show("Layer does not have field DMS_LINK :-" + vFeatLyr.Name.ToString());
                            vRetRes = false;
                            break;
                        }

                        if (!(valFldNullFSelFeatures(vFeatLyr.FeatureClass, vFeatSel )))
                        {
                            MessageBox.Show("Layer has DMS_LINK already assigned for one of the features selected :-" + vFeatLyr.Name.ToString());
                            vRetRes = false;
                            break;
                        }
                    }
                }
                vLyr = vEnmLyrs.Next();
            }
            return vRetRes;    
    //Dim vFLyr As IFeatureLayer
    //Dim vLyr As IFeatureLayer
    //Dim vSrcFSel As IFeatureSelection
    //Dim vWrkSpcEdt As IWorkspaceEdit
    
    //Dim vFeatCls As IFeatureClass
    //Dim vFeatDtSt As IDataset
    //Dim vWrkSpc As IWorkspace
    //Dim vTbl As ITable
    //For i = 0 To vDoc.FocusMap.LayerCount - 1
    //    Set vLyr = vDoc.FocusMap.Layer(i)
        
    //    Set vFeatCls = vLyr.FeatureClass
    //    Set vFeatDtSt = vFeatCls
    //    Set vWrkSpcEdt = vFeatDtSt.Workspace
        
    //    If vWrkSpcEdt.IsBeingEdited Then
    //        Set vSrcFSel = vLyr
    //        MsgBox vLyr.Name & ":" & vSrcFSel.SelectionSet.Count
    //    End If
        
    //Next
        }
        //validate features end
        //to be removed 
        //for Assign PWLink

        private void btnCnfrm_Click(object sender, EventArgs e)
        {
            int vSeqNo = 0;
            string vPHType = "";
            if (!(ValidateControls()))
                return;

            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (__VFrmMode == "N")
                {
                    //vSeqNo = getNewSeq("Data Source=wsldctgdw;Initial Catalog=GISAdmin;Integrated Security=True", "GISWSL.NextVal");
                    if (!(__DbFile.Connected))
                    {
                        connDB();
                    }
                    vSeqNo = __DbFile.getNewSeq("GISWSL.NextVal", "GISWSL.WA_PWLINK_SEQ");
                    txtPhLnk.Text = "PW" + vSeqNo.ToString();
                }
                
                foreach (DataGridViewRow dvRow in dtGrdVwItms.Rows)
                {
                    if (!(dvRow.Cells[6].Value.ToString() == "N"))
                    {
                        vPHType = getSqlStmnt(txtPhLnk.Text, dvRow);
                        __DbFile.execQry(vPHType);
                        //log
                        vPHType = dvRow.Cells[3].Value.ToString();
                        logNtry("WCTools", "PWLink", vPHType, __LogSessId, "TRC");
                        //MessageBox.Show(vPHType);
                    }
                }

                //if (__VFrmMode == "N")
                //{
                //    IWorkspaceEdit vWrkSpcEdt = __GISUtil.getWrkSpcFFeature(__SelFeat);
                //    vWrkSpcEdt.StartEditOperation();
                //    __GISUtil.setFieldValue(__SelFeat, "DMS_LINK", txtPhLnk.Text);
                //    vWrkSpcEdt.StopEditOperation();
                //    logNtry("WCTools", "PWLink", txtPhLnk.Text, __LogSessId, "TRC");
                //}
                logNtry("WCTools", "PWLink", txtPhLnk.Text, __LogSessId, "TRC");

                prepFrmInEdtMode(txtPhLnk.Text);

                btnCnfrm.Enabled = false;
                btnAdd.Enabled = false;
                btnEdt.Enabled = false;
                tbCtrlMod.Enabled = false;
                btnVw.Enabled = false; 
            }
            catch (Exception ex)
            {
                logNtry("WCTools", "exception" + ex.Message.ToString(), txtPhLnk.Text, __LogSessId, "TRCE");
                MessageBox.Show("GPF->  " + ex.Message.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void clrFrm()
        {
            prepFrmInNewMode();

            txtPhLnk.Enabled = true;
            btnCnfrm.Enabled = true;
            btnAdd.Enabled = true;
            btnEdt.Enabled = true;
            tbCtrlMod.Enabled = true;
            btnVw.Enabled = true;

            tbCtrlMod.SelectedIndex = 0;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //20150110
            if (tbCtrlMod.SelectedIndex == 1)
            {
                if (!(__VFrmMode == "E"))
                {
                    MessageBox.Show("Enter PW Ref#");
                    txtPhLnk.Focus();
                    return;
                }
            }
            //20150110

            string vConnStr = __UtilFile.getCfgFilePth();
            using (frmPWDet vFrmPWDet = new frmPWDet())
            {
                string vPwType = "", vDocNo = "", vComm = "", vDocType = "";
                vFrmPWDet.__PWConnStr = __VPWConnStr;
                if (vFrmPWDet.setNewMode(ref vPwType, ref vDocNo, ref vDocType, ref vComm) == DialogResult.OK)
                {
                    dtGrdVwItms.Rows.Add();
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[2].Value = vPwType;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[3].Value = vDocNo;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[4].Value = vDocType;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[5].Value = vComm;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[6].Value = "A";
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Selected = true;
                }
            }
            //dtGrdVwItms.NewRowIndex = dtGrdVwItms.RowCount - 1; 
        }

        private void btnEdt_Click(object sender, EventArgs e)
        {
              

            if (dtGrdVwItms.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select row to edit");
                return;
            }
            string vPwType = "", vDocNo = "", vComm = "", vDocType = "";
            using (frmPWDet vFrmPWDet = new frmPWDet())
            {
                vFrmPWDet.__PWConnStr = __VPWConnStr;
                //vFrmPhDet.setPhotoPath(__UtilFile.ConfigRead(vConnStr, "PhotoPath"));
                //vFrmPhDet.setAllowedExtensions(__UtilFile.ConfigRead(vConnStr, "PhotoXtnsns"));
                vPwType = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[2].Value.ToString();
                vDocNo = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[3].Value.ToString();
                vDocType = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[4].Value.ToString();
                vComm = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value.ToString();

                if (vFrmPWDet.setEdtMode(ref vPwType, ref vDocNo, ref vDocType, ref vComm) == DialogResult.OK)
                {
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[2].Value = vPwType;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[3].Value = vDocNo;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[4].Value = vDocType;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value = vComm;


                    if (!(dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[6].Value.ToString().Trim() == "A"))
                        dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[6].Value = "E";
                }
            }
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            if (txtPhLnk.Text.Trim().ToString() == "")
            {
                MessageBox.Show("Valid PW# required");
                return;
            }

            string vPhNo = __UtilFile.ConfigRead(__UtilFile.getCfgFilePth(), "PWLinkVwUrl");
            vPhNo = string.Format(vPhNo, txtPhLnk.Text);
            Process.Start(vPhNo);

        }

        private void BtnCls_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbCtrlMod_SelectedIndexChanged(object sender, EventArgs e)
        {
            prepFrmInNewMode();
            txtPhLnk.Text = "";
            txtPhLnk.ReadOnly = (tbCtrlMod.SelectedIndex == 0);
            btnVw.Visible = (tbCtrlMod.SelectedIndex == 1);
        }

        private void btnVw_Click(object sender, EventArgs e)
        {
            if (prepFrmInEdtMode(txtPhLnk.Text))
            {
                txtPhLnk.ReadOnly = true;
            }
            else
            {
                MessageBox.Show("Project wise link number not found");
            }
        }



        public void prepFrmInNewMode()
        {
            __VFrmMode = "N";
            //txtPhLnk.Enabled = false;
            dtGrdVwItms.Rows.Clear();
            //this.ShowDialog();
            txtPhLnk.Text = "";
            txtPhLnk.ReadOnly = true;
            btnVw.Visible = false;
        }


        public bool prepFrmInEdtMode(string inPHLnk)
        {
            bool retRes = false;

            if (!(__DbFile.Connected))
            {
                connDB();
            }
            string vSqlStr = "SELECT * FROM [GISWSL].[WA_PWLINK] WHERE PW_REF = '{0}' ORDER BY MODIFYDATE DESC";
            vSqlStr = string.Format(vSqlStr, inPHLnk);
            dtGrdVwItms.Rows.Clear();
            DataTable vDtTbl = __DbFile.getDtTblRecs(vSqlStr);

            if (vDtTbl.Rows.Count > 0)
            {
                retRes = true;
                refGrd(vDtTbl);
                txtPhLnk.Text = inPHLnk;
                //txtPhLnk.Enabled = false;
                __VFrmMode = "E";
                vDtTbl.Clear();
            }

            //this.ShowDialog();

            vDtTbl = null;

            return retRes;
        }

        public string prepFrmToCallFOther()
        {
            string vRetRes = "";
            prepFrmInNewMode();
            if (this.ShowDialog() == DialogResult.OK )
            {
                vRetRes = txtPhLnk.Text.ToString();
            }
            return vRetRes;
        }

        private void btnCncl_Click(object sender, EventArgs e)
        {
            clrFrm();
        }

    }
}
