﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCToolsBulk.BL.Forms.MultiPWLink
{
    public partial class frmSetMultiPWItemColl : Form
    {

        public frmSetMultiPWItemColl()
        {
            InitializeComponent();
        }

        private void frmSetMultiPWItemColl_Load(object sender, EventArgs e)
        {

        }

        private void btnTbPg1Nxt_Click(object sender, EventArgs e)
        {

        }

        public DialogResult setNewMode(ref string inOutOCompKey, ref string inOutNCompKey)
        {
            DialogResult vDlgRes = DialogResult.Cancel;
            txtOCompKey.Text = "";
            txtNewCKey.Text = "";

            if (this.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                inOutOCompKey = txtOCompKey.Text;
                inOutNCompKey = txtNewCKey.Text;
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        public DialogResult setEdtMode(ref string inOutOCompKey, ref string inOutNCompKey)
        {
            DialogResult vDlgRes = DialogResult.Cancel;
            txtOCompKey.Text = inOutOCompKey;
            txtNewCKey.Text = inOutNCompKey;

            if (this.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                inOutOCompKey = txtOCompKey.Text;
                inOutNCompKey = txtNewCKey.Text;
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            //if (txtOCompKey.Text == "")
            //{
            //    MessageBox.Show("Enter Old CompKey");
            //    return;
            //}
            if (txtNewCKey.Text == "")
            {
                MessageBox.Show("Enter New CompKey");
                return;
            }
            this.DialogResult = System.Windows.Forms.DialogResult.OK;

        }

        private void btnCncl_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
