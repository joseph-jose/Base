/* DEFINE CONSTANT VARIABLES*/
DIALOG_ALERT_WINDOW_SIZE = 0;

MEDIUM_VB_WINDOW_SIZE = 1;
LARGE_VB_WINDOW_SIZE = 2;
XLARGE_VB_WINDOW_SIZE = 3;

SMALL_WINDOW_SIZE = 4;
MEDIUM_WINDOW_SIZE = 5;
LARGE_WINDOW_SIZE = 6;

var default_window_sizes = [

    {'w':400, 'h':175},

    {'w':800, 'h':550},
    {'w':950, 'h':665},
    {'w':1200, 'h':800},

    {'w':400, 'h':385},
    {'w':650, 'h':550},
    {'w':800, 'h':665}    
];

var refreshList = [];
window.refresh = function () {

    if (refreshList.length == 0) {
        location.href = location.href;
    } else {
        for (var x = 0; x < refreshList.length; x++) {
            //need to do this due to a firefox bug as describe in
            //https://bugzilla.mozilla.org/show_bug.cgi?id=317600
            window.setTimeout('refreshList[' + x + '].refresh()', 0);
        }
    }
}
//for the inlineActionFrame
var inlinePostAction__ = "";

//for doing inline action such as save
function doInlineAction(actionID, noValidation) {

    var iFrameID = 'inlineactionframe__';

    if (document.getElementById(iFrameID) == null) {

        var inlineFrame = document.createElement('iframe');

        inlineFrame.name = iFrameID;
        inlineFrame.id = iFrameID;
        inlineFrame.style.display = 'none';
        inlineFrame.src = 'javascript:false;';

        document.body.appendChild(inlineFrame);

        /* *** This is a BUG FIX for Internet Explorer *** */
        if (self.frames[iFrameID].name != iFrameID) {
            self.frames[iFrameID].name = iFrameID;
        }

    }

    document.form.target = iFrameID;

    doAction(actionID, noValidation);

    return true;

}

//define a postaction after calling the inlineaction
function setInlinePostAction(action) {
    inlinePostAction__ = action;
}

//call by the update-inline-conent.jsp after performing the inline action
function updateInlineSaveAction(errorMessage, onCompleteMessage) {

    returnElement('_action_id').value = '';
    document.form.target = '';

    if (errorMessage.length > 0) {
        alert(errorMessage);
    } else if (inlinePostAction__.length > 0) {
        eval(inlinePostAction__);
    } else {
        if (onCompleteMessage && onCompleteMessage.length > 0) {
            alert(onCompleteMessage);
        } else {
            alert('Save Completed');
        }
    }

    inlinePostAction__ = "";

}

function selectComponentInWindow() {
    throw new Error("selectComponentInWindow is deprecated. Use openTPWindow.");
}


/* ALWAYS USE THE APPENDTOLOAD FUNCTION TO RUN SOME JS ON PAGE LOAD */
var onLoadEvents = new Array(0);
window.onload = function () {
    var log = "";
    for (var x = 0; x < onLoadEvents.length; x++) {
        //        try {
        log += "[" + (x + 1) + " of " + onLoadEvents.length + "] " + onLoadEvents[x] + "\n";
        eval(onLoadEvents[x]);
        //        } catch ( e ) {
        //			throw new Error("Touchpoint can not run load event '" + onLoadEvents[x] + "' because '" + e.description + "'");
        //        }
    }
    // run this to see what is happenin on page load
    // alert(log);
}

// Generic api for adding components to the screen. Same api as adding to a tab.
function registerDynamicComponent(event) {
    appendToLoad(event);
}

function appendToLoad(event) {
    onLoadEvents.push(event);
}

function openTPWindow(url, windowName, componentIDFieldName, componentIDParameterName, size, isRequired, target, allowScroll, allowResize) {

    var componentID = 0;

    if ((typeof size == "object") && size.size) {
        if (allowScroll == undefined || allowScroll == null) allowScroll = size.scrollbars;
        if (allowResize == undefined || allowResize == null) allowResize = size.resizable;
        size = size.size;
    }

    if (allowScroll == undefined || allowScroll == null) allowScroll = false;
    if (allowResize == undefined || allowResize == null) allowResize = false;

    if (componentIDFieldName && componentIDFieldName != 'null') {
        if (document.getElementById(componentIDFieldName)) {
            componentID = document.getElementById(componentIDFieldName).value;
        } else if (window.frames['contentFrame'] && window.frames['contentFrame'].document.getElementById(componentIDFieldName)) {
            componentID = window.frames['contentFrame'].document.getElementById(componentIDFieldName).value;
        }
    }

    if (isRequired && (! componentID || componentID == '0')) {

        return false;

    } else if (componentID) {

        var componentType = '';

        // if itemIdMask is reference but double click columnlist will open modify component screen that need id as parameter
        if (componentID.indexOf(":") > 0 && ((! componentIDParameterName) || (componentIDParameterName == "id") )) {
            componentType = componentID.substring(0, componentID.indexOf(":"));
            componentID = componentID.substring(componentID.indexOf(":") + 1);
        }

        if (windowName.lastIndexOf('_') == windowName.length - 1) {
            windowName += componentID;
        }

        if (url.indexOf('?') != -1) {
            url += "&";
        } else {
            url += "?";
        }

        url += componentIDParameterName ? componentIDParameterName : "id";
        url += "=" + componentID;

        if (componentType) {
            url = url.replace(/componenttype=[0-9]*&*/gi, "");
            url += '&componenttype=' + componentType;
        }

    }

    if (target) {

        // for forwarding an action
        if (target == '_self_resize') {

            var w, h;

            if (typeof size == "object") {
                w = size.w;
                h = size.h;
            } else {
                w = default_window_sizes[size].w;
                h = default_window_sizes[size].h;
            }

            window.document.write("");
            window.document.close();
            window.location.href = url;
            window.resizeTo(w, h);

        } else if (target == '_self') {
            window.location.href = url;
        } else { // iframe
            if (window.frames[target]) {
                window.frames[target].location.href = url;
            } else {
                window.location.href = url;
            }
        }

    } else {
        var newWin = openComponentWindow(url, windowName, null, null, size, null, null, allowScroll, allowResize);
        if (newWin && newWin.focus) newWin.focus();
        return newWin;
    }

}


/* OPEN A WINDOW */
function openComponentWindow(url, windowName, componentKeyName, componentKey, size, refreshParentOnClose, isUniqueByComponent, allowScroll, allowResize) {

    var w, h;

    if (typeof size == "object") {
        w = size.w;
        h = size.h;
    } else {
        w = default_window_sizes[size].w;
        h = default_window_sizes[size].h;
    }

    var features = "width=" + w + ",height=" + h + ",scrollbars=" + (allowScroll ? 1 : 0) + ",resizable=" + (allowResize ? 1 : 0);

    if (componentKeyName) {

        windowName += "_" + componentKeyName;

        if (componentKey) {
            windowName += "_" + componentKey;
        }

    }

    windowName = windowName.replace(/[^\a-z0-9_]/gi, "_");
    return window.open(url, windowName, features);

}

/* CREATE AN AJAX OBJECT */
function Ajax(requestURL) {

    this.requestObject = false;
    this.requestURL = requestURL;
    this.statusAction = {};
    this.defaultError = null;
    this.statusMessage = { /*"200" : "200 Load complete.",
        "400" : "400 Bad request!",
        "403" : "403 URL forbidden!",
        "404" : "404 URL not found!",
        "500" : "500 Internal server error!"*/ };

}

/* CREATES THE ACTUAL AJAX REQUEST WHEN .GO() IS CALLED ON AN AJAX OBJECT */
Ajax.prototype.createNewRequestObject = function() {

    /*@cc_on @*/
    /*@if (@_jscript_version >= 5)
    // JScript gives us Conditional compilation, we can cope with old IE versions.
    // and security blocked creation of the objects.
    try {
        this.requestObject = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
        try {
            this.requestObject = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (E) {
            this.requestObject = false;
        }
    }
    @end @*/

    if (!this.requestObject && typeof XMLHttpRequest != 'undefined') {
        this.requestObject = new XMLHttpRequest();
    }

    if (this.requestObject.readyState == 1) {
        this.requestObject = new XMLHttpRequest();
    }

    var oAjax = this;
    this.requestObject.onreadystatechange = function () {
        if (oAjax.requestObject.readyState == 4) {

            var status = ""
            var exceptionMessage = "";
            try {
                status = oAjax.requestObject.status;
            } catch (ex) {
                status = "500";
                exceptionMessage = ex;
            }

            if (oAjax.statusAction[status] && (!oAjax.requestObject.responseText.endsWith("<!-- 502 -->") && !oAjax.requestObject.responseText.endsWith("<!-- 404 -->"))) {
                oAjax.statusAction[status](oAjax.requestObject.responseText);

            } else  if (oAjax.statusMessage[status]) {
                alert(oAjax.statusMessage[status] + " Message:" + exceptionMessage);

            } else if (oAjax.defaultError) {
                oAjax.defaultError(status);

            } else {
                alert("An error has occurred processing this request. Please check and try again. If the problem persists then please contact support.");

            }
        }
    }

}

String.prototype.endsWith = function(str) {
    return (this.indexOf(str) == (this.length - str.length));
}

/* UPDATES THE URL YOUR AJAX OBJECT WILL REQUEST */
Ajax.prototype.setRequestUrl = function (requestURL) {
    this.requestURL = requestURL;
}

/* CALLED WHEN YOU WANT TO PERFORM THE ACTUAL HTTP REQUEST */
Ajax.prototype.go = function (parameters) {

    // THE PARAMETERS VARIABLE MUST EITHER BE NULL OR AN INSTANCE OF REXML

    this.createNewRequestObject();

    if (!parameters) {
        this.requestObject.open("GET", this.requestURL, true);
        //TODO IE Won't run the window.refresh() function. Crashes here.
        this.requestObject.send(null);
    } else {
        this.requestObject.open("POST", this.requestURL, true);
        this.requestObject.setRequestHeader("Content-type", "text/xml");
        this.requestObject.setRequestHeader("Content-length", parameters.XML.length);
        this.requestObject.setRequestHeader("Connection", "close");
        this.requestObject.send(parameters.XML);
    }

}

/* PRELOADS AN IMAGE AND RETURNS THE IMAGE OBJECT */
function preloadImage(imagePath, width, height, extraParams) {
    var img = new Image(width, height);
    img.src = imagePath;
    if (extraParams) {
        for (attr in extraParams) {
            if (attr == "class" && isMSIEBrowser())
                img.setAttribute(attr + "Name", extraParams[attr]);
            else
                img.setAttribute(attr, extraParams[attr]);
        }
    }
    return img;
}

/* DISPLAY/HIDE A FLOATING LAYER POPUP */
top.visFloatingLayer = [null,null];
function toggleFloatingElement(layerId, clickSrcElement) {

    var floatingLayer = returnElement(layerId);
    var floatingLayerTargetState = null;

    var hidingFunction = function (e) {

        var srcElement;

        if (!e) {
            var e = window.event;
            if (!e) {
                e = window.contentFrame.event;
            }
        }

        if (e.target) {
            srcElement = e.target;
        } else if (e.srcElement) {
            srcElement = e.srcElement;
        }

        if (srcElement == top.visFloatingLayer[1]) return;
        if (srcElement.parentNode) while (srcElement.parentNode) {

            if (srcElement.parentNode.id == top.visFloatingLayer[0]) {
                return;
            }
            srcElement = srcElement.parentNode;

        }

        toggleElement(top.visFloatingLayer[0], false);
        top.visFloatingLayer[0] = null;

    }

    if (floatingLayer.style.display == "block") {

        top.onclick = null;
        for (var x = 0; x < top.frames.length; x++) top.frames[x].document.onclick = null;

        floatingLayerTargetState = false;
        top.visFloatingLayer[0] = null;
        top.visFloatingLayer[1] = null;

    } else {

        top.onclick = hidingFunction;

        for (var x = 0; x < top.frames.length; x++) top.frames[x].document.onclick = hidingFunction;

        floatingLayerTargetState = true;
        top.visFloatingLayer[0] = layerId;
        top.visFloatingLayer[1] = clickSrcElement;

    }

    toggleElement(layerId, floatingLayerTargetState);

}


/* TO SHOW/HIDE A TABLE ROW RELIABLY ACROSS FF & IE */
function toggleElement(elementId, action) {
    if (returnElement(elementId)) {
        if (returnElement(elementId).tagName == "TR") {
            try {
                returnElement(elementId).style.display = action ? 'table-row' : 'none';
            } catch (ex) {
                returnElement(elementId).style.display = action ? 'block' : 'none';
            }
        } else if (returnElement(elementId).tagName == "TD") {
            try {
                returnElement(elementId).style.display = action ? 'table-cell' : 'none';
            } catch (ex) {
                returnElement(elementId).style.display = action ? 'block' : 'none';
            }
        } else {
            returnElement(elementId).style.display = action ? 'block' : 'none';
        }
    }
}

/* USE QueryString.get('varName') TO RETRIEVE A VALUE FROM THE QUERY STRING */
var QueryString = {
    'get' : function(attr) {
        var tmp = [], a = location.search.substr(1, location.search.length).split("&");
        for (var i = 0; i < a.length; i++) {
            tmp = a[i].split("=");
            if (new RegExp(tmp[0], "i").test(escape(attr)) && tmp[1]) {
                return unescape(tmp[1]);
            }
        }
        return null;
    }
};

/* CREATES THE TABLE ROW HIGHLINGING WHEN MOUSING OVER */
function createDataHighlight(tbodyId) {
    var rows = returnElement(tbodyId).rows;
    for (var x = 0; x < rows.length; x++) {

        if (x % 2 != 0) {
            if (rows[x].className) rows[x].className += " odd-row";
            else rows[x].className = "odd-row";
        }

        rows[x].setAttribute("initialClass", rows[x].className);

        rows[x].onmouseover = function () {
            this.className = "over-row";
        }
        rows[x].onmouseout = function () {
            if (this.getAttribute('initialClass')) {
                this.className = this.getAttribute('initialClass');
            } else {
                this.className = "";
            }
        }
    }
}

/* THE DOLLAR FUNCTION IS A QUICK WAY TO RETURN ELEMENTS */
function returnElement() {

    var elements = new Array();

    for (var i = 0; i < arguments.length; i++) {

        var element = arguments[i];

        if (typeof element == 'string')
            element = document.getElementById(element);
        if (arguments.length == 1)
            return element;

        elements.push(element);

    }

    return elements;

}


/* BEGIN ELEMENT HEIGHT RESIZING SCRIPTS */
appendToLoad("resolveConditionalSize()");
appendToLoad("setStructureSize()");

/*function setStructureSize() {

    var tmpEl = null;

    for ( var i=0; i<document.getElementsByTagName('*').length; i++ ) {

        tmpEl = document.getElementsByTagName('*')[i];

        if ( !tmpEl.tagName || tmpEl.tagName == "!" ) continue;

        if ( tmpEl.getAttribute( "dynamicHeight" ) && tmpEl.getAttribute( "dynamicHeight" ) == "true" ) {
            if ( /table/i.test( tmpEl.tagName ) ) {
                resizeTableHeight( tmpEl );
            } else {
                resizeElementHeight( tmpEl );
            }
        }

    }

}*/

function setStructureSize() {

    var x, y, z, el, table, rows, height;
    var fittedEls = {'heights':new Array()};
    var disabledEls = {'heights':new Array()};
    var allEls = document.body.getElementsByTagName('*');
    var allTables = {'heights':new Array()};
    var dynamicEls = new Array();

    for (x = 0; x < allEls.length; x++) {
        if (allEls[x].getAttribute && isDynamicHeight(allEls[x])) {
            fittedEls.heights.push(allEls[x]);
        }

        if (allEls[x].getAttribute && isDynamicWidth(allEls[x])) {
            dynamicEls.push(allEls[x]);
        }

        if (allEls[x].style.display && allEls[x].style.display == "none" && allEls[x].tagName.toLowerCase() == "div" && allEls[x].className.toLowerCase() == "tab-body") {
            disabledEls.heights.push(allEls[x]);
            allEls[x].style.display = "block";
        }
    }

    resolveDynamicWidths(dynamicEls);

    for (x = 0; x < fittedEls.heights.length; x++) {

        el = fittedEls.heights[x];

        if (el.tagName && el.tagName.toLowerCase() == "table" && isDynamicHeight(el)) {
            el.style.height = parentHeight(el, 'px');
            setRowHeightsInTable(el);
        } else if (el.tagName && el.tagName.toLowerCase() == "tr") {
        } else {
            if (el.tagName && el.tagName.toLowerCase() != "iframe" && el.parentNode && el.parentNode.tagName && el.parentNode.tagName.toLowerCase() == "td") {
                setElementHeightsInTableCell(el.parentNode);
            } else {
                el.style.height = parentHeight(el, 'px');
            }
        }

    }

    for (x = 0; x < disabledEls.heights.length; x++) {
        disabledEls.heights[x].style.display = "none";
    }

}

function resolveDynamicWidths(dynamicEls) {

    var el;

    for (x = 0; x < dynamicEls.length; x++) {
        el = dynamicEls[x];
        if (isTagName(el, "textarea")) {
            if (el.parentNode.clientWidth) {
                el.style.width = (el.parentNode.clientWidth - 4) + "px";
            } else {
                el.style.width = (el.parentNode.parentNode.clientWidth - 4) + "px";
            }
        } else if (isTagName(el, "div") && el.className.toLowerCase() == "tab-body") {
            el.style.width = calculateStyleWidth(el, el.parentNode.clientWidth) + "px";
        }
    }

}

function isTagName(el, name) {
    if (el.tagName && el.tagName.toLowerCase() == name) {
        return true;
    } else {
        return false;
    }
}

function isDynamicHeight(el) {
    return (el.getAttribute('dynamicHeight') && el.getAttribute('dynamicHeight') == "true") || (el.getAttribute('height') && el.getAttribute('height') == "100%");
}

function isDynamicWidth(el) {
    return ((el.getAttribute('width') && el.getAttribute('width') == "100%") || (el.style && el.style.width && el.style.width == "100%"));
}

function isFirefoxBrowser() {
    return (navigator.userAgent.indexOf("Firefox") >= 0);
}

function isMSIEBrowser() {
    return (navigator.userAgent.indexOf("MSIE") >= 0);
}

function isMSIE6Browser() {
    return (navigator.userAgent.indexOf("MSIE 6.0") >= 0);
}

function isMSIEOldBrowser() {
    return (navigator.userAgent.indexOf("MSIE 6") >= 0) || (navigator.userAgent.indexOf("MSIE 7") >= 0) || (navigator.userAgent.indexOf("MSIE 8") >= 0);
}

function parentHeight(el, units) {

    var height = 0;
    var pNode = el.parentNode;
    var divBorderWidth = 0;

    if (pNode.tagName.toLowerCase() == 'body' || pNode.tagName.toLowerCase() == 'form') {
        height = document.documentElement.clientHeight - 1;
    } else {

        if (pNode.tagName.toLowerCase() == "div" && pNode.className.toLowerCase() == "tab-body") {
            divBorderWidth = calculateStyleHeight(pNode, divBorderWidth) * -1;
            pNode = pNode.parentNode;
        }

        if (pNode.style && pNode.style.height && pNode.style.height.indexOf("px") > -1) {
            height = parseInt(pNode.style.height.match(/([0-9]+)px/)[1]);
        } else {
            height = pNode.clientHeight;
        }

        height -= divBorderWidth;
    }

    height = reduceHeightForTextArea(el, height);

    if (units) {
        height = height + units;
    }

    return height;

}

function setRowHeightsInTable(table) {

    var usedHeight = 0;
    var dynamicHeightRows = [];
    var rowHeight = 0;

    if (table.tBodies.length > 0) {

        var tableRows = table.tBodies[0].rows;

        for (var x = 0; x < tableRows.length; x++) {
            if (isDynamicHeight(tableRows[x])) {
                dynamicHeightRows.push(x);
            } else {
                rowHeight = getRequiredRowHeight(tableRows[x]);
                tableRows[x].style.height = rowHeight + "px";
                // need for fire fox
                usedHeight += rowHeight;
            }
        }

        if (table.cellSpacing && table.cellSpacing > 0) {
            usedHeight += table.cellSpacing * ( tableRows.length + 1 );
        }

        if (!/firefox/i.test(navigator.userAgent)) {
            if (table.cellPadding && table.cellPadding > 0) {
                usedHeight += table.cellPadding * ( tableRows.length * 2 );
            }
        }

        for (var r = 0; r < dynamicHeightRows.length; r++) {

            if (usedHeight > table.clientHeight) {
                if (tableRows[dynamicHeightRows[r]].offsetHeight > 0) {
                    tableRows[dynamicHeightRows[r]].style.height = tableRows[dynamicHeightRows[r]].offsetHeight;
                } else {
                    tableRows[dynamicHeightRows[r]].style.height = "50px";
                }
            } else {
                var calculatedHeight = ( table.clientHeight - usedHeight ) / dynamicHeightRows.length;
                if (!isMSIEBrowser() || tableRows[dynamicHeightRows[r]].offsetHeight != calculatedHeight) {
                    tableRows[dynamicHeightRows[r]].style.height = calculatedHeight + "px";
                }
            }

        }

    }
}

function readjustDynamicHeightElementHeightInRow(row, diff) {
    var cells = row.childNodes;
    if (cells) {
        for (var cellIndex = 0; cellIndex < cells.length; cellIndex++) {
            if (cells[cellIndex].tagName && cells[cellIndex].tagName.toLowerCase() == "td") {
                var elements = cells[cellIndex].childNodes;
                var dynamicHeightReadjusted = false;
                if (elements) {
                    for (var elIndex = 0; elIndex < elements.length; elIndex++) {
                        if (elements[elIndex].getAttribute && isDynamicHeight(elements[elIndex])) {
                            elements[elIndex].style.height = (elements[elIndex].offsetHeight - diff) + "px";
                            dynamicHeightReadjusted = true;
                        }
                    }
                    if (dynamicHeightReadjusted) {
                        cells[cellIndex].style.height = (cells[cellIndex].offsetHeight - diff) + "px";
                    }
                }
            }
        }
    }
}

function setElementHeightsInTableCell(cell) {

    var usedHeight = 0;
    var dynamicHeightElements = [];
    var cellHeight = 0;
    var children = cell.childNodes;

    for (var x = 0; x < children.length; x++) {
        if (children[x].getAttribute && isDynamicHeight(children[x])) {
            dynamicHeightElements.push(x);
        } else {
            if (children[x].tagName && children[x].tagName.toLowerCase().indexOf("script") < 0 && children[x].offsetHeight) {
                usedHeight += children[x].offsetHeight;
            }
        }
    }

    for (var r = 0; r < dynamicHeightElements.length; r++) {

        if (usedHeight > cell.clientHeight) {
            if (children[dynamicHeightElements[r]].offsetHeight > 0) {
                children[dynamicHeightElements[r]].style.height = children[dynamicHeightElements[r]].offsetHeight;
            } else {
                children[dynamicHeightElements[r]].style.height = "50px";
            }
        } else {
            children[dynamicHeightElements[r]].style.height = calculateStyleHeight(children[dynamicHeightElements[r]], ( cell.clientHeight - usedHeight ) / dynamicHeightElements.length) + "px";
        }

    }

}

function calculateStyleWidth(el, width) {

    var marginPaddingBorder = 0;
    var cssStyle;

    if (document.defaultView) {
        if (el.className) {
            cssStyle = document.defaultView.getComputedStyle(el, el.className);
        }
    } else if (el.currentStyle) {
        cssStyle = el.currentStyle;
    }

    if (el.style || cssStyle) {
        if (el.style && el.style.marginLeft) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.marginLeft);
        } else if (cssStyle && cssStyle.marginLeft) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.marginLeft);
        }
        if (el.style && el.style.marginRight) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.marginRight);
        } else if (cssStyle && cssStyle.marginRight) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.marginRight);
        }
        if (el.style && el.style.borderLeftWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.borderLeftWidth);
        } else if (cssStyle && cssStyle.borderLeftWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.borderLeftWidth);
        }
        if (el.style && el.style.borderRightWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.borderRightWidth);
        } else if (cssStyle && cssStyle.borderRightWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.borderRightWidth);
        }
        if (el.style && el.style.paddingLeft) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.paddingLeft);
        } else if (cssStyle && cssStyle.paddingLeft) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.paddingLeft);
        }
        if (el.style && el.style.paddingRight) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.paddingRight);
        } else if (cssStyle && cssStyle.paddingRight) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.paddingRight);
        }
    }

    return reduceHeightForTextArea(el, width - marginPaddingBorder);
}

function calculateStyleHeight(el, height) {

    var marginPaddingBorder = 0;
    var cssStyle;

    if (document.defaultView) {
        if (el.className) {
            cssStyle = document.defaultView.getComputedStyle(el, el.className);
        }
    } else if (el.currentStyle) {
        cssStyle = el.currentStyle;
    }

    if (el.style || cssStyle) {
        if (el.style && el.style.marginTop) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.marginTop);
        } else if (cssStyle && cssStyle.marginTop) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.marginTop);
        }
        if (el.style && el.style.marginBottom) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.marginBottom);
        } else if (cssStyle && cssStyle.marginBottom) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.marginBottom);
        }
        if (el.style && el.style.borderTopWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.borderTopWidth);
        } else if (cssStyle && cssStyle.borderTopWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.borderTopWidth);
        }
        if (el.style && el.style.borderBottomWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.borderBottomWidth);
        } else if (cssStyle && cssStyle.borderBottomWidth) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.borderBottomWidth);
        }
        if (el.style && el.style.paddingTop) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.paddingTop);
        } else if (cssStyle && cssStyle.paddingTop) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.paddingTop);
        }
        if (el.style && el.style.paddingBottom) {
            marginPaddingBorder += getNumberValueFromStyleValue(el.style.paddingBottom);
        } else if (cssStyle && cssStyle.paddingBottom) {
            marginPaddingBorder += getNumberValueFromStyleValue(cssStyle.paddingBottom);
        }
    }

    return reduceHeightForTextArea(el, height - marginPaddingBorder);
}

function getNumberValueFromStyleValue(styleValue) {
    if (styleValue.match(/([0-9]+)px/)) {
        //return parseInt(styleValue.match(/([0-9]+)px/)[1]);
    	//
    	//Previous integer conversion worked incorrectly on decimal values between 0 and 1,
    	//causing incorrect height layouts on several framework pages.
        return parseInt(styleValue);
    }
    return 0;
}

function isNumber(value) {
    return value.match(/([0-9]+)/);
}

function reduceHeightForTextArea(el, height) {

    if (el.tagName.toLowerCase() == "textarea") {
        if (!isMSIEBrowser()) {
            height -= 2;
        } else {
            height -= 2;
        }
    }

    return height;

}

function getRequiredRowHeight(row) {

    var cell;
    var rowHeight = 0;
    var cellHeight = 0;

    for (x = 0; x < row.childNodes.length; x++) {

        cell = row.childNodes[x];
        if (cell.tagName && cell.tagName.toLowerCase() == "td") {
            cellHeight = getRequiredCellHeight(cell);
            cell.style.height = getRequiredCellHeight(cell) + "px";
            // needed for fire fox.
            if (rowHeight < cellHeight) {
                rowHeight = cellHeight;
            }

        }

    }

    return rowHeight;

}

function getRequiredCellHeight(cell) {

    var cellHeight = 0;
    var node;

    for (y = 0; y < cell.childNodes.length; y++) {

        node = cell.childNodes[y];

        if (node.offsetHeight && cellHeight < node.offsetHeight) {
            cellHeight = reduceHeightForTextArea(node, node.offsetHeight);
        }

    }

    return cellHeight;

}

function getParentHeight(element) {

    var height = 0;

    if ((/body/i.test(element.parentNode.tagName) || /form/i.test(element.parentNode.tagName))) {

        height = document.documentElement.clientHeight - 1;

    } else {

        height = element.parentNode.clientHeight;

        if (height <= 1 && element.parentNode.parentNode && element.parentNode.parentNode.clientHeight > 1) {
            height = element.parentNode.parentNode.clientHeight;
        }
    }

    var log = "Tag: " + element.tagName + "\nID: " + element.id + "\nName: " + element.name + "\nClass: " + element.className + "\nHeight: " + height;
    //alert(log);

    return height;
}

function resizeElementHeight(el) {

    var usedHeight = 0;
    var selectors = ["borderTop", "borderBottom", "paddingTop", "paddingBottom", "marginTop", "marginBottom"];

    for (var x = 0; x < selectors.length; x++) {
        if (el.style[selectors[x]]) {
            var height = 0;
            if (/[0-9]+px/.test(el.style[selectors[x]])) {
                height = parseInt(el.style[selectors[x]].match(/([0-9]+)px/)[1]);
            } else if (el.style[selectors[x]].match(/[0-9]+/) && el.style[selectors[x]].match(/[0-9]+/).length < 6) {//donot want color
                height = parseInt(el.style[selectors[x]].match(/[0-9]+/));
            }

            usedHeight += height;
        }
    }
    el.style.height = ( getParentHeight(el) - usedHeight ) + "px";
}

function resizeTableHeight(table) {

    var usedHeight = 0;
    var dynamicHeightRows = [];

    if (table.tBodies.length > 0) {
        var tableRows = table.tBodies[0].rows;
        for (var x = 0; x < tableRows.length; x++) {
            if (tableRows[x].getAttribute("dynamicHeight") && tableRows[x].getAttribute("dynamicHeight") == "true") {
                dynamicHeightRows.push(x);
            } else {
                usedHeight += tableRows[x].clientHeight;
            }
        }

        if (table.cellSpacing && table.cellSpacing > 0) {
            usedHeight += table.cellSpacing * ( tableRows.length + 1 );
        }

        if (!/firefox/i.test(navigator.userAgent)) {
            if (table.cellPadding && table.cellPadding > 0) {
                usedHeight += table.cellPadding * ( tableRows.length * 2 );
            }
        }
        for (var r = 0; r < dynamicHeightRows.length; r++) {

            if (usedHeight > getParentHeight(table)) {
                if (tableRows[dynamicHeightRows[r]].clientHeight > 0) {
                    tableRows[dynamicHeightRows[r]].style.height = tableRows[dynamicHeightRows[r]].clientHeight;
                } else {
                    tableRows[dynamicHeightRows[r]].style.height = "50px";
                }
            } else {
                tableRows[dynamicHeightRows[r]].style.height = ( ( getParentHeight(table) - usedHeight ) / dynamicHeightRows.length ) + "px";
            }

        }

    }

}

function updateStatusBar(caption) {

    var element = document.getElementById('status-caption');

    if (! element && window.parent) {
        element = window.parent.document.getElementById('status-caption');
    }

    if (element) {
        element.innerHTML = caption;
    }

}

// delay a function call
function delay(callFunction, params, miliseconds) {
    var functionReference = getDelayFunction(callFunction, params);
    window.setTimeout(functionReference, miliseconds);
}

function getDelayFunction(callFunction, params) {
    return (function () {
        callFunction(params);
    });
}


// TODO: this mainly support date dual input/single, credit card number, may need to support select type or other composite input
function getElementValue(data, element) {
	if(element.className.indexOf('placeholder') >= 0){ // stops placeholder values going through 
		element.value = '';
	}
    var elementID = element.id;
    var prefix = '';
    if(element.type == 'checkbox'){
    	data[elementID] = element.checked;
    }else{
    	data[elementID] = escapeHTML(element.value.trim());
    }

    if (elementID.indexOf(".") > 0) {
        prefix = elementID.substring(0, elementID.indexOf("."));
        data[prefix] = (data[prefix] ? (data[prefix] + " ") : "") + escapeHTML(element.value.trim());
    }

}

var specifiedFormElements = [];

// if you want key different from element id, using mapping to map element id to key
function getFormData(form, mapping, elementIDs) {
    var data = new Array();

    if (elementIDs) {

        for (var i = 0; i < elementIDs.length; i++) {
            data[elementIDs[i]] = escapeHTML(document.getElementById(elementIDs[i]).value.trim());
        }

    } else {

        var elements = null

        if (form) {
            elements = form.elements;
        } else {
            elements = document.forms[0].elements;
            //todo
        }

        for (var i = 0; i < elements.length; i++) {
            // do not include elements[i].type == 'hidden' ||
            // check for null first and that name exists (filter inputs have no names and should not be included)        	
            if (elements[i].type != null && ( elements[i].type == 'textarea' || elements[i].type == 'checkbox' || elements[i].type == 'text' 
            	|| elements[i].type.indexOf('select') > -1) && elements[i].name) { // todo checkbox
                if (mapping) {
                    data[mapping[elements[i].id]] = escapeHTML(elements[i].value.trim());
                } else {
                    getElementValue(data, elements[i]);
                }

            }
        }

    }
    for (var i = 0; i < specifiedFormElements.length; i++) {
        if (returnElement(specifiedFormElements[i])) {
            data[specifiedFormElements[i]] = escapeHTML(returnElement(specifiedFormElements[i]).value.trim());
        } else if (returnElement(specifiedFormElements[i] + '_child')) {
            data[specifiedFormElements[i]] = escapeHTML(returnElement(specifiedFormElements[i] + '_child').value.trim());
        }
    }
    return data;

}

// try to get columnlist, tree or other javascript object
// or document elements
function getObject(elementID) {

    return ( eval('window.' + elementID + '_list') || eval('window.' + elementID + '0') ||
             eval('window.' + elementID) ||
             document.getElementById(elementID) );

}

// delay a function call
function delay(callFunction, params, miliseconds) {
    var functionReference = getDelayFunction(callFunction, params);
    window.setTimeout(functionReference, miliseconds);
}

function getDelayFunction(callFunction, params) {
    return (function () {
        callFunction(params);
    });
}

//copy from ui.js
function storeCaret(textEl)
{
    if (textEl.createTextRange)
    {
        //alert(texlEl.caretPos)
        textEl.caretPos = document.selection.createRange().duplicate();
    }
}


/*function insertAtCaret (textEl, text) {

    if (textEl.createTextRange && textEl.caretPos) {
		var caretPos = textEl.caretPos;
        caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + ' ' : text;
    } else {
    	textEl.value  += text;
    }

}*/


function insertAtCaret(obj, text) {

    if (document.selection) {
        obj.focus();
        var orig = obj.value.replace(/\r\n/g, "\n");
        var range = document.selection.createRange();

        if (range.parentElement() != obj) {
            return false;
        }

        range.text = text;

        var actual = tmp = obj.value.replace(/\r\n/g, "\n");

        for (var diff = 0; diff < orig.length; diff++) {
            if (orig.charAt(diff) != actual.charAt(diff)) break;
        }

        for (var index = 0, start = 0;
             tmp.match(text)
                     && (tmp = tmp.replace(text, ""))
                     && index <= diff;
             index = start + text.length
                ) {
            start = actual.indexOf(text, index);
        }
    } else {
        var start = obj.selectionStart;
        var end = obj.selectionEnd;

        obj.value = obj.value.substr(0, start)
                + text
                + obj.value.substr(end, obj.value.length);
    }

    if (start != null) {
        setCaretTo(obj, start + text.length);
    } else {
        obj.value += text;
        obj.focus();
    }
}

function setCaretTo(obj, pos) {
    if (obj.createTextRange) {
        var range = obj.createTextRange();
        range.move('character', pos);
        range.select();
    } else if (obj.selectionStart) {
        obj.focus();
        obj.setSelectionRange(pos, pos);
    }
}

//textFieldArea accepts an object reference, textString accepts the text string to add.
function insertAtCursor(textFieldArea, textString) {
    //IE support
    if (document.selection) {
        textFieldArea.focus();

		//in effect we are creating a text range with zero length at the cursor location and replacing it with textString 
        sel = document.selection.createRange();
        sel.text = textString;
    } else if (textFieldArea.selectionStart) {         //Mozilla/Firefox/Netscape 7+ support

        //Here we get the start and end points of the selection.
        //Then we create substrings up to the start of the selection and from the end point of the selection to the end of the field value.
        //Then we concatenate the first substring, textString, and the second substring to get the new value.
        var startPos = textFieldArea.selectionStart;
        var endPos = textFieldArea.selectionEnd;
        textFieldArea.value = textFieldArea.value.substring(0, startPos) + textString + textFieldArea.value.substring(endPos, textFieldArea.value.length);
    } else {
        textFieldArea.value += textString;
    }
}

function appendAttribute(from, to, encoding, type) {

    if (((typeof to) == 'string' && to.indexOf('editor') >= 0) ||
        ((typeof to) == 'object' && to.id.indexOf('editor') >= 0)) {

        var editor = null;
        if ((typeof to) == 'string') {
            editor = document.getElementById(to);
        } else {
            editor = to;
        }
        var index = from.selectedIndex;
        var attributeId = from.options[index].value;
        var attributeLabel = from.options[index].text;

        if (attributeId.length > 0) {
            if (type == 'textonly') {
                editor.InsertHtml(attributeId, '', true, true);
            } else {
                var oEditor;
                // [TPUI-2361] Space at end helps to prevent nested tp:attribute tags.
                var sHtml = '<tp:attribute name="' + attributeId + '" encoding="html">' + '[#' + attributeLabel + ']</tp:attribute> ';

                try {
                    //When new wysiwyg is used
                    if (window.CKEDITOR) {
                        oEditor = CKEDITOR.instances[editor.id];
                        if (oEditor.tpcore.isWysiwygMode()) {
                            oEditor.tpcore.insertHtml(sHtml);
                        } else {
                            alert("Please insert attributes via Edit Mode.");
                        }

                    //When old wysiwyg is used
                    } else {
                        oEditor = FCKeditorAPI.GetInstance(editor.id);
                        try {
                            oEditor.InsertHtml(sHtml);
                        } catch (e) {
                            alert("Please insert attributes via Edit Mode.");
                        }
                    }
                } catch (ex) {
                    insertAtCursor(editor, sHtml);
                }
            }
        }

    } else {

        var index = from.selectedIndex;
        var attributeId = from.options[index].value;
        if (encoding == 'html') {
            encoding = ' encoding="' + encoding + '"';
        } else {
            encoding = '';
        }

        if (attributeId.length > 0) {
            //        if (document.all) {

            //    	  var sel = to.createTextRange();
            var textBlah = (type == 'textonly') ? attributeId : ('<tp:attribute name="' + attributeId + '"' + encoding + ' />');
            insertAtCaret(to, textBlah);

            /*} else if ( MAC ) {

              var textBlah =  (type == 'textonly') ?  attributeId : ('<tp:attribute name="' + attributeId + '"' + encoding+' />');
          to.value += textBlah*/

            /*      } else {

                  var textBlah =  (type == 'textonly') ?  attributeId : ('<tp:attribute name="' + attributeId + '"' + encoding+' />');
              to.value += textBlah

            }*/
        }
    }
}

function loadDestination(destination, targetWindow) {

    if (!targetWindow) targetWindow = "self";

    if (window[targetWindow]) {
        notifyLoading(targetWindow);
        window[targetWindow].location.href = destination;
    } else {
        window[targetWindow] = window.open(destination, targetWindow);
    }

}

var loadingPopup = null;
var pageLoading = null;
var loadingTimeout = null;
function notifyLoading(targetWindow) {

    if (window != top && top.notifyLoading) top.notifyLoading('contentFrame');

    if (!loadingPopup && !pageLoading) {

        pageLoading = document.createElement("DIV");
        pageLoading.className = "loading-panel-bg sticky";
        pageLoading.id = "loading-panel-bg";

        if (targetWindow && (returnElement(targetWindow) && returnElement(targetWindow).tagName == "IFRAME")) {
            pageLoading.style.width = returnElement(targetWindow).clientWidth + "px";
            pageLoading.style.height = returnElement(targetWindow).clientHeight + "px";
            pageLoading.style.top = findPos(returnElement(targetWindow))[1] + "px";
            pageLoading.style.left = findPos(returnElement(targetWindow))[0] + "px";
        }

        document.body.appendChild(pageLoading);

        var tmpDiv = document.createElement("DIV");
        tmpDiv.innerHTML = "Loading...<br/>";
        tmpDiv.appendChild(preloadImage("/ui/images/ajax-load.gif", 150, 15));
        tmpDiv.className = "loading-panel";
        tmpDiv.id = "loading-panel";

        pageLoading.appendChild(tmpDiv);

        loadingPopup = Popup('loading-panel-bg');
        loadingPopup.open();

        tmpDiv.style.marginTop = Math.floor(pageLoading.offsetHeight / 2) - Math.floor(tmpDiv.offsetHeight / 2) + "px";

    }

}

function completeLoading() {

    if (window != top) top.completeLoading();

    if (loadingPopup && pageLoading) {

        loadingPopup.close();
        loadingPopup = null;

        document.body.removeChild(pageLoading);
        pageLoading = null;

        clearTimeout(loadingTimeout);
        loadingTimeout = null;

    }

}

appendToLoad("setTimeout('completeLoading()', 1000)");
// Delay closing the loading popup

function findPos(obj) { //return the position of a relative object
    var curleft = curtop = 0;
    if (obj.offsetParent) {
        curleft = obj.offsetLeft
        curtop = obj.offsetTop
        while (obj = obj.offsetParent) {
            curleft += obj.offsetLeft
            curtop += obj.offsetTop
        }
    }
    return [curleft,curtop];
}

function doAction(actionID, noValidation) {

    document.getElementById('_action_id').value = actionID;

    if (noValidation) {
        document.getElementById('_no_validation').value = 'true';
    }

    document.forms[0].submit();

}

function highlightMenuItem(menuID, scopeComponentID) {
    if (window.parent && window.parent.activateMenuItem) {
        window.parent.activateMenuItem(menuID, scopeComponentID);
    }
}

function displayContentSize(contentID, displaySizeID, displayPlusSymbol)
{
    var body = document.getElementById(contentID);

    if (body != null) {

        if (body.value == null) {
            return false;
        }

        var value = "";
        var length = 0;
        var haveSpecialCharacters = false;
        var hasTag = false;
        if (body.value != null) {
            value = body.value;
            var originalSize = value.length;
            value = value.replace(/<tp:.*?>/ig, '');
            hasTag = (originalSize != value.length);
            value = value.replace(/\r/ig, '');


          //method copy from MessageUtils.getMessageSize to keep is consistent
            //sepcial characters that telecom need to handle as 2 character
            var extendedGSMchars = {

                "\n":"\n",
                "[": "[",
                "]": "]",
                "{": "{",
                "}": "}",
                "\\": "\\",
                "^":"^",
                "|":"|",
                "~": "~"
            }

            var token;

            if (value.match(/[\[\]\{\}\\\|\~\^\n]/)) {


                haveSpecialCharacters = true;
                for (var index = 0; index < value.length; index++) {

                    length++;

                    if (index < value.length - 1) {
                        token = value.substring(index, index + 1);
                    } else {
                        token = value.substring(index);
                    }

                    if (extendedGSMchars[token] != null) {
                        length++;
                    }
                }
            }
        }

        var suffix = (displayPlusSymbol && hasTag ? '+' : '');

        if (haveSpecialCharacters) {
            document.getElementById(displaySizeID).innerHTML = length + suffix;
        } else {
            document.getElementById(displaySizeID).innerHTML = value.length + suffix;
        }

    }
}

// for popup selector
function updateSelection(uiComponentID, value, label) {

    var sourceElement = returnElement(uiComponentID);

    if (! sourceElement) {
        sourceElement = returnElement(uiComponentID + '_child');
        // for composite uicomponent
    }

    var oldValue = sourceElement.value;

    sourceElement.value = value;

    var displayElement = returnElement(uiComponentID + '_display');

    if (! displayElement) {
        displayElement = returnElement(uiComponentID + '_label');
    }

    if (! displayElement) {
        displayElement = returnElement(uiComponentID + '_child_display');
    }

    displayElement.value = label;


    if (oldValue != value) {
        if (displayElement.onchange) {
            displayElement.onchange();
        }
    }

    return true;

}

// for concat two associate array, for normal array use concat();
function addAll(toArray, fromArray) {
    if (toArray && fromArray) {
        for (var key in fromArray) {
            toArray[key] = fromArray[key];
        }
    }
}

String.prototype.trim = function () {
    return this.replace(/^\s*|\s*$/g, "");
}

String.prototype.endsWith = function(needle) {
    return (this.indexOf(needle) == this.length - needle.length);
}

function initialiseLoadScreen(tmp) {

    if (this != top) {
        top.initialiseLoadScreen();
        return;
    }

    if (window.contentFrame) {

        window.contentFrame.applyLoading = function() {
            notifyLoading('contentFrame');
        }

        window.contentFrame.onunload = window.contentFrame.applyLoading;
    }
}

appendToLoad("initialiseLoadScreen()");

function unescapeHTML(value) {
    return value ? value.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#13;\\n/g, ' ') : value;
}

function escapeHTML(value) {
    return value ? value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') : value;
}

function escapeSingleQuote(value) {
    return value ? value.replace(/'/g, "\\'") : value;
}

// since asign null to a input will get 'null'
function isBlank(value) {
    return value == null || value == 'null' || value == '0' || value == undefined;
}

function nonBlank(value) {
    return ! isBlank(value);
}

/*function printPage() {
    window.print();
}*/

function printPage() {

    var allElements = document.getElementsByTagName('*'), affectedElements = new Array(0);

    for (var x = 0; x < allElements.length; x++) {
        if (allElements[x].getAttribute("dynamicHeight") && allElements[x].getAttribute("dynamicHeight") == "true") {
            affectedElements.push({el:allElements[x],h:allElements[x].clientHeight});
            allElements[x].style.height = "auto";
        }
    }
	
	// Timeout is a hack for slower computers to render the above changes before printing
    setTimeout(function() {

        // IE hack to avoid printing the whole window.
        self.focus();
		
		// Print dialog is synchronous in FF, asynchronous in IE, but IE will still print what is there at the time the print dialog is called.
        self.print();

        for (var x = 0; x < affectedElements.length; x++) affectedElements[x].el.style.height = affectedElements[x].h + "px";

    }, 500);
}

/*
 * Fix for FIrefox XX bug
 * Do not remove.
*/
function fixSelect(el) {
    el = returnElement(el);
    if (el.options.length == 0 && isFirefoxBrowser()) {
        el.options.length++;
        el.options.length--;
    }
}

function resolveConditionalSize() {
    var allowedNodes = ["input", "select", "textarea"];
    var node;
    var element;
    var condWidth;
    var condHeight;

    for (var n = 0; n < allowedNodes.length; n++) {
        node = document.getElementsByTagName(allowedNodes[n]);
        for (var i = 0; i < node.length; i++) {
            element = node[i];
            condWidth = element.getAttribute("conditionalWidth");
            condHeight = element.getAttribute("conditionalHeight");
            if (condWidth) {
                element.style.width = calculateComponentSize(element.parentNode.offsetWidth - 20, condWidth);
            }
            if (condHeight) {
                element.style.height = height;
            }
        }
    }
}

function calculateComponentSize(availSize, size) {
    var indexOfColor;
    var percent;
    var pixcels;
    indexOfColon = size.indexOf(":");
    if (indexOfColon == -1) {
        return size;
    } else {
        percent = parseInt(size.substring(indexOfColon + 1));
        pixcels = parseInt(size.substring(0, indexOfColon));
        if (pixcels < availSize) {
            size = percent + "%";
            //			size = availSize + "px";
        } else {
            size = pixcels + "px";
        }
        return size;
    }
}

var defaultEnterActionButtonID = null;

function doDefaultEnterAction() {

    if (defaultEnterActionButtonID && returnElement(defaultEnterActionButtonID)) {
        returnElement(defaultEnterActionButtonID).click();
    }

}

function defaultEnterAction(e) {
    var keyCode = e ? (e.keyCode || e.which) : window.event.keyCode;
    if (keyCode == 13) {
        // without setTimeout, firefox will do a submit
        window.setTimeout("doDefaultEnterAction()", 100);
        return false;
    } else {
        return true;
    }
}

// setup default enter action for single element or form elements with id starting with 'selection' (for search)
function setDefaultEnterAction(buttonID, elementID) {

    defaultEnterActionButtonID = buttonID;

    if (elementID) {

        returnElement(elementID).onkeypress = defaultEnterAction;

    } else {

        var elements = document.forms[0].elements;
        for (var i = 0; i < elements.length; i++) {
            if (elements[i].type != null && elements[i].type == 'text' && elements[i].id && elements[i].id.indexOf('selection') >= 0) {
                elements[i].onkeypress = defaultEnterAction;
            }
        }
    }
}

// values are load from ComponentModuleActionRegistry by input-component-reference tag or selectone-column-list tag
var modifyComponentActionWindowSizes = {};

//type: ComponentReference or componentType
function getModifyComponentActionWindowSize(type) {

    if (type) {

        var componentType = type + '';

        if (componentType.indexOf(":") > 0) {
            componentType = componentType.substring(0, componentType.indexOf(":"))
        }

        if (modifyComponentActionWindowSizes[componentType]) {
            return modifyComponentActionWindowSizes[componentType];
        }

    }

    return MEDIUM_WINDOW_SIZE;

}

function closeWindow() {

    if (window.parent) {

        window.parent.close();

    } else {

        self.close();

    }

}

function refreshOpener(url, contentFrameOnly, forceRedirect) {

    if (! url) {
        url = window.parent ? ((contentFrameOnly && window.parent.opener.contentFrame) ? window.parent.opener.contentFrame.location.href : window.parent.opener.location.href) : ((contentFrameOnly && window.opener.contentFrame) ? window.opener.contentFrame.location.href : window.opener.location.href);
    } else {
        forceRedirect = true;
    }

    var rnd = Math.round(Math.random() * 1000);

    var lastChar = url.charAt(url.length - 1);

    if (( lastChar == '?' ) || ( lastChar == '#' ) || ( lastChar == '&' )) {
        url = url.substring(0, url.length - 1);
    }

    if (url.indexOf('?') < 0) {
        url = url + '?';
    } else {
        url = url + '&';
    }

    url += 'rnd=' + rnd;

    if (window.parent) {

        refreshWindow(window.parent.opener, url, forceRedirect, contentFrameOnly);

    } else {

        refreshWindow(window.opener, url, forceRedirect, contentFrameOnly);

    }

}

function refreshWindow(windowObject, url, forceRedirect, contentFrameOnly) {

    if (contentFrameOnly && windowObject.contentFrame) {

        if (! forceRedirect && windowObject.contentFrame.refresh && windowObject.contentFrame.refreshList.length > 0) {
            windowObject.contentFrame.refresh();
        } else {
            windowObject.contentFrame.location.href = url;
        }

    } else {

        if (! forceRedirect && windowObject.refresh && windowObject.refreshList.length > 0) {
            windowObject.refresh();
        } else {
            windowObject.location.href = url;
        }

    }

}

var Tooltip = {

    currentOpen: null,

    display: function(id) {

        if (this.currentOpen) Tooltip.hide(this.currentOpen);

        this.currentOpen = new Popup(id);
        this.currentOpen.open();

    },

    hide: function() {
        if (this.currentOpen) {
            this.currentOpen.close();
            this.currentOpen = null;
        }
    }

}

var clickingTimes = new Array();
var inputValues = '';

function getInputValues() {

    var values = '';

    var elements = document.forms[0].elements;

    for (var i = 0; i < elements.length; i++) {

        if (elements[i].type != null && (elements[i].type != 'hidden')) {

            if (elements[i].type == 'checkbox') {
                values += elements[i].checked;
            } else {
                values += elements[i].value;
            }

        }

    }

    var result = (values != inputValues);

    inputValues = values;

    return result;

}

function allowRepeatExecution(btn, allowRepeating, maxInterval) {

    if (maxInterval == 0) {

        return true;
        
    } else if (clickingTimes[btn.id] == undefined || clickingTimes[btn.id] == 0) {

        clickingTimes[btn.id] = new Date().getTime();
        getInputValues();

        return true;

    } else if (! allowRepeating) {

        return false;

    } else {

        if (getInputValues()) {

            clickingTimes[btn.id] = new Date().getTime();

            return true;

        } else if ((new Date().getTime() - clickingTimes[btn.id]) > maxInterval * 1000) {

            clickingTimes[btn.id] = new Date().getTime();

            return true;

        } else {

            alert('Please wait for the current execution to complete before executing again.');

            return false;

        }

    }

}