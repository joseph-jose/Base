import arcpy 
from arcpy import env
import os


try:
    sFC = arcpy.GetParameterAsText(0)
    dFC = arcpy.GetParameterAsText(1)  
    arcpy.CopyFeatures_management(sFC, dFC) 

except Exception as err:
    arcpy.AddError(err)
    print err 