﻿define(
   ({
    enableUndoRedo: "Bật Hoàn tác/Làm lại",
    toolbarVisible: "Thanh công cụ hiển thị",
    toolbarOptions: "Tùy chọn thanh công cụ",
    mergeVisible: "Trộn",
    cutVisible: "Cắt",
    reshapeVisible: "Tạo lại hình dạng",
    back: "Quay lại",
    label: "Lớp",
    edit: "Có thể chỉnh sửa",
    update: "Tắt Cập nhật Hình học",
    fields: "Trường",
    actions: "Các hành động",
    editpageName: "Tên",
    editpageAlias: "Bí danh",
    editpageVisible: "Hiển thị",
    editpageEditable: "Có thể chỉnh sửa",
    noLayers: "Không có lớp đối tượng nào có thể chỉnh sửa",
    configureFields: "Cấu hình Trường Lớp"
  })
);