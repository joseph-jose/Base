﻿define({
    unit: "Ĳ_Unit_ä",
    style: "Ĳ_Style_ä"
});