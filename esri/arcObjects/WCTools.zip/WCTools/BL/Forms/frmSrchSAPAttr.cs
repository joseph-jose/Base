﻿using ESRI.ArcGIS.ADF;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmSrchSAPAttr : Form
    {
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }
        private string vLogSessId="";
        public string vLogSession { set { vLogSessId = value; } }
        private IFeatureLayer __FeatLyr;
        private IList __Lst;

        WCTools.BL.Classes.cUtilGIS vGISUtil;
        WCTools.BL.Classes.cUtilFile vUtilFile;
        WCTools.BL.Classes.cDbFile vDbFile;

        public void connDB()
        {
            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            vDbFile.ConnectToDatabase(3, vConnStr);
        }

        public void helpersActivate()
        {
            vDbFile = new WCTools.BL.Classes.cDbSqlFile();
            vUtilFile = new WCTools.BL.Classes.cUtilFile();
            vGISUtil = new WCTools.BL.Classes.cUtilGIS();
            vGISUtil.vAppMap = __App;

            connDB();
            logNtry("WCTools", "SrchSAPAttr", "Start", vLogSessId, "TRC");
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "SrchSAPAttr", "End", vLogSessId, "TRC");
            vDbFile.Dispose();
            vDbFile = null;
            vGISUtil.Dispose();
            vGISUtil = null;

        }
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            //20150722
            //vUtilFile.logNtry(vDbFile, inCmdType, inMsg, inFld1, inSessId, inLogType);
            vUtilFile.logTxtNtry( inCmdType, inMsg, inFld1, inSessId, inLogType);
            //20150722
        }

        ~frmSrchSAPAttr()
        {
            if (!(__Lst == null))
            {
                __Lst.Clear();
                __Lst = null;
            }

            Marshal.ReleaseComObject(__FeatLyr); 
        }

        public bool validateOnLoad()
        {
            bool vresFn = false;

            //IWorkspaceEdit vWrkSpcEdt= null;
            ILayer vLyr = null;
            try
            {
                vLyr = vGISUtil.getSelItemInTOC(); 
                if (!(vLyr is IFeatureLayer ))
                {
                    MessageBox.Show("Select a feature layer");
                    return vresFn;
                }
                __FeatLyr = vLyr as IFeatureLayer;

            }
            finally
            {
                //Marshal.ReleaseComObject(vLyr);
                //Marshal.ReleaseComObject(vWrkSpcEdt);
                vLyr = null;
                //vWrkSpcEdt = null;
            }

            vresFn = true;

            return vresFn;
        }
        public frmSrchSAPAttr()
        {
            InitializeComponent();
        }


        private void ListsEqFeatLoad()
        {
            //object vObj = null;
            string vEqpIds = "";
            st_AttrValues vAttrValues;

            //IEnumerator vLstItmEnum = __Lst.GetEnumerator();
            //vLstItmEnum.Reset();

            foreach (object vObj in __Lst)
            {
                vAttrValues = (st_AttrValues)vObj;
                if (!(vEqpIds == ""))
                {
                    vEqpIds = vEqpIds + ",";
                }
                vEqpIds = vEqpIds + vAttrValues.WAT_SAP_Equipment.ToString();
            }


            int vFldIdx = -1;
            object vFldVal = -1;
            string vFldStrVal = "";

            vEqpIds = "EQUIP_ID in (" + vEqpIds + ")";

            using (ComReleaser vComRel = new ComReleaser())
            {
                IFeatureCursor vFeatCursr = null ;

                vComRel.ManageLifetime(vFeatCursr); 

                vFeatCursr = vGISUtil.getQryFltr(__FeatLyr, vEqpIds);

                IFeature vFeat = vFeatCursr.NextFeature();
                while (!(vFeat == null ))
                {
                    vFldIdx = vGISUtil.getFieldIdx(vFeat, "EQUIP_ID");
                    if (!(vFldIdx == -1))
                    {
                        vFldVal = vGISUtil.getFieldValue(vFeat, "EQUIP_ID");
                    }
                    if (!(vFldVal==null))
                    {
                        vFldStrVal = vFldVal.ToString();
                        var item = __Lst.Cast<st_AttrValues>().SingleOrDefault(i => i.WAT_SAP_Equipment == vFldStrVal);
                        //if (!(item is Nullable ))
                        if (!(item == null))
                        {
                            //MessageBox.Show("Hi"); 
                            item.vFlsStat = 1;

                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "ObjectId");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "ObjectId");
                                item.WT_PipeObjectId = vFldVal.ToString() ;
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "GIS_Id");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "GIS_Id");
                                item.WT_PipeGIS_Id = vFldVal.ToString();
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "Equip_Id");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "Equip_Id");
                                item.WT_PipeEquip_Id = vFldVal.ToString();
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "FAC_CODE");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "FAC_CODE");
                                item.WT_PipeFAC_CODE = vFldVal.ToString();
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "PROC_CODE");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "PROC_CODE");
                                item.WT_PipePROC_CODE = vFldVal.ToString();
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "GRP_CODE");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "GRP_CODE");
                                item.WT_PipeGRP_CODE = vFldVal.ToString();
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "INSTALLED");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "INSTALLED");
                                item.WT_PipeINSTALLED = vFldVal.ToString();
                            }

                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "NOM_DIA_MM");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "NOM_DIA_MM");
                                item.WT_PipeNOM_DIA_MM  =  vFldVal.ToString() ;
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "STATUS");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "STATUS");
                                item.WT_PipeSTATUS  =  vFldVal.ToString() ;
                            }
                            vFldIdx = vGISUtil.getFieldIdx(vFeat, "MODIFYREF");
                            if (!(vFldIdx == -1))
                            {
                                vFldVal = vGISUtil.getFieldValue(vFeat, "MODIFYREF");
                                item.WT_PipeMODIFYREF  =  vFldVal.ToString() ;
                            }

                        }
                    }
                    vFeat = vFeatCursr.NextFeature();
                }
            }
        }

        private void Listsload(ICursor inCursr)
        {
            st_AttrValues vAttrValues;
            int vFldIdx;
            string vStrVal;
            DateTime vtmpDate;

            if (__Lst == null)
            {
                __Lst = new List<st_AttrValues>();
            }
            else
            {
                //ListsClr();
                __Lst.Clear();
            }

            IRow vRow = null;
            vRow = inCursr.NextRow();
            while (!(vRow == null))
            {
                vAttrValues = new st_AttrValues();

                vAttrValues.vFlsStat = -1;

                vFldIdx = inCursr.FindField("Equipment");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_Equipment  = vStrVal;

                vFldIdx = inCursr.FindField("EQUIDESCR");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_Equidescr = vStrVal;


                vFldIdx = inCursr.FindField("FACILITY");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_FACILITY = vStrVal;

                vFldIdx = inCursr.FindField("PROCESS");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_PROCESS = vStrVal;

                vFldIdx = inCursr.FindField("GROUPCODE");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_GROUPCODE = vStrVal;

                vFldIdx = inCursr.FindField("DATEACQUIRED");
                vStrVal = vRow.Value[vFldIdx].ToString();
                if (DateTime.TryParse(vStrVal, out vtmpDate))
                {
                    vStrVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                }
                vAttrValues.WAT_SAP_DATEACQUIRED = vStrVal;

                vFldIdx = inCursr.FindField("SAP_NOM_DIA_MM_TMP");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_SAP_NOM_DIA_MM_TMP = vStrVal;

                vFldIdx = inCursr.FindField("SAP_STATUS_TMP");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_SAP_STATUS_TMP = vStrVal;

                vFldIdx = inCursr.FindField("GIS_REF");
                vStrVal = vRow.Value[vFldIdx].ToString();
                vAttrValues.WAT_SAP_GIS_REF = vStrVal;

                __Lst.Add(vAttrValues); 

                vRow = inCursr.NextRow();
            }
        }

        private void Listsload(DataTable inDtTbl)
        {
            st_AttrValues vAttrValues;
            //int vFldIdx;
            string vStrVal;
            DateTime vtmpDate;

            if (__Lst == null)
            {
                __Lst = new List<st_AttrValues>();
            }
            else
            {
                //ListsClr();
                __Lst.Clear();
            }

            for (int vI = 0; vI < inDtTbl.Rows.Count - 1; vI++)
            {
                DataRow vDataRow = inDtTbl.Rows[vI];

                vAttrValues = new st_AttrValues();
                vAttrValues.vFlsStat = -1;

                vStrVal = vDataRow["Equipment"].ToString();
                vAttrValues.WAT_SAP_Equipment = vStrVal;

                vStrVal = vDataRow["EQUIDESCR"].ToString();
                vAttrValues.WAT_SAP_Equidescr = vStrVal;

                vStrVal = vDataRow["FACILITY"].ToString();
                vAttrValues.WAT_SAP_FACILITY = vStrVal;

                vStrVal = vDataRow["PROCESS"].ToString();
                vAttrValues.WAT_SAP_PROCESS = vStrVal;

                vStrVal = vDataRow["GROUPCODE"].ToString();
                vAttrValues.WAT_SAP_GROUPCODE = vStrVal;

                vStrVal = vDataRow["DATEACQUIRED"].ToString();
                if (DateTime.TryParse(vStrVal, out vtmpDate))
                {
                    vStrVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                }
                vAttrValues.WAT_SAP_DATEACQUIRED = vStrVal;

                vStrVal = vDataRow["SAP_NOM_DIA_MM_TMP"].ToString();
                vAttrValues.WAT_SAP_SAP_NOM_DIA_MM_TMP = vStrVal;

                vStrVal = vDataRow["SAP_STATUS_TMP"].ToString();
                vAttrValues.WAT_SAP_SAP_STATUS_TMP = vStrVal;

                vStrVal = vDataRow["GIS_REF"].ToString();
                vAttrValues.WAT_SAP_GIS_REF = vStrVal;

                __Lst.Add(vAttrValues);
            }
        }

        private void loadGrids()
        {
            string vStrVal, vPreStrVal = "";
            bool vMisMtchFnd = false; 
            st_AttrValues vAttrValues;

            dtGrdLstAttr.Columns.Add("Col0", "ObjectId");
            dtGrdLstAttr.Columns.Add("Col1", "GIS_Id");
            dtGrdLstAttr.Columns.Add("Col2", "Equip_Id");
            dtGrdLstAttr.Columns.Add("Col3", "Equidescr");

            dtGrdLstAttr.Columns.Add("Col4", "FAC_CODE");
            dtGrdLstAttr.Columns.Add("Col5", "FACILITY");
            dtGrdLstAttr.Columns.Add("Col6", "PROC_CODE");
            dtGrdLstAttr.Columns.Add("Col7", "PROCESS");

            dtGrdLstAttr.Columns.Add("Col8", "GRP_CODE");
            dtGrdLstAttr.Columns.Add("Col9", "GROUPCODE");
            dtGrdLstAttr.Columns.Add("Col10", "INSTALLED");
            dtGrdLstAttr.Columns.Add("Col11", "DATEACQUIRED");

            dtGrdLstAttr.Columns.Add("Col12", "NOM_DIA_MM");
            dtGrdLstAttr.Columns.Add("Col13", "SAP_NOM_DIA_MM_TMP");
            dtGrdLstAttr.Columns.Add("Col14", "STATUS");
            dtGrdLstAttr.Columns.Add("Col15", "SAP_STATUS_TMP");
            dtGrdLstAttr.Columns.Add("Col16", "MODIFYREF");
            dtGrdLstAttr.Columns.Add("Col17", "GIS_REF");


            foreach (object vObj in __Lst)
            {
                vAttrValues = (st_AttrValues)vObj;

                if (vAttrValues.vFlsStat == 1)
                {
                    vMisMtchFnd = false;

                    dtGrdLstAttr.Rows.Add();

                    vStrVal = vAttrValues.WT_PipeObjectId.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = vStrVal;

                    vStrVal = vAttrValues.WT_PipeGIS_Id.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vStrVal;

                    vStrVal = vAttrValues.WT_PipeEquip_Id.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[2].Value = vStrVal;

                    vStrVal = vAttrValues.WAT_SAP_Equidescr.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = vStrVal;

                    vStrVal = vAttrValues.WT_PipeFAC_CODE.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vStrVal;
                    vPreStrVal = vStrVal;
                    vStrVal = vAttrValues.WAT_SAP_FACILITY.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Value = vStrVal;
                    if (!(vMisMtchFnd))
                    {
                        if ((vStrVal.Trim() != "") && (vPreStrVal != vStrVal))
                        {
                            vMisMtchFnd = true;
                            //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Style.BackColor = Color.Red;
                        }
                    }

                    vStrVal = vAttrValues.WT_PipePROC_CODE.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[6].Value = vStrVal;
                    vPreStrVal = vStrVal;
                    vStrVal = vAttrValues.WAT_SAP_PROCESS.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[7].Value = vStrVal;
                    if (!(vMisMtchFnd))
                    {
                        if ((vStrVal.Trim() != "") && (vPreStrVal != vStrVal))
                        {
                            vMisMtchFnd = true;
                            //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Style.BackColor = Color.Red;
                        }
                    }


                    vStrVal = vAttrValues.WT_PipeGRP_CODE.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[8].Value = vStrVal;
                    vPreStrVal = vStrVal;
                    vStrVal = vAttrValues.WAT_SAP_GROUPCODE.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[9].Value = vStrVal;
                    if (!(vMisMtchFnd))
                    {
                        if ((vStrVal.Trim() != "") && (vPreStrVal != vStrVal))
                        {
                            vMisMtchFnd = true;
                            //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Style.BackColor = Color.Red;
                        }
                    }

                    vStrVal = vAttrValues.WT_PipeINSTALLED.ToString();
                    DateTime vtmpDate;
                    if (DateTime.TryParse(vStrVal, out vtmpDate))
                    {
                        vStrVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                    }
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[10].Value = vStrVal;
                    vPreStrVal = vStrVal;
                    vStrVal = vAttrValues.WAT_SAP_DATEACQUIRED.ToString();
                    if (DateTime.TryParse(vStrVal, out vtmpDate))
                    {
                        vStrVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                    }
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[11].Value = vStrVal;
                    if (!(vMisMtchFnd))
                    {
                        if ((vStrVal.Trim() != "") && (vPreStrVal != vStrVal))
                        {
                            vMisMtchFnd = true;
                            //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Style.BackColor = Color.Red;
                        }
                    }

                    vStrVal = vAttrValues.WT_PipeNOM_DIA_MM.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[12].Value = vStrVal;
                    vPreStrVal = vStrVal;
                    vStrVal = vAttrValues.WAT_SAP_SAP_NOM_DIA_MM_TMP.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[13].Value = vStrVal;
                    if (!(vMisMtchFnd))
                    {
                        if ((vStrVal.Trim() != "") && (vPreStrVal != vStrVal))
                        {
                            vMisMtchFnd = true;
                            //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Style.BackColor = Color.Red;
                        }
                    }

                    vStrVal = vAttrValues.WT_PipeSTATUS.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[14].Value = vStrVal;
                    vPreStrVal = vStrVal;
                    vStrVal = vAttrValues.WAT_SAP_SAP_STATUS_TMP.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[15].Value = vStrVal;
                    if (!(vMisMtchFnd))
                    {
                        if ((vStrVal.Trim() != "") && (vPreStrVal != vStrVal))
                        {
                            vMisMtchFnd = true;
                            //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Style.BackColor = Color.Red;
                        }
                    }

                    vStrVal = vAttrValues.WT_PipeMODIFYREF.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[16].Value = vStrVal;
                    vPreStrVal = vStrVal;
                    vStrVal = vAttrValues.WAT_SAP_GIS_REF.ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[17].Value = vStrVal;
                    if (!(vMisMtchFnd))
                    {
                        if ((vStrVal.Trim() != "") && (vPreStrVal != vStrVal))
                        {
                            vMisMtchFnd = true;
                            //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Style.BackColor = Color.Red;
                        }
                    }

                    if (vMisMtchFnd)
                    {
                        dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Style.BackColor = Color.Red;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtTNo.Text == "")
            {
                MessageBox.Show("Enter the TNumber");
                txtTNo.Focus();
                return;
            }



            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");



            vDbFile.ConnectToDatabase(3, vConnStr);
            if (vDbFile.Connected)
            {
                vConnStr = "Select " +
                    " Equipment, Equidescr, FACILITY, PROCESS, GROUPCODE, DATEACQUIRED, SAP_NOM_DIA_MM_TMP,  SAP_STATUS_TMP, GIS_REF " +
                    "from [GISAdmin].[GISWSL].[WAT_SAPGIS] " +
                    "where " +
                    "GIS_REF ='{0}'";
                DataTable vDtTbl = vDbFile.getDtTblRecs(string.Format(vConnStr, txtTNo.Text.ToString() ));

                using (ComReleaser vComReleaser = new ComReleaser())
                {

                    Listsload(vDtTbl);
                    if (__Lst.Count > 0)
                    {
                        ListsEqFeatLoad();
                        loadGrids();
                    }
                    else
                    {
                        MessageBox.Show("TNo not found"); 
                    }
                }
                __Lst.Clear();
                vDtTbl = null;
                //vSelDataRow = vDtTbl.Rows[0];
            }
        }

        private void dtGrdLstAttr_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnUpdAttr_Click(object sender, EventArgs e)
        {
            if (!(dtGrdLstAttr.SelectedRows.Count > 0))
            {
                MessageBox.Show("Select an item in grid");
                return;
            }
            string vObjIdWhrStr;
            vObjIdWhrStr = dtGrdLstAttr.SelectedRows[0].Cells[0].Value.ToString();
            vObjIdWhrStr = "ObjectId=" + vObjIdWhrStr;
            vGISUtil.SelectOnMap(vGISUtil.vAppDoc , __FeatLyr, vObjIdWhrStr );


            IEnumFeature vEnmFeat = vGISUtil.getSelectedFeatures();
            IFeature vFeat = null;
            try
            {
                vEnmFeat.Reset();
                vFeat = vEnmFeat.Next();
                vGISUtil.ZoomToFeature(vFeat, vGISUtil.vAppDoc);
            }
            finally
            {
                Marshal.ReleaseComObject(vEnmFeat);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }


    public class st_AttrValues
    {
        public string WT_PipeObjectId, WT_PipeGIS_Id, WT_PipeEquip_Id, WT_PipeFAC_CODE, WT_PipePROC_CODE, WT_PipeGRP_CODE, WT_PipeINSTALLED, WT_PipeNOM_DIA_MM, WT_PipeSTATUS, WT_PipeMODIFYREF;
        public string WAT_SAP_Equipment, WAT_SAP_Equidescr, WAT_SAP_FACILITY, WAT_SAP_PROCESS, WAT_SAP_GROUPCODE, WAT_SAP_DATEACQUIRED, WAT_SAP_SAP_NOM_DIA_MM_TMP, WAT_SAP_SAP_STATUS_TMP, WAT_SAP_GIS_REF;
        public int vFlsStat;
    }

}
