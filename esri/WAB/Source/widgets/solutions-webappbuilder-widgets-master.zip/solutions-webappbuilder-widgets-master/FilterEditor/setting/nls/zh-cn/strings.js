﻿define(
   ({
    enableUndoRedo: "启用撤消/恢复",
    toolbarVisible: "工具条可见",
    toolbarOptions: "工具条选项",
    mergeVisible: "合并",
    cutVisible: "剪切",
    reshapeVisible: "整形",
    back: "返回",
    label: "图层",
    edit: "可编辑",
    update: "禁用更新几何",
    fields: "字段",
    actions: "操作",
    editpageName: "名称",
    editpageAlias: "别名",
    editpageVisible: "可见",
    editpageEditable: "可编辑",
    noLayers: "没有可用的可编辑要素图层",
    configureFields: "配置图层字段"
  })
);