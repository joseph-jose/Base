﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class members_topnav : System.Web.UI.UserControl
{
    public string css = "";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    // To highlight the active menu 
    #region For Getting Css class
    public string Activate(string nameurl, string level)
    {
        string css = "";
        string[] strUrls = nameurl.Split(',');
        string title = Request.RawUrl;
        for (int i = 0; i < strUrls.Length; i++)
        {
            if (title.Contains("/" + strUrls.GetValue(i).ToString()))
            {
                if (String.Compare(level,"main") == 0) {
                    css = " class=\"current\"";
                } else {
                    css = " class=\"current_sub\"";
                }
                break;
                return css;
            }
            else
                css = "";
        }
        return css;



    }
    #endregion


}
