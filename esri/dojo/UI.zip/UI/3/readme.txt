http://dojotoolkit.org/documentation/tutorials/1.10/selects/
https://dojotoolkit.org/reference-guide/1.10/dijit/form/Select.html
https://dojotoolkit.org/reference-guide/1.10/dijit/form/FilteringSelect.html
