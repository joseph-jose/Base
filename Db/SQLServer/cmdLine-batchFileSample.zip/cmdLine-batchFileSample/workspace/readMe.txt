MainFile
	batchFileSample\workspace\Start_SAPFULLT01.bat
		call ..\settings\DevD2mod.bat
			set global variables	
		copy all log files in Log folder to Archive
		delete all log files in Log folder
		copy all text files in Log folder to Archive
		delete all text files in Log folder

		set the name of log file(ext .log) and output file(ext .txt)

		
		call WA_SAP_Phase1SAPFULLT01.bat and write output
			use SqlServer command Sqlcmd to write SqlOutput
	