﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmPWDet : Form
    {
        //const string fldrPath = "G:\\Library\\Photos\\";
        //string __fldrPath = "";
        //string __phtAllwXtns = "";
        //string vFldr = "";
        public string __PWConnStr = "";

        public frmPWDet()
        {
            InitializeComponent();

            Dictionary<string, string> vPWType = new Dictionary<string, string>();
            vPWType.Add("MFL", "Multi Feature Link");
            vPWType.Add("SFL", "Single Feature Link");

            cmbPlType.DataSource = new BindingSource(vPWType, null);
            cmbPlType.DisplayMember = "Value";
            cmbPlType.ValueMember = "Key";
        }


        public DialogResult setNewMode(ref string inPlType, ref string inDocNo, ref string inType, ref string inComm)
        {
            DialogResult vDlgRes = DialogResult.Cancel;
            //txtPwRef.Text = "";
            cmbPlType.Text = "";
            txtDocNo.Text = "";
            cmbType.Text = "";
            txtFldComm.Text = "";
            if (this.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //inPWRef = txtPwRef.Text;
                inPlType = ((KeyValuePair<string, string>)cmbPlType.SelectedItem).Key.ToString();  
                //inPlType = cmbPlType.Text;
                inDocNo = txtDocNo.Text;
                inType = cmbType.Text;
                inComm = txtFldComm.Text;
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        public DialogResult setEdtMode(ref string inPlType, ref string inDocNo, ref string inType, ref string inComm)
        {
            DialogResult vDlgRes = DialogResult.Cancel;

            //txtPwRef.Text = inPWRef;
            //cmbPlType.Text = inPlType;
            cmbPlType.SelectedValue = inPlType;
            txtDocNo.Text = inDocNo;
            cmbType.Text = inType;
            txtFldComm.Text = inComm;

            if (this.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //inPWRef = txtPwRef.Text;
                inPlType = ((KeyValuePair<string, string>)cmbPlType.SelectedItem).Key.ToString();
                //inPlType = cmbPlType.Text;
                inDocNo = txtDocNo.Text;
                inType = cmbType.Text;
                inComm = txtFldComm.Text;
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        private bool ValidateControls()
        {
            bool bretRes = false;

            if (cmbPlType.Text.Trim() == "")
            {
                MessageBox.Show("Select type");
                cmbPlType.Focus();
                return bretRes;
            }
            if (txtDocNo.Text.Trim() == "")
            {
                MessageBox.Show("Enter document #");
                txtDocNo.Focus();
                return bretRes;
            }
            if (cmbType.Text == "")
            {
                MessageBox.Show("Enter document Type");
                cmbType.Focus();
                return bretRes;
            }

            bretRes = true;
            return bretRes;
        }


        public string getPWSQl(string inDocNo, string inDocType)
        {
            string sqlStr = "";
            if (inDocType == "Manual")
            {
                sqlStr = "select ma.I_doc_no_full, dd.O_PROJECTNO from dbo.doc_manuals ma,dbo.dms_doc dd where (ma.I_DOC_NO_FULL) in ('{0}')and (ma.I_doc_no_full = dd.O_ITEMNAME and substring(dd.O_ITEMDESC,1,4) <> 'COPY' and ma.O_itemno = dd.O_itemno) order by ma.I_doc_no_full";
            }
            else if (inDocType == "Report")
            {
                sqlStr = "select re.I_doc_no_full, dd.O_PROJECTNO  from dbo.doc_reports re,dbo.dms_doc dd where re.I_DOC_NO_FULL in ('{0}')and  (re.I_doc_no_full = dd.O_ITEMNAME and substring(dd.O_ITEMDESC,1,4) <> 'COPY' and re.O_itemno = dd.O_itemno) order by re.I_doc_no_full";
            }
            else if (inDocType == "Property")
            {
                sqlStr = "select pp.I_DOC_ID,dd.O_PROJECTNO from dbo.DOC_PROPERTY pp,dbo.dms_doc dd where pp.I_DOC_ID in ('{0}')and  (pp.I_doc_id = dd.O_ITEMNAME and substring(dd.O_ITEMDESC,1,4) <> 'COPY' and pp.O_itemno = dd.O_itemno) order by pp.I_doc_id";
            }
            else if (inDocType == "Retail")
            {
                sqlStr = "select pr.I_DOC_ID,dd.o_storno,pr from [PwiseCSandRN].dbo.DOC_NEW_DEV_DWG pr,[PwiseCSandRN].[dbo].[dms_doc] dd where (substring(pr.I_DOC_ID,1,12) in ('{0}') and  pr.a_version=pr.o_itemno) and  (pr.I_DOC_ID = dd.O_ITEMNAME and pr.o_itemno = dd.o_itemno) order by pr.I_DOC_ID";
            }
            else if (inDocType == "Image")
            {
                sqlStr = "select im.I_doc_no_full,dd.O_PROJECTNO from dbo.doc_pictorial im,dbo.dms_doc dd where (im.I_DOC_NO_FULL) in ('{0}')and (im.I_doc_no_full = dd.O_ITEMNAME and substring(dd.O_ITEMDESC,1,4) <> 'COPY' and im.O_itemno = dd.O_itemno) order by im.I_doc_no_full";
            }
            else if (inDocType == "Standard")
            {
                sqlStr = "select st.P_std_no, dd.O_PROJECTNO from dbo.doc_standards st,dbo.dms_doc dd where (st.P_std_no) in ('{0}') and (st.P_std_no = dd.O_ITEMNAME and substring(dd.O_ITEMDESC,1,4) <> 'COPY' and  st.O_itemno = dd.O_itemno) order by st.P_std_no";
            }
            else if (inDocType == "Contract")
            {
                sqlStr = "SELECT ct.I_DOC_NO_FULL, ct.I_FACILITY_CODE FROM dms_doc AS dd INNER JOIN DOC_CONTRACTS2 AS ct ON dd.o_itemname = ct.I_DOC_NO_FULL AND dd.o_itemno = ct.o_itemno WHERE (dd.o_itemdesc <> '[COPY]') AND (ct.I_DOC_NO_FULL in ('{0}'))";
            }
            else if (inDocType == "CCTV")
            {
                sqlStr = "select im.I_doc_no_full,dd.O_PROJECTNO from dbo.doc_pictorial im,dbo.dms_doc dd where (im.I_DOC_NO_FULL) in ('{0}')and (im.I_doc_no_full = dd.O_ITEMNAME and substring(dd.O_ITEMDESC,1,4) <> 'COPY' and im.O_itemno = dd.O_itemno) order by im.I_doc_no_full";
            }
            else if (inDocType == "Transmission")
            {
                sqlStr = "select dd.O_ITEMNAME,pr.I_FACILITY_CODE from dbo.DOC_CAPITALISATION pr join dbo.dms_doc dd on ((pr.I_DOC_NO + '.' + pr.I_SHEET) = dd.O_ITEMNAME) where (substring(dd.O_ITEMNAME,1,12)) in ('{0}') order by dd.O_ITEMNAME";
            }
            else if (inDocType == "GIS Updates")
            {
                sqlStr = "SELECT GU.I_DOC_NO, GU.I_SHEET,  dd.o_projectno FROM   DOC_GIS AS GU INNER JOIN dms_doc AS dd ON GU.o_itemno = dd.o_itemno AND GU.o_projectno = dd.o_projectno WHERE (GU.I_DOC_NO in ('{0}')) ORDER BY GU.I_DOC_NO, GU.I_SHEET";
            }
            else if (inDocType == "Worksover")
            {
                sqlStr = "SELECT  DOC_WORKSOVER.I_DOC_NO, dms_doc.o_filename  FROM  DOC_WORKSOVER INNER JOIN   dms_doc ON DOC_WORKSOVER.o_projectno = dms_doc.o_projectno AND DOC_WORKSOVER.o_itemno = dms_doc.o_itemno WHERE (DOC_WORKSOVER.I_DOC_NO in ('{0}')) ORDER BY DOC_WORKSOVER.I_DOC_NO";
            }
            else
            {
                sqlStr = "select pr.I_doc_no_full,dd.O_PROJECTNO from dbo.doc_plan_records2 pr,dbo.dms_doc dd where (substring(pr.I_DOC_NO_FULL,1,11) in ('{0}')and substring(pr.I_STATUS,1,4) <> 'SUPE' and substring(dd.O_ITEMDESC,1,4)<> 'COPY') and  pr.I_doc_no_full = dd.O_ITEMNAME and dd.o_original=0 order by pr.I_doc_no_full";
            }

            sqlStr = string.Format(sqlStr, inDocNo);
            return sqlStr;
        }

        public bool validateDocNo()
        {
            bool vRetRes = true;
            DataTable vDtTbl = null;
            string vSqlStr = getPWSQl(txtDocNo.Text.ToString(), cmbPlType.Text.ToString());

            using (WCTools.BL.Classes.cDbSqlFile vDbFile = new WCTools.BL.Classes.cDbSqlFile())
            {
                try
                {
                    vDbFile.ConnectToDatabase(3, __PWConnStr);
                    if (vDbFile.Connected)
                    {
                        vDtTbl = vDbFile.getDtTblRecs(vSqlStr); 
                        if (vDtTbl.Rows.Count == 0)
                        {
                            MessageBox.Show("Document# not present in Project Wise"); 
                            vRetRes = false;
                        }
                    }
                }
                finally
                {
                    vDtTbl.Clear();
                    vDtTbl = null;
                    vDbFile.CleanUpDBConnection();
                    vDbFile.Connected = false;
                }
            }

            return vRetRes;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (ValidateControls() == false)
                return;
            //if (!(validateDocNo()))
            //    return;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnCncl_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void btnBrwFldr_Click(object sender, EventArgs e)
        {
        }

        private void cmbPlType_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = false;            
        }



        private void frmPWDet_Load(object sender, EventArgs e)
        {


        }

        private void txtDocNo_KeyDown(object sender, KeyEventArgs e)
        {
            //if (char.IsLetterOrDigit(e.KeyChar))
            //    e.Handled = false;
            //else
            //    e.Handled = true;
        }
    }
}
