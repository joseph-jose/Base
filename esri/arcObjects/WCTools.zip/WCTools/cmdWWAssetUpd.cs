using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.ArcMapUI;
using System.Windows.Forms;

namespace WCTools
{
    /// <summary>
    /// Summary description for cmdWWAssetUpd.
    /// </summary>
    [Guid("189dd1b2-27a2-48b6-9986-e04458c97490")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("WCTools.cmdWWAssetUpd")]
    public sealed class cmdWWAssetUpd : BaseCommand
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IApplication m_application;
        public cmdWWAssetUpd()
        {
            //
            // TODO: Define values for the public properties
            //
            base.m_category = "WSLTools"; //localizable text
            base.m_caption = "WSLTools.WWAssetUpdate";  //localizable text
            base.m_message = "WSLTools.WWAssetUpdate";  //localizable text 
            base.m_toolTip = "AssetUpdate";  //localizable text 
            base.m_name = "WSLTools.WWAssetUpdate";   //unique id, non-localizable (e.g. "MyCategory_ArcMapCommand")

            try
            {
                //
                // TODO: change bitmap name if necessary
                //
                string bitmapResourceName = GetType().Name + ".bmp";
                base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
            }
        }

        #region Overridden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook == null)
                return;

            m_application = hook as IApplication;

            //Disable if it is not ArcMap
            if (hook is IMxApplication)
                base.m_enabled = true;
            else
                base.m_enabled = false;

            // TODO:  Add other initialization code
        }

        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            // TODO: Add cmdWWAssetUpd.OnClick implementation
            using (WCTools.BL.Forms.frmWWAssetUpd vFrmWWAssetUpd = new BL.Forms.frmWWAssetUpd())
            {
                string vLogCurrSessId = DateTime.Now.ToString("yyyyMMdd:hhmmss");
                try
                {
                    vFrmWWAssetUpd.__AppMap = m_application;
                    vFrmWWAssetUpd.vLogSessionId = vLogCurrSessId;
                    vFrmWWAssetUpd.helpersActivate();
                    if (vFrmWWAssetUpd.validateOnLoad())
                    {
                        vFrmWWAssetUpd.updAttributes();
                        //vFrmWWAssetUpd.ShowDialog();
                    }

                }
                catch (Exception e)
                {
                    MessageBox.Show("GPF!  -> " + e.Message.ToString());
                    vFrmWWAssetUpd.logNtry("WCTools", "SetGISIdMulti", e.Message.ToString(), vLogCurrSessId, "EXP");
                }
                finally
                {
                    vFrmWWAssetUpd.helpersDeActivate();
                }

            }

        }

        #endregion
    }
}
