﻿using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCToolsBulk.BL.Classes
{
        #region "DataStructureSection"
        public class  structAssetItemChanges
        {
            public string vLyrName = "";
            public string vOCompKey = "";
            public string vODMSLink = "";
            public IFeature vOFeature ;
            public string vNCompKey = "";
            public string vNDMSLink = "";
            public IFeature vNFeature;

            public void setAssetItemChanges(string inLyrName, string inOCompKey, string inODMSLink, string inNCompKey, string inNDMSLink)
            {
                vLyrName = inLyrName;
                vOCompKey = inOCompKey;
                vODMSLink = inODMSLink;
                vNCompKey = inNCompKey;
                vNDMSLink = inNDMSLink;
            }

            public void setOFeature(IFeature inFeat)
            {
                vOFeature = inFeat;
            }
            public void setNFeature(IFeature inFeat)
            {
                vNFeature = inFeat;
            }
        }


        //public struct stuctAssetLyrChanges
        //{
        //    public string vLyrName;
        //    public List<structAssetItemChanges> vLstAssetChanges;

        //    public structAssetItemChanges findAssetItem(string inCompKey)
        //    {
        //        structAssetItemChanges vAsstItem =  null ;
        //        for (int vI = 0; vI < vLstAssetChanges.Count; vI++)
        //        {
        //            vAsstItem = vLstAssetChanges[vI];
        //            if ((vAsstItem.vOCompKey == inCompKey) || (vAsstItem.vNCompKey == inCompKey))
        //            {
        //                break;
        //            }
        //        }
        //        return vAsstItem;
        //    }
        //    public stuctAssetLyrChanges(string inLyrName, List<structAssetItemChanges> inLstAssetChanges)
        //    {
        //        vLyrName = inLyrName;
        //        vLstAssetChanges = inLstAssetChanges;
        //    }
        //}

        public static class cLstStructures
        {
            public static string vLyrName;
            public static List<structAssetItemChanges> vLstAssetChanges;

            //public cLstStructures()
            //{
            //    vLstAssetChanges = new List<structAssetItemChanges>();
            //}
            public static void crtVariables()
            {
                vLstAssetChanges = new List<structAssetItemChanges>();
            }

            public static structAssetItemChanges findAssetItem(string inCompKey)
            {
                structAssetItemChanges vAsstItem = null;

                for (int vI = 0; vI < vLstAssetChanges.Count; vI++)
                {
                    vAsstItem = vLstAssetChanges[vI];
                    if ((vAsstItem.vOCompKey == inCompKey) || (vAsstItem.vNCompKey == inCompKey))
                    {
                        break;
                    }
                }
                return vAsstItem;
            }
            public static void stuctAssetLyrChanges(string inLyrName, List<structAssetItemChanges> inLstAssetChanges)
            {
                vLyrName = inLyrName;
                vLstAssetChanges = inLstAssetChanges;
            }
            public static void addStuctAssetLyrChanges(structAssetItemChanges inStructAssetItemChanges)
            {
                vLstAssetChanges.Add(inStructAssetItemChanges);
            }
        }

        #endregion
    //class cLstStructures
    //{
    //    public List<stuctAssetLyrChanges> vLstAssetLyrChanges;

    //    public cLstStructures()
    //    {
    //        vLstAssetLyrChanges = new List<stuctAssetLyrChanges>();
    //    }
    //}
}
