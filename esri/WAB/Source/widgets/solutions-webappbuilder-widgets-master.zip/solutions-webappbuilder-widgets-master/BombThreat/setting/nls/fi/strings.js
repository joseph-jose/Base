﻿define({
    left: "VASEN",
    right: "OIKEA",
    arrangement: "Asettelu",
    autoUpdate: "Automaattinen päivitys",
    respectCurrentMapScale: "Nykyisen kartan mittakaavan suhteessa"
});