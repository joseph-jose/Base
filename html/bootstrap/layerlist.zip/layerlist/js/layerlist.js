$(document).ready(function() {
    $('#myTable').DataTable( {
        "order": [[ 2, "asc" ]],
        "columnDefs": [
          { "orderable": false, "targets": [3,4,5,6,7,8,9,10,11,12,13]},
          { "bSearchable": false, "aTargets": [ 1,2,3,4,5,6,7,8,9,10,11,12,13 ] }
        ],
        "iDisplayLength":25,
        "scrollX": false,
        "scrolly": true
    } );
} );

// load this function for all websites in order for the header and footer to load on each website
$(function(){
  console.log("ddwadwa")
  $("#nav").load("shared/_nav.html"); 
  $("#footer").load("shared/_footer.html"); 
});

