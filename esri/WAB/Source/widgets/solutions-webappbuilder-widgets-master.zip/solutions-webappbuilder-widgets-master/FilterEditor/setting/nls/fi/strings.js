﻿define(
   ({
    enableUndoRedo: "Ota käyttöön Kumoa / Tee uudelleen",
    toolbarVisible: "Työkalupalkki näkyvissä",
    toolbarOptions: "Työkalupalkin asetukset",
    mergeVisible: "Sulauta kohteet",
    cutVisible: "Leikkaa",
    reshapeVisible: "Muotoile uudelleen",
    back: "Takaisin",
    label: "Karttataso",
    edit: "Muokattavissa",
    update: "Poista käytöstä geometrian päivitys",
    fields: "Kentät",
    actions: "Toimet",
    editpageName: "Nimi",
    editpageAlias: "Alias",
    editpageVisible: "Näkyvä",
    editpageEditable: "Muokattavissa",
    noLayers: "Muokattavia kohdekarttatasoja ei ole käytettävissä",
    configureFields: "Määritä karttatason kentät"
  })
);