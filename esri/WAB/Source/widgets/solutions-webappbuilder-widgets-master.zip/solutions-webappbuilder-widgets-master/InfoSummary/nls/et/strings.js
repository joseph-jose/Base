﻿define(
   ({
    title: "Info kokkuvõtte vidin",
    helpText: "Märkus. Info kokkuvõtte spikritekst",
    labels: {
      status: "Olek",
      result: "Tulemus"
    },
    _widgetLabel: "Teabe kokkuvõte (beeta)"
  })
);