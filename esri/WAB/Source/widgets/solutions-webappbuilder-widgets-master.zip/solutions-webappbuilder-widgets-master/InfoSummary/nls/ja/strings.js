﻿define(
   ({
    title: "情報サマリー ウィジェット",
    helpText: "TODO 情報サマリー ヘルプ テキスト",
    labels: {
      status: "ステータス",
      result: "結果"
    },
    _widgetLabel: "情報サマリー (ベータ版)"
  })
);