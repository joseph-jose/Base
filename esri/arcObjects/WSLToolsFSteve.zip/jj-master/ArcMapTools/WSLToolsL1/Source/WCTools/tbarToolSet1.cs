using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.ADF.BaseClasses;

namespace WCTools
{
    /// <summary>
    /// Summary description for tbarToolSet1.
    /// </summary>
    [Guid("6accdca3-9afb-4be2-b7e7-99386af7ad9f")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("WCTools.tbarToolSet1")]
    public sealed class tbarToolSet1 : BaseToolbar
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommandBars.Register(regKey);
        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommandBars.Unregister(regKey);
        }

        #endregion
        #endregion

        public tbarToolSet1()
        {
            //
            // TODO: Define your toolbar here by adding items
            //
            //AddItem("esriArcMapUI.ZoomInTool");
            //BeginGroup(); //Separator
            //AddItem("{FBF8C3FB-0480-11D2-8D21-080009EE4E51}", 1); //undo command
            //AddItem(new Guid("FBF8C3FB-0480-11D2-8D21-080009EE4E51"), 2); //redo command

            AddItem("{8fa72d90-2063-40c9-87b7-7a61894a715c}", 1); 
            AddItem("{d8d26223-3349-4876-88d1-40cbc70e368e}", 2);
            BeginGroup();
            AddItem("{139c79a4-7b6a-45b4-9cb3-d789a7f3403c}", 1);
            BeginGroup();
            AddItem("{3e50b444-8a0f-4de2-82b1-105d97fb5936}", 1);
            AddItem("{3c1fd966-dd22-47aa-8650-0c194c007652}", 2);
            BeginGroup();
            AddItem("{b1665ffb-1817-48aa-8d7f-4a1f69b5ac2f}", 1);
            //20160330
            //Disabled PW assign - not used in team
            //AddItem("{8a5ae78b-088c-4efa-8f44-cce5f978f7ce}", 3);
            //20160330
            //AddItem("{ab5bf331-8a31-47dc-af4a-684efe387f07}", 4);
            BeginGroup();
            AddItem("{311ef63b-ebc5-4f40-8839-3b842b883c1c}", 1);

        }

        public override string Caption
        {
            get
            {
                //TODO: Replace bar caption
                return "WSL Common";
            }
        }
        public override string Name
        {
            get
            {
                //TODO: Replace bar ID
                return "tbarToolSet1";
            }
        }
    }
}