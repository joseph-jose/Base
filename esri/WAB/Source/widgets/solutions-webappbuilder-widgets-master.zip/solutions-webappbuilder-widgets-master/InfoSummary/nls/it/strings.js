﻿define(
   ({
    title: "Widget InfoSummary",
    helpText: "Testo guida TODO InfoSummary",
    labels: {
      status: "Stato",
      result: "Risultato"
    },
    _widgetLabel: "Riepilogo informazioni (Beta)"
  })
);