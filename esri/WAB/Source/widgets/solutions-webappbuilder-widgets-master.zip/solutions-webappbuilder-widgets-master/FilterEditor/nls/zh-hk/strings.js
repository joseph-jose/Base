﻿define(
   ({
    _widgetLabel: "編輯",
    title: "選擇範本以建立圖徵",
    pressStr: "按 ",
    ctrlStr: " Ctrl 鍵 ",
    snapStr: " 啟用貼齊"
  })
);