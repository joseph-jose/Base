﻿define({
    select: "ø_Select_å",
    results: "ø_Results_å",
    selectLayer: "ø_Select from layer:_å",
    selectDrawtool: "ø_Select draw tool:_å",
    result: "ø_Result:_å",
    noresult: "ø_No query results to display chart._å",
    nomedia: "ø_There's no media in configuration!_å",
    envelop: "ø_Draw Rectangle_å",
    circle: "ø_Draw Circle_å",
    ellipse: "ø_Draw Ellipse_å",
    polygon: "ø_Draw Polygon_å",
    freehand: "ø_Draw Freehand Polygon_å",
    clear:"ø_Clear_å"
});