﻿define({
    select: "Š_Select_ä",
    results: "Š_Results_ä",
    selectLayer: "Š_Select from layer:_ä",
    selectDrawtool: "Š_Select draw tool:_ä",
    result: "Š_Result:_ä",
    noresult: "Š_No query results to display chart._ä",
    nomedia: "Š_There's no media in configuration!_ä",
    envelop: "Š_Draw Rectangle_ä",
    circle: "Š_Draw Circle_ä",
    ellipse: "Š_Draw Ellipse_ä",
    polygon: "Š_Draw Polygon_ä",
    freehand: "Š_Draw Freehand Polygon_ä",
    clear:"Š_Clear_ä"
});