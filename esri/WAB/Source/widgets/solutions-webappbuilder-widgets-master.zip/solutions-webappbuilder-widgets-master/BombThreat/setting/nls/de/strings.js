﻿define({
    left: "LINKS",
    right: "RECHTS",
    arrangement: "Anordnung",
    autoUpdate: "Automatische Aktualisierung",
    respectCurrentMapScale: "Aktuellen Kartenmaßstab berücksichtigen"
});