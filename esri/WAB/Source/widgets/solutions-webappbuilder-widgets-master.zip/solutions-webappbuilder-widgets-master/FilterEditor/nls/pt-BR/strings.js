﻿define(
   ({
    _widgetLabel: "Editar",
    title: "Selecione um modelo para criar feições",
    pressStr: "Pressionar ",
    ctrlStr: " CTRL ",
    snapStr: " para habilitar o ajuste"
  })
);