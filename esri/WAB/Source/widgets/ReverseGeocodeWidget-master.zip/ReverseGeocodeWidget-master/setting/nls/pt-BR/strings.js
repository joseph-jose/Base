﻿define({
    unit: "ã_Unit_Ç",
    style: "ã_Style_Ç"
});