﻿using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCTools.BL.Classes;

namespace WCTools.BL.Forms
{
    public partial class frmPWAssgn : Form
    {
        //string __VFrmMode="";
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }
        //private IFeature __SelFeat;

        private string __LogSessId = "";
        public string __LogSessionId { set { __LogSessId = value; } }

        WCTools.BL.Classes.cDbSqlFile __DbFile;
        WCTools.BL.Classes.cUtilFile __UtilFile;
        WCTools.BL.Classes.cUtilGIS __GISUtil;
    #region Helpers
        public void helpersActivate()
        {
            __DbFile = new cDbSqlFile();
            __UtilFile = new cUtilFile();
            __GISUtil = new cUtilGIS();
            __GISUtil.vAppMap = __App;

            connDB();
            logNtry("WCTools", "PWAssign", "Start", __LogSessId, "TRC");
        }
        //private IFeature __SelFeature;
        public void helpersDeActivate()
        {
            logNtry("WCTools", "PWAssign", "End", __LogSessId, "TRC");
            //if (!(__SelFeature == null))
            //{
            //    Marshal.ReleaseComObject(__SelFeature);
            //}
            __DbFile.CleanUpDBConnection();
            __DbFile.Dispose();
            __DbFile = null;
            __GISUtil.Dispose();
            __GISUtil = null;
        }

        public void loadGrdFFeat(IFeature inFeat)
        {
            object vFldVal = null;
            string vFldValStr = "";
            int vFldIdx = -1;
            dtGrdLst.Rows.Add();

            vFldValStr = inFeat.Class.AliasName.ToString();
            dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colFClsName"].Value = vFldValStr;

            vFldValStr = "";
            vFldVal = __GISUtil.getFieldValue(inFeat, "OBJECTID");
            if (!(vFldVal == null))
            {
                vFldValStr = vFldVal.ToString();
            }
            dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colObjId"].Value = vFldValStr;

            vFldVal = null;
            vFldValStr = "";
            vFldIdx = __GISUtil.getFieldIdx(inFeat, "EQUIP_ID");
            if (!(vFldIdx == -1))
            {
                vFldVal = __GISUtil.getFieldValue(inFeat, "EQUIP_ID");
                if (!(vFldVal == null))
                {
                    vFldValStr = vFldVal.ToString();
                }
                dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colEqpId"].Value = vFldValStr;
            }

            vFldVal = null;
            vFldValStr = "";
            vFldIdx = __GISUtil.getFieldIdx(inFeat, "COMPKEY");
            if (!(vFldIdx == -1))
            {
                vFldVal = __GISUtil.getFieldValue(inFeat, "COMPKEY");
                if (!(vFldVal == null))
                {
                    vFldValStr = vFldVal.ToString();
                }
                dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colCompKey"].Value = vFldValStr;
            }
            vFldIdx = __GISUtil.getFieldIdx(inFeat , "CREATEBY");
            if (!(vFldIdx ==  -1))
            {
                vFldVal = __GISUtil.getFieldValue(inFeat, "CREATEBY");                
                dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colCrtby"].Value = vFldVal as string;
            }
            vFldIdx = __GISUtil.getFieldIdx(inFeat, "MODIFYBY");
            if (!(vFldIdx == -1))
            {
                vFldVal = __GISUtil.getFieldValue(inFeat, "MODIFYBY");
                dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colModby"].Value = vFldVal as string;
            }
            vFldIdx = __GISUtil.getFieldIdx(inFeat, "CREATEDATE");
            if (!(vFldIdx ==  -1))
            {
                vFldVal = __GISUtil.getFieldValue(inFeat, "CREATEDATE");
                vFldValStr = "";
                if (!(vFldVal == null))
                {
                    vFldValStr = vFldVal.ToString();
                    DateTime vDtTm;
                    if (DateTime.TryParse(vFldValStr, out vDtTm))
                    {
                        vFldValStr = string.Format("{0:dd/MM/yyyy}", vFldValStr);
                        dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colCrtDt"].Value = vFldValStr;
                    }
                }
            }

            vFldVal = null;
            vFldValStr = "";
            vFldIdx = __GISUtil.getFieldIdx(inFeat, "GIS_ID");
            if (!(vFldIdx == -1))
            {
                vFldVal = __GISUtil.getFieldValue(inFeat, "GIS_ID");
            }
            //20160921  New Netview
            //else
            //{
            //    vFldIdx = __GISUtil.getFieldIdx(inFeat, "RGIS_ID");
            //    if (!(vFldIdx == -1))
            //    {
            //        vFldVal = __GISUtil.getFieldValue(inFeat, "RGIS_ID"); 
            //    }
            //}
            //20160921
            vFldValStr = "";
            if (!(vFldVal == null))
            {
                vFldValStr = vFldVal.ToString();
                dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colGISId"].Value = vFldValStr;
            }
        }

        public bool validateOnLoad()
        {
            bool vResFn = true;
            int vFldIdx = 0;
            vFldIdx = __GISUtil.getFeatureSelectCount();

            if (vFldIdx == 0)
            {
                MessageBox.Show("No features selected");
                vResFn = false;
                return vResFn;
            }
            if (vFldIdx > 100)
            {
                MessageBox.Show("Maximum 100 features allowed at a time");
                vResFn = false;
                return vResFn;
            }


            dtGrdLst.Columns.Add("colFClsName", "Feature class");
            dtGrdLst.Columns.Add("colObjId", "ObjectId");
            dtGrdLst.Columns.Add("colGISId", "GIS_Id");
            dtGrdLst.Columns.Add("colDMSLnk", "DMS_LINK");
            dtGrdLst.Columns.Add("colEqpId", "Equip_Id");
            dtGrdLst.Columns.Add("colCompKey", "CompKey");
            dtGrdLst.Columns.Add("colCrtby", "Createby");
            dtGrdLst.Columns.Add("colModby", "Modifyby");
            dtGrdLst.Columns.Add("colCrtDt", "CreateDate");

            List<string> vClassNames = new List<string>();

            string vFeatClsName = "";
            vFldIdx = 0;
            IFeature vFeat;
            IWorkspaceEdit vWrkSpcEdit = null;
            object vObjVal;
            IEnumFeature vEnmFeat = __GISUtil.getSelectedFeatures();
            vEnmFeat.Reset();
            vFeat = vEnmFeat.Next();

            try
            {
                while (!(vFeat == null))
                {
                    vFeatClsName = vFeat.Class.AliasName.ToString();
                    if ((vClassNames.IndexOf(vFeatClsName) == -1))
                    {
                        vClassNames.Add(vFeatClsName);
                        vFldIdx = __GISUtil.getFieldIdx(vFeat, "DMS_LINK");
                        if ((vFldIdx == -1 ))
                        {
                            MessageBox.Show("Attribute DMS_LINK missing for feature class: " + vFeatClsName);
                            vResFn = false;
                            break;
                        }

                        vWrkSpcEdit = __GISUtil.getWrkSpcFFeature(vFeat);
                        if (!(vWrkSpcEdit.IsBeingEdited()))
                        {
                            MessageBox.Show("Feature not in edit mdoe for feature class: " + vFeatClsName);
                            vResFn = false;
                            break;
                        }
                    }
                    vObjVal = __GISUtil.getFieldValue(vFeat, "DMS_LINK");
                    if (!(vObjVal is System.DBNull))
                    {
                        MessageBox.Show("Attribute DMS_LINK already set for one feature in feature class: " + vFeatClsName);
                        vResFn = false;
                        break;
                    }

                    vFldIdx = __GISUtil.getFieldIdx(vFeat, "Modifyby");
                    if ((vFldIdx ==  -1))
                    {
                        MessageBox.Show("Attribute Modify by missing for feature class: " + vFeatClsName);
                        vResFn = false;
                        break;
                    }
                    vObjVal = __GISUtil.getFieldValue(vFeat, "Modifyby");
                    if (!(vObjVal.ToString().Trim().ToUpper() == Environment.UserName.ToUpper()))
                    {
                        MessageBox.Show("One feature selected not created by current user in feature class : " + vFeatClsName);
                        vResFn = false;
                        break;
                    }

                    loadGrdFFeat(vFeat);

                    vFeat = vEnmFeat.Next();
                }


            }
            finally
            {
                if (!(vWrkSpcEdit == null))
                {
                    Marshal.ReleaseComObject(vWrkSpcEdit);
                }
                Marshal.ReleaseComObject(vEnmFeat);
                vClassNames = null;
            }

            return vResFn;
        }


        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            if (!(__UtilFile.logNtry(__DbFile, inCmdType, inMsg, inFld1, inSessId, inLogType)))
            {
                MessageBox.Show("GPF-> Logging failed"); 
            }
        }


        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

    #endregion



        ~frmPWAssgn()
        {
            helpersDeActivate();
        }


        public bool updPWLnkFFeatures()
        {
            bool vResFn = false;

            IFeature vFeat;
            IWorkspaceEdit vWrkSpcEdit = null;
            //object vObjVal;
            IEnumFeature vEnmFeat = __GISUtil.getSelectedFeatures();
            vEnmFeat.Reset();
            vFeat = vEnmFeat.Next();

            try
            {
                IWorkspaceEdit vWrkSpcEdt = __GISUtil.getWrkSpcFFeature(vFeat);
                vWrkSpcEdt.StartEditOperation();

                while (!(vFeat == null))
                {
                    __GISUtil.setFieldValue(vFeat, "DMS_LINK", txtPhLnk.Text);
                    vFeat = vEnmFeat.Next();
                }
                vWrkSpcEdt.StopEditOperation(); 
            }
            finally
            {
                if (!(vWrkSpcEdit == null))
                {
                    Marshal.ReleaseComObject(vWrkSpcEdit);
                }
                Marshal.ReleaseComObject(vEnmFeat);
            }

            vResFn = true;
            return vResFn;
        }

        public void prepFrmInEdtMode()
        {

        }

        public frmPWAssgn()
        {
            InitializeComponent();
        }

        private bool valCntrls()
        {
            bool retRes = true;

            if (txtPhLnk.Text.Trim() == "")
            {
                MessageBox.Show("Enter PWLink");
                txtPhLnk.Focus();
                retRes = false;
            }

            if (!(__DbFile.Connected))
            {
                connDB();
            }

            string vSqlStr = "SELECT * FROM [GISWSL].[WA_PWLINK] WHERE PW_REF = '{0}' ORDER BY MODIFYDATE DESC";
            vSqlStr = string.Format(vSqlStr, txtPhLnk.Text.Trim());
            DataTable vDtTbl = __DbFile.getDtTblRecs(vSqlStr);

            if (vDtTbl.Rows.Count == 0)
            {
                MessageBox.Show("Project wise link not available");
                txtPhLnk.Focus();
                retRes = false;

            }

            vDtTbl = null;

            return retRes ;

        }

        private void btnCnfrm_Click(object sender, EventArgs e)
        {
            string vUnqKey = "";
            this.Cursor = Cursors.WaitCursor; 
            try
            {
                if (valCntrls() == false)
                {
                    return;
                }
                updPWLnkFFeatures();
                for (int i = 0; i < dtGrdLst.RowCount; i++)
                {
                    if (!(dtGrdLst.Rows[i].Cells["colCompKey"].Value == null))
                    {
                        vUnqKey = dtGrdLst.Rows[i].Cells["colCompKey"].Value.ToString();
                    }
                    if (vUnqKey.Trim() == "")
                    {
                        if (!(dtGrdLst.Rows[i].Cells["colEqpId"].Value == null))
                        {
                            vUnqKey = dtGrdLst.Rows[i].Cells["colEqpId"].Value.ToString();
                        }
                    }
                    logNtry("WCTools", "PWAssign", vUnqKey, __LogSessId, "TRC");
                    vUnqKey = "";
                    dtGrdLst.Rows[i].Cells["colDMSLnk"].Value = txtPhLnk.Text.ToString();
                }
                txtPhLnk.ReadOnly = true;
                btnCnfrm.Enabled = false; 
            }
            catch (Exception ex)
            {
                logNtry("WCTools", "exception" + ex.Message.ToString(), txtPhLnk.Text, __LogSessId, "TRCE");
                MessageBox.Show("GPF->  " + ex.Message.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ////using (frmPWLst vFrmPWLst = new frmPWLst())
            ////{
            ////    txtPhLnk.Text = vFrmPWLst.prepFrmToCallFOther(); 
            ////}
            //using (WCTools.BL.Forms.frmPWLst vFrmPWLst = new WCTools.BL.Forms.frmPWLst())
            //{
            //    string vLogCurrSessId = DateTime.Now.ToString("yyyymmdd:hhmmss");
            //    vFrmPWLst.__LogSessionId = vLogCurrSessId;

            //    vFrmPWLst.__AppMap = __App;
            //    vFrmPWLst.helpersActivate();
            //    string vPhLnkId = "";
            //    try
            //    {
            //        if (!(vFrmPWLst.validateOnLoad(out vPhLnkId)))
            //        {
            //            return;
            //        }
            //        txtPhLnk.Text = vFrmPWLst.prepFrmToCallFOther(); 
            //        //TODO show dialog and load equipments
            //    }
            //    catch (Exception e)
            //    {
            //        MessageBox.Show("GPF!  -> " + e.Message.ToString());
            //        vFrmPWLst.logNtry("WCTools", "UpdPHUpdates", e.Message.ToString(), vLogCurrSessId, "EXP");

            //    }
            //    finally
            //    {
            //        vFrmPWLst.helpersDeActivate();
            //    }
            //}
        }

        private void BtnCls_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
