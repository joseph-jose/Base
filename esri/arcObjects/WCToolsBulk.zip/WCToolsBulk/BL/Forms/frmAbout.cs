﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            Assembly vAssmbly = Assembly.GetExecutingAssembly();
            FileVersionInfo vFlVerInfo = FileVersionInfo.GetVersionInfo(vAssmbly.Location);

            lblFlVer.Text = "File version: " + vFlVerInfo.FileVersion;
            lblProdVer.Text = "Product version: " + vFlVerInfo.ProductVersion;
            lblComp.Text = "Company: " +vFlVerInfo.CompanyName;  
        }
    }
}
