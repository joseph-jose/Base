﻿define({
    unit: "Š_Unit_ä",
    style: "Š_Style_ä"
});