﻿define(
   ({
    title: "정보 요약 위젯",
    helpText: "TODO 정보 요약 도움말 텍스트",
    labels: {
      status: "상태",
      result: "결과"
    },
    _widgetLabel: "정보 요약(베타)"
  })
);