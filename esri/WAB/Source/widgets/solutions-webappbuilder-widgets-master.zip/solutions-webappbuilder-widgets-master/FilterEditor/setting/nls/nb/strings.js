﻿define(
   ({
    enableUndoRedo: "Aktiver Angre/Gjenta",
    toolbarVisible: "Verktøylinje synlig",
    toolbarOptions: "Verktøylinjealternativer",
    mergeVisible: "Slå sammen",
    cutVisible: "Klipp ut",
    reshapeVisible: "Omforme",
    back: "Bak",
    label: "Lag",
    edit: "Redigerbar",
    update: "Deaktiver geometrioppdatering",
    fields: "Felter",
    actions: "Handlinger",
    editpageName: "Navn",
    editpageAlias: "Alias",
    editpageVisible: "Synlig",
    editpageEditable: "Redigerbar",
    noLayers: "Det er ingen redigerbare geoobjektlag tilgjengelig",
    configureFields: "Konfigurer felter for lagene"
  })
);