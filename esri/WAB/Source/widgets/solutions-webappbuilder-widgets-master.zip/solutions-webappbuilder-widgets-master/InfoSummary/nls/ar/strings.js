﻿define(
   ({
    title: "عنصر واجهة مستخدم InfoSummary",
    helpText: "نص تعليمات TODO InfoSummary",
    labels: {
      status: "الحالة",
      result: "النتيجة"
    },
    _widgetLabel: "ملخص المعلومات (بيتا)"
  })
);