﻿define(
   ({
    title: "InfoSummary-Widget",
    helpText: "TODO-InfoSummary-Hilfetext",
    labels: {
      status: "Status",
      result: "Ergebnis"
    },
    _widgetLabel: "Info-Zusammenfassung (Beta)"
  })
);