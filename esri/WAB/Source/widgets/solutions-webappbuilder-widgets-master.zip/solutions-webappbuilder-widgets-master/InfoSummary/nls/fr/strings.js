﻿define(
   ({
    title: "Widget Résumé infos",
    helpText: "A FAIRE : texte d’aide Résumé infos",
    labels: {
      status: "Statut",
      result: "Résultat"
    },
    _widgetLabel: "Résumé infos (Bêta)"
  })
);