﻿define(
   ({
    enableUndoRedo: "Aktivovat funkci Zpět/Znovu (krok vpřed)",
    toolbarVisible: "Viditelná lišta nástrojů",
    toolbarOptions: "Možnosti lišty nástrojů",
    mergeVisible: "Sloučit",
    cutVisible: "Vyjmout",
    reshapeVisible: "Změnit tvar",
    back: "Zpět",
    label: "Vrstva",
    edit: "Upravitelné",
    update: "Zakázat aktualizaci geometrie",
    fields: "Pole",
    actions: "Akce",
    editpageName: "Název",
    editpageAlias: "Přezdívka",
    editpageVisible: "Viditelná",
    editpageEditable: "Upravitelné",
    noLayers: "K dispozici nejsou žádné vrstvy prvků, které by bylo možno upravit.",
    configureFields: "Konfigurovat pole vrstvy"
  })
);