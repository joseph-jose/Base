﻿define(
   ({
    enableUndoRedo: "Ενεργοποίηση Αναίρεσης/Επανάληψης",
    toolbarVisible: "Ορατή γραμμή εργαλείων",
    toolbarOptions: "Επιλογές γραμμής εργαλείων",
    mergeVisible: "Συγχώνευση",
    cutVisible: "Αποκοπή",
    reshapeVisible: "Ανασχεδίαση",
    back: "Επιστροφή",
    label: "Θεματικό Επίπεδο",
    edit: "Με δυνατότητα επεξεργασίας",
    update: "Απενεργοποίηση ενημέρωσης γεωμετρίας",
    fields: "Πεδία",
    actions: "Ενέργειες",
    editpageName: "Όνομα",
    editpageAlias: "Ψευδώνυμο",
    editpageVisible: "Ορατό",
    editpageEditable: "Επεξεργάσιμο",
    noLayers: "Δεν υπάρχουν διαθέσιμα feature layers με δυνατότητα επεξεργασίας",
    configureFields: "Διαμόρφωση πεδίων θεματικού επιπέδου"
  })
);