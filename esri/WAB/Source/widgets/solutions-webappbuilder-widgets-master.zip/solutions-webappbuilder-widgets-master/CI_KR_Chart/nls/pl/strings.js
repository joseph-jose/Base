﻿define({
    select: "ł_Select_ą",
    results: "ł_Results_ą",
    selectLayer: "ł_Select from layer:_ą",
    selectDrawtool: "ł_Select draw tool:_ą",
    result: "ł_Result:_ą",
    noresult: "ł_No query results to display chart._ą",
    nomedia: "ł_There's no media in configuration!_ą",
    envelop: "ł_Draw Rectangle_ą",
    circle: "ł_Draw Circle_ą",
    ellipse: "ł_Draw Ellipse_ą",
    polygon: "ł_Draw Polygon_ą",
    freehand: "ł_Draw Freehand Polygon_ą",
    clear:"ł_Clear_ą"
});