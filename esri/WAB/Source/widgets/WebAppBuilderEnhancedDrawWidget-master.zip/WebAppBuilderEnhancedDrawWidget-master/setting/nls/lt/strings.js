﻿define(
   ({
    addDistance: "Pridėti ilgio vienetą",
    addArea: "Pridėti ploto vienetą",
    label: "Žymė",
    abbr: "Trumpinys",
    conversion: "Konvertavimas",
    actions: "Veiksmai",
    areaUnits: "Ploto vienetai",
    distanceUnits: "Ilgio vienetai",
    kilometers: "Kilometrai",
    miles: "Mylios",
    meters: "Metrai",
    feet: "Pėdos",
    yards: "Jardai",
    squareKilometers: "Kvadratiniai kilometrai",
    squareMiles: "Kvadratinės mylios",
    acres: "Akrai",
    hectares: "Hektarai",
    squareMeters: "Kvadratiniai metrai",
    squareFeet: "Kvadratinė pėda",
    squareYards: "Kvadratiniai jardai",
    distance: "Atstumai",
    area: "Plotai"
  })
);