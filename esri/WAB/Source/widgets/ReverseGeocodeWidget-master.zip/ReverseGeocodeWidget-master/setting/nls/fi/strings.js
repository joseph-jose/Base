﻿define({
    unit: "Å_Unit_ö",
    style: "Å_Style_ö"
});