﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools
{
    public partial class frmPHDet : Form
    {
        //const string fldrPath = "G:\\Library\\Photos\\";
        string __fldrPath ="";
        string __phtAllwXtns = "";
        //string vFldr = "";
        public frmPHDet()
        {
            InitializeComponent();
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;

            Dictionary<string, string> vItmType = new Dictionary<string, string>();
            vItmType.Add("MFL", "Multi Feature Link");
            vItmType.Add("SFL", "Single Feature Link");
            cmbPhType.DataSource = new BindingSource(vItmType, null);
            cmbPhType.DisplayMember = "Value";
            cmbPhType.ValueMember = "Key";
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        public void setPhotoPath(string inPath)
        {
            __fldrPath = inPath;
            opnFlDlg.InitialDirectory = __fldrPath;
        }

        public void setAllowedExtensions(string inPath)
        {
            __phtAllwXtns = inPath;
        }

        public DialogResult setNewMode(ref string inFlName, ref string inPhType, ref DateTime inDtTm, ref string inComm, ref string inFldr)
        {
            DialogResult vDlgRes = DialogResult.Cancel;
            txtFlNm.Text = "";
            cmbPhType.Text = "";
            dtTmDtTkn.Value = DateTime.Today;
            txtFldComm.Text = "";
            if (this.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                inFlName = Path.GetFileName ( txtFlNm.Text);
                //inPhType = cmbPhType.Text;
                inPhType = ((KeyValuePair<string, string>)cmbPhType.SelectedItem).Key.ToString(); 

                if (dtTmDtTkn.Value == dtTmDtTkn.MinDate)
                    inDtTm = DateTime.MinValue;
                else
                    inDtTm = dtTmDtTkn.Value;
                inComm = txtFldComm.Text;
                inFldr = Path.GetDirectoryName(txtFlNm.Text);
                inFldr = inFldr.Replace(__fldrPath, "");
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        //Open the form and capture the values in edit
        public DialogResult setEdtMode(ref string inFlName, ref string inPhType, ref DateTime inDtTm, ref string inComm, ref string inFldr)
        {
            DialogResult vDlgRes = DialogResult.Cancel;
            if (inDtTm == DateTime.MinValue)
                dtTmDtTkn.Value = dtTmDtTkn.MinDate;
            else
                dtTmDtTkn.Value = inDtTm;
            txtFldComm.Text = inComm;
            //vFldr = inFldr;


            txtFlNm.Text = __fldrPath + inFldr + "\\" + inFlName;
            //cmbPhType.Text = inPhType;
            cmbPhType.SelectedValue = inPhType;

            if (File.Exists(txtFlNm.Text))
            {
                pBox.ImageLocation = txtFlNm.Text;
            }
            if (this.ShowDialog() ==  System.Windows.Forms.DialogResult.OK) 
            {
                inFlName = Path.GetFileName( txtFlNm.Text);
                inPhType = ((KeyValuePair<string, string>)cmbPhType.SelectedItem).Key.ToString(); 
                if (dtTmDtTkn.Value == dtTmDtTkn.MinDate)
                    inDtTm = DateTime.MinValue ;
                else
                    inDtTm = dtTmDtTkn.Value;
                inComm = txtFldComm.Text;
                inFldr = Path.GetDirectoryName(txtFlNm.Text);
                inFldr = inFldr.Replace(__fldrPath, "");
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        //Validate the controls
        private bool ValidateControls()
        {
            bool bretRes = false;
            if (txtFlNm.Text.Trim() == "")
            {
                MessageBox.Show("Select a Photo");
                txtFlNm.Focus();
                return bretRes;
            }
            if (cmbPhType.Text.Trim() == "")
            {
                MessageBox.Show("Select Photo type");
                cmbPhType.Focus();
                return bretRes;
            }
            if (!(File.Exists(txtFlNm.Text)))
            {
                MessageBox.Show("Invalid file selected");
                txtFlNm.Focus();
                return bretRes;
            }
            if (txtFlNm.Text.ToString().IndexOf(__fldrPath) == -1)
            {
                MessageBox.Show("Photo selected not in valid directory");
                txtFlNm.Focus();
                return bretRes;
            }
            if (__phtAllwXtns.IndexOf(Path.GetExtension(txtFlNm.Text), StringComparison.OrdinalIgnoreCase) == -1)
            {
                MessageBox.Show("Invalid file type selected");
                txtFlNm.Focus();
                return bretRes;
            }

            if (dtTmDtTkn.Value > DateTime.Now.Date)
            {
                MessageBox.Show("Future date cannot be selected");
                dtTmDtTkn.Focus();
                return bretRes;
            }
            bretRes = true;
            return bretRes;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (ValidateControls() == false)
                return;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnCncl_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void btnBrwFldr_Click(object sender, EventArgs e)
        {
            if (opnFlDlg.ShowDialog() == DialogResult.OK)
            {
                txtFlNm.Text = opnFlDlg.FileName.ToString();
                pBox.ImageLocation = txtFlNm.Text; 
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }


    }
}
