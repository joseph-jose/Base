﻿define(
   ({
    enableUndoRedo: "실행 취소/다시 실행 사용",
    toolbarVisible: "도구모음 보이기",
    toolbarOptions: "도구모음 옵션",
    mergeVisible: "병합",
    cutVisible: "잘라내기",
    reshapeVisible: "재변형",
    back: "뒤로",
    label: "레이어",
    edit: "편집 가능",
    update: "지오메트리 업데이트 사용 안 함",
    fields: "필드",
    actions: "작업",
    editpageName: "이름",
    editpageAlias: "별칭",
    editpageVisible: "표시",
    editpageEditable: "편집 가능",
    noLayers: "편집 가능한 피처 레이어를 사용할 수 없음",
    configureFields: "레이어 필드 구성"
  })
);