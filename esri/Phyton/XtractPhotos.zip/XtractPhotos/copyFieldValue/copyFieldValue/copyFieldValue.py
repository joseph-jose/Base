import arcpy 
import arcpy.da 

try:

	FCs = arcpy.GetParameterAsText(0)
	arcpy.env.workspace = FCs

	inFeature = "ObservePoints__ATTACH"
	dfieldname = "UniqueIdR"
	sfieldname = "UniqueId"

	with arcpy.da.UpdateCursor(inFeature, [dfieldname, sfieldname]) as cursor:
		for row in cursor:
			row[0] = row[1]
			cursor.updateRow(row)

	print "Values copied successfully"

except Exception as err:
	arcpy.AddError(err)
	print err

#with arcpy.da.UpdateCursor(inFeature, ["UniqueId", "CONTENT_TYPE"]) as cursor:
#    for row in cursor:
#		row[0] = row[1]
#		cursor.updateRow(row)

#with arcpy.UpdateCursor(inFeature) as cursor:
#    for row in cursor:
#		row[7] = row[3]
#		rows.updateRow(row)