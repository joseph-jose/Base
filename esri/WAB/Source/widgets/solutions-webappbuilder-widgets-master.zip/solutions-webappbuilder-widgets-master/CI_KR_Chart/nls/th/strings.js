﻿define({
    select: "ก้_Select_ษฺ",
    results: "ก้_Results_ษฺ",
    selectLayer: "ก้_Select from layer:_ษฺ",
    selectDrawtool: "ก้_Select draw tool:_ษฺ",
    result: "ก้_Result:_ษฺ",
    noresult: "ก้_No query results to display chart._ษฺ",
    nomedia: "ก้_There's no media in configuration!_ษฺ",
    envelop: "ก้_Draw Rectangle_ษฺ",
    circle: "ก้_Draw Circle_ษฺ",
    ellipse: "ก้_Draw Ellipse_ษฺ",
    polygon: "ก้_Draw Polygon_ษฺ",
    freehand: "ก้_Draw Freehand Polygon_ษฺ",
    clear:"ก้_Clear_ษฺ"
});