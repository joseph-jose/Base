﻿namespace WCToolsBulk.BL.Forms.MultiPWLink
{
    partial class frmSetMultiPWLnks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtLyr = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtGrdCompKeys = new System.Windows.Forms.DataGridView();
            this.colLayerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOCompKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colODMSLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNCompKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNDMSLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dtGrdVwItms = new System.Windows.Forms.DataGridView();
            this.colPWId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPWRef = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPWType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colComm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chgBit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnFinish = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeys)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdVwItms)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtLyr);
            this.panel1.Location = new System.Drawing.Point(0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(624, 59);
            this.panel1.TabIndex = 1;
            // 
            // txtLyr
            // 
            this.txtLyr.Location = new System.Drawing.Point(429, 36);
            this.txtLyr.Name = "txtLyr";
            this.txtLyr.Size = new System.Drawing.Size(128, 20);
            this.txtLyr.TabIndex = 0;
            this.txtLyr.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.dtGrdCompKeys);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(0, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(624, 312);
            this.panel3.TabIndex = 3;
            // 
            // dtGrdCompKeys
            // 
            this.dtGrdCompKeys.AllowUserToAddRows = false;
            this.dtGrdCompKeys.AllowUserToDeleteRows = false;
            this.dtGrdCompKeys.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdCompKeys.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colLayerName,
            this.colOCompKey,
            this.colODMSLink,
            this.colNCompKey,
            this.colNDMSLink});
            this.dtGrdCompKeys.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dtGrdCompKeys.Location = new System.Drawing.Point(11, 12);
            this.dtGrdCompKeys.Name = "dtGrdCompKeys";
            this.dtGrdCompKeys.Size = new System.Drawing.Size(587, 116);
            this.dtGrdCompKeys.TabIndex = 24;
            // 
            // colLayerName
            // 
            this.colLayerName.HeaderText = "LayerName";
            this.colLayerName.Name = "colLayerName";
            // 
            // colOCompKey
            // 
            this.colOCompKey.HeaderText = "Old CompKey";
            this.colOCompKey.Name = "colOCompKey";
            // 
            // colODMSLink
            // 
            this.colODMSLink.HeaderText = "Old DMSLink";
            this.colODMSLink.Name = "colODMSLink";
            // 
            // colNCompKey
            // 
            this.colNCompKey.HeaderText = "New CompKey";
            this.colNCompKey.Name = "colNCompKey";
            // 
            // colNDMSLink
            // 
            this.colNDMSLink.HeaderText = "New DMSLink";
            this.colNDMSLink.Name = "colNDMSLink";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(482, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 23;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dtGrdVwItms);
            this.panel4.Location = new System.Drawing.Point(3, 148);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(600, 146);
            this.panel4.TabIndex = 20;
            // 
            // dtGrdVwItms
            // 
            this.dtGrdVwItms.AllowUserToAddRows = false;
            this.dtGrdVwItms.AllowUserToDeleteRows = false;
            this.dtGrdVwItms.AllowUserToResizeRows = false;
            this.dtGrdVwItms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdVwItms.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPWId,
            this.colPWRef,
            this.colPWType,
            this.colDocNo,
            this.colDocType,
            this.colComm,
            this.chgBit});
            this.dtGrdVwItms.Location = new System.Drawing.Point(9, 15);
            this.dtGrdVwItms.MultiSelect = false;
            this.dtGrdVwItms.Name = "dtGrdVwItms";
            this.dtGrdVwItms.ReadOnly = true;
            this.dtGrdVwItms.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGrdVwItms.ShowEditingIcon = false;
            this.dtGrdVwItms.ShowRowErrors = false;
            this.dtGrdVwItms.Size = new System.Drawing.Size(578, 116);
            this.dtGrdVwItms.TabIndex = 4;
            this.dtGrdVwItms.TabStop = false;
            // 
            // colPWId
            // 
            this.colPWId.Frozen = true;
            this.colPWId.HeaderText = "PW Id";
            this.colPWId.Name = "colPWId";
            this.colPWId.ReadOnly = true;
            this.colPWId.Width = 75;
            // 
            // colPWRef
            // 
            this.colPWRef.HeaderText = "PW Ref";
            this.colPWRef.Name = "colPWRef";
            this.colPWRef.ReadOnly = true;
            this.colPWRef.Visible = false;
            // 
            // colPWType
            // 
            this.colPWType.HeaderText = "PW Type";
            this.colPWType.Name = "colPWType";
            this.colPWType.ReadOnly = true;
            // 
            // colDocNo
            // 
            this.colDocNo.HeaderText = "Doc No";
            this.colDocNo.Name = "colDocNo";
            this.colDocNo.ReadOnly = true;
            // 
            // colDocType
            // 
            this.colDocType.HeaderText = "Doc Type";
            this.colDocType.Name = "colDocType";
            this.colDocType.ReadOnly = true;
            this.colDocType.Width = 150;
            // 
            // colComm
            // 
            this.colComm.HeaderText = "Comments";
            this.colComm.Name = "colComm";
            this.colComm.ReadOnly = true;
            this.colComm.Width = 200;
            // 
            // chgBit
            // 
            this.chgBit.HeaderText = "chgBit";
            this.chgBit.Name = "chgBit";
            this.chgBit.ReadOnly = true;
            this.chgBit.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.chgBit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.chgBit.Visible = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 456);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(627, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Controls.Add(this.btnFinish);
            this.panel2.Location = new System.Drawing.Point(4, 384);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(621, 68);
            this.panel2.TabIndex = 4;
            // 
            // btnFinish
            // 
            this.btnFinish.Location = new System.Drawing.Point(445, 24);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(75, 23);
            this.btnFinish.TabIndex = 12;
            this.btnFinish.Text = "Finish";
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(535, 24);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmSetMultiPWLnks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 478);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmSetMultiPWLnks";
            this.Text = "Confirm PW Link";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeys)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdVwItms)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtLyr;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dtGrdCompKeys;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLayerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOCompKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn colODMSLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNCompKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNDMSLink;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dtGrdVwItms;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPWId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPWRef;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPWType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComm;
        private System.Windows.Forms.DataGridViewTextBoxColumn chgBit;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.Button btnClose;
    }
}