﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.Odbc;
using System.Text.RegularExpressions;
using System.Data.SqlClient; 

namespace WCTools.BL.Classes
{
    class cDbFile : cBase
    {
        public const short DBTYPE_ACCESS = 1;
        public const short DBTYPE_ODBC = 2;
        public const short DBTYPE_SQLSRVR = 3;

        public bool Connected;
        //' -- Current DB connection settings --
        public int CurrentDBType;
        public string ConnString;
        public string ConnSysMDB;
        public string ConnUser;
        public string ConnPassword;

        public string CurrentITable;
        public string CurrentDTable;
        public short ErrorLineNum=0;

        public string __SqlSrvrInitCatalog = "";
        //'*** Connection String to use for ADO Connection with Access Database
        //TODO- use string.format for connection string
        private const string adoJetProvider = "Provider=Microsoft.Jet.OLEDB.4.0;Persist Security Info=False;Data Source=";
        private const string adoJetPassword = ";Password=";
        private const string adoJetSystemDb = ";Jet OLEDB:System Database=";
        private DbDataAdapter rsIndex;//'*** ADO Index Table Recordset
        private DbProviderFactory dbFactory;
        private string strIdentifierQuote;

        public DbConnection cnADO; //  '*** ADO Connection Object


        #region "Db Specific"
        //'***************************************
        //'Connect to the database
        //'***************************************
        public void ConnectToDatabase(int ConnType, string connString)
        {
            //string connectionString;

            //' If we are already connected to a database
            //' with the same settings, just exit
            if (Connected == true)
                return;

            //' If we are connected to a database,
            //' close the database before continuing
            CleanUpDBConnection();
            Connected = false;

            //' Build the proper connection string.  If ODBC, the
            //' options line of the OpenDatabase method accepts the
            //' connection string.  If Access, just pass in the
            //' filename
            switch (ConnType)
            {
                case DBTYPE_ACCESS:
                    dbFactory = OleDbFactory.Instance;
                    cnADO = dbFactory.CreateConnection();
                    //'Add the string to specify to use s engine with the database path
                    break;
                case DBTYPE_ODBC:
                    dbFactory = OdbcFactory.Instance;
                    cnADO = dbFactory.CreateConnection();
                    break;
                case DBTYPE_SQLSRVR:
                    dbFactory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                    cnADO = dbFactory.CreateConnection();

                    System.Data.SqlClient.SqlConnection conn = (System.Data.SqlClient.SqlConnection)dbFactory.CreateConnection();

                    break;
                default:
                    //' Invalid Database type
                    throw new ArgumentException("Bad database type selection.", "ConnType");
            }

            //'If there is a connection failure, the exception is caught and handled elsewhere
            cnADO.ConnectionString = connString;

            int nMaxAttempts = 3;
            for (int i = 0; i <= nMaxAttempts; i++)
            {
                try
                {
                    cnADO.Open();
                    //'*** If we get a successful open, exit the loop and continue.
                    break;
                }
                catch (Exception e)
                {
                    //'*** If we are at our last attempt, throw the exception to the caller,
                    //'*** otherwise we will re-try again.
                    if (i == nMaxAttempts)
                        throw e;
                    //'*** Pause half a second, to allow time for the cause of the lock prevention
                    //'*** to resolve (and it may not be possible).
                    System.Threading.Thread.Sleep(500);
                }
            }

            //' We are connected
            Connected = true;

            //' Remember the current DB settings
            CurrentDBType = ConnType;
            ConnString = connString;
            ConnSysMDB = "";
            ConnUser = "";
            ConnPassword = "";

            //' *** Fix the SPR 66104*******************
            //' Use the identifier quote instead of brackets for the table name and the schema
            //'strIdentifierQuote = GetIdentifierQuote(cnADO)
            strIdentifierQuote = "";
        }

        public void ConnectToDatabase(int ConnType, string DatabaseName, string SystemMDB, string UserName, string Password)
        {
            string connectionString;

            //' If we are already connected to a database
            //' with the same settings, just exit
            if (Connected == true)
            {
            }
            if (Connected == true && CurrentDBType == ConnType && ConnString == DatabaseName && ConnSysMDB == SystemMDB && ConnUser == UserName && ConnPassword == Password)
                return;

            //' If we are connected to a database,
            //' close the database before continuing
            CleanUpDBConnection();
            Connected = false;

            //' Build the proper connection string.  If ODBC, the
            //' options line of the OpenDatabase method accepts the
            //' connection string.  If Access, just pass in the
            //' filename
            switch (ConnType)
            {
                case DBTYPE_ACCESS:
                    dbFactory = OleDbFactory.Instance;
                    cnADO = dbFactory.CreateConnection();
                    //'Add the string to specify to use s engine with the database path
                    connectionString = adoJetProvider + DatabaseName;
                    if (String.IsNullOrEmpty(UserName))
                    {
                        UserName = "Admin";
                    }
                    connectionString = String.Concat(connectionString, ";User ID=", UserName);
                    if (!String.IsNullOrEmpty(Password))
                        connectionString = String.Concat(connectionString, adoJetPassword, Password);
                    if (!String.IsNullOrEmpty(SystemMDB))
                        connectionString = String.Concat(connectionString, adoJetSystemDb, SystemMDB);
                    break;
                case DBTYPE_ODBC:
                    dbFactory = OdbcFactory.Instance;
                    cnADO = dbFactory.CreateConnection();
                    connectionString = "DSN=" + DatabaseName;
                    if (!String.IsNullOrEmpty(UserName))
                        connectionString = String.Concat(connectionString, "; uid=", UserName);
                    if (!String.IsNullOrEmpty(Password))
                        connectionString = String.Concat(connectionString, "; pwd=", Password);
                    break;
                case DBTYPE_SQLSRVR:
                    dbFactory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                    cnADO = dbFactory.CreateConnection();

                    System.Data.SqlClient.SqlConnection conn = (System.Data.SqlClient.SqlConnection)dbFactory.CreateConnection();

                    if ((UserName == "") && (Password == "")) //'Assumed windows authenthication
                    {
                        connectionString = "Data Source={0};Initial Catalog={1};Integrated Security=True";
                        connectionString = String.Format(connectionString, DatabaseName, __SqlSrvrInitCatalog);
                    }
                    else
                    {
                        connectionString = "Data Source={0};Initial Catalog={1};User ID={2};Password={3}";
                        connectionString = String.Format(connectionString, DatabaseName, __SqlSrvrInitCatalog, UserName, Password);
                    }
                    break;
                default:
                    //' Invalid Database type
                    throw new ArgumentException("Bad database type selection.", "ConnType");
            }

            //'If there is a connection failure, the exception is caught and handled elsewhere
            cnADO.ConnectionString = connectionString;

            int nMaxAttempts = 10;
            for (int i = 0; i < nMaxAttempts; i++)
            {
                try
                {
                    cnADO.Open();
                    //'*** If we get a successful open, exit the loop and continue.
                    break;
                }
                catch (Exception e)
                {
                    //'*** If we are at our last attempt, throw the exception to the caller,
                    //'*** otherwise we will re-try again.
                    if (i == nMaxAttempts)
                        throw e;
                    //'*** Pause half a second, to allow time for the cause of the lock prevention
                    //'*** to resolve (and it may not be possible).
                    System.Threading.Thread.Sleep(500);
                }
            }

            //' We are connected
            Connected = true;

            //' Remember the current DB settings
            CurrentDBType = ConnType;
            ConnString = DatabaseName;
            ConnSysMDB = SystemMDB;
            ConnUser = UserName;
            ConnPassword = Password;

            //' *** Fix the SPR 66104*******************
            //' Use the identifier quote instead of brackets for the table name and the schema
            //'strIdentifierQuote = GetIdentifierQuote(cnADO)
            strIdentifierQuote = "";
        }
        //'***************************************
        //' <summary>
        //' Utility function to create an ADO.NET command object
        //' using the stored DbConnection
        //' </summary>
        //' <param name="commandText">The SQL text of the command</param>
        //' <returns>An initialized DbCommand</returns>
        //' <remarks></remarks>
        //'***************************************
        public DbCommand CreateCommand(string commandText)
        {
            DbCommand command = dbFactory.CreateCommand();
            command.Connection = cnADO;
            command.CommandText = commandText;
            return command;
        }
        //'***************************************
        //' <summary>
        //' Utility function to create an ADO.NET data adapter
        //' using the stored DbConnection
        //' </summary>
        //' <param name="commandText">The SQL SELECT command to use</param>
        //' <returns>An initialized DbDataAdapter</returns>
        //' <remarks></remarks>
        //'***************************************
        public DbDataAdapter CreateDataAdapter(string commandText)
        {
            DbDataAdapter dataAdapter = dbFactory.CreateDataAdapter();
            dataAdapter.SelectCommand = CreateCommand(commandText);
            DbCommandBuilder commandBuilder = dbFactory.CreateCommandBuilder();

            //'*** Fix the SPR 66104*******************
            //'*** Use the identifier quotes instead of brackets for the identifier delimiters.
            //'*** In the databases we've tested, the suffix quote is identical to the prefix quote
            //'*** The tested databases are:
            //'***    MS Access: the identifier quote is `
            //'***    SQL, Oracle, DB2: the identifier quote is "
            commandBuilder.QuotePrefix = strIdentifierQuote;
            commandBuilder.QuoteSuffix = strIdentifierQuote;
            commandBuilder.DataAdapter = dataAdapter;
            return dataAdapter;
        }
        //'***************************************
        //' Return the schema of connection in a datatable
        //'***************************************
        public DataTable GetSchema(string inTbl)
        {
            return cnADO.GetSchema(inTbl);
        }
        //''' <summary>
        //''' Gets the database dependent quote character used to delimit identifiers.
        //''' </summary>
        //''' <param name="oDBConnection">The database connection that is already opened</param>
        //''' <returns>The identifier quote character.</returns>
        //''' <remarks></remarks>
        private string GetIdentifierQuote(DbConnection oDBConnection)
        {
            string strResult = String.Empty;
            DataTable oDT;
            string strQuotedIdentifierPattern;
            try
            {
                oDT = oDBConnection.GetSchema(DbMetaDataCollectionNames.DataSourceInformation);
                strQuotedIdentifierPattern = System.Text.RegularExpressions.Regex.Unescape(
                  Convert.ToString(oDT.Rows[0][DbMetaDataColumnNames.QuotedIdentifierPattern]));
                if ((strQuotedIdentifierPattern != "") && (strQuotedIdentifierPattern.Length > 0))
                {
                    strResult = strQuotedIdentifierPattern.Substring(0, 1);
                }
            }
            finally
            {
            }

            //'*** Return " by default.
            if (strResult.Length == 0)
            {
                strResult = "";
            }
            return strResult;
        }
        //'***************************************
        //'Executes a query
        //'***************************************
        public bool execQry(string inSql)
        {
            bool resFn = false;

            DbCommand vSqlCmd;

            vSqlCmd = CreateCommand(inSql);
            vSqlCmd.ExecuteNonQuery();
            resFn = true;

            vSqlCmd = null;
            return resFn;
        }
        //'***************************************
        //'Gets datas for a table
        //'***************************************
        public DataTable getDtTblRecs(string inSql)
        {
            DbCommand vSqlCmd;
            DbDataReader vRdr;
            DataTable vDtTbl = new DataTable();

            vSqlCmd = CreateCommand(inSql);
            vRdr = vSqlCmd.ExecuteReader();
            vDtTbl.Load(vRdr);

            vRdr.Close();

            vRdr = null;
            vSqlCmd = null;

            return vDtTbl;
        }

        public int getNewSeq(string inSQL, string inSeqVal)
        {
            //GISWSL.WA_PWLINK_SEQ
            int vResInt = -1;
            SqlParameter vSqlParam1;
            SqlParameter vSqlParam2;
            DbCommand vSqlCmd;
            vSqlCmd = CreateCommand(inSQL);
            vSqlCmd.CommandType = CommandType.StoredProcedure;

            vSqlParam1 = new SqlParameter("@sequenceName", SqlDbType.VarChar, 40);
            //vSqlParam1.Value = "GISWSL.WA_PHLINK_SEQ";
            vSqlParam1.Value = inSeqVal;
            vSqlCmd.Parameters.Add(vSqlParam1);
            vSqlParam2 = new SqlParameter("@nextVal", SqlDbType.Int);
            vSqlParam2.Direction = ParameterDirection.Output;
            vSqlParam2.Value = 1;
            vSqlCmd.Parameters.Add(vSqlParam2);

            vSqlCmd.ExecuteNonQuery();

            vResInt = Convert.ToInt32(vSqlCmd.Parameters["@nextVal"].Value);
            return vResInt;
        }
        //'***************************************
        //'Select specific column from database
        //'***************************************
        public string GetColumnSelect(string strTableName, string strColumnName)
        {
            return String.Concat("SELECT ", strIdentifierQuote,
             strColumnName, strIdentifierQuote, " FROM ",
             strIdentifierQuote, Regex.Replace(strTableName, "\\.", strIdentifierQuote + "." + strIdentifierQuote),
             strIdentifierQuote, " WHERE 1=0");
        }
        #endregion


        #region "IDisposable Support "
        //'***************************************
        //'Clean up connection
        //'Always to be called before a connection is created
        //'***************************************
        public override void CleanUpDBConnection()
        {
            //' Close the database
            if (Connected)
            {
                // Close the recordsets
                if (!(rsIndex == null))
                {
                    rsIndex.Dispose();
                    rsIndex = null;
                }

                //' Disconnect and cleanup
                if (!(cnADO == null))
                {
                    cnADO.Close(); 
                    cnADO.Dispose();
                    cnADO = null;
                }

                CurrentDTable = String.Empty;
                CurrentITable = String.Empty;
                Connected = false;

                dbFactory = null;
            }
        }


        #endregion


    }
}
