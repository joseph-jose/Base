﻿define(
   ({
    enableUndoRedo: "Luba tühistamine ja ennistamine",
    toolbarVisible: "Tööriistariba nähtav",
    toolbarOptions: "Tööriistariba valikud",
    mergeVisible: "Ühenda",
    cutVisible: "Lõika",
    reshapeVisible: "Muuda kuju",
    back: "Tagasi",
    label: "Kiht",
    edit: "Muudetav",
    update: "Keela geomeetria uuendamine",
    fields: "Väljad",
    actions: "Tegevused",
    editpageName: "Nimi",
    editpageAlias: "Alias",
    editpageVisible: "Nähtav",
    editpageEditable: "Muudetav",
    noLayers: "Muudetavaid objektikihte pole saadaval",
    configureFields: "Kihi väljade seadistamine"
  })
);