/*----------------------------------------------------------------------------\
|                           Column List Widget 1.04                           |
|-----------------------------------------------------------------------------|
|                           Created by Emil A Eklund                          |
|                   (http://webfx.eae.net/contact.html#emil)                  |
|                      For WebFX (http://webfx.eae.net/)                      |
|-----------------------------------------------------------------------------|
| A DHTML column list widget. Can be generated from supplied data or attached |
| to an existing html structure. Supports multiple selection, sorting, column |
| resizing, column moving and keyboard navigation.                            |
|-----------------------------------------------------------------------------|
|                Copyright (c) 2004, 2005, 2006 Emil A Eklund                 |
|-----------------------------------------------------------------------------|
| Licensed under the Apache License, Version 2.0 (the "License"); you may not |
| use this file except in compliance with the License.  You may obtain a copy |
| of the License at http://www.apache.org/licenses/LICENSE-2.0                |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
| Unless  required  by  applicable law or  agreed  to  in  writing,  software |
| distributed under the License is distributed on an  "AS IS" BASIS,  WITHOUT |
| WARRANTIES OR  CONDITIONS OF ANY KIND,  either express or implied.  See the |
| License  for the  specific language  governing permissions  and limitations |
| under the License.                                                          |
|-----------------------------------------------------------------------------|
| Dependencies: columnlist.css      Column list style declarations            |
|               sortabletable.js    Provides table sorting functionality      |
|-----------------------------------------------------------------------------|
| Browser compatibility: IE           Verified, 6.0+                          |
|                        Mozilla      Verified, 1.7+ (Firefox 1.0+)           |
|                        Opera        Verified, 8.0+                          |
|                        Safari/KTML: Not Verified                            |
|-----------------------------------------------------------------------------|
| 2004-08-22 | Work started.                                                  |
| 2004-10-24 | First version published.                                       |
| 2004-11-01 | Added resizeColumns property,  allowing column  resizing to be |
|            | enabled/disabled.  Fixed a bug in the  sort method that caused |
|            | getSelectedRow to return an invalid index when called from the |
|            | function triggered by onselect. Misc bugfixes for Mozilla.     |
| 2004-11-23 | Fixed column resizing in mozilla.  It still can't make columns |
|            | smaller than their content, but otherwise it seems to work.    |
| 2005-05-22 | Fixed a bug in the removeRange method for index based removal, |
|            | where the rows where deleted in the wrong order.  Also added a |
|            | clear method, that removes all rows.                           |
| 2005-11-30 | Fixed bug that caused rows to be colored even if colorEvenRows |
|            | was false.  Added  rowSelection,  columnSorting,  moveColumns, |
|            | sortAscImage and sortDescImage properties.  Implemented column |
|            | moving and alignment. Updated column resizing implementation.  |
| 2005-12-08 | Added support for making columns smaller than their content in |
|            | Mozilla, bringing the Mozilla support up to pair with that for |
|            | IE. Also added support for specifying column width on create.  |
| 2005-12-20 | Fixed bug in setCellValue method.                              |
| 2006-03-14 | Fixed bug in getVellValue method, implemented this.moveColumns |
|            | property and fixed an alignment bug.                           |
| 2006-05-27 | Changed license to Apache Software License 2.0.                |
|-----------------------------------------------------------------------------|
| Created 2004-08-22 | All changes are in the log above. | Updated 2006-05-27 |
\----------------------------------------------------------------------------*/

var TYPE_STRING = 0;
var TYPE_NUMBER = 1;
var TYPE_DATE = 2;
var TYPE_STRING_NO_CASE = 3;
var TYPE_ICON = 4;
var TYPE_FUNCTION = 5;
var TYPE_LINK = 6; 

var SORT_ASCENDING = 0;
var SORT_DESCENDING = 1;

var ALIGN_AUTO = "auto";
var ALIGN_LEFT = "left";
var ALIGN_CENTER = "center";
var ALIGN_RIGHT = "right";

var COL_HEAD_NONE = 0;
var COL_HEAD_EDGE = 1;
var COL_HEAD_OVER = 2;
var COL_HEAD_SIZE = 3;
var COL_HEAD_DOWN = 4;
var COL_HEAD_MOVE = 5;

var COMPONENT_WINDOW_TARGET_TYPE = "component-window"; // existing or new component window (will be unique for component type/id).
var WINDOW_TARGET_TYPE = "window"; // existing or new window
var DIALOG_TARGET_TYPE = "dialog";
var SCREEN_TARGET_TYPE = "screen"; // current window or iframe |
var COMPONENT_DIALOG_TARGET_TYPE = "component-dialog";

var PAGE_FIRST = 0;
var PAGE_PREVIOUS = 1;
var PAGE_NEXT = 2;
var PAGE_LAST = 3;
var PAGE_CURRENT = 4;

var COUNT_LOADING_HTML = '<div style="text-align:center;padding-top:70px;">Please wait while counting ... <br /><img src="/ui/images/ajax-load.gif" width="150" height="15"/></div>';
 
var COUNT_RESULT_HTML = '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
COUNT_RESULT_HTML += '<tr><td><table cellpadding="0" cellspacing="10" border="0" width="100%" class="window-header">';
COUNT_RESULT_HTML += '<tr><td><div class="heading" style="white-space:nowrap;">Selection Count</div></td></tr></table></td></tr>';
COUNT_RESULT_HTML += '<tr><td><table cellpadding="0" cellspacing="10" border="0" width="100%">';
COUNT_RESULT_HTML += '<tr><td><table cellpadding="0" cellspacing="10" border="0" width="100%">';
COUNT_RESULT_HTML += '<tr><td>The total items for this criteria is</td>';
COUNT_RESULT_HTML += '<td><div style="background-color:#FFFFFF; margin:10px; text-align:center; font-size:18pt; padding: 5pt 15pt 5pt 15pt"><span id="totalCount"></span></div></td></tr></table></td></tr>';
COUNT_RESULT_HTML += '<tr><td><table cellpadding="0" cellspacing="0" border="0">';
COUNT_RESULT_HTML += '<tr><td width="100%">&nbsp;</td><td><input type="button" name="id0" id="id0" value="Done" onclick="window.close();return false;" class="command-button"></td></tr></table>';
COUNT_RESULT_HTML += '</td></tr></table></td></tr></table>';

/*
 * oColumnList = new WebFXColumnList()
 * Default constructor
 */
function WebFXColumnList(jsVarName, eCont, requestURL, pageSize, xml, displayRefreshButton, displayHeading) {

    /* public properties */
    this.multiple = false;                                                   // Allow multiple selection (true or false)
    this.colorEvenRows = false;                                              // Mark even rows with different color (true or false)
    this.resizeColumns = false;                                              // Enable column resizing (true or false)
    this.bodyColResize = true;                                               // Resize body columns during resize operation (true or false)
    this.moveColumns = false;                                                // Enable column moving (true or false)
    this.rowSelection = false;                                               // Enable row selection (true or false)
    this.columnSorting = true;                                               // Enable sorting (true or false)
    this.columnAlign = true;                                                 // Enable column text alignment (true or false)
    this.selectedId = null;
    this.allowConfig = false;
    this.displayTotal = true;                                               // Shows number of results at the bottom left

    /* public read only properties */
    this.sortCol = 2;                                                        // Column index currently sorted by, read only
    this.sortDescending = 0;                                                 // Column sort direction, read only (SORT_ASCENDING or SORT_DESCENDING)
    this.error = '';                                                         // Error message set if an error code was returned, read only.
    this.selectedRows = [];                                                  // Currently selected rows, read only.

    /* events */
    this.onresize = null;
    this.onsort = null;
    this.onselect = this.updateStatusBar;

    /*refresh button*/
    this._displayRefreshButton = displayRefreshButton;
    this._displayHeading = displayHeading;

    /* private properties */
    if (jsVarName) {
        this._componentID = jsVarName.substring(0, jsVarName.indexOf('_list'));
    }
    this._eCont = document.getElementById(eCont);
    this._eHead = null;
    this._eBody = null;
    this._eFoot = null;
    this._eHeadTable = null;
    this._eBodyTable = null;
    this._eFootTable = null;
    this._eHeadCols = null;
    this._eBodyCols = null;
    this._eFootCols = null;
    this._eMessage = null;
    this._aColumnTypes = [];
    this._aColumnAlign = [];
    this._rows = 0;
    this._cols = 0;
    this._headerOper = COL_HEAD_NONE;
    this._headerData = null;
    this._requestURL = requestURL;
    this._columnDef = [];
    this._fieldDefinitions = [];    
    this._iconData = { 'width':16, 'height':16 };
    this._jsVarName = jsVarName;
    this._pageSize = pageSize ? pageSize : 0;
    this._totalDBSize = null;
    this._currentPage = 0;
    this._totalPages = 0;
    this._countPopup = null;
    this._imageList = {
        'sortAscImage' : preloadImage('/tpportal/images/icons/asc.png', 8, 7),
        'sortDescImage' : preloadImage('/tpportal/images/icons/desc.png', 8, 7),

        'refresh' : preloadImage('/tpportal/images/icons/refresh.png', 16, 16, {'title': 'Refresh', 'class': 'enabled'}),
        'count' : preloadImage('/tpportal/images/icons/count.png', 16, 16, {'title': 'Count', 'class': 'enabled'}),
        'configure' : preloadImage('/tpportal/images/icons/configure.png', 16, 16, {'title': 'Configure List', 'class': 'enabled'}),

        'page_first' : preloadImage('/tpportal/images/icons/paging-first.gif', 30, 20, {'title': 'First Page'}),
        'page_previous' : preloadImage('/tpportal/images/icons/paging-previous.gif', 25, 20, {'title': 'Previous Page'}),
        'page_next' : preloadImage('/tpportal/images/icons/paging-next.gif', 25, 20, {'title': 'Next Page'}),
        'page_last' : preloadImage('/tpportal/images/icons/paging-last.gif', 30, 20, {'title': 'Last Page'})

    };

    this.create();

    if (xml) this.loadXML(xml);

}

WebFXColumnList.prototype.fixSize = function () {
    var dw = (window.innerWidth) ? window.innerWidth : document.documentElement.clientWidth;
    var dh = (window.innerHeight) ? window.innerHeight : document.documentElement.clientHeight;
    if (navigator.userAgent.indexOf("MSIE") == -1) {
        //this.resize(dw-2, this._eCont.style.height);
        this.resize(this._eCont.offsetWidth, this._eCont.style.height);
    }
};

/*
 * iError = create(eContainer, sColumn[])
 * Transforms the supplied container into a column list.
 * sColumn[]   - Array containing column headers
 * sColumn[][] - Two dimensional array with column headers, widths and types
*/
WebFXColumnList.prototype.create = function() {
    var eRow, eCell, eDiv, eImg, eTableBody, eColGroup, eCol, a, b;

    for (var i = this._eCont.childNodes.length - 1; i >= 0; i--) {
        this._eCont.removeChild(this._eCont.childNodes[i]);
    }

    /* Create container, header and body */
    //this._eCont = document.getElementById( eContainerId );
    this._eHead = document.createElement('div');
    this._eBody = document.createElement('div');
    if (this._eCont.className) {
    	if(this._eCont.className != 'webfx-columnlist'){ // stops double ups of the same class name
          this._eCont.className = this._eCont.className + ' webfx-columnlist';
    	}
    } else {
        this._eCont.className = 'webfx-columnlist';
    }
    this._eHead.className = 'webfx-columnlist-head';
    this._eBody.className = 'webfx-columnlist-body';
    if(this._displayHeading){
        this._eCont.appendChild(this._eHead);
    }
    this._eCont.appendChild(this._eBody);

    /* Populate header */
    this._eHeadTable = document.createElement('table');
    //this._eHeadTable.style.width = '100px'; // if a width is not set here the overflow: hidden rule will be ignored by mozilla
    this._eHeadTable.cellSpacing = 0;
    this._eHeadTable.cellPadding = 0;
    this._eHeadTable.style.whiteSpace = 'nowrap';
    this._eHeadTable.style.tableLayout = 'fixed';
    this._eHead.appendChild(this._eHeadTable);
    eTableBody = document.createElement('tbody');
    this._eHeadTable.appendChild(eTableBody);
    eRow = document.createElement('tr');
    eTableBody.appendChild(eRow);

    if (this._columnDef.length == 0) return;

    for (var i = 0; i < this._columnDef.length; i++) {    	
        eCell = document.createElement('td');
        eRow.appendChild(eCell);
        eDiv = document.createElement('div');
        eDiv.style.overflow = 'hidden';
        eDiv.style.whiteSpace = 'nowrap';
        if(this.resizeColumns && i > 0){         
          eDiv.style.borderLeft = '1px solid #ccc'; // only show borders if you can resize columns and don't add border to first column
        }
        eCell.appendChild(eDiv);
        //eDiv.appendChild(document.createTextNode('\u00a0')); // removing space before column headings
        eImg = document.createElement('img');
        if (typeof(this._columnDef[i]) == 'object') {
            eDiv.appendChild(document.createTextNode(this._columnDef[i][0]));            
            if(this._columnDef[i][3] == 'right'){
            	eDiv.style.paddingRight = '10px';
            }
        }
        else {
            eDiv.appendChild(document.createTextNode(this._columnDef[i]));
        }
        eDiv.appendChild(eImg);
    }

    /* Create main table, colgroup and col elements */
    this._eBodyTable = document.createElement('table');
    this._eBodyTable.style.whiteSpace = 'nowrap';
    this._eBodyTable.style.tableLayout = 'fixed';
    this._eBodyTable.style.width = '100%';
    this._eBodyTable.cellSpacing = 0;
    this._eBodyTable.cellPadding = 0;
    this._eBody.appendChild(this._eBodyTable);
    eTableBody = document.createElement('tbody');
    this._eBodyTable.appendChild(eTableBody);
    eColGroup = document.createElement('colgroup');
    //this._eBodyTable.appendChild(eColGroup);
    var tableWidth = 0;

    /*for (var i = 0; i < this._columnDef.length; i++) {
        eCol = document.createElement('col');

        if (parseInt(this._columnDef[i][1]) < 0) {
            this._columnDef[i][1] = parseInt(this._columnDef[i][1]) * -1 + "px";
        }

        if ((typeof(this._columnDef[i]) == 'object') && (this._columnDef[i].length) && (this._columnDef[i].length > 1)) {
            eCol.style.width = this._columnDef[i][1];
            tableWidth += parseInt(this._columnDef[i][1]);
        }
        else {
            eCol.style.width = 'auto';
        }
        if (navigator.userAgent.indexOf("MSIE 6") > -1)
            // IE6 poops its e-pants when you try to appendChild too many times in a row.
            // Same reason Homer Simpson went bald.
            delay(eColGroup.appendChild, eCol, 10);
        else
            eColGroup.appendChild(eCol);
    }*/

    //removed below line to stop the table adding a fixed width
    //if (tableWidth > 0) this._eBodyTable.style.width = tableWidth + "px"; // THIS LINE MAKES COLUMN PIXEL WIDTHS WORK IN FF   

    this.createStatusBar();

    /* Init sortable table */
    this._stl = new SortableTable(this._eBodyTable);

    /* Set column data types */
    a = new Array();
    b = false;
    for (var i = 0; i < this._columnDef.length; i++) {
        if ((typeof(this._columnDef[i]) == 'object') && (this._columnDef[i].length) && (this._columnDef[i].length > 2)) {
            a.push(this._columnDef[i][2]);
            b = true;
        }
        else {
            a.push(TYPE_STRING);
        }
    }

    this._cols = this._columnDef.length;
    this.setColumnAlignment();
    /* Only set explicitly if type was specified for at least one column */
    if (b) {
        this.setColumnTypes(a);
    }

    this._eHeadCols = eRow.cells;
    this._eBodyCols = null;

    this._rows = 0;

    this._init();

    return 0;
};

WebFXColumnList.prototype.isKnownSize = function() {
    return (! this._totalDBSize) || (('' + this._totalDBSize).indexOf('+') < 0);
};

WebFXColumnList.prototype.createStatusBar = function() {
    var ePageTable, eRow, eCell, eDiv, eImg, eTableBody, eColGroup, eCol, a, b, cl;

    cl = this;
    this._eFoot = document.createElement('div');
    this._eFoot.className = 'webfx-columnlist-foot';
    this._eCont.appendChild(this._eFoot);

    /* Create Footer and display columns */
    this._eFootTable = document.createElement('table');
    this._eFootTable.width = "100%";
    this._eFootTable.cellSpacing = 0;
    this._eFootTable.cellPadding = 0;
    this._eFoot.appendChild(this._eFootTable);
    eTableBody = document.createElement('tbody');
    this._eFootTable.appendChild(eTableBody);
    eRow = document.createElement('tr');
    eTableBody.appendChild(eRow);


    // Create left status bar column
    eCell = document.createElement('td');
    eRow.appendChild(eCell);
    if (isMSIEBrowser()) {
        eCell.style.width = Math.floor((document.documentElement.clientWidth - 28) / 2) + "px";	// this is a temporary solution. need to remove subtraction on contant 28.
    } else {
        eCell.style.width = "50%";
    }

    // Create icon container status bar column
    eCell = document.createElement('td');
    eCell.nowrap = "nowrap";
    eRow.appendChild(eCell);

    // Create right status bar column
    eCell = document.createElement('td');
    eCell.align = "right";
    eRow.appendChild(eCell);
    if (isMSIEBrowser()) {
        eCell.style.width = Math.floor((document.documentElement.clientWidth - 28) / 2) + "px";	// this is a temporary solution. need to remove subtraction on contant 28.
    } else {
        eCell.style.width = "50%";
    }

    // Create images for left column
    if (this._displayRefreshButton) {

        eImg = this._imageList['refresh'];
        eImg.onclick = function() {
            cl.loadData();
        }
        eRow.cells[1].appendChild(eImg);

        eImg = this._imageList['count'];
                eImg.onclick = function() { 
                    if (this.className == 'enabled') cl.countTotal();
                }
        eRow.cells[1].appendChild(eImg);        
        eImg.style.display = 'none';
    }

    //Add this back if need to support count function
    // this._countPopup = new WindowPopup('Count Total', COUNT_LOADING_HTML);

    if (this.allowConfig) {
        eImg = this._imageList['configure'];
        eImg.onclick = function() {
            // TODO Popup configuration screen
            // cl.extend_doConfigure();
        }
        eRow.cells[1].appendChild(eImg);
    }

    this._eFootCols = eRow.cells;

    if (this._totalPages > 1 || (! this.isKnownSize())) {

        // Create Table
        ePageTable = document.createElement('table');
        ePageTable.cellSpacing = 0;
        ePageTable.cellPadding = 0;
        ePageTable.border = 0;
        eRow.cells[0].appendChild(ePageTable);
		
	    //Create tBody
        eTableBody = document.createElement('tbody');
        ePageTable.appendChild(eTableBody)
		
	    //Create table row
        eRow = document.createElement('tr');
        eTableBody.appendChild(eRow);
		
	    //Create first cell
        eCell = document.createElement('td');
        eRow.appendChild(eCell);        
        eImg = this._imageList['page_first'];
        eImg.className = ( this._currentPage > 1 ) ? "enabled" : "disabled";
        eImg.onclick = function() {
            cl.loadData(PAGE_FIRST);
        }
        eCell.appendChild(eImg);
		
	    //Create previous cell
        eCell = document.createElement('td');
        eRow.appendChild(eCell);
        eImg = this._imageList['page_previous'];
        eImg.className = ( this._currentPage > 1 ) ? "enabled" : "disabled";
        eImg.onclick = function() {
            cl.loadData(PAGE_PREVIOUS);
        }
        eCell.appendChild(eImg);
		
	    //Create status cell
        eCell = document.createElement('td');
        eCell.nowrap = "nowrap";
        eCell.appendChild(document.createTextNode("Page " + this._currentPage + (this.isKnownSize() ? (" of " + this._totalPages) : "")));
        eRow.appendChild(eCell);
		
        //Create next cell
        eCell = document.createElement('td');
        eRow.appendChild(eCell);
        eImg = this._imageList['page_next'];
        eImg.className = ( (this._currentPage < this._totalPages) || (! this.isKnownSize())) ? "enabled" : "disabled";
        eImg.onclick = function() {
            cl.loadData(PAGE_NEXT);
        }
        eCell.appendChild(eImg);
		
	    //Create last cell
        eCell = document.createElement('td');
        eRow.appendChild(eCell);
        eImg = this._imageList['page_last'];
        eImg.className = ( (this._currentPage < this._totalPages) || (! this.isKnownSize())) ? "enabled" : "disabled";

        if (this.isKnownSize()) {
            eImg.onclick = function() {
                cl.loadData(PAGE_LAST);
            }
        } else {
            eImg.className = "disabled";
        }

        eCell.appendChild(eImg);

    }else{
    	if(this._eFoot){
    		this._eFoot.style.display = 'none';
    	}
    }

};

WebFXColumnList.prototype.updateStatusBar = function() {	
  if(this.displayTotal){
	  if(this._totalDBSize > 0){
		this._eFoot.style.display = 'block';
	    var displayText = this._totalDBSize + " item";
	    if(this._totalDBSize > 1){
	    	displayText += 's';
	    }
	    this._eFootCols[2].innerHTML = displayText;	
	    this._imageList['count'].style.display = this.isKnownSize() ? 'none' : 'inline'; 
	    this._imageList['count'].className = 'enabled';
	  }else{
		  if(this._eFoot){
    		this._eFoot.style.display = 'none';
    	  }
	  }
  }
};


function moveItems(oFrom, oTo) {

    copyItems(oFrom, oTo);

    oFrom.removeRange(oFrom.getSelectedRange());

}


function copyItems(oFrom, oTo) {

    var selRows = oFrom.getSelectedRange();
    var copyData = [];
    var rowData;

    if (!selRows.length) return;

    for (var x = 0; x < selRows.length; x++) {
        rowData = new Array(0);
        rowData.push(oFrom.getRowComponentId(x));
        for (var y = 0; y < oFrom.getColumnCount(); y++) {
            rowData.push(oFrom.getCellValue(x, y));
        }
        copyData.push(rowData);
    }

    oTo.addRows(copyData);

}

/*
 * void _init(iWidth, iHeight)
 * Initializes column list, called by create and bind
*/
WebFXColumnList.prototype._init = function(iWidth, iHeight) {
    if (navigator.product == 'Gecko') {
        /*
	     * Mozilla does not allow the scroll* properties of containers with the
	     * overflow property set to 'hidden' thus we'll have to set it to
	     * '-moz-scrollbars-none' which is basically the same as 'hidden' in IE,
	     * the container has overflow type 'scroll' but no scrollbars are shown.
	     */
        for (var n = 0; n < document.styleSheets.length; n++) {
            if (document.styleSheets[n].href == null || document.styleSheets[n].href.indexOf('columnlist.css') == -1) {
                continue;
            }
            var rules = document.styleSheets[n].cssRules;
            for (var i = 0; i < rules.length; i++) {
                if ((rules[i].type == CSSRule.STYLE_RULE) && (rules[i].selectorText == '.webfx-columnlist-head')) {
                    rules[i].style.overflow = '-moz-scrollbars-none';
                }
            }
        }
    }

    /*
     * Set tab index to allow element to be focused using keyboard, also allows
     * keyboard events to be captured for Mozilla.
     */
    this._eCont.tabIndex = '0';

    //this.calcSize(); // do not calculate size until body is filled
    this._assignEventHandlers();
    if (this.colorEvenRows) {
        this._colorEvenRows();
    }
    if (this.columnAlign) {
        this._setAlignment();
    }

    this.updateStatusBar();

};


/*
 * void calcSize()
 * Used to calculate the desired size of the grid and size it accordingly.
 */
WebFXColumnList.prototype.calcSize = function() {	
    if (this._eCont.offsetWidth >= 4) {

        var windowWidth = (window.innerWidth) ? window.innerWidth : document.documentElement.clientWidth;

        /* Size body */
        
        // setting fixed height
//        var h = this._eCont.clientHeight - this._eHead.offsetHeight - 20;
//               
//        if(jQuery){
//        	this._eBody.style.height = jQuery(this._eBody).height() + 'px';
//        }else{
//        	this._eBody.style.height = (this._eBody.clientHeight ? this._eBody.clientHeight : h ) + 'px';
//        }

        if(isScrollable){
            this._eBody.style.height = this._eCont.clientHeight - this._eHead.offsetHeight - 27 +"px";
        }
        
        if(this._eBodyTable != null){
        if(this._eBodyTable.rows[this._eBodyTable.rows.length-1]){
          this._eBodyTable.rows[this._eBodyTable.rows.length-1].className = 'last'; // adding class to remove border from last row
        }
        }
        
        // setting fixed width
        var w = this._eCont.offsetWidth;
        var totalWidth = 0;
        this._eBody.style.width = ((w > windowWidth) ? windowWidth : w) + "px";
        //this._eBody.style.paddingTop = this._eHead.offsetHeight + 'px'; // removed padding
        this._eBody.style.marginBottom = '0px'; // IE NEEDS THIS LINE SO THE FOOTER DOES NOT COVER THE HORIZ SCROLL BAR

        /* Size header */
        var bNoScrollbar = ((this._eBody.offsetWidth - this._eBody.clientWidth) == 2);
        this._eHeadTable.style.width = calculateStyleWidth(this._eHeadTable, this._eBody.clientWidth) + 'px';
        this._eHead.style.width = calculateStyleWidth(this._eHead, this._eBody.clientWidth) + 'px';

        /* Size columns */        
        if (this._eBodyCols) {
            var length = this._eBodyCols.length;
            for (var i = 0; i < length; i++) {
                //totalWidth += (this._eBodyCols[i].offsetWidth);
                //this._eHeadCols[i].style.width = (this._eBodyCols[i].offsetWidth - 4) + 'px';
            	//using actual widths instead of offsetWidth to resize column head widths
            	totalWidth += parseInt((this._eBodyCols[i].style.width).replace('px',''));
                this._eHeadCols[i].style.width = this._eBodyCols[i].style.width;
            }
        }
    }

    this.updateStatusBar();

};

WebFXColumnList.prototype.showErrorScreen = function() {

    var timeoutMessage = document.createElement('div');
    timeoutMessage.className = 'warning';
    timeoutMessage.style.width = '200px';
    timeoutMessage.style.height = '35px';
    timeoutMessage.style.textAlign = 'left';
    timeoutMessage.style.marginLeft = 'auto';
    timeoutMessage.style.marginRight = 'auto';
    timeoutMessage.innerHTML = 'A timeout has been detected. Please try again later or contact support if the problem persists.';

    this.displayMessage(timeoutMessage);

};

WebFXColumnList.prototype.showNoResultsScreen = function() {

    this._eHead.style.display = 'none';
    var noResultsMessage = document.createElement('span');
    noResultsMessage.innerHTML = 'No results found';
    this.displayMessage(noResultsMessage);

};

WebFXColumnList.prototype.showLoadingScreen = function() {

    var loadingMessage = document.createElement('span');
    //loadingMessage.innerHTML = "Loading...<br/>";
    loadingMessage.appendChild(preloadImage('/tpportal/images/preload.gif', 25, 25, {'alt': 'Loading...', 'title': 'Loading...'}));

    this.displayMessage(loadingMessage);

};

WebFXColumnList.prototype.displayMessage = function(message) {	

    if (!message) return;

	//this._eBody.removeChild(this._eBodyTable);
    this._eBody.innerHTML = '';
    if(this._eFoot){
    	this._eFoot.style.display = 'none';
    }

    this._eMessage = document.createElement("div");
    this._eMessage.style.textAlign = "center";

    this._eMessage.appendChild(message);

    this._eBody.appendChild(this._eMessage);
 
    this._eMessage.style.paddingTop = '20px';    
    this._eMessage.style.paddingBottom = '20px';

};


WebFXColumnList.prototype.displayErrorMessage = function(message) {

    this._eBody.innerHTML = '';
    this._eBody.appendChild(message);

};

WebFXColumnList.prototype.loadData = function(page) {

    this.resetSelectedValue();

    if (page == PAGE_FIRST) {
        if (this._currentPage != 1) {
            this._currentPage = 1;
        } else return;

    } else if (page == PAGE_PREVIOUS) {
        if (this._currentPage > 1) {
            this._currentPage--;
        } else return;

    } else if (page == PAGE_NEXT) {
        if ((this._currentPage < this._totalPages) || (! this.isKnownSize())) {
            this._currentPage++;
        } else return;

    } else if (page == PAGE_LAST) {
        if (this._currentPage < this._totalPages) {
            this._currentPage = this._totalPages;
        } else if (! this.isKnownSize()) {
            this._currentPage++;
        } else return;

    }
    this.showLoadingScreen();

    var listObj = this;
    if (getController) {
        getController().loadPage(this._componentID, this._currentPage);

        getController().ajax.defaultError = function(status) {
            listObj.showErrorScreen();
        }
    } else {
        var listData = new Ajax(requestURL);
        listData.statusAction["200"] = function (responseData) {
            listObj.loadXML(responseData);
        }
        listData.go();
    }

};

WebFXColumnList.prototype.processEvent = function(event) {
	
    if (event.eventID == 'refresh') {

        this.refresh();

    } else if (event.eventID == 'update') {

        this.updateSelection(event.getAttribute("formData"));

    }

 // return false;

};

WebFXColumnList.prototype.updateSelection = function(attributes) {

    getController().getRequest(this._componentID).update(attributes);

    this.refresh();

};

WebFXColumnList.prototype.refresh = function() {

    this.reset();
    this.showLoadingScreen();

    getController().loadData([this._componentID]);

};

WebFXColumnList.prototype.countTotal = function() {

    this._countPopup.open('center', 'middle');

    this._imageList['count'].className = 'disabled';

    getController().countTotal([this._componentID]);

};

WebFXColumnList.prototype.loadXML = function(xml) {
    var response = null;

    if (typeof xml == 'string') {
        response = new SelectionResponse(xml);
    } else if (xml) {
        response = xml;
    }

    this._totalPages = parseInt((response.totalSize - 1) / this._pageSize + 1);
    this._totalDBSize = response.totalSize;

    if (! response.knownSize) {
        this._totalDBSize += "+";
    }

    if (this._currentPage == 0 && this._totalPages > 0) {
        this._currentPage = 1;
    }   
    
    if(response.totalSize < 1){ // if less than 1 result found then display no results found message    	
    	this.showNoResultsScreen();
    }else{
        this.setColumns(response.fieldDefinitions, response.data);        
        this.addRows(response.data);
        this.updateStatusBar();
        this.fixSize();
    }

    if (response.errorMessage) {
        this.displayErrorMessage(response.getErrorMessage());
    }

};

WebFXColumnList.prototype.reset = function() {
    this._currentPage = 0;
    this.resetSelectedValue();
};

WebFXColumnList.prototype.resetSelectedValue = function() {
	returnElement(this._componentID).value = '';
    this.selectedId = '';
};

WebFXColumnList.prototype.displayCountResult = function(total) {

    this._countPopup.updateContent(COUNT_RESULT_HTML, 'totalCount', total);

    this._imageList['count'].className = 'enabled';
    
};

WebFXColumnList.prototype.updateResponse = function(request, response) {
    if (response.errorMessage) {
        this.displayErrorMessage(response.getErrorMessage());
        return;
    } else if (response.functionID == 'countTotal') {
        this.displayCountResult(response.totalSize);
        return;
    }

//    this.clear();
    if (request.maximum > 0 && request.maximum != this._pageSize) {
        this._pageSize = request.maximum;
    }

    this._totalPages = parseInt((response.totalSize - 1) / request.maximum + 1);

    if (this._currentPage == 0 && this._totalPages > 0) {
        this._currentPage = 1;
    }

    this._totalDBSize = response.totalSize;

    if (! response.knownSize) {
        this._totalDBSize += "+";
    }
    
    if(response.totalSize < 1){ // if less than 1 result found then display no results found message
    	this.showNoResultsScreen();
    }else{
        this.setColumns(response.fieldDefinitions, response.data);        
        this.addRows(response.data);       
    }      
    this.updateStatusBar();
    this.fixSize();
};


/*
 * iError = bind(eContainer, eHeader, eBody)
 * Binds column list to an existing HTML structure. Use create
 * to generate the strucutr automatically.
*/
WebFXColumnList.prototype.bind = function(eCont, eHead, eBody) {
    try {
        this._eCont = eCont;
        this._eHead = eHead;
        this._eBody = eBody;
        this._eHeadTable = this._eHead.getElementsByTagName('table')[0];
        this._eBodyTable = this._eBody.getElementsByTagName('table')[0];
        this._eHeadCols = this._eHeadTable.tBodies[0].rows[0].cells;
        this._eBodyCols = this._eBodyTable.tBodies[0].rows[0].cells;
    }
    catch(oe) {
        this.error = 'Unable to bind to elements: ' + oe.message;
        return 1;
    }
    if (this._eHeadCols.length != this._eBodyCols.length) {
        this.error = 'Unable to bind to elements: Number of columns in header and body does not match.';
        return 2;
    }

    this._eHeadCols = this._eHeadTable.tBodies[0].rows[0].cells;
    this._eBodyCols = this._eBodyTable.tBodies[0].rows[0].cells;

    this._cols = this._eHeadCols.length;
    this._rows = this._eBodyTable.tBodies[0].rows.length;

    this._stl = new SortableTable(this._eBodyTable);

    /* Set column class names (used for alignment in mozilla) */
    if ((!document.all) && (this.columnAlign)) {
        aRows = this._eBodyTable.tBodies[0].rows;
        this._rows = aRows.length;
        for (i = 0; i < this._rows; i++) {
            for (j = 0; j < this._cols; j++) {
                aRows[i].cells[j].className = 'webfx-columnlist-col-' + j;
            }
        }
    }

    this._init();

    return 0;
};


/*
 * void _assignEventHandlers()
 * Assigns event handlers to the grid elements, called by bind.
*/
WebFXColumnList.prototype._assignEventHandlers = function() {
    var oThis = this;
    this._eCont.onclick = function(e) {
        oThis._click(e);
    }
    this._eCont.ondblclick = function(e) {
        oThis._dblclick(e);
    }
    if (this.resizeColumns) {
        this._eCont.onmousedown = function(e) {
            oThis._mouseDown(e);
        }
        this._eCont.onmousemove = function(e) {
            oThis._mouseMove(e);
        }
    }
    this._eCont.onmouseup = function(e) {
        oThis._mouseUp(e);
    }
    this._eCont.onselectstart = function(e) {
        return false;
    }
    this._eBody.onscroll = function() {
        oThis._eHead.scrollLeft = oThis._eBody.scrollLeft;
    };
    this._eCont.onkeydown = function(e) {
        var el = (e) ? e.target : window.event.srcElement;
        var key = (e) ? e.keyCode : window.event.keyCode;
        if (oThis._handleRowKey(key)) {
            return;
        }
        if (window.event) {
            window.event.cancelBubble = true;
        }
        else {
            e.preventDefault();
            e.stopPropagation()
        }
        return false;
    };
};

WebFXColumnList.prototype.deselectRow = function() {
    this.deselectCurrentRow(this.getSelectedRow());
};

WebFXColumnList.prototype.deselectCurrentRow = function(iRowIndex) {
    if (!this.rowSelection) {    	
        return;
    }

    if ((iRowIndex < 0) || (iRowIndex > this._rows - 1)) {
        return 1;
    }
    var eRows = this._eBodyTable.tBodies[0].rows;
    eRows[iRowIndex].className = '';
};

/*
 * iErrorCode = selectRow(iRowIndex, bMultiple)
 * Selects the row identified by the sequence number supplied,
 *
 * If bMultiple is specified and multi-select is allowed the
 * the previously selected row will not be deselected. If the
 * specified row is already selected it will be deselected.
 */
WebFXColumnList.prototype.selectRow = function(iRowIndex, bMultiple) {
    if (!this.rowSelection) {
        return;
    }

    if ((iRowIndex < 0) || (iRowIndex > this._rows - 1)) {
        this.error = 'Unable to select row, index out of range.';
        return 1;
    }
    var eRows = this._eBodyTable.tBodies[0].rows;
    var bSelect = true;

    /* Normal click */
    if ((!bMultiple) || (!this.multiple)) {

        /* Deselect previously selected rows */
        while (this.selectedRows.length) {
            if (this.colorEvenRows) {
                eRows[this.selectedRows[0]].className = (this.selectedRows[0] & 1) ? 'odd' : 'even';
            }
            else {
                if (eRows[this.selectedRows[0]]) {
                    eRows[this.selectedRows[0]].className = '';
                }
            }
            this.selectedRows.splice(0, 1);
        }
    }

        /* Control + Click */
    else {
        for (var i = 0; i < this.selectedRows.length; i++) {

            /* Deselect clicked row */
            if (this.selectedRows[i] == iRowIndex) {
                if (this.colorEvenRows) {
                    eRows[this.selectedRows[i]].className = (i & 1) ? 'odd' : 'even';
                }
                else {
                    eRows[this.selectedRows[i]].className = '';
                }
                this.selectedRows.splice(i, 1);
                bSelect = false;
                break;
            }
        }
    }

    /* Select clicked row */
    if (bSelect) {
        this.selectedRows.push(iRowIndex);
        eRows[iRowIndex].className = 'selected';
        this.selectedId = this._eBody.childNodes[0].tBodies[0].rows[iRowIndex].getAttribute("component_id");
    }

    var a = (eRows[iRowIndex].offsetTop + this._eHead.offsetHeight) + eRows[iRowIndex].offsetHeight + 1;
    var b = (this._eBody.clientHeight + this._eBody.scrollTop);
    if (a > b) {
        this._eBody.scrollTop = (a - this._eBody.clientHeight);
    }
    var c = eRows[iRowIndex].offsetTop;
    var d = this._eBody.scrollTop;
    if (c < d) {
        this._eBody.scrollTop = c;
    }

    /* Call onselect if defined */
    if (this.onselect) {
        this.onselect(this.selectedRows);
    }

    return 0;
};


WebFXColumnList.prototype.getRowComponentId = function (iRowIndex) {
    return this._eBody.childNodes[0].tBodies[0].rows[iRowIndex].getAttribute("component_id")
};

WebFXColumnList.prototype.getCellValueById = function (id, iColIndex) {

    for (var i = 0; i <= this._rows; i++) {
        var rowID = this.getRowComponentId(i);
        if (rowID == id) {
            return this.getCellValue(i, iColIndex);
        }
    }

    return null;

};


/*
 * iErrorCode = selectRange(iRowIndex[])
 * iErrorCode = selectRange(iFromRowIndex, iToRowIndex)
 * Selects all rows between iFromRowIndex and iToRowIndex.
 */
WebFXColumnList.prototype.selectRange = function(a, b) {
    var aRowIndex;

    if (!this.rowSelection) {
        return;
    }

    if (typeof a == 'number') {
        aRowIndex = new Array();
        for (var i = a; i <= b; i++) {
            aRowIndex.push(i);
        }
        for (var i = b; i <= a; i++) {
            aRowIndex.push(i);
        }
    }
    else {
        aRowIndex = a;
    }

    for (var i = 0; i < aRowIndex.length; i++) {
        if ((aRowIndex[i] < 0) || (aRowIndex[i] > this._rows - 1)) {
            this.error = 'Unable to select rows, index out of range.';
            return 1;
        }
    }

    /* Deselect previously selected rows */
    var eRows = this._eBodyTable.tBodies[0].rows;
    while (this.selectedRows.length) {
        if (this.colorEvenRows) {
            eRows[this.selectedRows[0]].className = (this.selectedRows[0] & 1) ? 'odd' : 'even';
        }
        else {
            eRows[this.selectedRows[0]].className = '';
        }
        this.selectedRows.splice(0, 1);
    }

    /* Select all rows indicated by range */
    var eRows = this._eBodyTable.tBodies[0].rows;
    var bMatch;
    for (var i = 0; i < aRowIndex.length; i++) {
        bMatch = false;
        for (var j = 0; j < this.selectedRows.length; j++) {
            if (this.selectedRows[j] == aRowIndex[i]) {
                bMatch = true;
                break;
            }
        }
        if (!bMatch) {
            /* Select row */
            this.selectedRows.push(aRowIndex[i]);
            eRows[aRowIndex[i]].className = 'selected';
        }
    }

    /* Call onselect if defined */
    if (this.onselect) {
        this.onselect(this.selectedRows);
    }

    return 0;
};


/*
 * void resize(iWidth, iHeight)
 * Resize the grid to the given dimensions, the outer (border) size is given, not the inner (content) size.
 */
WebFXColumnList.prototype.resize = function(w, h) {
    if (navigator.userAgent.indexOf("MSIE") == -1) {
        this._eCont.style.width = (w - 1) + 'px';
        this._eCont.style.width = calculateStyleWidth(this._eCont, w) + 'px';
    } else {
        this._eCont.style.width = w + 'px';
    }
    this._eCont.style.height = h + 'px';
    this.calcSize();

    /* Call onresize if defined */
    if (this.onresize) {
        this.onresize();
    }
};


/*
 * void _colorEvenRows()
 * Changes the color of even rows (usually to light yellow) to make it easier to read.
 * Also updates the id column to a sequence counter rather than the row ids.
 */
WebFXColumnList.prototype._colorEvenRows = function() {
    if (this._eBodyTable.tBodies.length) {
        var nodes = this._eBodyTable.tBodies[0].rows;
        var len = nodes.length;
        for (var i = 0; i < len; i++) {
            if (nodes[i].className != 'selected') {
                nodes[i].className = (i & 1) ? 'odd' : 'even';
            }
        }
    }
};


/*
 * iErrorCode = addRow(aRowData)
 * Appends supplied row to the column list.
 */
WebFXColumnList.prototype.addRow = function(aRowData) {
    var rc = this._addRow(aRowData);
    if (rc) {
        return rc;
    }
    this.calcSize();
    return 0;
};


/*
 * iErrorCode = addRows(aData)
 * Appends supplied rows to the column list.
 */
WebFXColumnList.prototype.addRows = function(aData) {
    for (var i = 0; i < aData.length; i++) {
        var rc = this._addRow(aData[i]);
        if (rc) {
            return rc;
        }
    }
    this.updateStatusBar();
    this.calcSize();
    return 0;
};


/*
 * void _colorEvenRows()
 * Changes the color of even rows (usually to light yellow) to make it easier to read.
 * Also updates the id column to a sequence counter rather than the row ids.
 */
WebFXColumnList.prototype._colorEvenRows = function() {
    if (this._eBodyTable.tBodies.length) {
        var nodes = this._eBodyTable.tBodies[0].rows;
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].className != 'selected') {
                nodes[i].className = (i & 1) ? 'odd' : 'even';
            }
        }
    }
};


/*
 * iErrorCode = _addRow(aRowData)
 */
WebFXColumnList.prototype._addRow = function(aRowData) {	

    var eBody, eRow, eCell, i, len, tempText, eImg, fieldDefinition, value, idValue, url;

    /* Construct Body Row */
    eBody = this._eBodyTable.tBodies[0];
    eRow = document.createElement('tr');
    eRow.setAttribute("component_id", aRowData['_id']);
    if (this.colorEvenRows) {
        eRow.className = (this._rows & 1) ? 'odd' : 'even';
    }

    for (i = 0; i < this._cols; i++) {
    	fieldDefinition = this._columnDef[i][4];

	 	value = aRowData[fieldDefinition.fieldID];
        idValue = aRowData['_id'];

        eCell = document.createElement('td');
        eCell.className = 'webfx-columnlist-col-' + i;
        eCell.style.width = this._columnDef[i][1];
        eDiv = document.createElement('div');
		if(fieldDefinition.alignment == 'right'){ // add padding to fields if they are right aligned to space out the columns
			eDiv.style.paddingRight = '10px';
		}
	    if (fieldDefinition.type == TYPE_FUNCTION){
	        eDiv.style.whiteSpace = 'normal';
	        eDiv.style.overflow = 'visible';
	    } else {
	        eDiv.style.whiteSpace = 'nowrap';
            eDiv.style.overflow = 'hidden';
	    }
        
	    eCell.appendChild(eDiv);
        //   eCell.style.paddingLeft = '0px';
        //   eCell.style.paddingRight = '0px';
            
		if (fieldDefinition.type == TYPE_ICON) {	    	
	        eImg = document.createElement('img');
	        eImg.src = aRowData[fieldDefinition.fieldID];
	        eImg.width = this._iconData['width'];
	        eImg.height = this._iconData['height'];
	        eDiv.appendChild(eImg);	        
	    } else if (fieldDefinition.type == TYPE_LINK){	    	
	  	    var linkLabel = fieldDefinition.linkLabel;
		    if ( linkLabel == null  || linkLabel == '') {
		        if ( fieldDefinition.label == null ) {
			        linkLabel = fieldDefinition.label;
			    } else {
			        linkLabel = value;
			    }
		    }	 

		    var url = '';
		    if ( fieldDefinition.linkUrl != null ) {

			url = aRowData[fieldDefinition.fieldID + 'linkurl'];
	
			if( typeof url != "undefined" && url.length > 0 && value != null){
				if(url.indexOf("?") > 0){
					url = url + '&id=' + idValue;

				} else {
					url = url + '?id=' + idValue;
				}
			}				
		    }
		   
		    if (typeof url != "undefined" && url.length == 0) {
		    	if (fieldDefinition.linkLabel == null || fieldDefinition.linkLabel == '') {
				eDiv.innerHTML = value;
			} else {
				eDiv.innerHTML = '';
			}
		} else { 
		       // todo RUA escape label	    
		       if (fieldDefinition.linkTargetType == COMPONENT_DIALOG_TARGET_TYPE || fieldDefinition.linkTargetType == DIALOG_TARGET_TYPE) {
				eDiv.innerHTML = '<a href="#" onclick="javascript:showPopupFixedSize(' + "'" + url + "'" + ','+ fieldDefinition.linkTargetWidth +',' + fieldDefinition.linkTargetHeight + ')">' + linkLabel + '</a>';

		       } else {
	        	   eDiv.innerHTML = '<a href="' + value +'">' + linkLabel + '</a>';

		       }  
		    }           
	    } else if (fieldDefinition.type == TYPE_FUNCTION ){
	    	var myFunc = fieldDefinition.renderFunction;
	    	//eDiv.innerHTML = fieldDefinition.renderFunction(aRowData);
	    	eDiv.innerHTML = window[myFunc](aRowData);
	    } else {	    
	    	if ( value == null ) {
				value = '';
	    	}
	        eDiv.appendChild(document.createTextNode(value.replace(/ /g, "\u00a0")));
	    }
	    eRow.appendChild(eCell);
    }

    eBody.appendChild(eRow);

    /* Update row counter */
    this._rows++;

    if (this._eBodyCols == null) {
        this._eBodyCols = this._eBodyTable.tBodies[0].rows[0].cells;
    }

    return 0;
};


/*
 * iErrorCode = removeRow(iRowIndex)
 * Appends supplied row to the grid.
 */
WebFXColumnList.prototype.removeRow = function(iRowIndex) {
    /* Remove row */
    var rc = this._removeRow(iRowIndex);
    if (rc) {
        return rc;
    }

    /* Update row counter and select previous row, if any */
    this._rows--;
    this.selectRow((iRowIndex > 1) ? iRowIndex - 1 : 0);

    /* Recolor rows, if needed */
    if (this.colorEvenRows) {
        this._colorEvenRows();
    }
    this.calcSize();

    /* Call onselect if defined */
    if (this.onselect) {
        this.onselect(this.selectedRows);
    }

    return 0;
};


/*
 * iErrorCode = removeRange(iRowIndex[])
 * iErrorCode = removeRange(iFirstRowIndex, iLastRowIndex)
 * Appends supplied row to the grid.
 */
WebFXColumnList.prototype.removeRange = function(a, b) {
    var aRowIndex = new Array();
    if (typeof a == 'number') {
        for (var i = a; i <= b; i++) {
            aRowIndex.push(i);
        }
    }
    else {
        for (var i = 0; i < a.length; i++) {
            aRowIndex.push(a[i]);
        }
        aRowIndex.sort(compareNumericAsc);
    }

    while ((i = aRowIndex.pop()) >= 0) {
        var rc = this._removeRow(i);
        this._rows--;
    }

    /* Recolor rows, if needed */
    if (this.colorEvenRows) {
        this._colorEvenRows();
    }
    this.calcSize();

    /* Call onselect if defined */
    if (this.onselect) {
        this.onselect(this.selectedRows);
    }

    return 0;
};


/*
 * iErrorCode = clear()
 * Removes all rows from the column list.
 */
WebFXColumnList.prototype.clear = function() {

    this.resetSelectedValue();

    if (this._rows > 0)
        return this.removeRange(0, this._rows - 1);

    // this._currentPage   = 0;
    // this._totalPages    = 0;
};

/*
 * iErrorCode = _removeRow(iRowIndex)
 */
WebFXColumnList.prototype._removeRow = function(iRowIndex) {
    if ((iRowIndex < 0) || (iRowIndex > this._rows - 1)) {
        this.error = 'Unable to remove row, row index out of range.';
        return 1;
    }

    /* Remove from selected */
    for (var i = this.selectedRows.length - 1; i >= 0; i--) {
        if (this.selectedRows[i] == iRowIndex) {
            this.selectedRows.splice(i, 1);
        }
    }

    this._eBodyTable.tBodies[0].removeChild(this._eBodyTable.tBodies[0].rows[iRowIndex]);
    return 0;
};


/*
 * iRowIndex getSelectedRow()
 * Returns the index of the selected row or -1 if no row is selected.
 */
WebFXColumnList.prototype.getSelectedRow = function() {
    return (this.selectedRows.length) ? this.selectedRows[this.selectedRows.length - 1] : -1;
};


/*
 * iRowIndex[] getSelectedRange()
 * Returns an array with the row index of all selecteds row or null if no row is selected.
 */
WebFXColumnList.prototype.getSelectedRange = function() {
    return (this.selectedRows.length) ? this.selectedRows : -1;
};


/*
 * iRows getRowCount()
 * Returns the nummer of rows.
 */
WebFXColumnList.prototype.getRowCount = function() {
    return this._rows;
};


/*
 * iRows getColumnCount()
 * Returns the nummer of columns.
 */
WebFXColumnList.prototype.getColumnCount = function() {
    return this._cols;
};


/*
 * sValue = getCellValue(iRowIndex, iColumnIndex, bHTML)
 * Returns the content of the specified cell.
 */
WebFXColumnList.prototype.getCellValue = function(iRowIndex, iColIndex, bHTML) {
    var el;

    if ((iRowIndex < 0) || (iRowIndex > this._rows - 1)) {
        this.error = 'Unable to get cell value , row index out of range.';
        return null;
    }
    if ((iColIndex < 0) || (iColIndex > this._cols - 1)) {
        this.error = 'Unable to get cell value , row index out of range.';
        return null;
    }

    el = this._eBodyTable.tBodies[0].rows[iRowIndex].cells[iColIndex];

    return (bHTML) ? el.innerHTML : getInnerText(el);
};

WebFXColumnList.prototype.getSelectedItemLabel = function(labelIndex) {

    return this.getCellValue(this.getSelectedRow(), labelIndex);

};

/*
 * iError = setCellValue(iRowIndex, iColumnIndex, sValue, bHTML)
 * Sets the content of the specified cell.
 */
WebFXColumnList.prototype.setCellValue = function(iRowIndex, iColIndex, sValue, bHTML) {
    var el;

    if ((iRowIndex < 0) || (iRowIndex > this._rows - 1)) {
        this.error = 'Unable to set cell value , row index out of range.';
        return 1;
    }
    if ((iColIndex < 0) || (iColIndex > this._cols - 1)) {
        this.error = 'Unable to set cell value , row index out of range.';
        return 2;
    }

    el = this._eBodyTable.tBodies[0].rows[iRowIndex].cells[iColIndex];
    if (bHTML) {
        el.innerHTML = sValue;
    }
    else {
        while (el.firstChild != el.lastChild) {
            el.removeChild(el.lastChild);
        }
        if (el.firstChild) {
            el.firstChild.nodeValue = sValue;
        }
        else {
            el.appendChild(document.createTextNode(sValue));
        }
    }

    this.calcSize();

    return 0;
};


/*
 * void setSortTypes(sSortType[]) {
 * Sets the column data types for sorting.
 * Valid options: TYPE_STRING, TYPE_NUMBER, TYPE_DATE, TYPE_STRING_NO_CASE or
 * custom string value that will be passed to sortable table. Can be registered
 * with the SortableTable.prototype.addSortType method.
 */
WebFXColumnList.prototype.setSortTypes = function(aSortTypes) {
    var i, a = new Array();

    this._aColumnTypes = aSortTypes;
    for (i = 0; i < this._cols; i++) {
        switch (aSortTypes[i]) {
            case TYPE_STRING:         a.push('String');                break;
            case TYPE_NUMBER:         a.push('Number');                break;
            case TYPE_DATE:           a.push('Date');                  break;
            case TYPE_STRING_NO_CASE: a.push('CaseInsensitiveString'); break;
            default:                  a.push('String');
        }
        ;
    }
    this._stl.setSortTypes(a);
};


/*
 * void setColumnTypes(aColumnTypes[]) {
 * Sets the column data types for sorting, also affects the alignment for columns
 * with alignment set to ALIGN_AUTO (which is the default), strings and dates
 * are left aligned, numbers right aligned.
 * Valid options: TYPE_STRING, TYPE_NUMBER, TYPE_DATE, TYPE_STRING_NO_CASE or
 * custom string value that will be passed to sortable table. Can be registered
 * with the SortableTable.prototype.addSortType method.
 */
WebFXColumnList.prototype.setColumnTypes = function(aColumnTypes) {
    this.setSortTypes(aColumnTypes);
    if (this.columnAlign) {
        this._setAlignment();
    }
};


/*
 * void setColumnAlignment(iAlignment[])
 * Sets column text alignment, ALIGN_AUTO, ALIGN_LEFT, ALIGN_CENTER or ALIGN_RIGHT.
 */
WebFXColumnList.prototype.setColumnAlignment = function() {
    for (var x = 0; x < this._columnDef.length; x++) {
        this._aColumnAlign[x] = this._columnDef[x][3];
    }
//	_aColumnAlign = aAlignment;
};


/*
 * void sort(iColumnIndex, [bDescending])
 * Sorts the grid by the specified column (zero based index) and, optionally, in the specified direction.
 */
WebFXColumnList.prototype.sort = function(iCol, bDesc) {
    if (!this.columnSorting) {
        return;
    }

    /* Hide arrow from header for column currently sorted by */
    if (this.sortCol != -1 && this._eHeadTable.tBodies[0].rows[0].cells[this.sortCol]) {
        var eImg = this._eHeadTable.tBodies[0].rows[0].cells[this.sortCol].getElementsByTagName('img')[0];
        eImg.style.display = 'none';
    }

    /* Determine sort direction */
    if (bDesc == null) {
        bDesc = false;
        if ((!this.sortDescending) && (iCol == this.sortCol)) {
            bDesc = true;
        }
    }

    /* Indicate sorting using arrow in header */
    var eImg = this._eHeadTable.tBodies[0].rows[0].cells[iCol].getElementsByTagName('img')[0];
    eImg.src = (bDesc) ? this._imageList['sortDescImage'].src : this._imageList['sortAscImage'].src;
    eImg.style.display = 'inline';

    /* Perform sort operation */
    this._stl.sort(iCol, bDesc);
    this.sortCol = iCol;
    this.sortDescending = bDesc;

    /* Update row coloring */
    if (this.colorEvenRows) {
        this._colorEvenRows();
    }

    /* Update selection */
    var nodes = this._eBodyTable.tBodies[0].rows;
    var len = nodes.length;
    var a = new Array();
    for (var i = 0; i < len; i++) {
        if (nodes[i].className == 'selected') {
            a.push(i);
        }
    }
    this.selectRange(a);

    /* Call onsort if defined */
    if (this.onsort) {
        this.onsort(this.sortCol, this.sortDescending);
    }

};


/*
 * void _handleRowKey(iKeyCode)
 * Key handler for events on row level.
 */
WebFXColumnList.prototype._handleRowKey = function(iKeyCode, bCtrl, bShift) {
    var iActiveRow = -1;
    if (this.selectedRows.length != 0) {
        iActiveRow = this.selectedRows[this.selectedRows.length - 1];
    }
    if ((!bCtrl) && (!bShift)) {
        if (iKeyCode == 38) {                                                       // Up
            if (iActiveRow > 0) {
                this.selectRow(iActiveRow - 1);
            }
        }
        else if (iKeyCode == 40) {                                                  // Down
            if (iActiveRow < this._rows - 1) {
                this.selectRow(iActiveRow + 1);
            }
        }
        else if (iKeyCode == 33) {                                                  // Page Up
            if (iActiveRow > 10) {
                this.selectRow(iActiveRow - 10);
            }
            else {
                this.selectRow(0);
            }
        }
        else if (iKeyCode == 34) {                                                  // Page Down
            if (iActiveRow < this._rows - 10) {
                this.selectRow(iActiveRow + 10);
            }
            else {
                this.selectRow(this._rows - 1);
            }
        }
        else if (iKeyCode == 36) {
            this.selectRow(0);
        }                             // Home
        else if (iKeyCode == 35) {
            this.selectRow(this._rows - 1);
        }                // End
        else {
            return true;
        }
        return false;
    }
};


/*
 * Event Handlers
 */
WebFXColumnList.prototype._mouseMove = function(e) {
    var el, x, w, tw, ox, rx, i, l;

    el = (e) ? e.target : window.event.srcElement;
    x = (e) ? e.pageX : window.event.x + this._eBody.scrollLeft;

    /*
         * Column move operation started, create elements required to indicate moving
         * and set operation flag to COL_HEAD_MOVE.
         */
    if ((this._headerOper == COL_HEAD_DOWN) && (this.moveColumns)) {
        this._headerOper = COL_HEAD_MOVE;
        this._eCont.style.cursor = 'move';

        w = this._headerData[2] + (x - this._headerData[1]);

        if (!this._moveEl) {
            this._moveEl = document.createElement('div');
            this._moveEl.appendChild(document.createTextNode(this._headerData[0].firstChild.nodeValue));
            this._moveEl.className = 'webfx-columnlist-move-header';
            this._eHead.appendChild(this._moveEl);

            if (this.columnAlign) {
                switch (this._aColumnAlign[this._headerData[0].cellIndex]) {
                    case ALIGN_LEFT:   this._moveEl.style.textAlign = 'left';   break;
                    case ALIGN_CENTER: this._moveEl.style.textAlign = 'center'; break;
                    case ALIGN_RIGHT:  this._moveEl.style.textAlign = 'right';  break;
                    case ALIGN_AUTO:
                    default:
                        switch (this._aColumnTypes[this._headerData[0].cellIndex]) {
                            case TYPE_NUMBER: this._moveEl.style.textAlign = 'right'; break;
                            default:          this._moveEl.style.textAlign = 'left';
                        };
                }
                ;
            }


        }
        else {
            this._moveEl.firstChild.nodeValue = this._headerData[0].firstChild.nodeValue;
        }
        this._moveEl.style.width = this._headerData[0].clientWidth + 'px';

        if (!this._moveSepEl) {
            this._moveSepEl = document.createElement('div');
            this._moveSepEl.className = 'webfx-columnlist-separator-header';
            this._eHead.appendChild(this._moveSepEl);
        }
    }

    /*
         * Column move operation, determine position of column and move place holder
         * to that position. Also indicate in between which columns it will be placed.
         */
    if (this._headerOper == COL_HEAD_MOVE) {
        ox = this._headerData[1] + (x - this._headerData[2]);
        this._moveEl.style.left = ox + 'px';

        ox = 0,rx = x - this._headerData[3];
        for (i = 0; i < this._cols; i++) {
            ox += this._eHeadCols[i].offsetWidth;
            if (ox >= rx) {
                break;
            }
        }
        if (i == this._cols) {
            this._moveSepEl.style.left = (this._eHeadCols[this._cols - 1].offsetLeft + this._eHeadCols[this._cols - 1].offsetWidth - 1) + 'px';
        }
        else {
            this._moveSepEl.style.left = this._eHeadCols[i].offsetLeft + 'px';
        }

        this._headerData[4] = i;
    }

        /*
          * Column resize operation, determine and set new size based on the original
          * size and the difference between the current mouse position and the one that
          * was recorded once the resize operation was started.
          */
    else if (this._headerOper == COL_HEAD_SIZE) {
        w = this._headerData[1] + x - this._headerData[2];
        tw = ((w - this._headerData[1]) + this._headerData[3]) + 1;
        this._eHeadTable.style.width = tw + 'px';
        if (w > 5) {
            this._headerData[0].style.width = w + 'px';
            if (this.bodyColResize) {
                this._eBodyTable.style.width = tw + 'px';
                //this._eBodyTable.getElementsByTagName('colgroup')[0].getElementsByTagName('col')[this._headerData[0].cellIndex].style.width = w + 'px';
                aRows = this._eBodyTable.tBodies[0].rows;
                this._rows = aRows.length;
                for (i = 0; i < this._rows; i++) {
                    aRows[i].cells[this._headerData[0].cellIndex].style.width = w + 'px';
                    aRows[i].cells[this._headerData[0].cellIndex].firstChild.style.width = w + 'px';
                }
            }
        }
    }

    else {
        this._checkHeaderOperation(el, x);
    }

};


WebFXColumnList.prototype._mouseDown = function(e) {
    var el = (e) ? e.target : window.event.srcElement;
    var x = (e) ? e.pageX : window.event.x + this._eBody.scrollLeft;

    if ((el.tagName == 'TD') && (el.parentNode.parentNode.parentNode.parentNode.className == 'webfx-columnlist-head') ||
        (el.tagName == 'DIV') && (el.parentNode.parentNode.parentNode.parentNode.parentNode.className == 'webfx-columnlist-head')) {
        if (el.tagName == 'DIV') {
            el = el.parentNode
        }
        this._checkHeaderOperation(el, x);

        if (this._headerOper == COL_HEAD_EDGE) {
            if (this.bodyColResize) {
                this._sizeBodyAccordingToHeader();
            }
            this._headerOper = COL_HEAD_SIZE;
        }
        else if (this._headerOper == COL_HEAD_OVER) {
            this._headerOper = COL_HEAD_DOWN;
            this._headerData[0].className = 'webfx-columnlist-active-header';
        }
    }
};


WebFXColumnList.prototype._mouseUp = function(e) {
    var el = (e) ? e.target : window.event.srcElement;
    var x = (e) ? e.pageX : window.event.x + this._eBody.scrollLeft;

    if (this._headerOper == COL_HEAD_SIZE) {

    }
    else if (this._headerOper == COL_HEAD_MOVE) {
        if (this._moveEl) {
            this._eHead.removeChild(this._moveEl);
            this._moveEl = null;
        }
        if (this._moveSepEl) {
            this._eHead.removeChild(this._moveSepEl);
            this._moveSepEl = null;
        }
        this._moveColumn(this._headerData[0].cellIndex, this._headerData[4]);
    }
    else if (this._headerOper == COL_HEAD_DOWN) {
        el = el.parentNode;
        this.sort(el.cellIndex);
    }

    if (this._headerOper != COL_HEAD_NONE) {
        this._headerOper = COL_HEAD_NONE;
        this._eCont.style.cursor = 'default';
        this._headerData[0].className = '';
        this._headerData = null;
        this._sizeBodyAccordingToHeader();
    }

};


WebFXColumnList.prototype._click = function(e) {
    var el = (e) ? e.target : window.event.srcElement;
    if (el.tagName == 'NOBR') {
        el = el.parentNode;
    }
    if (el.tagName == 'IMG') {
        el = el.parentNode;
    }
    if (el.tagName == 'DIV') {
        el = el.parentNode;
    }
    if ((el.tagName == 'TD') && (el.parentNode.parentNode.parentNode.parentNode.className == 'webfx-columnlist-body')) {
        if (((e) ? e.shiftKey : window.event.shiftKey) && (this.selectedRows.length) && (this.multiple)) {
            this.selectRange(this.selectedRows[this.selectedRows.length - 1], el.parentNode.rowIndex);
        }
        else {
            this.selectRow(el.parentNode.rowIndex, (e) ? e.ctrlKey : window.event.ctrlKey);
        }
        this.updateStatusBar();
    }
};

WebFXColumnList.prototype._dblclick = function(e) {
    var el = (e) ? e.target : window.event.srcElement;
    if (el.tagName == 'DIV' && el.parentNode.tagName == 'TD') {
        el = el.parentNode;
    }
    if ((el.tagName == 'TD') && (el.parentNode.parentNode.parentNode.parentNode.className == 'webfx-columnlist-body')) {
        if (this.ondblclick) {
            this.ondblclick(el.parentNode.getAttribute('component_id'));
        }
    }
};


/*
 * Event handler helpers
 */

WebFXColumnList.prototype._checkHeaderOperation = function(el, x) {
    var prev, next, left, right, l, r;

    /*
         * Checks if the mouse cursor is near the edge of a header
         * cell, in that case the cursor is set to 'e-resize' and
         * the operation is set to COL_HEAD_EDGE, if it's over the
         * header but not near the edge it's set to COL_HEAD_OVER
         * and finnaly if it's not over the header it's set to
         * COL_HEAD_NONE. The operation value is used to trigger
         * column resize, move and sort commands.
         */

    if ((el.tagName == 'TD') && (el.parentNode.parentNode.parentNode.parentNode.className == 'webfx-columnlist-head') ||
        (el.tagName == 'DIV') && (el.parentNode.parentNode.parentNode.parentNode.parentNode.className == 'webfx-columnlist-head')) {
        if (el.tagName == 'IMG') {
            el = el.parentNode.parentNode;
        }
        if (el.tagName == 'DIV') {
            el = el.parentNode;
        }

        prev = el.previousSibling;
        next = el.nextSibling;
        left = getLeftPos(el);
        right = left + el.offsetWidth;
        l = (x - 5) - left;
        r = right - x;

        if ((l < 5) && (prev)) {
            this._eCont.style.cursor = 'e-resize';
            this._headerOper = COL_HEAD_EDGE;
            this._headerData = [prev, prev.offsetWidth - 5, x, this._eHeadTable.offsetWidth];
        }
        else if (r < 5) {
            this._eCont.style.cursor = 'e-resize';
            this._headerOper = COL_HEAD_EDGE;
            this._headerData = [el, el.offsetWidth - 5, x, this._eHeadTable.offsetWidth];
        }
        else {
            this._eCont.style.cursor = 'default';
            this._headerOper = COL_HEAD_OVER;
            this._headerData = [el, el.offsetLeft, x, getLeftPos(this._eHead), el.cellIndex];
        }
    }
    else {
        this._eCont.style.cursor = 'default';
        this._headerOper = COL_HEAD_NONE;
        this._headerData = null;
    }
};


WebFXColumnList.prototype._sizeBodyAccordingToHeader = function() {
    //var aCols = this._eBodyTable.getElementsByTagName('colgroup')[0].getElementsByTagName('col');
    var length = aCols.length;
    var bNoScrollbar = ((this._eBody.offsetWidth - this._eBody.clientWidth) == 2);
    this._eBodyTable.style.width = this._eHeadTable.offsetWidth - ((bNoScrollbar) ? 2 : 0) + 'px';
    for (var i = 0; i < length; i++) {
        aCols[i].style.width = (this._eHeadCols[i].offsetWidth - ((document.all) ? 2 : 0)) - (((bNoScrollbar && i) == (length - 1)) ? 2 : 0) + 'px';
    }
};


/*
 * void moveColumn(iColumnIndex, iNewColumnIndex)
 * Moves column from givin column index to new index.
 */
WebFXColumnList.prototype._moveColumn = function(iCol, iNew) {
    var i, oParent, oCol, oBefore, aRows, a;

    if (iCol == iNew) {
        return;
    }

    /* Move header */
    oCol = this._eHeadCols[iCol];
    oParent = oCol.parentNode;
    if (iNew == this._cols) {
        oParent.removeChild(oCol);
        oParent.appendChild(oCol);
    }
    else {
        oBefore = this._eHeadCols[iNew];
        oParent.removeChild(oCol);
        oParent.insertBefore(oCol, oBefore);
    }

    /* Move cols */
//    oCol = this._eBodyTable.getElementsByTagName('colgroup')[0].getElementsByTagName('col')[iCol];
//    oParent = oCol.parentNode;
//    if (iNew == this._cols) {
//        oParent.removeChild(oCol);
//        oParent.appendChild(oCol);
//    }
//    else {
//        oBefore = this._eBodyTable.getElementsByTagName('colgroup')[0].getElementsByTagName('col')[iNew];
//        oParent.removeChild(oCol);
//        oParent.insertBefore(oCol, oBefore);
//    }

    /* Move cells */
    aRows = this._eBodyTable.tBodies[0].rows;
    this._rows = aRows.length;
    for (i = 0; i < this._rows; i++) {
        oCol = aRows[i].cells[iCol];
        oParent = aRows[i];

        if (iNew == this._cols) {
            oParent.removeChild(oCol);
            oParent.appendChild(oCol);
        }
        else {
            oBefore = aRows[i].cells[iNew];
            oParent.removeChild(oCol);
            oParent.insertBefore(oCol, oBefore);
        }
    }

    /* Reorganize column type and sort data */
    a = new Array();
    oCol = this._aColumnTypes[iCol];
    for (i = 0; i < this._aColumnTypes.length; i++) {
        if (i == iCol) {
            continue;
        }
        if (i == iNew) {
            a.push(oCol);
        }
        a.push(this._aColumnTypes[i]);
    }
    if (iNew == this._aColumnTypes.length - 1) {
        a.push(oCol);
    }
    this._aColumnTypes = a;
    this.setSortTypes(a);

    /* If sorted by column, update sortCol property */
    if (iCol == this.sortCol) {
        this.sortCol = iNew;
    }
};

function getType(type) {

    if (type) {

        if (type == 'number' || type == 'amount') {
            return TYPE_NUMBER;
        } else if (type == 'date' || type == 'datetime') {
            return TYPE_DATE;
        } else if (type == 'icon') {
            return TYPE_ICON;
        }

    }

    return TYPE_STRING;

}

WebFXColumnList.prototype.setColumns = function(fieldDefinitions, responseData) {
	
    // init loop
    var x;

    // Get the width of the container div
    var availWidth;

    if (isMSIEBrowser()) {
        this._eCont.style.width = calculateStyleWidth(this._eCont, this._eCont.offsetWidth) + "px";
    }

    if (responseData && responseData.length * 27 > this._eCont.clientHeight - this._eHead.offsetHeight - 21 - 18) {
        availWidth = this._eCont.clientWidth - 19;
    } else {
        availWidth = this._eCont.clientWidth - 2;
    }
        
    var fieldDefinition;
    var columnDef = new Array();
    
    for (x = 0; x < fieldDefinitions.length; x++) {
		fieldDefinition = fieldDefinitions[x];	
		if ( fieldDefinition.visible == true ||  fieldDefinition.visible == 'true') {
	    	columnDef.push([fieldDefinition.label,
			fieldDefinition.width,
			getType(fieldDefinition.type),
			fieldDefinition.alignment,
			fieldDefinition
			]);
		}
    }
    
    // The number of columns displayed on column list
    var numCols = columnDef.length;
    
    
    // Hold all percentage values for processing
    var percs = new Array();

    // The total of all percentage values
    var totalPercentage = 0;
    
    // The index of ':' in ColumnDef values
    var indexOfColon;
    
    // The percent value that comes after token ':' in ColumnDef values
    var percent;
    
    // The percent value that comes before token ':' in ColumnDef values
    var pixcels;
    
    // The calculated pixcels from percent value that comes after token ':' in ColumnDef values
    var pixcelsCalculatedFromPercent;

    // Remove specific pixel widths from available width
    for (x = 0; x < columnDef.length; x++) {

        // If the column definition is passed in as a string
        if (typeof columnDef[x] == "string")
            columnDef[x] = new Array(columnDef[x], '100%', TYPE_STRING);

        // If there is no column width defined
        if (!columnDef[x][1])
            columnDef[x][1] = "100%";

        // If there is a width but no units
        if (parseInt(columnDef[x][1]) == columnDef[x][1])
            columnDef[x][1] = columnDef[x][1] + "px";

        // Remove all fixed width columns from available width
        if (columnDef[x][1].endsWith("px")) {
            availWidth -= parseInt(columnDef[x][1]);
        }

        // Gather all percentage widths for processing
        if (columnDef[x][1].endsWith("%")) {
            indexOfColon = columnDef[x][1].indexOf(":");
            if (indexOfColon == -1) {
                percs.push([x, parseInt(columnDef[x][1])]);
                totalPercentage += parseInt(columnDef[x][1]);
            } else {
                percs.push([x, columnDef[x][1]]);
                totalPercentage += parseInt(columnDef[x][1].substring(indexOfColon + 1));
            }
        }

    }
    
    for (x = 0; x < percs.length; x++) {
        indexOfColon = columnDef[percs[x][0]][1].indexOf(":");
        if (indexOfColon != -1) {
            percent = parseInt(columnDef[percs[x][0]][1].substring(indexOfColon + 1));
            pixcels = parseInt(columnDef[percs[x][0]][1].substring(0, indexOfColon));
            pixcelsCalculatedFromPercent = Math.floor(percent / totalPercentage * availWidth);
            if (pixcelsCalculatedFromPercent < pixcels) {
                availWidth -= pixcels;
                totalPercentage -= percent;
                columnDef[percs[x][0]][1] = pixcels + "px";
            } else {
                percs[x][1] = percent;
            }
        }
    }

    for (x = 0; x < percs.length; x++) {
        if (columnDef[percs[x][0]][1].endsWith("%")) {
            columnDef[percs[x][0]][1] = Math.floor(percs[x][1] / totalPercentage * availWidth) + "px";
        }
    }
    
    this._columnDef = columnDef;
    this._fieldDefinitions = fieldDefinitions;
    this.create();

};

/*
 * void _setAlignment()
 * Sets column alignment
 */
WebFXColumnList.prototype._setAlignment = function() {

    var i, aRows, aAlign, j;

    aAlign = new Array();
    for (i = 0; i < this._cols; i++) {
        switch (this._aColumnAlign[i]) {
            case ALIGN_LEFT:   align = 'left';   break;
            case ALIGN_CENTER: align = 'center'; break;
            case ALIGN_RIGHT:  align = 'right';  break;
            case ALIGN_AUTO:
            default:
                switch (this._aColumnTypes[i]) {
                    case TYPE_DATE:
                    case TYPE_NUMBER: align = 'right'; break;
                    default:          align = 'left';
                };
        }
        aAlign.push(align);
    }

    /* Set alignment for headers */
    for (i = 0; i < this._cols; i++) {
        try {
        	if (this._eHeadCols != null) {
        		this._eHeadCols[i].style.textAlign = aAlign[i];
        	}
        } catch (ex) {
        }
    }
    
    /* set alignment for body */
//    for (i=0; i<this._cols; i++){
//    	this._eBodyCols[]
//    }
    
    /*
         * Set alignment for rows.
         * IE supports the align property on cols in colgorups. As thats the, by far,
         * fastest way of setting it, that what we'll use.
         */
//    var aCols = this._eBodyTable.getElementsByTagName('colgroup')[0].getElementsByTagName('col');
//    //alert(aCols.length);
//    var length = aCols.length;
    var browser = '';
    if(isMSIEBrowser()){
    	browser = 'ie';
    }
        
    //todo IE6
    
    //check ie8 issue    
//    if (isMSIEOldBrowser()) {
//        for (var i = 0; i < length; i++) {
//            if (aAlign[i]) aCols[i].align = aAlign[i];
//        }
//    }
//
//        /*
//          * Mozilla does not support the align property, so we'll update the style
//          * sheet rule for each column instead. Still a lot faster than setting the
//          * style text-alignment property for all cells.
//          */
//    else {
        var ss = null, rules = null;
        for (var n = 0; n < document.styleSheets.length; n++) {
            if (document.styleSheets[n].href == null || document.styleSheets[n].href.indexOf('columnlist.css') == -1) {
                continue;
            }
            ss = document.styleSheets[n];
            rules = ss.cssRules ? ss.cssRules : ss.rules;
        }
        var isSupported = ss.cssRules ? true : false;

        if (!rules) {
            return;
        }

        if (!this._aColRules) {
            this._aColRules = new Array();            
        }
        //alert(length);
        for (var j = 0; j < length; j++) {
            if (!this._aColRules[j]) {
                //alert('1');
                for (var i = 0; i < rules.length; i++) {
                    if (rules[i].selectorText == '.webfx-columnlist-col-' + j) {      
                        this._aColRules[j] = rules[i];
                        break;
                    }
                }
            }
            if (this._aColRules[j]) {
            	//alert('2');
            	try{
            		this._aColRules[j].style.textAlign = aAlign[j];
            	}catch(err){}
            }
            else {
            	//alert('3');
            	if(ss.insertRule){
            		this._aColRules[j] = ss.insertRule('.webfx-columnlist-col-' + j + ' { text-align: ' + aAlign[j] + '}', 0);
            	}else if(ss.addRule){
            		this._aColRules[j] = ss.addRule('.webfx-columnlist-col-' + j, 'text-align: ' + aAlign[j]);
            	}
            }
            
        }
    //}
};


/*
 * Helper functions
 */

function getLeftPos(_el) {
    var x = 0;
    for (var el = _el; el; el = el.offsetParent) {
        x += el.offsetLeft;
    }
    return x;
}


function compareNumericAsc(n1, n2) {
    if (Number(n1) < Number(n2)) {
        return -1;
    }
    if (Number(n1) > Number(n2)) {
        return 1;
    }
    return 0;
}


function getInnerText(el) {
    if (document.all) {
        return el.innerText;
    }
    var str = '';
    var cs = el.childNodes;
    var l = cs.length;
    for (var i = 0; i < l; i++) {
        switch (cs[i].nodeType) {
            case 1: //ELEMENT_NODE
                str += getInnerText(cs[i]);
                break;
            case 3:        //TEXT_NODE
                str += cs[i].nodeValue;
                break;
        }
    }
    return str;
}


/*----------------------------------------------------------------------------\
|                            Sortable Table 1.12                              |
|-----------------------------------------------------------------------------|
|                         Created by Erik Arvidsson                           |
|                  (http://webfx.eae.net/contact.html#erik)                   |
|                      For WebFX (http://webfx.eae.net/)                      |
|-----------------------------------------------------------------------------|
| A DOM 1 based script that allows an ordinary HTML table to be sortable.     |
|-----------------------------------------------------------------------------|
|                  Copyright (c) 1998 - 2004 Erik Arvidsson                   |
|-----------------------------------------------------------------------------|
| This software is provided "as is", without warranty of any kind, express or |
| implied, including  but not limited  to the warranties of  merchantability, |
| fitness for a particular purpose and noninfringement. In no event shall the |
| authors or  copyright  holders be  liable for any claim,  damages or  other |
| liability, whether  in an  action of  contract, tort  or otherwise, arising |
| from,  out of  or in  connection with  the software or  the  use  or  other |
| dealings in the software.                                                   |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
| This  software is  available under the  three different licenses  mentioned |
| below.  To use this software you must chose, and qualify, for one of those. |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
| The WebFX Non-Commercial License          http://webfx.eae.net/license.html |
| Permits  anyone the right to use the  software in a  non-commercial context |
| free of charge.                                                             |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
| The WebFX Commercial license           http://webfx.eae.net/commercial.html |
| Permits the  license holder the right to use  the software in a  commercial |
| context. Such license must be specifically obtained, however it's valid for |
| any number of  implementations of the licensed software.                    |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
| GPL - The GNU General Public License    http://www.gnu.org/licenses/gpl.txt |
| Permits anyone the right to use and modify the software without limitations |
| as long as proper  credits are given  and the original  and modified source |
| code are included. Requires  that the final product, software derivate from |
| the original  source or any  software  utilizing a GPL  component, such  as |
| this, is also licensed under the GPL license.                               |
|-----------------------------------------------------------------------------|
| 2003-01-10 | First version                                                  |
| 2003-01-19 | Minor changes to the date parsing                              |
| 2003-01-28 | JScript 5.0 fixes (no support for 'in' operator)               |
| 2003-02-01 | Sloppy typo like error fixed in getInnerText                   |
| 2003-07-04 | Added workaround for IE cellIndex bug.                         |
| 2003-11-09 | The bDescending argument to sort was not correctly working     |
|            | Using onclick DOM0 event if no support for addEventListener    |
|            | or attachEvent                                                 |
| 2004-01-13 | Adding addSortType and removeSortType which makes it a lot     |
|            | easier to add new, custom sort types.                          |
| 2004-01-27 | Switch to use descending = false as the default sort order.    |
|            | Change defaultDescending to suit your needs.                   |
| 2004-03-14 | Improved sort type None look and feel a bit                    |
| 2004-08-26 | Made the handling of tBody and tHead more flexible. Now you    |
|            | can use another tHead or no tHead, and you can chose some      |
|            | other tBody.                                                   |
|-----------------------------------------------------------------------------|
| Created 2003-01-10 | All changes are in the log above. | Updated 2004-08-26 |
\----------------------------------------------------------------------------*/


function SortableTable(oTable, oSortTypes) {

    this._sortTypes = oSortTypes || [];

    this.sortColumn = null;
    this.descending = null;

    var oThis = this;
    this._headerOnclick = function (e) {
        oThis.headerOnclick(e);
    };

    if (oTable) {
        this.setTable(oTable);
        this.document = oTable.ownerDocument || oTable.document;
    }
    else {
        this.document = document;
    }


	// only IE needs this
    var win = this.document.defaultView || this.document.parentWindow;
    this._onunload = function () {
        oThis.destroy();
    };
    if (win && typeof win.attachEvent != "undefined") {
        win.attachEvent("onunload", this._onunload);
    }
}

SortableTable.gecko = navigator.product == "Gecko";
SortableTable.msie = /msie/i.test(navigator.userAgent);
// Mozilla is faster when doing the DOM manipulations on
// an orphaned element. MSIE is not
SortableTable.removeBeforeSort = SortableTable.gecko;

SortableTable.prototype.onsort = function () {
};

// default sort order. true -> descending, false -> ascending
SortableTable.prototype.defaultDescending = false;

// shared between all instances. This is intentional to allow external files
// to modify the prototype
SortableTable.prototype._sortTypeInfo = {};

SortableTable.prototype.setTable = function (oTable) {
    if (this.tHead)
        this.uninitHeader();
    this.element = oTable;
    this.setTHead(oTable.tHead);
    this.setTBody(oTable.tBodies[0]);
};

SortableTable.prototype.setTHead = function (oTHead) {
    if (this.tHead && this.tHead != oTHead)
        this.uninitHeader();
    this.tHead = oTHead;
    this.initHeader(this._sortTypes);
};

SortableTable.prototype.setTBody = function (oTBody) {
    this.tBody = oTBody;
};

SortableTable.prototype.setSortTypes = function (oSortTypes) {
    if (this.tHead)
        this.uninitHeader();
    this._sortTypes = oSortTypes || [];
    if (this.tHead)
        this.initHeader(this._sortTypes);
};

// adds arrow containers and events
// also binds sort type to the header cells so that reordering columns does
// not break the sort types
SortableTable.prototype.initHeader = function (oSortTypes) {
    if (!this.tHead) return;
    var cells = this.tHead.rows[0].cells;
    var doc = this.tHead.ownerDocument || this.tHead.document;
    this._sortTypes = oSortTypes || [];
    var l = cells.length;
    var img, c;
    for (var i = 0; i < l; i++) {
        c = cells[i];
        if (this._sortTypes[i] != null && this._sortTypes[i] != "None") {
            img = doc.createElement("IMG");
            img.src = "images/blank.png";
            c.appendChild(img);
            if (this._sortTypes[i] != null)
                c._sortType = this._sortTypes[i];
            if (typeof c.addEventListener != "undefined")
                c.addEventListener("click", this._headerOnclick, false);
            else if (typeof c.attachEvent != "undefined")
                c.attachEvent("onclick", this._headerOnclick);
            else
                c.onclick = this._headerOnclick;
        }
        else
        {
            c.setAttribute("_sortType", oSortTypes[i]);
            c._sortType = "None";
        }
    }
    this.updateHeaderArrows();
};

// remove arrows and events
SortableTable.prototype.uninitHeader = function () {
    if (!this.tHead) return;
    var cells = this.tHead.rows[0].cells;
    var l = cells.length;
    var c;
    for (var i = 0; i < l; i++) {
        c = cells[i];
        if (c._sortType != null && c._sortType != "None") {
            c.removeChild(c.lastChild);
            if (typeof c.removeEventListener != "undefined")
                c.removeEventListener("click", this._headerOnclick, false);
            else if (typeof c.detachEvent != "undefined")
                c.detachEvent("onclick", this._headerOnclick);
            c._sortType = null;
            c.removeAttribute("_sortType");
        }
    }
};

SortableTable.prototype.updateHeaderArrows = function () {
    if (!this.tHead) return;
    var cells = this.tHead.rows[0].cells;
    var l = cells.length;
    var img;
    for (var i = 0; i < l; i++) {
        if (cells[i]._sortType != null && cells[i]._sortType != "None") {
            img = cells[i].lastChild;
            if (i == this.sortColumn)
                img.className = "sort-arrow " + (this.descending ? "descending" : "ascending");
            else
                img.className = "sort-arrow";
        }
    }
};

SortableTable.prototype.headerOnclick = function (e) {
    // find TD element
    var el = e.target || e.srcElement;
    while (el.tagName != "TD")
        el = el.parentNode;

    this.sort(SortableTable.msie ? SortableTable.getCellIndex(el) : el.cellIndex);
};

// IE returns wrong cellIndex when columns are hidden
SortableTable.getCellIndex = function (oTd) {
    var cells = oTd.parentNode.childNodes
    var l = cells.length;
    var i;
    for (i = 0; cells[i] != oTd && i < l; i++)
        ;
    return i;
};

SortableTable.prototype.getSortType = function (nColumn) {
    return this._sortTypes[nColumn] || "String";
};

// only nColumn is required
// if bDescending is left out the old value is taken into account
// if sSortType is left out the sort type is found from the sortTypes array

SortableTable.prototype.sort = function (nColumn, bDescending, sSortType) {
    if (!this.tBody) return;
    if (sSortType == null)
        sSortType = this.getSortType(nColumn);

	// exit if None
    if (sSortType == "None")
        return;

    if (bDescending == null) {
        if (this.sortColumn != nColumn)
            this.descending = this.defaultDescending;
        else
            this.descending = !this.descending;
    }
    else
        this.descending = bDescending;

    this.sortColumn = nColumn;

    if (typeof this.onbeforesort == "function")
        this.onbeforesort();

    var f = this.getSortFunction(sSortType, nColumn);
    var a = this.getCache(sSortType, nColumn);
    var tBody = this.tBody;

    a.sort(f);

    if (this.descending)
        a.reverse();

    if (SortableTable.removeBeforeSort) {
        // remove from doc
        var nextSibling = tBody.nextSibling;
        var p = tBody.parentNode;
        p.removeChild(tBody);
    }

	// insert in the new order
    var l = a.length;
    for (var i = 0; i < l; i++)
        tBody.appendChild(a[i].element);

    if (SortableTable.removeBeforeSort) {
        // insert into doc
        p.insertBefore(tBody, nextSibling);
    }

    this.updateHeaderArrows();

    this.destroyCache(a);

    if (typeof this.onsort == "function")
        this.onsort();
};

SortableTable.prototype.asyncSort = function (nColumn, bDescending, sSortType) {
    var oThis = this;
    this._asyncsort = function () {
        oThis.sort(nColumn, bDescending, sSortType);
    };
    window.setTimeout(this._asyncsort, 1);
};

SortableTable.prototype.getCache = function (sType, nColumn) {
    if (!this.tBody) return [];
    var rows = this.tBody.rows;
    var l = rows.length;
    var a = new Array(l);
    var r;
    for (var i = 0; i < l; i++) {
        r = rows[i];
        a[i] = {
            value:                this.getRowValue(r, sType, nColumn),
            element:        r
        };
    }
    ;
    return a;
};

SortableTable.prototype.destroyCache = function (oArray) {
    var l = oArray.length;
    for (var i = 0; i < l; i++) {
        oArray[i].value = null;
        oArray[i].element = null;
        oArray[i] = null;
    }
};

SortableTable.prototype.getRowValue = function (oRow, sType, nColumn) {
    // if we have defined a custom getRowValue use that
    if (this._sortTypeInfo[sType] && this._sortTypeInfo[sType].getRowValue)
        return this._sortTypeInfo[sType].getRowValue(oRow, nColumn);

    var s;
    var c = oRow.cells[nColumn];
    if (typeof c.innerText != "undefined")
        s = c.innerText;
    else
        s = SortableTable.getInnerText(c);
    return this.getValueFromString(s, sType);
};

SortableTable.getInnerText = function (oNode) {
    var s = "";
    var cs = oNode.childNodes;
    var l = cs.length;
    for (var i = 0; i < l; i++) {
        switch (cs[i].nodeType) {
            case 1: //ELEMENT_NODE
                s += SortableTable.getInnerText(cs[i]);
                break;
            case 3:        //TEXT_NODE
                s += cs[i].nodeValue;
                break;
        }
    }
    return s;
};

SortableTable.prototype.getValueFromString = function (sText, sType) {
    if (this._sortTypeInfo[sType])
        return this._sortTypeInfo[sType].getValueFromString(sText);
    return sText;
    /*
        switch (sType) {
                case "Number":
                        return Number(sText);
                case "CaseInsensitiveString":
                        return sText.toUpperCase();
                case "Date":
                        var parts = sText.split("-");
                        var d = new Date(0);
                        d.setFullYear(parts[0]);
                        d.setDate(parts[2]);
                        d.setMonth(parts[1] - 1);
                        return d.valueOf();
        }
        return sText;
        */
};

SortableTable.prototype.getSortFunction = function (sType, nColumn) {
    if (this._sortTypeInfo[sType])
        return this._sortTypeInfo[sType].compare;
    return SortableTable.basicCompare;
};

SortableTable.prototype.destroy = function () {
    this.uninitHeader();
    var win = this.document.parentWindow;
    if (win && typeof win.detachEvent != "undefined") {        // only IE needs this
        win.detachEvent("onunload", this._onunload);
    }
    this._onunload = null;
    this.element = null;
    this.tHead = null;
    this.tBody = null;
    this.document = null;
    this._headerOnclick = null;
    this.sortTypes = null;
    this._asyncsort = null;
    this.onsort = null;
};

// Adds a sort type to all instance of SortableTable
// sType : String - the identifier of the sort type
// fGetValueFromString : function ( s : string ) : T - A function that takes a
//    string and casts it to a desired format. If left out the string is just
//    returned
// fCompareFunction : function ( n1 : T, n2 : T ) : Number - A normal JS sort
//    compare function. Takes two values and compares them. If left out less than,
//    <, compare is used
// fGetRowValue : function( oRow : HTMLTRElement, nColumn : int ) : T - A function
//    that takes the row and the column index and returns the value used to compare.
//    If left out then the innerText is first taken for the cell and then the
//    fGetValueFromString is used to convert that string the desired value and type

SortableTable.prototype.addSortType = function (sType, fGetValueFromString, fCompareFunction, fGetRowValue) {
    this._sortTypeInfo[sType] = {
        type:                                sType,
        getValueFromString:        fGetValueFromString || SortableTable.idFunction,
        compare:                        fCompareFunction || SortableTable.basicCompare,
        getRowValue:                fGetRowValue
    };
};

// this removes the sort type from all instances of SortableTable
SortableTable.prototype.removeSortType = function (sType) {
    delete this._sortTypeInfo[sType];
};

SortableTable.basicCompare = function compare(n1, n2) {
    if (n1.value < n2.value)
        return -1;
    if (n2.value < n1.value)
        return 1;
    return 0;
};

SortableTable.idFunction = function (x) {
    return x;
};

SortableTable.toUpperCase = function (s) {
    return s.toUpperCase();
};

SortableTable.toDate = function (s) {
    var parts = s.split("-");
    var d = new Date(0);
    d.setFullYear(parts[0]);
    d.setDate(parts[2]);
    d.setMonth(parts[1] - 1);
    return d.valueOf();
};


// add sort types
SortableTable.prototype.addSortType("Number", Number);
SortableTable.prototype.addSortType("CaseInsensitiveString", SortableTable.toUpperCase);
SortableTable.prototype.addSortType("Date", SortableTable.toDate);
SortableTable.prototype.addSortType("String");
// None is a special case
