﻿define(
   ({
    _widgetLabel: "Rediģēt",
    title: "Izvēlēties šablonu, lai veidotu elementus",
    pressStr: "Nospiediet ",
    ctrlStr: " CTRL ",
    snapStr: " , lai iespējotu pieķeršanos"
  })
);