using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.ArcMapUI;
using System.Windows.Forms;

namespace WCTools
{
    /// <summary>
    /// Summary description for cmdSrchSAPAttr.
    /// </summary>
    [Guid("c4f44b06-c4ae-4ff3-9133-984037f1faaf")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("WCTools.cmdSrchSAPAttr")]
    public sealed class cmdSrchSAPAttr : BaseCommand
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IApplication m_application;
        public cmdSrchSAPAttr()
        {
            //
            // TODO: Define values for the public properties
            //
            base.m_category = "WSLTools"; //localizable text
            base.m_caption = "WSLTools.SrchSAPAttributes";  //localizable text
            base.m_message = "WSLTools.SrchSAPAttributes";  //localizable text 
            base.m_toolTip = "Search SAPAttributes";  //localizable text 
            base.m_name = "WSLTools.SrchSAPAttributes";   //unique id, non-localizable (e.g. "MyCategory_ArcMapCommand")

            try
            {
                //
                // TODO: change bitmap name if necessary
                //
                string bitmapResourceName = GetType().Name + ".bmp";
                base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
            }
        }

        #region Overridden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook == null)
                return;

            m_application = hook as IApplication;

            //Disable if it is not ArcMap
            if (hook is IMxApplication)
                base.m_enabled = true;
            else
                base.m_enabled = false;

            // TODO:  Add other initialization code
        }

        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            // TODO: Add cmdSrchSAPAttr.OnClick implementation
            //MessageBox.Show("Under development!!");
            //return;

            using (WCTools.BL.Forms.frmSrchSAPAttr vFrmSrchSAPAttr = new BL.Forms.frmSrchSAPAttr())
            {
                string vLogCurrSessId = DateTime.Now.ToString("yyyyMMdd:hhmmss");
                try
                {
                    vFrmSrchSAPAttr.__AppMap = m_application;
                    vFrmSrchSAPAttr.vLogSession = vLogCurrSessId;
                    vFrmSrchSAPAttr.helpersActivate(); 
                    if (vFrmSrchSAPAttr.validateOnLoad())
                    {
                        vFrmSrchSAPAttr.ShowDialog();
                    }

                }
                catch( Exception e)
                {
                    MessageBox.Show("GPF!  -> " + e.Message.ToString());
                    vFrmSrchSAPAttr.logNtry("WCTools", "SetGISIdMulti", e.Message.ToString(), vLogCurrSessId, "EXP");
                }
                finally
                {
                    vFrmSrchSAPAttr.helpersDeActivate(); 
                }

            }
        }

        #endregion
    }
}
