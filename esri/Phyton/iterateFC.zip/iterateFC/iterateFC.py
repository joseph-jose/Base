import arcpy
import os
import datetime

#FCs = arcpy.GetParameterAsText(0)
#FCs = 'C:\Joseph\Task\TASK-38428_OpenCarParks\ProjectData.gdb'
FCs = r'\\atalnapn02\vol_cifs_t2_user_data$\AC_FGDBs\Publication20180826.gdb'
#FCs = r'\\atalnapn02\vol_cifs_t2_user_data$\AC_FGDBs\PropertyAndConsents20180812.gdb'

arcpy.env.workspace = FCs

#datasets = arcpy.ListDatasets(feature_type='feature')
#datasets = [''] + datasets if datasets is not None else []

print(datetime.datetime.now())
#for ds in datasets:
#    print('For FC')
for fc in arcpy.ListFeatureClasses():
#    #print('Path')
#    #path = os.path.join(arcpy.env.workspace, ds, fc)
    print(fc)
print(datetime.datetime.now())
    
   
