﻿define({
    left: "LEWA",
    right: "PRAWA",
    arrangement: "Rozmieszczenie",
    autoUpdate: "Automatyczna aktualizacja",
    respectCurrentMapScale: "Uwzględniaj bieżącą skalę mapy"
});