// comment out to disable notifications
$( document ).ready(function() {
  // $.notify("Help guide: New section on Draw Widget", {
  //   position: 'bottom right',
  //   style: 'bootstrap',
  //   className: 'success',
  //   autoHide: true,
  //   autoHideDelay: 7000,
  //   arrowSize: 5,
  //   showAnimation: 'slideDown',
  //   gap: 2
  // });
  // // click on nofity to go to site
  // $(".notifyjs-container").on('click', function(){
  //   window.location.href= "helpnv.html";  
  // });

});

