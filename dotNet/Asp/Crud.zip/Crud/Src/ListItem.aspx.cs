﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ListItem : System.Web.UI.Page
{
    int vGlobalRes = -1; //' Result of the Global function
//dynamic server switch
    private void getDbVals(out string outSrvrName, out string outSrvrPwd)
    {
        string vWebSrvrName = "";
        vWebSrvrName = Request.ServerVariables["SERVER_NAME"];

        //Dynamic server switch
        switch (vWebSrvrName)
        {
            case "localhost":
                outSrvrName = "WSLDCTDGDB";
                outSrvrPwd = "G1s@webde01";
                break;
            case "wsldctdgweb":
                outSrvrName = "WSLDCTDGDB";
                outSrvrPwd = "G1s@webde01";
                break;
            case "giswebdev":
                outSrvrName = "WSLDCTDGDB";
                outSrvrPwd = "G1s@webde01";
                break;
            case "giswebtest":
                outSrvrName = "WSLDCTTGDBR";
                outSrvrPwd = "Agsw105G1s@t01";
                break;
            case "wsldcttgweb":
                outSrvrName = "WSLDCTTGDBR";
                outSrvrPwd = "Agsw105G1s@t01";
                break;
            case "gisweb":
                outSrvrName = "WSLDCTPGDBR";
                outSrvrPwd = "AgsP105G1s@w01";
                break;
            case "wsldctpgweb":
                outSrvrName = "WSLDCTPGDBR";
                outSrvrPwd = "AgsP105G1s@w01";
                break;
            default:
                outSrvrName = "WSLDCTPGDBR";
                outSrvrPwd = "AgsP105G1s@w01";
                break;
        }
    }

    private bool getRecordsFId(string inSrchName, string inSrchKey, string inDbName)
    {
        bool bRetFn = false;

        string vSrvrName = "";
        string vPsswrd = "";
        getDbVals(out vSrvrName, out vPsswrd);

        try
        {
            DSSearch.ConnectionString = "Data Source={0};User ID=gisweb;Password={1};Initial Catalog={2}";
            DSSearch.ConnectionString = string.Format(DSSearch.ConnectionString, vSrvrName, vPsswrd, inDbName);

            DSSearch.ConnectionString = "Driver={Microsoft Access Driver (*.mdb, *.accdb)};Dbq=C:\\Joseph\\Source\\Official\\Work\\Crud\\Db\\DbData.accdb;Uid=Admin;Pwd=;";

            DSSearch.SelectCommand = string.Format("SELECT TOP 1000 [FCLASS] ,[LAYER] ,[GIS_ID] ,[EQUIP_ID] ,[COMPKEY] ,[STATUS] , [DATASOURCE] FROM [GISWSL].[WA_Netview_View] where DATASOURCE like '%{0}%'", inSrchKey);
            grdVw.DataSource = DSSearch;
            grdVw.DataBind();
            bRetFn = true;

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
        finally
        {
            //if (!(vSqlCmd == null))
            //{
            //    vSqlCmd = null;
            //}
            //if (!(vAdoConn == null))
            //{
            //    vAdoConn.Close();
            //    vAdoConn = null;
            //}
        }
        return bRetFn;
    }

    private void getUrlNameKeyPair(out string outQryParamStr, out string outIDToSrchInt)
    {
        string vQryParamStr, vQryValStr;
        vQryParamStr = "";
        string ViDToSrchStr;
        ViDToSrchStr = "";
        for (int vI = 0; vI < Request.QueryString.Keys.Count; vI++)
        {
            vQryParamStr = Request.QueryString.Keys[vI].ToString();
            vQryValStr = Request.QueryString[Request.QueryString.Keys[vI].ToString()];

            switch (vQryParamStr.ToUpper())
            {
                case "DMSID":
                    ViDToSrchStr = vQryValStr;
                    break;
                case "COMPKEY":
                    //ViDToSrchStr = vQryValStr;
                    break;
            }
        }

        outIDToSrchInt = ViDToSrchStr;
        outQryParamStr = vQryParamStr.ToUpper();
    }

    private bool valParams(out string voutQryParamStr, out string VoutiDToSrchStr)
    {
        bool vRetFn = true;

        getUrlNameKeyPair(out voutQryParamStr, out VoutiDToSrchStr);

        if (VoutiDToSrchStr == "")
        {
            vGlobalRes = -1;
            vRetFn = false;
            return vRetFn;
        }

        return vRetFn;
    }


    private void loadPages()
    {
        string vQryParamStr = "";
        string ViDToSrchStr = "";
        if (Request.QueryString.Keys.Count == 0)
        {
            Label1.Text = "Valid parameters not found";
            Label1.Visible = true;
            return;
        }


        if (valParams(out vQryParamStr, out ViDToSrchStr))
        {
            switch (vQryParamStr.ToUpper())
            {
                case "DMSID":
                    if (!getRecordsFId(vQryParamStr, ViDToSrchStr, "GISNet1"))
                    {
                        vGlobalRes = -1;
                    }
                    else
                        vGlobalRes = 11;
                    break;
                case "GISID":
                    //vGlobalRes = procGISID(vQryParamStr, ViDToSrchStr);
                    break;
            }
        }


        if (vGlobalRes == -1)
        {
            Label1.Text = "<br/><br/><br/>GPF-><br /> Please contact <a href=mailto:GISServices@water.co.nz>GISServices</a> for more information <br/><br/><br/><br/><br/><br/>";
            Label1.Visible = true;
        }
        else if (vGlobalRes == 10)
            Label1.Text = "<br/><br/><br/>This asset does not exist in GIS - please try a different search.<br/><br/><br/><br/><br/><br/>";
        else if (vGlobalRes == 0)
            Label1.Text = "<br/><br/><br/>This asset does not exist in GIS - please try a different search.<br/><br/><br/><br/><br/><br/>";

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //http://localhost:6797/GISDmsSearch.aspx?DMSID=R0006515
        try
        {
            loadPages();
        }
        catch (Exception ex)
        {
            Response.Write("Error : " + ex.Message.ToString());
        }
    }


    protected void grdVw_PageIndexChanged(object sender, EventArgs e)
    {


    }

    protected void grdVw_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        e.Cancel = false;
        grdVw.PageIndex = e.NewPageIndex;
        loadPages();
    }
}
