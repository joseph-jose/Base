#
#        _                        
#  _ __ |_|_ __   __ _  __ _ _ __ 
# | '_ \| | '_ \ / _` |/ _` | '__|
# | |_) | | | | | (_| | (_| | |   
# | .__/|_|_| |_|\__, |\__,_|_|   
# |_|            |___/            
#
# This code is example code and is provided "as-is" without warranty.  You may modify, copy and distribute this code.

Param(
    [Parameter(Mandatory = $True)]
    [ValidateNotNull()]
    $siteUrl,
    [Parameter(Mandatory = $True)]
    [ValidateNotNull()]
    $listTitle,
    [Parameter(Mandatory = $True)]
    [ValidateNotNull()]
    $username,
    [Parameter(Mandatory = $True)]
    [ValidateNotNull()]
    $password,
    [Parameter(Mandatory = $True)]
    [ValidateNotNull()]
    $workingDirectoryPath,
    [Parameter(Mandatory = $True)]
    [ValidateNotNull()]
    $outputFilePath
)

# An array to hold all of the ListItems
$global:allItems = @()

$securePassword = ConvertTo-SecureString $password -AsPlainText -Force

$libraryPath = $workingDirectoryPath + "\Microsoft.SharePoint.Client.dll"
Add-Type -Path $libraryPath
$libraryPath = $workingDirectoryPath + "\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path $libraryPath


Write-Host ("`nStarting the process to fetch all list item details under the target {0}`n" -f $siteUrl)

$ctx = New-Object Microsoft.SharePoint.Client.ClientContext($siteUrl)
if ($siteUrl -match "sharepoint.com") {
    $ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($username, $securePassword)
}
else {
    $psCred = New-Object System.Management.Automation.PSCredential ($username, $securePassword)
    $ctx.Credentials = $psCred.GetNetworkCredential()
}

$ll = $ctx.Web.Lists.GetByTitle($listTitle)
$defaultViewFlds = $ll.DefaultView.ViewFields
$ctx.Load($ll)
$ctx.Load($defaultViewFlds)
$ctx.ExecuteQuery()
$fieldArray = @()
$llFields = @()

foreach ($fld  in $defaultViewFlds) {
    $llField = $ll.Fields.GetByInternalNameOrTitle($fld)
    $ctx.Load($llField)
    $ctx.ExecuteQuery()
    $fieldString = "<FieldRef Name='{0}' />" -f $fld
    $fieldArray += $fieldString
    $llFields += $llField    
}

$fieldQueryString = [string]::Join("", $fieldArray)

# Prepare the query
$query = New-Object Microsoft.SharePoint.Client.CamlQuery
$query.ViewXml = "<View Scope='RecursiveAll'><RowLimit>4999</RowLimit><ViewFields>{0}</ViewFields></View>" -f $fieldQueryString

# Get Items from the List until we reach the end
$index = 0
do {
    $listItems = $ll.GetItems($query)
    $ctx.Load($listItems)
    $ctx.ExecuteQuery()
    $query.ListItemCollectionPosition = $listItems.ListItemCollectionPosition
    foreach ($item in $listItems) {
        # Add each item
        $fldValues = $item.FieldValuesAsText
        $ctx.Load($fldValues)
        $ctx.ExecuteQuery()
        $term = New-Object PSObject
        foreach ($fld in $llFields) {
            if ($fld.InternalName -in "LinkTitle", "LinkTitleNoMenu", "SurveyTitle") {
                $term | Add-Member -Name $fld.Title -MemberType NoteProperty -Value $fldValues["Title"]    
            }
            else {
                $term | Add-Member -Name $fld.Title -MemberType NoteProperty -Value $fldValues[$fld.InternalName]
            }            
        }
        $index = $index + 1
        $global:allItems += $term 
        Write-Progress -Activity "Fetch SPO List Items" -Status "Progress:" -PercentComplete ($index / $ll.ItemCount * 100)
    }
}
While ($query.ListItemCollectionPosition -ne $null)

$global:allItems | Export-Csv $outputFilePath -notype -encoding "unicode" -Delimiter '|'

Write-Host "`nProcessing complete!`n"