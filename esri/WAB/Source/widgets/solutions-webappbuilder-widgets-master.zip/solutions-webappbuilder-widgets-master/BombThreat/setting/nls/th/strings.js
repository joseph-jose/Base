﻿define({
    left: "ก้_LEFT_ษฺ",
    right: "ก้_RIGHT_ษฺ",
    arrangement: "การจัดเรียง",
    autoUpdate: "อัพเดทอัตโนมัติ",
    respectCurrentMapScale: "เชื่อในมาตราส่วนแผนที่ปัจจุบัน"
});