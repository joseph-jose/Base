﻿define(
   ({
    _widgetLabel: "Muuda",
    title: "Valige objektide loomiseks mall",
    pressStr: "Snäppimise kasutamiseks ",
    ctrlStr: " vajutage ",
    snapStr: " CTRL"
  })
);