﻿define(
   ({
    _widgetLabel: "Redaguoti",
    title: "Pasirinkite šabloną elementui kurti",
    pressStr: "Paspausti ",
    ctrlStr: " CTRL ",
    snapStr: " pritraukimui įjungti"
  })
);