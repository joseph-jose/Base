﻿define(
   ({
    _widgetLabel: "แก้ไข",
    title: "เลือกเทมเพลตเพื่อสร้างฟีเจอร์",
    pressStr: "กด ",
    ctrlStr: " CTRL ",
    snapStr: " เพื่อเปิดการใช้งาน Snapping"
  })
);