﻿define(
   ({
    _widgetLabel: "编辑",
    title: "选择模板以创建要素",
    pressStr: "按 ",
    ctrlStr: " Ctrl 键 ",
    snapStr: " 以启用捕捉"
  })
);