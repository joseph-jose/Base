﻿define(
   ({
    enableUndoRedo: "[元に戻す]/[やり直し] の有効化",
    toolbarVisible: "ツールバーの表示",
    toolbarOptions: "ツールバーのオプション",
    mergeVisible: "マージ",
    cutVisible: "切り取り",
    reshapeVisible: "形状変更",
    back: "戻る",
    label: "レイヤー",
    edit: "編集可能",
    update: "ジオメトリ更新の無効化",
    fields: "フィールド",
    actions: "アクション",
    editpageName: "名前",
    editpageAlias: "エイリアス",
    editpageVisible: "表示",
    editpageEditable: "編集可能",
    noLayers: "編集可能なフィーチャ レイヤーはありません",
    configureFields: "レイヤー フィールドの構成"
  })
);