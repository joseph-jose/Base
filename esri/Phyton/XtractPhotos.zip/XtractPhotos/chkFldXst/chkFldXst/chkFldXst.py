import arcpy 
import arcpy.da 

try:

	FCs = arcpy.GetParameterAsText(0)
	arcpy.env.workspace = FCs

	inFeature = "ObservePoints__ATTACH"
	dfieldname = "UniqueIdR"
	sfieldname = "UniqueId"
	xfieldname = "UniqueId"

        def chkIfFldXsts():
            vFldNames = arcpy.ListFields(inFeature, dfieldname)        
            if len(vFldNames) > 0:
                return True
            else:
                return False

        if (not(chkIfFldXsts())):
            print "Xists"
        else:
            print "NotXists"


except Exception as err:
	arcpy.AddError(err)
	print err

