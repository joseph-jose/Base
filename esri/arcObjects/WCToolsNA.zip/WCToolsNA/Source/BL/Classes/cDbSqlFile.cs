﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace WCToolsNA.BL.Classes
{
    class cDbSqlFile : cDbFile
    {

        #region " SQL Server queries "
        //'SQL SERVER SPECIFIC CODES

        //'***************************************
        //' Return the tables in the database
        //'***************************************
        public string GetSqlFSqlSrvrTbls(string inDb)
        {
            string vStr;
            vStr = "select name from {0}.dbo.sysobjects where type = 'U'";
            vStr = String.Format(vStr, inDb);
            return vStr;
        }
        //'***************************************
        //' Return the datases in the SQL Server
        //'***************************************
        public string GetSqlFSqlSrvrDbs()
        {
            return String.Concat("SELECT dbid,[name] FROM master.dbo.sysdatabases ",
                                 "WHERE dbid > 4");
        }
        //'***************************************
        //' Return SQL Servers in the networks
        //'Microsoft comments that this function may be dependant on various factors
        //'***************************************
        public DataTable GetSQLServers()
        {
            System.Data.Sql.SqlDataSourceEnumerator instance = System.Data.Sql.SqlDataSourceEnumerator.Instance;
            System.Data.DataTable vTbl = instance.GetDataSources();
            return vTbl;
        }

        #endregion




    }
}
