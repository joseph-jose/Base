﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCTools.BL.Classes;
using System.Configuration;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase; 

namespace WCTools.BL.Forms
{
    public partial class frmUpdSAPAttr : Form
    {
        private IApplication vApp;
        public IApplication vAppMap { set { vApp = value; } }
        private string vLogSessId = "";
        public string vLogSessionId { set { vLogSessId = value; } }

        WCTools.BL.Classes.cDbSqlFile vDbFile ;
        WCTools.BL.Classes.cUtilFile vUtilFile ;
        WCTools.BL.Classes.cUtilGIS vGISUtil;

        private IFeature vSelFeature;
        private DataRow vSelDataRow;

        public bool helpersActivate()
        {
            bool vBRes = true;
            vDbFile = new cDbSqlFile();
            vUtilFile = new cUtilFile();
            vGISUtil = new cUtilGIS() ;
            vGISUtil.vAppMap = vApp;

            //20170510 Non GISEditor intimation
            //connDB();
            try
            {
                connDB();
            }
            catch (Exception e)
            {
                MessageBox.Show("Access to database couldn't be obtained");
                vBRes = false;
                return vBRes;
            }
            //20170510 Non GISEditor intimation
            logNtry("WCTools", "UpdSAPAttr", "Start", vLogSessId, "TRC");
            return vBRes;
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "UpdSAPAttr", "End", vLogSessId, "TRC");
            vDbFile.CleanUpDBConnection();
            vDbFile.Dispose();
            vDbFile = null ;
            vGISUtil.Dispose();
            vGISUtil = null;

        }
        
        public void connDB()
        {
            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            vDbFile.ConnectToDatabase(3, vConnStr);
        }

        public void logNtry()
        {
        }
        ~frmUpdSAPAttr()
        {
            vSelFeature = null;
            vSelDataRow = null;
            vUtilFile = null;
            vApp = null;
        }
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            //20150722
            //vUtilFile.logNtry(vDbFile, inCmdType, inMsg, inFld1, inSessId, inLogType);
            vUtilFile.logTxtNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
            //20150722
        }

        public frmUpdSAPAttr()
        {
            InitializeComponent();
        }

        #region GridUtilities
        //20150422
        //private void getArrVals(out string[] outFeatFldStr, out string[] outSAPFldStr, out Type[] outDtTypeFldStr)
        //{
        //    string[] vFeatFldStr = new string[8];

        //    vFeatFldStr[0] = "FAC_CODE";
        //    vFeatFldStr[1] = "PROC_CODE";
        //    vFeatFldStr[2] = "GRP_CODE";
        //    vFeatFldStr[3] = "INSTALLED";
        //    vFeatFldStr[4] = "CP_ID";
        //    vFeatFldStr[5] = "NOM_DIA_MM";
        //    vFeatFldStr[6] = "STATUS";
        //    vFeatFldStr[7] = "MODIFYREF";
        //    outFeatFldStr = vFeatFldStr;

        //    string[] vSAPFldStr = new string[8];
        //    vSAPFldStr[0] = "FACILITY";
        //    vSAPFldStr[1] = "PROCESS";
        //    vSAPFldStr[2] = "GROUPCODE";
        //    vSAPFldStr[3] = "DATEACQUIRED";
        //    vSAPFldStr[4] = "MPA_005_CP_SITE_ID";
        //    vSAPFldStr[5] = "SAP_NOM_DIA_MM_TMP";
        //    vSAPFldStr[6] = "SAP_STATUS_TMP";
        //    vSAPFldStr[7] = "GIS_REF";
        //    outSAPFldStr = vSAPFldStr;

        //    Type[] vDtTypeFldStr = new Type[8];
        //    vDtTypeFldStr[0] = typeof(string);
        //    vDtTypeFldStr[1] = typeof(string);
        //    vDtTypeFldStr[2] = typeof(string);
        //    vDtTypeFldStr[3] = typeof(DateTime);
        //    vDtTypeFldStr[4] = typeof(string);
        //    vDtTypeFldStr[5] = typeof(string);
        //    vDtTypeFldStr[6] = typeof(string);
        //    vDtTypeFldStr[7] = typeof(string);
        //    outDtTypeFldStr = vDtTypeFldStr;

        //    //for (int i = 0; i < vSAPFldStr.Length; i++)
        //    //{
        //    //    dtGrdLstAttr.Rows.Add();
        //    //    dtGrdLstAttr[0, dtGrdLstAttr.RowCount - 1].Value = vFeatFldStr[i];
        //    //    dtGrdLstAttr[3, dtGrdLstAttr.RowCount - 1].Value = vDtTypeFldStr[i];
        //    //    dtGrdLstAttr[4, dtGrdLstAttr.RowCount - 1].Value = vDtTypeFldStr[i].ToString();
        //    //}
        //}
        private void setFldValue(string inFeatFldName, string inSAPFldName)
        {
            string vTmpVal = "";
            DateTime vtmpDate;

            if (!(vGISUtil.getFieldIdx(vSelFeature, inFeatFldName) == -1))
            {
                dtGrdLstAttr.Rows.Add();
                if (vSelDataRow[inSAPFldName].GetType() is System.DateTime)
                {
                    if (DateTime.TryParse(vGISUtil.getFieldValue(vSelFeature, inFeatFldName).ToString(), out vtmpDate))
                    {
                        vTmpVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                    }
                }
                else
                    vTmpVal = vGISUtil.getFieldValue(vSelFeature, inFeatFldName).ToString();

                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = inFeatFldName;
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                if (vSelDataRow[inSAPFldName].GetType() is System.DateTime)
                {
                    if (DateTime.TryParse(vTmpVal = vSelDataRow[inSAPFldName].ToString(), out vtmpDate))
                    {
                        vTmpVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                    }
                }
                else
                    vTmpVal = vSelDataRow[inSAPFldName].ToString();

                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = inSAPFldName;
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;
            }
        }
        //20150422
        private void setGridVals()
        {
            //20160920
            //New netview
            setFldValue("FAC_CODE", "FACILITY");
            setFldValue("SITE_ID", "MPA_005_CP_SITE_ID");
            //setFldValue("GRP_CODE", "GROUPCODE");
            //setFldValue("PROC_CODE", "PROCESS");
            //setFldValue("CP_ID", "MPA_005_CP_SITE_ID");
            //20160920
            setFldValue("INSTALLED", "DATEACQUIRED");
            setFldValue("NOM_DIA_MM", "SAP_NOM_DIA_MM_TMP");
            setFldValue("MODIFYREF", "GIS_REF");
            setFldValue("STATUS", "SAP_STATUS_TMP");
            setFldValue("MATERIAL", "MATERIAL");
        }

        //public void setFldVal(string inFldNm, string inFldVal)
        //{
        //    //IWorkspaceEdit vWrkSpcEdt = vGisEdtr.getWrkSpcFFeature(inFeat);
        //    //vWrkSpcEdt.StartEditOperation();

        //    vGISUtil.setFieldValue(vSelFeature, inFldNm, inFldVal );

        //    //vWrkSpcEdt.StopEditOperation();
        //}

        private void updGridCells()
        {
            string vCol1, vCol2;
            //log
            int vResFnSetDomChk = -1;
            string vLogStr = "";
            this.Cursor = Cursors.WaitCursor;
            IWorkspaceEdit vWkrSpcEdt = vGISUtil.getWrkSpcFFeature(vSelFeature);
            vWkrSpcEdt.StartEditOperation();
            try
            {
                for (int i = 0; i < dtGrdLstAttr.RowCount; i++)
                {
                    if (dtGrdLstAttr[4, i].Value == null)
                        vCol2 = "";
                    else
                        vCol2 = dtGrdLstAttr[4, i].Value.ToString();
                    if (dtGrdLstAttr[1, i].Value == null)
                        vCol1 = "";
                    else
                        vCol1 = dtGrdLstAttr[1, i].Value.ToString();


                    if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                    {
                        if (!(vCol2 == ""))
                        {
                            vCol1 = dtGrdLstAttr[0, i].Value.ToString();
                            //20150720 Domain check fun
                            dtGrdLstAttr[1, i].Value = vCol2;
                            dtGrdLstAttr[2, i].Style.BackColor = Color.White;
                            vGISUtil.setFieldValue(vSelFeature, vCol1, vCol2);
                            //vResFnSetDomChk = vGISUtil.setFieldWDomCheckValue(vSelFeature, vCol1, vCol2);
                            //if (!(vResFnSetDomChk == 0))
                            //{
                            //    if (vResFnSetDomChk == -2)
                            //    {
                            //        MessageBox.Show(String.Format("Field does not exists:{0}", vCol1));
                            //    }
                            //    if (vResFnSetDomChk == -3)
                            //    {
                            //        MessageBox.Show(String.Format("Invalid Domain value for Field {0} -> {1}", vCol1, vCol2));
                            //    }
                            //}
                            //else
                            //{
                            //    dtGrdLstAttr[1, i].Value = vCol2;
                            //    dtGrdLstAttr[2, i].Style.BackColor = Color.White;
                            //}
                            //20150720 Domain check fun end

                            //log
                            if (!(vLogStr == ""))
                            {
                                vLogStr = vLogStr + ",";
                            }
                            vLogStr = vLogStr + vCol1 + "=" + vCol2;
                        }
                    }
                    Application.DoEvents();
                }

                //log
                vCol2 = vGISUtil.getFieldValue(vSelFeature, "GIS_ID").ToString();
                vCol1 = "GIS_ID";
                vLogStr = vLogStr + "[" + vCol1 + "=" + vCol2 + "]";
                logNtry("WCTools", "UpdSAPAttr", vLogStr, vLogSessId , "TRC");

            }
            finally
            {
                vWkrSpcEdt.StopEditOperation();
                this.Cursor = Cursors.Default;
            }
        }
        private void hghlghtGrid()
        {
            string vCol1, vCol2;
            for (int i = 0; i < dtGrdLstAttr.RowCount; i++)
            {
                if (dtGrdLstAttr[4, i].Value == null)
                    vCol2 = "";
                else
                    vCol2 = dtGrdLstAttr[4, i].Value.ToString();
                if (dtGrdLstAttr[1, i].Value == null)
                        vCol1 = "";
                else
                        vCol1 = dtGrdLstAttr[1, i].Value.ToString();


                if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                {
                        dtGrdLstAttr[2, i].Style.BackColor = Color.Red;
                }
            }

        }
        #endregion

        public bool validateOnLoad(out int outEqpId)
        {
            bool vResFn = false;
            outEqpId = -1;
            if (!(vGISUtil.getFeatureSelectCount() == 1) )
            {
                MessageBox.Show("Select single feature");
                return vResFn;
            }
            IFeature vFeat;
            IEnumFeature vEnmFeat = vGISUtil.getSelectedFeatures(); 
            vEnmFeat.Reset() ;
            vFeat = vEnmFeat.Next();
            IWorkspaceEdit vWrkSpcEdit = vGISUtil.getWrkSpcFFeature(vFeat);
            if (!(vWrkSpcEdit.IsBeingEdited()))
            {
                MessageBox.Show("Feature not in edit mode");
                return vResFn;
            }

            //New netview
            int vFldIdx = vGISUtil.getFieldIdx(vFeat, "AMS");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute AMS missing for feature");
                return vResFn;
            }
            object vAMSFldVal = vGISUtil.getFieldValue(vFeat, "AMS");
            if (!(vAMSFldVal.ToString() == "SAP"))
            {
                MessageBox.Show("Selected feature should be a SAP feature");
                return vResFn;
            }
            //New netview end

            vFldIdx = vGISUtil.getFieldIdx(vFeat, "FAC_CODE");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute FAC_CODE missing for feature");
                return vResFn;
            }
            //vFldIdx = vGISUtil.getFieldIdx(vFeat, "PROC_CODE");
            //if (vFldIdx == -1)
            //{
            //    MessageBox.Show("Attribute PROC_CODE missing for feature");
            //    return vResFn;
            //}
            vFldIdx = vGISUtil.getFieldIdx(vFeat, "INSTALLED");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute INSTALLED missing for feature");
                return vResFn;
            }

            vFldIdx = vGISUtil.getFieldIdx(vFeat, "MODIFYREF");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute NOM_DIA_MM missing for feature");
                return vResFn;
            }
            vFldIdx = vGISUtil.getFieldIdx(vFeat, "STATUS");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute STATUS missing for feature");
                return vResFn;
            }

            vFldIdx = vGISUtil.getFieldIdx(vFeat, "EQUIP_ID");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute EQUIP_ID missing for feature");
                return vResFn;
            }
            else
            {
                object vobjEqpFld = vGISUtil.getFieldValue(vFeat, "EQUIP_ID");
                if (vobjEqpFld is System.DBNull)
                {
                    MessageBox.Show("Attribute EQUIP_ID missing for feature");
                    return vResFn;
                }
                else
                {
                    outEqpId = (int) vobjEqpFld ;
                }
            }
            vSelFeature = vFeat;


            vResFn = true;
            return vResFn;
        }
        public  bool LoadSAPAttr(long inEqpId)
        {
            bool resFn = false;
            //Configuration vConfig = vUtilFile.getConfig();
            //string vConnStr = vConfig.ConnectionStrings.ConnectionStrings["GIS_Connection"].ConnectionString.ToString();
            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb"); 



            vDbFile.ConnectToDatabase(3, vConnStr);
            if (vDbFile.Connected)
            {
                DataTable vDtTbl = vDbFile.getDtTblRecs(string.Format("Select * from [GISAdmin].[GISWSL].[WAT_SAPGIS] where Equipment = {0} and GISSTATE = '{1}'", inEqpId, "In Progress"));

                using (WCTools.BL.Forms.frmUpdSAPSel vfrmUpdSAPSel = new frmUpdSAPSel())
                {
                    vSelDataRow = vfrmUpdSAPSel.LoadUpdSAPSel(vDtTbl);  
                    if (!(vSelDataRow == null))
                    {
                        setGridVals();
                        hghlghtGrid();
                        resFn = true;
                    }
                }
                //vSelDataRow = vDtTbl.Rows[0];
            }
            return resFn;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtGrdLstAttr_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnUpdAttr_Click(object sender, EventArgs e)
        {
            updGridCells();
            btnUpdAttr.Enabled = false; 
        }
    }
}
