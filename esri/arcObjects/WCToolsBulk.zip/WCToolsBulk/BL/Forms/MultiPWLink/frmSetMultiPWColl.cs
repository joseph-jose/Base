﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCToolsBulk.BL.Forms.MultiPWLink
{
    public partial class frmSetMultiPWColl : Form
    {
        //used to stored which columns can be Copy/pasted
        const int __cOldCKColIdx = 1;
        const int __cNewCKColIdx = 3;
        //used to identify which column has been clicked for Copy/pasted
        int __cColIdx = -1;
        //used to force that users don't change the tab index
        int __CurrTbIdx = 0;

        //IFeatureCursor __FeatCrsr = null;
        ILayer __SelLyr = null;

        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }

        private string __LogSessId;
        public string __LogSessionId { set { __LogSessId = value; } }


        private WCToolsBulk.BL.Classes.cUtilFile __UtilFile;
        private WCToolsBulk.BL.Classes.cUtilGIS __GISUtil;
        private WCToolsBulk.BL.Classes.cDbSqlFile __DbFile;

        #region "CommonFunctions"
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            __UtilFile.logNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public void helpersActivate()
        {
            __GISUtil = new Classes.cUtilGIS();
            __GISUtil.vAppMap = __App;

            __UtilFile = new Classes.cUtilFile();
            __DbFile = new Classes.cDbSqlFile();
            logNtry("WCBulkTools", "SetMultiPWLinksCollect", "Start", __LogSessId, "TRC");
        }

        public void helpersDeActivate()
        {
            logNtry("WCBulkTools", "SetMultiPWLinksCollect", "End", __LogSessId, "TRC");
            __GISUtil.Dispose();
            __GISUtil = null;
            __UtilFile = null;

            __DbFile.Connected = false;
            __DbFile.Dispose();
            __DbFile = null;

            __App = null;
        }

        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

        //Do any validations on the form
        public bool validateOnLoad(out string fldPresent)
        {
            fldPresent = "";
            return true;
        }
        #endregion

        public frmSetMultiPWColl()
        {
            InitializeComponent();
        }

        ~frmSetMultiPWColl()
        {
            helpersDeActivate();
        }

        //disable tab page change
        private void tbPgSetMultiPWLnk_MouseDown(object sender, MouseEventArgs e)
        {
            //MEssagebox
            __CurrTbIdx = tbPgSetMultiPWLnk.SelectedIndex;
        }

        private void tbPgSetMultiPWLnk_MouseUp(object sender, MouseEventArgs e)
        {
            tbPgSetMultiPWLnk.SelectedIndex = __CurrTbIdx;
        }

        #region "Tab1CommonFunctions"
        private void loadMapLayers()
        {
            IEnumLayer vLyrsInToc = __GISUtil.getLyrsInTOC();
            try
            {
                ILayer vCurrLyr = null;

                vLyrsInToc.Reset();
                vCurrLyr = vLyrsInToc.Next();
                while (!(vCurrLyr == null))
                {
                    if (vCurrLyr is IFeatureLayer)
                    {
                        cmbLyrs.Items.Add(vCurrLyr.Name.ToString());
                    }
                    vCurrLyr = vLyrsInToc.Next();
                }
            }
            finally
            {
                Marshal.ReleaseComObject(vLyrsInToc);
            }
        }

        private string getClipboardText()
        {
            System.IO.Stream vClpStrm = null;
            System.Text.Encoding vEncder;
            System.IO.StreamReader vStrmReader = null;

            vClpStrm = (System.IO.Stream)Clipboard.GetDataObject().GetData(DataFormats.CommaSeparatedValue);

            vEncder = System.Text.Encoding.GetEncoding(1252);
            vStrmReader = new System.IO.StreamReader(vClpStrm, vEncder);

            return vStrmReader.ReadToEnd();
        }

        private bool doTab1Validations()
        {
            bool retRes = true;
            if (cmbLyrs.Text == "")
            {
                MessageBox.Show("Select a layer");
                cmbLyrs.Focus();
                retRes = false;
                return retRes;
            }
            if (dtGrdCompKeys.Rows.Count == 0)
            {
                MessageBox.Show("Compkeys to be replaced not specified");
                cmbLyrs.Focus();
                retRes = false;
                return retRes;
            }
            if (dtGrdCompKeys.RowCount > 5)
            {
                MessageBox.Show("Maximum of 5 rows can be used at a time");
                retRes = false;
                return retRes;
            }
            object vObjCellVal = null;
            string vStrVal = "";
            int vIntVal = 0;
            for (int vI = 0; vI < dtGrdCompKeys.RowCount ; vI++)
            {
                vStrVal = ""; vIntVal = 0;
                vObjCellVal = dtGrdCompKeys.Rows[vI].Cells[__cNewCKColIdx].Value;
                if (!(vObjCellVal == null ))
                    vStrVal = vObjCellVal.ToString();
                if (vStrVal == "")
                {
                    MessageBox.Show(string.Format("Compkey not specified at row {0}", vI+1));
                    retRes = false  ;
                    break;
                }
                if (!(int.TryParse(vStrVal, out vIntVal)))
                {
                    MessageBox.Show(string.Format("Compkey specified at row {0} must be an integer", vI+1));
                    retRes = false  ;
                    break;
                }
            }
            return retRes;
        }
        #endregion

        #region "Tab2CommonFunctions"
        private bool doTab2Validations()
        {
            bool retRes = true;
            object vObjCellVal = null;
            string vStrVal = "";
            string vDMSVal = "";

            string vDupCompKeys = "";
            string vDupDMSLnks = "";
            
            if (dtGrdVwItms.RowCount == 0)
            {
                MessageBox.Show("New Document# to be attached not entered");
                retRes = false;
                return retRes;
            }

            for (int vI = 0; vI < dtGrdCompKeys.RowCount; vI++)
            {
                //Finding if DMSKey already exists
                vStrVal = "";
                vDMSVal = "";
                vObjCellVal = dtGrdCompKeysTab2.Rows[vI].Cells[__cNewCKColIdx].Value;
                vStrVal = vObjCellVal.ToString();
                vObjCellVal = dtGrdCompKeysTab2.Rows[vI].Cells[__cNewCKColIdx + 1].Value;
                vDMSVal = vObjCellVal.ToString();
                if (!(vDMSVal == ""))
                {
                    MessageBox.Show(string.Format("DMSLink for compkey={0} already exists", vStrVal));
                    retRes = false;
                    break;
                }

                //Get duplicates
                //  oldCompKey
                vObjCellVal = dtGrdCompKeysTab2.Rows[vI].Cells[__cOldCKColIdx].Value;
                vStrVal = vObjCellVal.ToString();
                if (!(vStrVal == ""))
                {
                    if (!(vDupCompKeys=="")) 
                        vDupCompKeys = vDupCompKeys + ",";
                    vDupCompKeys = vDupCompKeys + vStrVal;
                }
                //  newCompKey
                vObjCellVal = dtGrdCompKeysTab2.Rows[vI].Cells[__cNewCKColIdx].Value;
                vStrVal = vObjCellVal.ToString();
                if (!(vStrVal == ""))
                {
                    if (!(vDupCompKeys == ""))
                        vDupCompKeys = vDupCompKeys + ",";
                    vDupCompKeys = vDupCompKeys + vStrVal;
                }

                //  DMSLink
                vObjCellVal = dtGrdCompKeysTab2.Rows[vI].Cells[__cOldCKColIdx + 1].Value;
                vDMSVal = vObjCellVal.ToString();
                
                if (!(vDMSVal == ""))
                {
                    if (!(vDupDMSLnks == ""))
                        vDupDMSLnks = vDupDMSLnks + ",";
                    vDupDMSLnks = vDupDMSLnks + vDMSVal;
                }
            }
            if (!(vDupCompKeys==""))
            {
                if (__UtilFile.DuplicateQuery(vDupCompKeys ))
                {
                    MessageBox.Show("Duplicate CompKeys exists"); 
                    retRes = false;
                }
            }
            if (!(vDupDMSLnks == ""))
            {
                if (__UtilFile.DuplicateQuery(vDupDMSLnks))
                {
                    MessageBox.Show("Duplicate DMS Links exists");
                    retRes = false;
                }
            }


            return retRes;
        }
        #endregion


        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string vClpStrs = "";
            string[] vClpStrLines = null;
            if (Clipboard.ContainsText(TextDataFormat.CommaSeparatedValue))
            {
                vClpStrs = getClipboardText();
                vClpStrs = vClpStrs.Replace("\0", "");

                string[] stringSeparator = { "\r\n" };
                vClpStrLines = vClpStrs.Split(stringSeparator, StringSplitOptions.None);

                dtGrdCompKeys.RowCount = vClpStrLines.Count() - 1;
                int i = 0;
                foreach (string vCurrStr in vClpStrLines)
                {
                    if (!(vCurrStr.Trim() == ""))
                    {
                        dtGrdCompKeys.Rows[i].Cells[__cColIdx].Value = vCurrStr;
                        i = i + 1;
                    }
                }
            }
            else
                MessageBox.Show("Clipboard data not in excel format");
        }

        private void frmSetMultiPWColl_Load(object sender, EventArgs e)
        {
            loadMapLayers();
        }

        private void dtGrdCompKeys_MouseClick(object sender, MouseEventArgs e)
        {


        }

        private void dtGrdCompKeys_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if ((e.Button == System.Windows.Forms.MouseButtons.Right))
            {
                if ((e.ColumnIndex == 1) || (e.ColumnIndex == 3))
                {
                    ctxMnuPaste.Show();
                    ctxMnuPaste.Top = this.Top + (sender as DataGridView).Top + e.Y;
                    ctxMnuPaste.Left = this.Left + (sender as DataGridView).Left + e.X;
                    __cColIdx = e.ColumnIndex;
                }
            }
        }

        #region "Tab1.NextButtonClick"
        //Copy grid values from Tab1 to Tab2
        private void copyGridVals()
        {
            dtGrdCompKeysTab2.Rows.Clear();
            dtGrdCompKeysTab2.RowCount = dtGrdCompKeys.RowCount;

            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges;

            for (int vCurrIdx = 0; vCurrIdx < WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges.Count; vCurrIdx++)
            {
                vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[vCurrIdx];
                dtGrdCompKeysTab2.Rows[vCurrIdx].Cells[0].Value = vAssetItemChanges.vLyrName;
                dtGrdCompKeysTab2.Rows[vCurrIdx].Cells[1].Value = vAssetItemChanges.vOCompKey;
                dtGrdCompKeysTab2.Rows[vCurrIdx].Cells[2].Value = vAssetItemChanges.vODMSLink;
                dtGrdCompKeysTab2.Rows[vCurrIdx].Cells[3].Value = vAssetItemChanges.vNCompKey;
                dtGrdCompKeysTab2.Rows[vCurrIdx].Cells[4].Value = vAssetItemChanges.vNDMSLink;
            }
        }
        //Check if features touch each other
        public bool chkIfFeatIntersect()
        {
            bool vBoolRes = true;
            string vStrVal = "";
            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges;

            for (int vCurrIdx = 0; vCurrIdx < WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges.Count; vCurrIdx++)
            {
                vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[vCurrIdx];
                if (!(vAssetItemChanges.vOCompKey.Trim() == ""))
                {
                    if (vAssetItemChanges.vOFeature == null)
                    {
                        MessageBox.Show(string.Format("Feature for compkey = {0} not found", vAssetItemChanges.vOCompKey));
                        vBoolRes = false;
                        break;
                    }
                }

                if (vAssetItemChanges.vNFeature  == null)
                {
                    MessageBox.Show (string.Format("Feature for compkey = {0} not found", vAssetItemChanges.vNCompKey  ));
                    vBoolRes = false ;
                    break;
                }
                if (!(vAssetItemChanges.vNFeature == null))
                {
                    if (!(vAssetItemChanges.vOFeature == null))
                    {
                        //20160404
                        //if (!(__GISUtil.CheckIfFeaturesTouchWTolerance(vAssetItemChanges.vOFeature, vAssetItemChanges.vNFeature, 20)))
                        //Kept around 6m
                        if (!(__GISUtil.CheckIfFeaturesTouchWTolerance(vAssetItemChanges.vOFeature, vAssetItemChanges.vNFeature, 10)))
                        //20160404
                        {
                            vStrVal = "Features are not near each other- CompKey= {0} & CompKey = {1}";
                            vStrVal = string.Format(vStrVal, vAssetItemChanges.vOCompKey, vAssetItemChanges.vNCompKey);
                            MessageBox.Show(vStrVal);
                            vBoolRes = false;
                            break;
                        }
                    }
                }
            }
            return vBoolRes;
        }

        //Populate DMS values into Grid
        private void findDMLinGrd(string inCompKey, string inDMSLink)
        {
            //MessageBox.Show(inCompKey + "," + inDMSLink);
            string vColVal = "";
            object vObjVal = null;

            for (int vCurrIdx = 0; vCurrIdx < dtGrdCompKeys.Rows.Count; vCurrIdx++)
            {
                vObjVal = dtGrdCompKeys.Rows[vCurrIdx].Cells[__cOldCKColIdx].Value;
                if (!(vObjVal == null))
                {
                    vColVal = vObjVal.ToString();
                    if (!(vColVal.Trim() == ""))
                    {
                        if (vColVal == inCompKey)
                        {
                            dtGrdCompKeys.Rows[vCurrIdx].Cells[__cOldCKColIdx + 1].Value = inDMSLink;
                            break;
                        }
                    }
                }
                vObjVal = dtGrdCompKeys.Rows[vCurrIdx].Cells[__cNewCKColIdx].Value;
                if (!(vObjVal == null))
                {
                    vColVal = vObjVal.ToString();
                    if (!(vColVal.Trim() == ""))
                    {
                        if (vColVal == inCompKey)
                        {
                            dtGrdCompKeys.Rows[vCurrIdx].Cells[__cNewCKColIdx + 1].Value = inDMSLink;
                            break;
                        }
                    }
                }
            }
        }

        //Populate DMS links into Datastructures & Grid
        private void popFeatAttrInStructures(IFeatureCursor inFeatCur)
        {
            IFeature vCurrFeat = null;
            int vFldIdx = -1;
            object vFldVal;
            string vCompKey = "";
            string vDMSLink = "";
            Classes.structAssetItemChanges vDtStructItemChanges = null;
            vCurrFeat = inFeatCur.NextFeature();

            while (!(vCurrFeat == null))
            {
                vFldIdx = __GISUtil.getFieldIdx(vCurrFeat, "COMPKEY");
                if (!(vFldIdx == -1))
                {
                    vFldVal = __GISUtil.getFieldValue(vCurrFeat, "COMPKEY");
                    if (!(vFldVal == null))
                    {
                        vCompKey = vFldVal.ToString();
                        vFldIdx = __GISUtil.getFieldIdx(vCurrFeat, "DMS_LINK");
                        if (!(vFldIdx == -1))
                        {
                            vFldVal = __GISUtil.getFieldValue(vCurrFeat, "DMS_LINK");
                            if (!(vFldVal == null))
                            {
                                vDMSLink = vFldVal.ToString();
                                //Populate into Grid
                                findDMLinGrd(vCompKey, vDMSLink);
                                //Populate into datastructure
                                vDtStructItemChanges = WCToolsBulk.BL.Classes.cLstStructures.findAssetItem(vCompKey);
                                if (vDtStructItemChanges.vOCompKey == vCompKey)
                                {
                                    vDtStructItemChanges.vODMSLink = vDMSLink;
                                    vDtStructItemChanges.vOFeature = vCurrFeat;
                                }
                                if (vDtStructItemChanges.vNCompKey == vCompKey)
                                {
                                    vDtStructItemChanges.vNDMSLink = vDMSLink;
                                    vDtStructItemChanges.vNFeature = vCurrFeat;
                                }
                            }
                        }
                    }
                }
                vCurrFeat = inFeatCur.NextFeature();
            }
        }

        //load all DMSLinks for CompKeys in Grid
        private void setAssetDetailsInGrd(ILayer inLayer, string inFltrCond)
        {
            IFeatureLayer vFeatLyr = null;
            vFeatLyr = (IFeatureLayer)inLayer;

            IFeatureCursor vFeatCrsr = null;
            try
            {
                vFeatCrsr = __GISUtil.getQryFltr(vFeatLyr, inFltrCond);
                if (!(vFeatCrsr == null))
                {
                    popFeatAttrInStructures(vFeatCrsr);
                }
            }
            finally
            {
                Marshal.ReleaseComObject(vFeatLyr);
            }
        }


        public string getCmmLmtdStr(string inOrgStr, string inAStr)
        {
            if (inOrgStr == "")
                return inAStr;
            else
                return inOrgStr + " , " + inAStr;
        }

        //get the list of CompKey to get DMSLinks from feature classes
        public string getAllCompKeys()
        {
            string vStrCKeys = "";

            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges;

            for (int vCurrIdx = 0; vCurrIdx < WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges.Count; vCurrIdx++)
            {
                vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[vCurrIdx];
                if (!(vAssetItemChanges.vOCompKey == "" || vAssetItemChanges.vOCompKey== null))
                    vStrCKeys = getCmmLmtdStr(vStrCKeys, vAssetItemChanges.vOCompKey);
                if (!(vAssetItemChanges.vNCompKey == "" || vAssetItemChanges.vNCompKey == null ))
                    vStrCKeys = getCmmLmtdStr(vStrCKeys, vAssetItemChanges.vNCompKey); 

            }
            return vStrCKeys;
        }

        //Populate the list structures
        public void popStructures()
        {
            string vColVal = "";
            object vObjVal = null;
            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges;

            WCToolsBulk.BL.Classes.cLstStructures.crtVariables();

            for (int vCurrIdx = 0; vCurrIdx < dtGrdCompKeys.Rows.Count; vCurrIdx++)
            {
                vAssetItemChanges = new WCToolsBulk.BL.Classes.structAssetItemChanges();

                vObjVal = dtGrdCompKeys.Rows[vCurrIdx].Cells[__cOldCKColIdx].Value;
                if (!(vObjVal == null))
                {
                    vColVal = vObjVal.ToString();
                    vAssetItemChanges.vOCompKey = vColVal;
                }
                else
                    vAssetItemChanges.vOCompKey = "";
                vObjVal = dtGrdCompKeys.Rows[vCurrIdx].Cells[__cNewCKColIdx].Value;
                if (!(vObjVal == null))
                {
                    vColVal = vObjVal.ToString();
                    vAssetItemChanges.vNCompKey = vColVal;
                }
                else
                    vAssetItemChanges.vNCompKey = "";
                vObjVal = dtGrdCompKeys.Rows[vCurrIdx].Cells[0].Value;
                if (!(vObjVal == null))
                {
                    vColVal = vObjVal.ToString();
                    vAssetItemChanges.vLyrName = vColVal;
                }
                WCToolsBulk.BL.Classes.cLstStructures.vLyrName = cmbLyrs.Text;
                WCToolsBulk.BL.Classes.cLstStructures.addStuctAssetLyrChanges(vAssetItemChanges);
            }
        }

        private void btnTbPg1Nxt_Click(object sender, EventArgs e)
        {
            if (!(doTab1Validations()))
            {
                return;
            }

            __SelLyr = __GISUtil.getLayerByName(cmbLyrs.Text);

            //validation
            IFeatureLayer vFeatLyr = __SelLyr as IFeatureLayer;
            IWorkspaceEdit vWrkSpcFeat = null;
            vWrkSpcFeat = __GISUtil.getWrkSpcFLayer(vFeatLyr);
            try
            {
                if (!(vWrkSpcFeat.IsBeingEdited()))
                {
                    MessageBox.Show("Layer not in edit mode");
                    return;
                }

                for (int vI = 0; vI < dtGrdCompKeys.Rows.Count; vI++)
                {
                    dtGrdCompKeys.Rows[vI].Cells[0].Value = cmbLyrs.Text.ToString();
                }

                popStructures();
                string vStrCKeys = "";
                vStrCKeys = getAllCompKeys();
                vStrCKeys = string.Format("CompKey in ({0})", vStrCKeys);

                if (!(__SelLyr == null))
                {
                    //vCurrLyr = __GISUtil.getLayerByIdx(vLyrIdx);
                    setAssetDetailsInGrd(__SelLyr, vStrCKeys);
                }
                if (!(chkIfFeatIntersect()))
                {
                    return;
                }
                copyGridVals();

                tbPgSetMultiPWLnk.SelectedIndex = tbPgSetMultiPWLnk.SelectedIndex + 1;

            }
            finally
            {
                Marshal.ReleaseComObject(vFeatLyr);
                Marshal.ReleaseComObject(vWrkSpcFeat); 
            }
        }
        #endregion


        private void btnTabPg1Edt_Click(object sender, EventArgs e)
        {
            using (frmSetMultiPWItemColl vFrmPWMultiPWItemColl = new frmSetMultiPWItemColl())
            {
                string vOldCKey = "", vNewCKey = "";
                if (!(dtGrdCompKeys.Rows[dtGrdCompKeys.SelectedRows[0].Index].Cells[1].Value == null))
                    vOldCKey = dtGrdCompKeys.Rows[dtGrdCompKeys.SelectedRows[0].Index].Cells[1].Value.ToString();
                if (!(dtGrdCompKeys.Rows[dtGrdCompKeys.SelectedRows[0].Index].Cells[3].Value == null))
                    vNewCKey = dtGrdCompKeys.Rows[dtGrdCompKeys.SelectedRows[0].Index].Cells[3].Value.ToString();

                if (vFrmPWMultiPWItemColl.setEdtMode(ref vOldCKey, ref vNewCKey) == DialogResult.OK)
                {
                    dtGrdCompKeys.Rows[dtGrdCompKeys.SelectedRows[0].Index].Cells[1].Value = vOldCKey;
                    dtGrdCompKeys.Rows[dtGrdCompKeys.SelectedRows[0].Index].Cells[3].Value = vNewCKey;
                }
            }
        }

        private void btnTabPg1Add_Click(object sender, EventArgs e)
        {
            using (frmSetMultiPWItemColl vFrmPWMultiPWItemColl = new frmSetMultiPWItemColl())
            {
                string vOldCKey = "", vNewCKey = "";
                if (vFrmPWMultiPWItemColl.setNewMode(ref vOldCKey, ref vNewCKey) == DialogResult.OK)
                {
                    dtGrdCompKeys.Rows.Add();
                    dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Cells[1].Value = vOldCKey;
                    dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Cells[3].Value = vNewCKey;
                    dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Selected = true;
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (frmPWDet vFrmPWDet = new frmPWDet())
            {
                string vPwType = "", vDocNo = "", vComm = "", vDocType = "";
                if (vFrmPWDet.setNewMode(ref vPwType, ref vDocNo, ref vDocType, ref vComm) == DialogResult.OK)
                {
                    dtGrdVwItms.Rows.Add();
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[2].Value = vPwType;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[3].Value = vDocNo;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[4].Value = vDocType;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[5].Value = vComm;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[6].Value = "N";
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Selected = true;
                }
            }
        }

        private void btnEdt_Click(object sender, EventArgs e)
        {
            string vPwType = "", vDocNo = "", vComm = "", vDocType = "";
            using (frmPWDet vFrmPWDet = new frmPWDet())
            {
                vPwType = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[2].Value.ToString();
                vDocNo = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[3].Value.ToString();
                vDocType = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[4].Value.ToString();
                vComm = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value.ToString();

                if (vFrmPWDet.setEdtMode(ref vPwType, ref vDocNo, ref vDocType, ref vComm) == DialogResult.OK)
                {
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[2].Value = vPwType;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[3].Value = vDocNo;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[4].Value = vDocType;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value = vComm;


                    if (!(dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[6].Value.ToString().Trim() == "A"))
                        dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[6].Value = "E";
                }
            }

        }

        private void btnTbPg2Nxt_Click(object sender, EventArgs e)
        {
            if (!(doTab2Validations()))
            {
                return ;
            }
            using (frmSetMultiPWLnks vFrmSetMultiPWLnks = new frmSetMultiPWLnks())
            {
                vFrmSetMultiPWLnks.copyGridValsToPostForm("GRIDTOP", dtGrdCompKeysTab2);
                vFrmSetMultiPWLnks.copyGridValsToPostForm("GRIDBOTTOM", dtGrdVwItms);

                vFrmSetMultiPWLnks.__AppMap = this.__App;
                vFrmSetMultiPWLnks.__LogSessionId = this.__LogSessId;

                vFrmSetMultiPWLnks.setLayerName(cmbLyrs.Text);
                vFrmSetMultiPWLnks.helpersActivate();
                if (vFrmSetMultiPWLnks.validateOnLoad())
                {
                    //if (vFrmSetMultiPWLnks.ShowDialog() == DialogResult.OK)
                    vFrmSetMultiPWLnks.ShowDialog();
                    this.Close();
                }
            }
        }

        private void btnTbPg2Prev_Click(object sender, EventArgs e)
        {
            tbPgSetMultiPWLnk.SelectedIndex = tbPgSetMultiPWLnk.SelectedIndex - 1;
        }

        private void btnTabPg1Clr_Click(object sender, EventArgs e)
        {
            dtGrdCompKeys.Rows.Clear();
            dtGrdCompKeys.RowCount = 0;
        }



    }
}
