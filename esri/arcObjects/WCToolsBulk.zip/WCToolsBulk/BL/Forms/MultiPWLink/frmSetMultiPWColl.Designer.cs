﻿namespace WCToolsBulk.BL.Forms.MultiPWLink
{
    partial class frmSetMultiPWColl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tbPgSetMultiPWLnk = new System.Windows.Forms.TabControl();
            this.tbPg1 = new System.Windows.Forms.TabPage();
            this.btnTabPg1Edt = new System.Windows.Forms.Button();
            this.btnTabPg1Add = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTbPg1Nxt = new System.Windows.Forms.Button();
            this.cmbLyrs = new System.Windows.Forms.ComboBox();
            this.dtGrdCompKeys = new System.Windows.Forms.DataGridView();
            this.colLayerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOCompKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colODMSLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNCompKey = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNDMSLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbPg2 = new System.Windows.Forms.TabPage();
            this.dtGrdCompKeysTab2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnTbPg2Nxt = new System.Windows.Forms.Button();
            this.btnTbPg2Prev = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dtGrdVwItms = new System.Windows.Forms.DataGridView();
            this.colPWId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPWRef = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPWType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDocType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colComm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chgBit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEdt = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.ctxMnuPaste = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnTabPg1Clr = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbPgSetMultiPWLnk.SuspendLayout();
            this.tbPg1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeys)).BeginInit();
            this.tbPg2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeysTab2)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdVwItms)).BeginInit();
            this.ctxMnuPaste.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(641, 66);
            this.panel1.TabIndex = 6;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 532);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(641, 22);
            this.statusStrip1.TabIndex = 30;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tbPgSetMultiPWLnk
            // 
            this.tbPgSetMultiPWLnk.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tbPgSetMultiPWLnk.Controls.Add(this.tbPg1);
            this.tbPgSetMultiPWLnk.Controls.Add(this.tbPg2);
            this.tbPgSetMultiPWLnk.Dock = System.Windows.Forms.DockStyle.Left;
            this.tbPgSetMultiPWLnk.Location = new System.Drawing.Point(0, 66);
            this.tbPgSetMultiPWLnk.Name = "tbPgSetMultiPWLnk";
            this.tbPgSetMultiPWLnk.SelectedIndex = 0;
            this.tbPgSetMultiPWLnk.Size = new System.Drawing.Size(643, 466);
            this.tbPgSetMultiPWLnk.TabIndex = 31;
            this.tbPgSetMultiPWLnk.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tbPgSetMultiPWLnk_MouseDown);
            this.tbPgSetMultiPWLnk.MouseUp += new System.Windows.Forms.MouseEventHandler(this.tbPgSetMultiPWLnk_MouseUp);
            // 
            // tbPg1
            // 
            this.tbPg1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPg1.Controls.Add(this.btnTabPg1Clr);
            this.tbPg1.Controls.Add(this.btnTabPg1Edt);
            this.tbPg1.Controls.Add(this.btnTabPg1Add);
            this.tbPg1.Controls.Add(this.label1);
            this.tbPg1.Controls.Add(this.btnTbPg1Nxt);
            this.tbPg1.Controls.Add(this.cmbLyrs);
            this.tbPg1.Controls.Add(this.dtGrdCompKeys);
            this.tbPg1.Controls.Add(this.panel2);
            this.tbPg1.Location = new System.Drawing.Point(4, 25);
            this.tbPg1.Name = "tbPg1";
            this.tbPg1.Padding = new System.Windows.Forms.Padding(3);
            this.tbPg1.Size = new System.Drawing.Size(635, 437);
            this.tbPg1.TabIndex = 0;
            this.tbPg1.Text = "Enter Info";
            this.tbPg1.UseVisualStyleBackColor = true;
            // 
            // btnTabPg1Edt
            // 
            this.btnTabPg1Edt.Location = new System.Drawing.Point(547, 295);
            this.btnTabPg1Edt.Name = "btnTabPg1Edt";
            this.btnTabPg1Edt.Size = new System.Drawing.Size(37, 22);
            this.btnTabPg1Edt.TabIndex = 29;
            this.btnTabPg1Edt.Text = "Edit";
            this.btnTabPg1Edt.UseVisualStyleBackColor = true;
            this.btnTabPg1Edt.Click += new System.EventHandler(this.btnTabPg1Edt_Click);
            // 
            // btnTabPg1Add
            // 
            this.btnTabPg1Add.Location = new System.Drawing.Point(507, 295);
            this.btnTabPg1Add.Name = "btnTabPg1Add";
            this.btnTabPg1Add.Size = new System.Drawing.Size(34, 22);
            this.btnTabPg1Add.TabIndex = 28;
            this.btnTabPg1Add.Text = "Add";
            this.btnTabPg1Add.UseVisualStyleBackColor = true;
            this.btnTabPg1Add.Click += new System.EventHandler(this.btnTabPg1Add_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "Layer";
            // 
            // btnTbPg1Nxt
            // 
            this.btnTbPg1Nxt.Location = new System.Drawing.Point(526, 347);
            this.btnTbPg1Nxt.Name = "btnTbPg1Nxt";
            this.btnTbPg1Nxt.Size = new System.Drawing.Size(75, 23);
            this.btnTbPg1Nxt.TabIndex = 0;
            this.btnTbPg1Nxt.Text = "Next";
            this.btnTbPg1Nxt.UseVisualStyleBackColor = true;
            this.btnTbPg1Nxt.Click += new System.EventHandler(this.btnTbPg1Nxt_Click);
            // 
            // cmbLyrs
            // 
            this.cmbLyrs.FormattingEnabled = true;
            this.cmbLyrs.Location = new System.Drawing.Point(75, 20);
            this.cmbLyrs.Name = "cmbLyrs";
            this.cmbLyrs.Size = new System.Drawing.Size(121, 21);
            this.cmbLyrs.TabIndex = 25;
            // 
            // dtGrdCompKeys
            // 
            this.dtGrdCompKeys.AllowUserToAddRows = false;
            this.dtGrdCompKeys.AllowUserToDeleteRows = false;
            this.dtGrdCompKeys.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdCompKeys.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colLayerName,
            this.colOCompKey,
            this.colODMSLink,
            this.colNCompKey,
            this.colNDMSLink});
            this.dtGrdCompKeys.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtGrdCompKeys.Location = new System.Drawing.Point(14, 57);
            this.dtGrdCompKeys.Name = "dtGrdCompKeys";
            this.dtGrdCompKeys.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGrdCompKeys.Size = new System.Drawing.Size(587, 232);
            this.dtGrdCompKeys.TabIndex = 24;
            this.dtGrdCompKeys.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtGrdCompKeys_ColumnHeaderMouseClick);
            this.dtGrdCompKeys.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dtGrdCompKeys_MouseClick);
            // 
            // colLayerName
            // 
            this.colLayerName.HeaderText = "LayerName";
            this.colLayerName.Name = "colLayerName";
            this.colLayerName.Visible = false;
            // 
            // colOCompKey
            // 
            this.colOCompKey.HeaderText = "Old CompKey";
            this.colOCompKey.Name = "colOCompKey";
            // 
            // colODMSLink
            // 
            this.colODMSLink.HeaderText = "Old DMSLink";
            this.colODMSLink.Name = "colODMSLink";
            // 
            // colNCompKey
            // 
            this.colNCompKey.HeaderText = "New CompKey";
            this.colNCompKey.Name = "colNCompKey";
            // 
            // colNDMSLink
            // 
            this.colNDMSLink.HeaderText = "New DMSLink";
            this.colNDMSLink.Name = "colNDMSLink";
            // 
            // tbPg2
            // 
            this.tbPg2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPg2.Controls.Add(this.dtGrdCompKeysTab2);
            this.tbPg2.Controls.Add(this.panel5);
            this.tbPg2.Controls.Add(this.panel4);
            this.tbPg2.Location = new System.Drawing.Point(4, 25);
            this.tbPg2.Name = "tbPg2";
            this.tbPg2.Padding = new System.Windows.Forms.Padding(3);
            this.tbPg2.Size = new System.Drawing.Size(635, 437);
            this.tbPg2.TabIndex = 1;
            this.tbPg2.Text = "Enter New DMS";
            this.tbPg2.UseVisualStyleBackColor = true;
            // 
            // dtGrdCompKeysTab2
            // 
            this.dtGrdCompKeysTab2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdCompKeysTab2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dtGrdCompKeysTab2.Location = new System.Drawing.Point(6, 6);
            this.dtGrdCompKeysTab2.Name = "dtGrdCompKeysTab2";
            this.dtGrdCompKeysTab2.Size = new System.Drawing.Size(587, 148);
            this.dtGrdCompKeysTab2.TabIndex = 25;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "LayerName";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Old CompKey";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Old DMSLink";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "New CompKey";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "New DMSLink";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnTbPg2Nxt);
            this.panel5.Controls.Add(this.btnTbPg2Prev);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(3, 375);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(627, 57);
            this.panel5.TabIndex = 6;
            // 
            // btnTbPg2Nxt
            // 
            this.btnTbPg2Nxt.Location = new System.Drawing.Point(527, 19);
            this.btnTbPg2Nxt.Name = "btnTbPg2Nxt";
            this.btnTbPg2Nxt.Size = new System.Drawing.Size(75, 23);
            this.btnTbPg2Nxt.TabIndex = 2;
            this.btnTbPg2Nxt.Text = "Next";
            this.btnTbPg2Nxt.UseVisualStyleBackColor = true;
            this.btnTbPg2Nxt.Click += new System.EventHandler(this.btnTbPg2Nxt_Click);
            // 
            // btnTbPg2Prev
            // 
            this.btnTbPg2Prev.Location = new System.Drawing.Point(431, 19);
            this.btnTbPg2Prev.Name = "btnTbPg2Prev";
            this.btnTbPg2Prev.Size = new System.Drawing.Size(75, 23);
            this.btnTbPg2Prev.TabIndex = 1;
            this.btnTbPg2Prev.Text = "Previous";
            this.btnTbPg2Prev.UseVisualStyleBackColor = true;
            this.btnTbPg2Prev.Click += new System.EventHandler(this.btnTbPg2Prev_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dtGrdVwItms);
            this.panel4.Controls.Add(this.btnEdt);
            this.panel4.Controls.Add(this.btnAdd);
            this.panel4.Location = new System.Drawing.Point(6, 160);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(587, 159);
            this.panel4.TabIndex = 20;
            // 
            // dtGrdVwItms
            // 
            this.dtGrdVwItms.AllowUserToAddRows = false;
            this.dtGrdVwItms.AllowUserToDeleteRows = false;
            this.dtGrdVwItms.AllowUserToResizeRows = false;
            this.dtGrdVwItms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdVwItms.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPWId,
            this.colPWRef,
            this.colPWType,
            this.colDocNo,
            this.colDocType,
            this.colComm,
            this.chgBit});
            this.dtGrdVwItms.Location = new System.Drawing.Point(3, 7);
            this.dtGrdVwItms.MultiSelect = false;
            this.dtGrdVwItms.Name = "dtGrdVwItms";
            this.dtGrdVwItms.ReadOnly = true;
            this.dtGrdVwItms.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGrdVwItms.ShowEditingIcon = false;
            this.dtGrdVwItms.ShowRowErrors = false;
            this.dtGrdVwItms.Size = new System.Drawing.Size(581, 108);
            this.dtGrdVwItms.TabIndex = 4;
            this.dtGrdVwItms.TabStop = false;
            // 
            // colPWId
            // 
            this.colPWId.Frozen = true;
            this.colPWId.HeaderText = "PW Id";
            this.colPWId.Name = "colPWId";
            this.colPWId.ReadOnly = true;
            this.colPWId.Width = 75;
            // 
            // colPWRef
            // 
            this.colPWRef.HeaderText = "PW Ref";
            this.colPWRef.Name = "colPWRef";
            this.colPWRef.ReadOnly = true;
            this.colPWRef.Visible = false;
            // 
            // colPWType
            // 
            this.colPWType.HeaderText = "PW Type";
            this.colPWType.Name = "colPWType";
            this.colPWType.ReadOnly = true;
            // 
            // colDocNo
            // 
            this.colDocNo.HeaderText = "Doc No";
            this.colDocNo.Name = "colDocNo";
            this.colDocNo.ReadOnly = true;
            // 
            // colDocType
            // 
            this.colDocType.HeaderText = "Doc Type";
            this.colDocType.Name = "colDocType";
            this.colDocType.ReadOnly = true;
            this.colDocType.Width = 150;
            // 
            // colComm
            // 
            this.colComm.HeaderText = "Comments";
            this.colComm.Name = "colComm";
            this.colComm.ReadOnly = true;
            this.colComm.Width = 200;
            // 
            // chgBit
            // 
            this.chgBit.HeaderText = "chgBit";
            this.chgBit.Name = "chgBit";
            this.chgBit.ReadOnly = true;
            this.chgBit.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.chgBit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.chgBit.Visible = false;
            // 
            // btnEdt
            // 
            this.btnEdt.Location = new System.Drawing.Point(536, 121);
            this.btnEdt.Name = "btnEdt";
            this.btnEdt.Size = new System.Drawing.Size(37, 22);
            this.btnEdt.TabIndex = 22;
            this.btnEdt.Text = "Edit";
            this.btnEdt.UseVisualStyleBackColor = true;
            this.btnEdt.Click += new System.EventHandler(this.btnEdt_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(496, 121);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(34, 22);
            this.btnAdd.TabIndex = 21;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // ctxMnuPaste
            // 
            this.ctxMnuPaste.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.ctxMnuPaste.Name = "ctxMnuPaste";
            this.ctxMnuPaste.Size = new System.Drawing.Size(103, 26);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(102, 22);
            this.toolStripMenuItem1.Text = "Paste";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // btnTabPg1Clr
            // 
            this.btnTabPg1Clr.Location = new System.Drawing.Point(14, 295);
            this.btnTabPg1Clr.Name = "btnTabPg1Clr";
            this.btnTabPg1Clr.Size = new System.Drawing.Size(44, 22);
            this.btnTabPg1Clr.TabIndex = 30;
            this.btnTabPg1Clr.Text = "Clear";
            this.btnTabPg1Clr.UseVisualStyleBackColor = true;
            this.btnTabPg1Clr.Click += new System.EventHandler(this.btnTabPg1Clr_Click);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(7, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(603, 335);
            this.panel2.TabIndex = 31;
            // 
            // frmSetMultiPWColl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 554);
            this.Controls.Add(this.tbPgSetMultiPWLnk);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmSetMultiPWColl";
            this.Text = "Collect PW Link";
            this.Load += new System.EventHandler(this.frmSetMultiPWColl_Load);
            this.tbPgSetMultiPWLnk.ResumeLayout(false);
            this.tbPg1.ResumeLayout(false);
            this.tbPg1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeys)).EndInit();
            this.tbPg2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeysTab2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdVwItms)).EndInit();
            this.ctxMnuPaste.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabControl tbPgSetMultiPWLnk;
        private System.Windows.Forms.TabPage tbPg1;
        private System.Windows.Forms.Button btnTabPg1Edt;
        private System.Windows.Forms.Button btnTabPg1Add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTbPg1Nxt;
        private System.Windows.Forms.ComboBox cmbLyrs;
        private System.Windows.Forms.DataGridView dtGrdCompKeys;
        private System.Windows.Forms.TabPage tbPg2;
        private System.Windows.Forms.DataGridView dtGrdCompKeysTab2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnTbPg2Nxt;
        private System.Windows.Forms.Button btnTbPg2Prev;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dtGrdVwItms;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPWId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPWRef;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPWType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDocType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComm;
        private System.Windows.Forms.DataGridViewTextBoxColumn chgBit;
        private System.Windows.Forms.Button btnEdt;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ContextMenuStrip ctxMnuPaste;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLayerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOCompKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn colODMSLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNCompKey;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNDMSLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Button btnTabPg1Clr;
        private System.Windows.Forms.Panel panel2;
    }
}