﻿define(
   ({
    enableUndoRedo: "Permitir Undo/Redo",
    toolbarVisible: "Barra de Ferramentas Visível",
    toolbarOptions: "Opções da Barra de Ferramentas",
    mergeVisible: "Juntar",
    cutVisible: "Cortar",
    reshapeVisible: "Redefinir",
    back: "Regressar",
    label: "Camada",
    edit: "Editável",
    update: "Desativar Atualizar Geometria",
    fields: "Campos",
    actions: "Ações",
    editpageName: "Nome",
    editpageAlias: "Nome Alternativo",
    editpageVisible: "Visível",
    editpageEditable: "Editável",
    noLayers: "Não há camadas de elementos editáveis",
    configureFields: "Configurar Campos de Camadas"
  })
);