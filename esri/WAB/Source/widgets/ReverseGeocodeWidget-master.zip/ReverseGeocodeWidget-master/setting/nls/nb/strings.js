﻿define({
    unit: "å_Unit_ø",
    style: "å_Style_ø"
});