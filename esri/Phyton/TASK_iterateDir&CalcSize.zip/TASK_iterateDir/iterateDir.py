import os
import arcpy

top_folder = r"path\to\top\folder"

for path, dirs, files in os.walk(top_folder):
    for d in dirs:
        if not d.endswith(".gdb"):
            continue
        gdb_path = os.path.join(path, d)
        print gdb_path

        arcpy.env.workspace = gdb_path
        all_fcs = arcpy.ListFeatureClasses()
        for fds in arcpy.ListDatasets('','feature'):
            for fc in arcpy.ListFeatureClasses('','',fds):
                all_fcs.append(fc)

        for fc in all_fcs:
            fieldnames = [f.name.lower() for f in arcpy.ListFields(fc)]
            if myField.lower() in fieldnames:
                print fc