﻿define(
   ({
    _widgetLabel: "Chỉnh sửa",
    title: "Chọn một mẫu để tạo các đối tượng",
    pressStr: "Nhấn ",
    ctrlStr: " CTRL ",
    snapStr: " để bật tính năng chụp ảnh nhanh"
  })
);