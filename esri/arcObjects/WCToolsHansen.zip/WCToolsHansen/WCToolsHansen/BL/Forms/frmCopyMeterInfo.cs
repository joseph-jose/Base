﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;

namespace WCToolsHansen.BL.Forms
{
    public partial class frmCopyMeterInfo : Form
    {
        private IApplication vApp;
        public IApplication vAppMap { set { vApp = value; } }
        private Process vPWProc ;

        const int cDelayTime = 3000;

        [DllImport("user32.dll")]
        static extern int SetForegroundWindow(IntPtr point);

        private string vLogSessId = "";
        public string vLogSessionId { set { vLogSessId = value; } }
        private IFeature vSelFeat;


        private WCToolsHansen.BL.Classes.cUtilFile vUtilFile;
        private WCToolsHansen.BL.Classes.cUtilGIS vGISUtil;

        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            vUtilFile.logNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public void helpersActivate()
        {
            vGISUtil = new Classes.cUtilGIS();
            vGISUtil.vAppMap = vApp;

            vUtilFile = new Classes.cUtilFile();
            logNtry("WCTools", "Hansen-copyMeterInfo", "Start", vLogSessId, "TRC");
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "Hansen-copyMeterInfo", "End", vLogSessId, "TRC");
            vGISUtil.Dispose();
            vGISUtil = null;
            vUtilFile = null;
        }

        public frmCopyMeterInfo()
        {
            InitializeComponent();
        }

        ~frmCopyMeterInfo()
        {
            helpersDeActivate();
        }

        public bool validateOnLoad()
        {
            bool vResFn = false;
            if (!(vGISUtil.getFeatureSelectCount() == 1))
            {
                MessageBox.Show("Select single feature");
                return vResFn;
            }
            IFeature vFeat;
            IEnumFeature vEnmFeat = vGISUtil.getSelectedFeatures();
            vEnmFeat.Reset();
            vFeat = vEnmFeat.Next();
            IWorkspaceEdit vWrkSpcEdit = vGISUtil.getWrkSpcFFeature(vFeat);
            if (!(vWrkSpcEdit.IsBeingEdited()))
            {
                MessageBox.Show("Feature not in edit mode");
                return vResFn;
            }

            IDataset vDtSet = null;
            vDtSet = vFeat.Table as IDataset;
            if (vDtSet.Category.ToString().IndexOf("SDE") == -1)
            {
                MessageBox.Show("Layer selected should belong to a geodatabase");
                return vResFn;
            }

            object vObjVal;
            int vFldIdx;
            string vFldVal;

            vFldIdx = vGISUtil.getFieldIdx(vFeat, "COMPKEY");
            if (!(vFldIdx == -1))
            {
                vObjVal = vGISUtil.getFieldValue(vFeat, "COMPKEY");
            }
            else
            {
                MessageBox.Show("Attribute COMPKEY missing for feature");
                return vResFn;
            }
            if (!(vObjVal is System.DBNull))
            {
                vFldVal = vObjVal.ToString();
                txtCompKey.Text = vFldVal;
            }
            else
            {
                MessageBox.Show("Attribute COMPKEY is empty for feature");
                return vResFn;
            }

            vFldIdx = vGISUtil.getFieldIdx(vFeat, "UNITID");
            if (!(vFldIdx == -1))
            {
                vObjVal = vGISUtil.getFieldValue(vFeat, "UNITID");
            }
            else
            {
                MessageBox.Show("Attribute UNITID missing for feature");
                return vResFn;
            }
            if (!(vObjVal is System.DBNull))
            {
                vFldVal = vObjVal.ToString();
                txtUnitIdX.Text = vFldVal;
            }
            else
            {
                MessageBox.Show("Attribute UNITId is empty for feature");
                return vResFn;
            }


            vFldIdx = vGISUtil.getFieldIdx(vFeat, "UNITTYPE");
            if (!(vFldIdx == -1))
            {
                vObjVal = vGISUtil.getFieldValue(vFeat, "UNITTYPE");
            }
            else
            {
                MessageBox.Show("Attribute UNITTYPE missing for feature");
                return vResFn;
            }
            if (!(vObjVal is System.DBNull))
            {
                vFldVal = vObjVal.ToString();
                txtUnitTypeX.Text = vFldVal;
            }
            else
            {
                MessageBox.Show("Attribute UNITTYPE is empty for feature");
                return vResFn;
            }

            vSelFeat = vFeat;

            setDisableMode();

            vResFn = true;
            return vResFn;
        }

        private void setEnableMode()
        {
            if (!(txtUnitIdX.Text.ToString().ToUpper() == txtUnitId.Text.ToString().ToUpper()))
            {
                chkUnitId.Enabled = true;
            }
            if (!(txtUnitTypeX.Text.ToString().ToUpper() == txtUnitType.Text.ToString().ToUpper()))
            {
                chkUnitType.Enabled = true;
            }
            if ((chkUnitId.Enabled) || (chkUnitType.Enabled))
            {
                btnConfrm.Enabled = true;  
            }
        }

        private void setDisableMode()
        {
            chkUnitId.Enabled = false;
            chkUnitType.Enabled = false;
            btnConfrm.Enabled = false; 
        }

        private void validateDiff()
        {
            //if (txtUnitId.Text.ToString().ToUpper() == txtUnitIdX.ToString().ToUpper())
            //    grpBxUnitId.BackColor = System.Drawing.SystemColors.ActiveCaption;
            //else
            //    grpBxUnitId.BackColor = Color.Red;

            //if (txtUnitType.Text.ToString().ToUpper() == txtUnitTypeX.ToString().ToUpper())
            //    grpBxUnitType.BackColor = System.Drawing.SystemColors.ActiveCaption;
            //else
            //    grpBxUnitType.BackColor = Color.Red;


            if (!(txtUnitIdX.Text.ToString().ToUpper() == txtUnitId.Text.ToString().ToUpper()))
                grpBxUnitId.BackColor = Color.Red;
            else
                grpBxUnitId.BackColor = System.Drawing.SystemColors.ActiveCaption;

            if (!(txtUnitTypeX.Text.ToString().ToUpper() == txtUnitType.Text.ToString().ToUpper()))
                grpBxUnitType.BackColor = Color.Red;
            else
                grpBxUnitType.BackColor = System.Drawing.SystemColors.ActiveCaption;

        }

        //Gets the Hansen window
        private void getHansenHandle()
        {
            Process[] vProcesses = Process.GetProcessesByName("IMSV732");
            vPWProc = vProcesses[0];
        }
        
        private void closeWindowHandle()
        {
            vPWProc = null;
        }
        //Set the foreground
        private void sendMsg(Process inProc)
        {
            IntPtr vPointer = inProc.MainWindowHandle;
            SetForegroundWindow(vPointer);
        }

        private void openLoadForm()
        {
            if (!(vPWProc == null))
            {
                sendMsg(vPWProc);
                SendKeys.SendWait("{TAB 1}");
                SendKeys.SendWait("^{l}");
                System.Threading.Thread.Sleep(cDelayTime);
                SendKeys.SendWait("^{s}");

            }
        }
        private void copyContends()
        {
            if (!(vPWProc == null))
            {
                sendMsg(vPWProc);
                //Key press Home + Shift + End + Copy   (Select All-copy)
                SendKeys.SendWait("{HOME}");
                SendKeys.SendWait("+{END}");
                SendKeys.SendWait("^{INS}");

                System.Threading.Thread.Sleep(cDelayTime);

                txtUnitId.Text = Clipboard.GetText();

                System.Threading.Thread.Sleep(cDelayTime);
                //Key press &T
                SendKeys.SendWait("%(T)");
                //Key press TAB
                SendKeys.SendWait("{TAB 1}");
                //Key press Home + Shift + End + Copy   (Select All-copy)
                SendKeys.SendWait("{HOME}");
                SendKeys.SendWait("+{END}");
                SendKeys.SendWait("^{INS}");
                txtUnitType.Text = Clipboard.GetText();
                System.Threading.Thread.Sleep(cDelayTime);
                SendKeys.SendWait("^{F4}");
            }
        }

        private void openAssetWindow(string inCompKey)
        {
            if (!(vPWProc == null))
            {
                sendMsg(vPWProc);
                //SendKeys.SendWait("{TAB 1}");
                //Click the menu of hansen form
                //Key press &T
                SendKeys.SendWait("%{A}");
                //Godown 3 menus
                SendKeys.SendWait("{DOWN 3}");
                //Go right 1 menus
                SendKeys.SendWait("{RIGHT 1}");
                Application.DoEvents();
                //Go down 3 menus
                SendKeys.SendWait("{DOWN 3}");
                //Activates the menu
                SendKeys.SendWait("{ENTER 1}");
                Application.DoEvents();
                //Key press &O
                SendKeys.SendWait("^{O}");
                //Key press &G
                SendKeys.SendWait("%{G}");
                Application.DoEvents();
                System.Threading.Thread.Sleep(cDelayTime);
                SendKeys.SendWait(inCompKey);
                Application.DoEvents();
                System.Threading.Thread.Sleep(cDelayTime);
                //Key press TAB1
                SendKeys.SendWait("{TAB 1}");
            }
        }

        private void frmCopyMeterInfo_Load(object sender, EventArgs e)
        {

        }

        private void btnGetDet_Click(object sender, EventArgs e)
        {
            pnlMsg.Visible = true;
            lblMsg.ForeColor = Color.Red;
            lblMsg.Text = "Extracting from Hansen-Getting handler....";
            getHansenHandle();
            lblMsg.Text = "Extracting from Hansen-Opening hansen window....";
            openAssetWindow(txtCompKey.Text );
            lblMsg.Text = "Extracting from Hansen-Finding and loading asset....";
            openLoadForm();
            lblMsg.Text = "Extracting from Hansen-Copying attributes....";
            copyContends();
            lblMsg.Text = "Extracting from Hansen-Closing window....";
            closeWindowHandle();
            lblMsg.Text = "Extracting from Hansen-Completed";
            lblMsg.ForeColor = Color.Green;
            validateDiff();
            setEnableMode();

        }

        private void btnConfrm_Click(object sender, EventArgs e)
        {
            IWorkspaceEdit vWrkSpcEdt = vGISUtil.getWrkSpcFFeature(vSelFeat);
            try
            {
                vWrkSpcEdt.StartEditOperation(); 

                if (chkUnitId.Checked)
                {
                    if (!(txtUnitIdX.Text.ToString().ToUpper() == txtUnitId.Text.ToString().ToUpper()))
                    {
                    txtUnitIdX.Text = txtUnitId.Text;
                    vGISUtil.setFieldValue(vSelFeat, "UNITID", txtUnitId.Text); 
                    }
                }
                if (chkUnitType.Checked)
                {
                    if (!(txtUnitTypeX.Text.ToString().ToUpper() == txtUnitType.Text.ToString().ToUpper()))
                    {
                    txtUnitTypeX.Text = txtUnitType.Text;
                    vGISUtil.setFieldValue(vSelFeat, "UNITTYPE", txtUnitType.Text);
                    }
                }
                validateDiff();
                setDisableMode();

                vWrkSpcEdt.StopEditOperation();
                logNtry("WCTools", "Hansen-copyMeterInfo", txtCompKey.Text, vLogSessId, "TRC");

            }
            finally
            {
                vWrkSpcEdt = null;
            }


        }
    }
}
