# ---------------------------------------------------------------------------
# Add_Mosaic_Dataset_Indexes.py
# Created on: 2015-06-19
# Modified on: 2016-08-29
# Steven Lambert, Esri, Inc.
# Usage: Add_Mosaic_Dataset_Indexes(MDS, Att_List)
#
# The Add Mosaic Dataset Indexes script tool adds attribute indexes
# to an existing feature class or overwrites existing indexes. The indexes 
# will be single column/field indexes, with default the characteristics of UNIQUE
# and ASCENDING.
#
# The Field List is extracted from the mosaic dataset.
#
# Index naming will follow the recommended naming convention for attribute
# indexes, that is, FieldName_IDX.
#
# The field name in the index will be truncated since the length of an index name
# is limited to 10 characters, including the _IDX suffix. Vowels will be removed
# and names will be reduced to 6 characters, plus _IDX. For example, the index
# name for a field named Spacing will be SPCING_IDX.
# 
# Duplicate index names may result because of this truncation. If this happens, 
# the index will only be created for the last field with a duplicate name. For 
# example, two fields named Control and Central will both be truncated to 
# CNTRL_, resulting in duplicate index names of CNTRL_IDX. If the first field in 
# the attribute table is Control and the second is Central, an index will be added 
# for the Control field, then it will be deleted when the index is added for the
# Central field. 
#
# You can add additional indexes for any fields for which indexes were not created
# using this tool. To learn more about adding attribute indexes, see:
# http://desktop.arcgis.com/en/arcmap/latest/manage-data/tables/creating-attribute-indexes.htm
#
# 
# ---------------------------------------------------------------------------
#
def AddMsgAndPrint(msg):
# Adds a Message (in case this is run as a tool)
# and also prints the message to the screen (standard output)
# 
    arcpy.AddMessage(msg)
    print msg

    return

try:
    import os
    import sys
    import traceback
    import arcpy

    vowels = ['a', 'e', 'i', 'o' ,'u', 'y', 'A', 'E', 'I', 'O', 'U', 'Y']
    
# Extract input parameters

    in_mds = arcpy.GetParameterAsText(0)
    if not in_mds:
        AddMsgAndPrint("Error: Input mosaic dataset required")
        sys.exit(1)
        if not os.path.exists(in_mds):
            AddMsgAndPrint("Error: Input mosaic dataset not found.")
            sys.exit(1)

# Extract the list of fields in the mosaic dataset attribute table

    mds_fields = arcpy.GetParameterAsText(1)

# Extract list of existing indexes

    idx_list = arcpy.ListIndexes(in_mds)
    idx_names = []
    for idx in idx_list:
        idx_names.append(idx.name.upper())
    
# Begin working way through table

    for field in mds_fields.split(';'):
        try:
            out_idx = ''.join([l for l in field if l not in vowels])[:6]
            out_idx = (out_idx + '_IDX').upper()
            out_idx = arcpy.ValidateFieldName(out_idx, in_mds)
            if out_idx in idx_names:
                AddMsgAndPrint('Warning: Dropping previous index file -> ' + out_idx)
                arcpy.RemoveIndex_management (in_mds, out_idx)
            arcpy.AddIndex_management (in_mds, field, out_idx, "UNIQUE", "ASCENDING")
            AddMsgAndPrint('Success: Created index file -> ' + out_idx)
        except:
            AddMsgAndPrint('Error: Unable to process index creation for field: ' + field + ' in mosaic dataset -> ' + in_mds)

# Write final status message

    AddMsgAndPrint('Index creation completed.')
                
except:

# Get the traceback object

    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]

# Concatenate information together concerning the error into a
# message string

    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + \
            "\nError Info:\n" + str(sys.exc_info()[1])

# Print Python error messages for use in Python / Python Window

    print pymsg + "\n"
