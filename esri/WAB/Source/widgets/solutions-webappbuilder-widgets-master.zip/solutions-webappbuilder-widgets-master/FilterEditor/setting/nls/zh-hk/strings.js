﻿define(
   ({
    enableUndoRedo: "啟用復原/重做",
    toolbarVisible: "工具列可見",
    toolbarOptions: "工具列選項",
    mergeVisible: "合併",
    cutVisible: "剪下",
    reshapeVisible: "重塑",
    back: "上一步",
    label: "圖層",
    edit: "可編輯",
    update: "停用更新幾何",
    fields: "欄位",
    actions: "操作",
    editpageName: "名稱",
    editpageAlias: "別名",
    editpageVisible: "可見",
    editpageEditable: "可編輯",
    noLayers: "沒有可編輯圖徵圖層",
    configureFields: "配置圖層欄位"
  })
);