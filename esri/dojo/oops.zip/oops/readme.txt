https://dojotoolkit.org/documentation/tutorials/1.10/deferreds/
https://dojotoolkit.org/documentation/tutorials/1.10/ajax/
https://dojotoolkit.org/documentation/tutorials/1.10/promises/
https://dojotoolkit.org/reference-guide/1.6/dojo/declare.html
