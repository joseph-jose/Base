https://blogs.esri.com/esri/arcgis/2011/06/06/modelbuilderifthenelse1/
