﻿define({
    left: "VÄNSTER",
    right: "HÖGER",
    arrangement: "Placering",
    autoUpdate: "Uppdatera automatiskt",
    respectCurrentMapScale: "Respektera aktuell kartskala"
});