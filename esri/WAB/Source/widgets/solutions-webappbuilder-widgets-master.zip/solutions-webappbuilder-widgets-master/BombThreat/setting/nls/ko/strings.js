﻿define({
    left: "왼쪽",
    right: "오른쪽",
    arrangement: "정렬",
    autoUpdate: "자동 업데이트",
    respectCurrentMapScale: "현재 맵 축척 관련"
});