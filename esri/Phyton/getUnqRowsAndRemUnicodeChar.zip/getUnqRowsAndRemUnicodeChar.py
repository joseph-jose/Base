import arcpy
import arcpy.da
import re

def valRegXpForCommonStrings(inString):
    #regXp = re.compile(r"[a-zA-Z0-9\s-]")
    #refer codetable.net
    #For char code 168 to 254
    #regXp = re.compile(r"[^\xA8-\xFE]")
    #For char code 127 to 255
    regXp = re.compile(r"[^\xAF-\xFF]")
    #regXp = re.compile(r"\W")
    if regXp.search(inString):
        return 1
    else:
        return 0

def unique_values(table, field):
    with arcpy.da.SearchCursor(table, [field]) as cursor:
        return sorted({row[0] for row in cursor})

vUnqValues = unique_values(r"c:\Joseph\Task\TASK_IPV_SymProblem\Project.gdb\UniqueActivityTypeDesc", r"activity_type_desc")
for item in vUnqValues:
#    print item
    vResFn = valRegXpForCommonStrings(item)
    if vResFn == "0":
        print "Faulty" + item
    else:
        print item
#word = r"Renewal - PT"
#vResFn = valRegXpForCommonStrings(word)
#print vResFn
