﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;
using System.Globalization;
using System.IO;
using WCTools.BL.Classes;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System.Runtime.InteropServices;
using System.Diagnostics;  

namespace WCTools.BL.Forms
{
    public partial class frmPHLst : Form
    {
        string __VFrmMode="";
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }
        //private IFeature __SelFeat;

        private string __LogSessId = "";
        public string __LogSessionId { set { __LogSessId = value; } }

        WCTools.BL.Classes.cDbSqlFile __DbFile;
        WCTools.BL.Classes.cUtilFile __UtilFile;
        WCTools.BL.Classes.cUtilGIS __GISUtil;

        //private IFeature __SelFeature;

        public frmPHLst()
        {
            InitializeComponent();
        }

        ~frmPHLst()
        {
            helpersDeActivate();
        }


        public bool helpersActivate()
        {
            bool vBRes = true;
            __DbFile = new cDbSqlFile();
            __UtilFile = new cUtilFile();
            __GISUtil = new cUtilGIS();
            __GISUtil.vAppMap = __App;

            //20170510 Non GISEditor intimation
            //connDB();
            try
            {
                connDB();
            }
            catch (Exception e)
            {
                MessageBox.Show("Access to database couldn't be obtained");
                vBRes = false;
                return vBRes;
            }
            //20170510 Non GISEditor intimation
            logNtry("WCTools", "PHLink", "Start", __LogSessId, "TRC");
            return vBRes;
        }

        public void helpersDeActivate()
        {
            logNtry("WCTools", "PHLink", "End", __LogSessId, "TRC");
            //if (!(__SelFeature == null))
            //{
            //    Marshal.ReleaseComObject(__SelFeature);
            //}
            __DbFile.CleanUpDBConnection();
            __DbFile.Dispose();
            __DbFile = null;
            __GISUtil.Dispose();
            __GISUtil = null;
        }

        public bool validateOnLoad(out string outLnkId)
        {
            bool vResFn = false;
            outLnkId = "";
            //if (!(__GISUtil.getFeatureSelectCount() == 1))
            //{
            //    MessageBox.Show("Select single feature");
            //    return vResFn;
            //}
            //IFeature vFeat;
            //IEnumFeature vEnmFeat = __GISUtil.getSelectedFeatures();
            //vEnmFeat.Reset();
            //vFeat = vEnmFeat.Next();
            //IWorkspaceEdit vWrkSpcEdit = __GISUtil.getWrkSpcFFeature(vFeat);
            //if (!(vWrkSpcEdit.IsBeingEdited()))
            //{
            //    MessageBox.Show("Feature not in edit mode");
            //    return vResFn;
            //}

            //object vObjVal;
            //int vFldIdx;
            //vFldIdx = __GISUtil.getFieldIdx(vFeat, "PHOTO_LINK");
            //if (!(vFldIdx == -1))
            //{
            //    vObjVal = __GISUtil.getFieldValue(vFeat, "PHOTO_LINK");
            //    if (vObjVal is System.DBNull)
            //        outLnkId = "";
            //    else
            //        outLnkId = vObjVal.ToString();
            //}
            //else
            //{
            //    MessageBox.Show("Attribute PHOTO_LINK missing for feature");
            //    return vResFn;
            //}

            //__SelFeat = vFeat;

            vResFn = true;
            return vResFn;
        }


        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            if (!(__UtilFile.logNtry(__DbFile, inCmdType, inMsg, inFld1, inSessId, inLogType)))
            {
                MessageBox.Show("GPF-> Logging failed"); 
            }
        }

        private void BtnCls_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void refGrd(DataTable vDtTbl)
        {
            string vFldVal = "", vPhLnk = "", vFlType = "";
            DateTime vDtTm;
            foreach (DataRow dr in vDtTbl.Rows)
            {
                dtGrdVwItms.Rows.Add();
                vFldVal = dr["PH_ID"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[0].Value = vFldVal;
                vFldVal = dr["PH_LINK"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[1].Value = vFldVal;
                vPhLnk = vFldVal;
                vFldVal = dr["PH_TYPE"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[2].Value = vFldVal;
                vFlType = vFldVal;
                vFldVal = dr["FILE_NAME"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[3].Value = vFldVal;
                vFldVal = dr["FOLDER"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[4].Value = vFldVal;
                if (!(dr["DATE_TAKEN"] is DBNull))
                {
                    vFldVal = dr["DATE_TAKEN"].ToString();
                    vDtTm = Convert.ToDateTime(vFldVal);
                    //vFldVal = vDtTm.ToString("d", DateTimeFormatInfo.InvariantInfo);
                    vFldVal = vDtTm.ToString("dd/MM/yyy");
                }
                else
                    vFldVal = "";
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[5].Value = vFldVal;
                //vFldVal = dr["STATUS"].ToString();
                //dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[6].Value = vFldVal;
                vFldVal = dr["MODIFYBY"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[6].Value = vFldVal;
                vFldVal = dr["MODIFYDATE"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[7].Value = vFldVal;
                //vFldVal = dr["ADMIN_FLAG"].ToString();
                //dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[9].Value = vFldVal;
                vFldVal = dr["COMMENTS"].ToString();
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[8].Value = vFldVal;
                //chgBit
                dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[9].Value = "N";

                //Column 9 holds the state of the record
                //N= No Change, A=Added, E=Edit
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

        public bool prepFrmInEdtMode(string inPHLnk)
        {
            bool retRes = false;
            if (!(__DbFile.Connected))
            {
                connDB();
            }
            string vSqlStr = "SELECT * FROM GISWSL.WA_PHLINK WHERE PH_LINK = '{0}' ORDER BY MODIFYDATE DESC, FILE_NAME ASC";
            vSqlStr = string.Format(vSqlStr, inPHLnk);
            dtGrdVwItms.Rows.Clear();
            DataTable vDtTbl = __DbFile.getDtTblRecs(vSqlStr);

            if (vDtTbl.Rows.Count > 0)
            {
                retRes = true;
                refGrd(vDtTbl);
                txtPhLnk.Text = inPHLnk;
                //txtPhLnk.Enabled = false;
                __VFrmMode = "E";
                vDtTbl.Clear();

                //this.ShowDialog();
            }
            vDtTbl = null;
            return retRes;
        }

        private bool ValidateControls()
        {
            bool bretRes = false;

            if (dtGrdVwItms.RowCount == 0)
            {
                MessageBox.Show("No Photos entered");
                return bretRes;
            }
            //20150110
            if (tbCtrlMod.SelectedIndex == 1)
            {
                if (txtPhLnk.Text.Trim() == "")
                {
                    MessageBox.Show("Enter PH Link# ");
                    txtPhLnk.Focus();
                    return bretRes;
                }
            }
            //20150110

            bretRes = true;
            return bretRes;
        }

        public void prepFrmInNewMode()
        {
            __VFrmMode = "N";
            //txtPhLnk.Enabled = false;
            dtGrdVwItms.Rows.Clear();
            //this.ShowDialog();
            txtPhLnk.Text = "";
            txtPhLnk.ReadOnly = true;
            btnVw.Visible = false;
        }

        private void dtGrdVwItms_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            //20150110
            if (tbCtrlMod.SelectedIndex == 1)
            {
                if (!(__VFrmMode == "E"))
                {
                    MessageBox.Show("Enter PH Link#");
                    txtPhLnk.Focus();
                    return;
                }
            }
            //20150110

            string vConnStr = __UtilFile.getCfgFilePth();
            using (frmPHDet vFrmPhDet = new frmPHDet()) 
            {
                string vFlNm = "", vComm = "", vFldr = "", vPhType = "";
                DateTime vDtTm = DateTime.Now;
                vFrmPhDet.setPhotoPath(__UtilFile.ConfigRead(vConnStr, "PhotoPath"));
                vFrmPhDet.setAllowedExtensions(__UtilFile.ConfigRead(vConnStr, "PhotoXtnsns"));
                if (vFrmPhDet.setNewMode(ref vFlNm, ref vPhType, ref vDtTm, ref vComm, ref vFldr) == DialogResult.OK)
                {
                    dtGrdVwItms.Rows.Add();
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[2].Value = vPhType;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[3].Value = vFlNm;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[4].Value = vFldr;

                    //dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[5].Value = vDtTm;
                    if (vDtTm == DateTime.MinValue)
                        dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[5].Value = "";
                    else
                        dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[5].Value = vDtTm;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[8].Value = vComm;
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Cells[9].Value = "A";
                    dtGrdVwItms.Rows[dtGrdVwItms.RowCount - 1].Selected = true;
                }
            }
            //dtGrdVwItms.NewRowIndex = dtGrdVwItms.RowCount - 1; 
        }

        private void btnEdt_Click(object sender, EventArgs e)
        {
            if (dtGrdVwItms.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select row to edit");
                return;
            }
            string vFlNm = "", vComm = "", vFldr="", vPhType="";
            string vConnStr = __UtilFile.getCfgFilePth();
            DateTime vDtTm = DateTime.Now;
            using (frmPHDet vFrmPhDet = new frmPHDet())
            {
                vFrmPhDet.setPhotoPath(__UtilFile.ConfigRead(vConnStr, "PhotoPath"));
                vFrmPhDet.setAllowedExtensions(__UtilFile.ConfigRead(vConnStr, "PhotoXtnsns"));

                vFlNm = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[3].Value.ToString();
                vPhType = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[2].Value.ToString();
                if (!(dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value.ToString().Trim() == ""))
                {
                    vDtTm = Convert.ToDateTime(dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value.ToString());
                }
                else
                {
                    vDtTm = DateTime.MinValue;
                }
                vComm = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[8].Value.ToString();
                vFldr = dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[4].Value.ToString();

                if (vFrmPhDet.setEdtMode(ref vFlNm, ref vPhType, ref vDtTm, ref vComm, ref vFldr) == DialogResult.OK)
                {
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[2].Value = vPhType;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[3].Value = vFlNm;
                    if (vDtTm == DateTime.MinValue)
                        dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value = "";
                    else
                        dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[5].Value = vDtTm;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[8].Value = vComm;
                    dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[4].Value = vFldr;
                    if (!(dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[9].Value.ToString().Trim() == "A"))
                        dtGrdVwItms.Rows[dtGrdVwItms.SelectedRows[0].Index].Cells[9].Value = "E";
                }
            }
        }

        private void btnSav_Click(object sender, EventArgs e)
        {
            if (txtPhLnk.Text.Trim().ToString() == "")
            {
                MessageBox.Show("Valid PH# required");
                return; 
            }

            string vPhNo = __UtilFile.ConfigRead(__UtilFile.getCfgFilePth(), "PhotoVwUrl"); 
            vPhNo = string.Format(vPhNo ,    txtPhLnk.Text) ;
//            vPhNo = "http://wsldctvgpw/gisapps/GAdmin/Photo_Edit.aspx?PH_LINK=" + vPhNo;
            Process.Start(vPhNo);
        }

        private string getSqlStmnt(string inPhLnk, DataGridViewRow indtGrdRow)
        {
            string vretRes = "", vtmpStr;


            //PH_ID
            string vPhIdStr ; //= indtGrdRow.Cells[0].Value.ToString();
            //FILE_TYPE
            string vflTypeStr = indtGrdRow.Cells[2].Value.ToString();
            //FILE_NAME
            string vflNmStr = indtGrdRow.Cells[3].Value.ToString();
            //FOLDER
            string vFldrStr = indtGrdRow.Cells[4].Value.ToString();
            //DATE_TAKEN
            string vDtTknStr = indtGrdRow.Cells[5].Value.ToString();
            if (!(vDtTknStr == ""))
            {
                DateTime vDtTm = Convert.ToDateTime(vDtTknStr);
                vDtTknStr = vDtTm.ToString("yyyy/dd/MM");
                vDtTknStr = string.Format("convert(datetime, '{0}', 103)", vDtTknStr);
            }
            else
            {
                vDtTknStr = "null";
            }
            //COMMENTS
            string vCommStr = indtGrdRow.Cells[8].Value.ToString();
            //MODIFYBY
            
            //Changed Bit
            vtmpStr = indtGrdRow.Cells[9].Value.ToString();
            if (vtmpStr.Trim() == "A")
            {
                vretRes = "Insert into GISWSL.WA_PHLINK (PH_LINK, PH_TYPE, FILE_NAME, FOLDER, DATE_TAKEN, MODIFYBY, MODIFYDATE, COMMENTS) " +
                    " values ('{0}', '{1}', '{2}', '{3}', {4}, '{5}', {6}, '{7}')";
                vretRes = string.Format(vretRes, inPhLnk, vflTypeStr, vflNmStr, vFldrStr, vDtTknStr, Environment.UserName, "getdate()", vCommStr);
            } 
            else if (vtmpStr.Trim() == "E")
            {
                //PH_ID
                vPhIdStr = indtGrdRow.Cells[0].Value.ToString();
                vretRes = "Update GISWSL.WA_PHLINK set PH_LINK = '{0}', PH_TYPE = '{1}', FILE_NAME = '{2}', FOLDER = '{3}', DATE_TAKEN =  {4}, MODIFYBY = '{5}', MODIFYDATE = {6}, COMMENTS = '{7}' " +
                    " where (PH_ID = '{8}')";
                vretRes = string.Format(vretRes, inPhLnk, vflTypeStr, vflNmStr, vFldrStr, vDtTknStr, Environment.UserName, "getdate()", vCommStr, vPhIdStr);                
            }


            return vretRes;
        }

        private void btnCnfrm_Click(object sender, EventArgs e)
        {
            int vSeqNo = 0 ;
            string vPHType = "";
            if (!(ValidateControls()))
                return;

            this.Cursor = Cursors.WaitCursor;
            try
            {
                if (__VFrmMode == "N")
                {
                    //vSeqNo = getNewSeq("Data Source=wsldctgdw;Initial Catalog=GISAdmin;Integrated Security=True", "GISWSL.NextVal");
                    if (!(__DbFile.Connected))
                    {
                        connDB();
                    }
                    vSeqNo = __DbFile.getNewSeq("GISWSL.NextVal", "GISWSL.WA_PHLINK_SEQ");
                    txtPhLnk.Text = "PH" + vSeqNo.ToString();

                }


                foreach (DataGridViewRow dvRow in dtGrdVwItms.Rows)
                {
                    if (!(dvRow.Cells[9].Value.ToString() == "N"))
                    {
                        vPHType = getSqlStmnt(txtPhLnk.Text, dvRow);
                        __DbFile.execQry(vPHType);
                        //log
                        vPHType = dvRow.Cells[3].Value.ToString();
                        logNtry("WCTools", "PHLink", vPHType, __LogSessId, "TRC");
                        //MessageBox.Show(vPHType);
                    }
                }

                //if (__VFrmMode == "N")
                //{
                //    IWorkspaceEdit vWrkSpcEdt = __GISUtil.getWrkSpcFFeature(__SelFeat);
                //    vWrkSpcEdt.StartEditOperation();
                //    __GISUtil.setFieldValue(__SelFeat, "PHOTO_LINK", txtPhLnk.Text);
                //    vWrkSpcEdt.StopEditOperation();
                //    logNtry("WCTools", "PHLink", txtPhLnk.Text, __LogSessId, "TRC");
                //}

                prepFrmInEdtMode(txtPhLnk.Text);

                btnCnfrm.Enabled = false;
                btnAdd.Enabled = false;
                btnEdt.Enabled = false;
                tbCtrlMod.Enabled = false;
                btnVw.Enabled = false; 
            }
            catch (Exception ex)
            {
                logNtry("WCTools", "exception" + ex.Message.ToString(), txtPhLnk.Text, __LogSessId, "TRCE");
                MessageBox.Show("GPF->  " + ex.Message.ToString()); 
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void clrFrm()
        {
            prepFrmInNewMode();

            txtPhLnk.Enabled = true;
            btnCnfrm.Enabled = true;
            btnAdd.Enabled = true;
            btnEdt.Enabled = true;
            tbCtrlMod.Enabled = true;
            btnVw.Enabled = true;

            tbCtrlMod.SelectedIndex = 0;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tbCtrlMod_SelectedIndexChanged(object sender, EventArgs e)
        {
            prepFrmInNewMode();
            txtPhLnk.Text = "";
            txtPhLnk.ReadOnly = (tbCtrlMod.SelectedIndex == 0);
            btnVw.Visible = (tbCtrlMod.SelectedIndex == 1);
        }

        private void btnVw_Click(object sender, EventArgs e)
        {
            if (prepFrmInEdtMode(txtPhLnk.Text))
            {
                txtPhLnk.ReadOnly = true;
            }
            else
            {
                MessageBox.Show("Photo link number not found");
            }

        }

        private void btnCncl_Click(object sender, EventArgs e)
        {
            clrFrm();
        }
    }
}
