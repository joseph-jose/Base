﻿define({
    select: "Ř_Select_ů",
    results: "Ř_Results_ů",
    selectLayer: "Ř_Select from layer:_ů",
    selectDrawtool: "Ř_Select draw tool:_ů",
    result: "Ř_Result:_ů",
    noresult: "Ř_No query results to display chart._ů",
    nomedia: "Ř_There's no media in configuration!_ů",
    envelop: "Ř_Draw Rectangle_ů",
    circle: "Ř_Draw Circle_ů",
    ellipse: "Ř_Draw Ellipse_ů",
    polygon: "Ř_Draw Polygon_ů",
    freehand: "Ř_Draw Freehand Polygon_ů",
    clear:"Ř_Clear_ů"
});