﻿define(
   ({
    enableUndoRedo: "Включить Отмена/Повтор",
    toolbarVisible: "Видимость панели инструментов",
    toolbarOptions: "Параметры панели инструментов",
    mergeVisible: "Слияние",
    cutVisible: "Вырезать",
    reshapeVisible: "Изменить форму",
    back: "Назад",
    label: "Слой",
    edit: "Доступно для редактирования",
    update: "DisableUpdateGeometry",
    fields: "Поля",
    actions: "Действия",
    editpageName: "Имя",
    editpageAlias: "Псевдоним",
    editpageVisible: "Видимый",
    editpageEditable: "Доступно для редактирования",
    noLayers: "Нет доступных для редактирования объектов",
    configureFields: "Настроить поля слоя"
  })
);