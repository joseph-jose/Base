// due to the nature of iframes. All iframes will need to be preloaded. This javascript hides the inactive elements when user clicks on the pills menu.
$( document).ready(function() {
  	$("#prod-gallery").load("/GISWebPage/dashboard/db-prd-gallery.html"); 
  	
	$('#v-pills-0-tab').click(function(){
		$('#v-pills-1').hide();
		$('#v-pills-2').hide();
		$('#v-pills-3').hide();
		$('#v-pills-4').hide();
		$('#v-pills-5').hide();
		$('#v-pills-0').show();
	});

	$('#v-pills-1-tab').click(function(){
		$('#v-pills-0').hide();
		$('#v-pills-2').hide();
		$('#v-pills-3').hide();
		$('#v-pills-4').hide();
		$('#v-pills-5').hide();
		$('#v-pills-1').show();
	});

	$('#v-pills-2-tab').click(function(){
		$('#v-pills-0').hide();
		$('#v-pills-1').hide();
		$('#v-pills-3').hide();
		$('#v-pills-4').hide();
		$('#v-pills-5').hide();
		$('#v-pills-2').show();
	});

	$('#v-pills-3-tab').click(function(){
		$('#v-pills-0').hide();
		$('#v-pills-1').hide();
		$('#v-pills-2').hide();
		$('#v-pills-4').hide();
		$('#v-pills-5').hide();
		$('#v-pills-3').show();
	});

	$('#v-pills-4-tab').click(function(){
		$('#v-pills-0').hide();
		$('#v-pills-1').hide();
		$('#v-pills-2').hide();
		$('#v-pills-3').hide();
		$('#v-pills-5').hide();
		$('#v-pills-4').show();
	});


	$('#v-pills-5-tab').click(function(){
		$('#v-pills-0').hide();
		$('#v-pills-1').hide();
		$('#v-pills-2').hide();
		$('#v-pills-3').hide();
		$('#v-pills-4').hide();
		$('#v-pills-5').show();
	});


});
