﻿using ESRI.ArcGIS.ADF;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmPWSrch : Form
    {
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }
        private string __LogSessId = "";
        public string __LogSession { set { __LogSessId = value; } }
        //private IFeatureLayer __FeatLyr;
        //private IList __Lst;

        WCTools.BL.Classes.cUtilGIS __GISUtil;
        WCTools.BL.Classes.cUtilFile __UtilFile;
        WCTools.BL.Classes.cDbFile __DbFile;

        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

        public bool helpersActivate()
        {
            bool vBRes = true; 
            __DbFile = new WCTools.BL.Classes.cDbSqlFile();
            __UtilFile = new WCTools.BL.Classes.cUtilFile();
            __GISUtil = new WCTools.BL.Classes.cUtilGIS();
            __GISUtil.vAppMap = __App;

            //20170510 Non GISEditor intimation
            //connDB();
            try
            {
                connDB();
            }
            catch (Exception e)
            {
                MessageBox.Show("Access to database couldn't be obtained");
                vBRes = false;
                return vBRes;
            }
            //20170510 Non GISEditor intimation
            logNtry("WCTools", "SrchPW", "Start", __LogSessId, "TRC");
            return vBRes;
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "SrchPW", "End", __LogSessId, "TRC");
            __DbFile.Dispose();
            __DbFile = null;
            __GISUtil.Dispose();
            __GISUtil = null;

        }
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            __UtilFile.logNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public bool validateOnLoad()
        {
            bool vResFn = false;

            vResFn = true;
            return vResFn;
        }

        public frmPWSrch()
        {
            InitializeComponent();
        }

        ~frmPWSrch()
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void loadMapLayers()
        {
            IEnumLayer vLyrsInToc = __GISUtil.getLyrsInTOC();
            try
            {
                ILayer vCurrLyr = null;

                cmbLyrs.Items.Add("All..");
                vLyrsInToc.Reset();
                vCurrLyr = vLyrsInToc.Next();
                while (!(vCurrLyr == null))
                {
                    if (vCurrLyr is IFeatureLayer)
                    {
                        cmbLyrs.Items.Add(vCurrLyr.Name.ToString());
                    }
                    vCurrLyr = vLyrsInToc.Next();
                }
                cmbLyrs.SelectedIndex = 0;
            }
            finally
            {
                Marshal.ReleaseComObject(vLyrsInToc);
            }
        }

        private void Listsload(DataTable inDtTbl)
        {
            //int vFldIdx;
            string vStrVal;
            DateTime vtmpDate;

            dtGrdLstAttr.Columns.Add("Col0", "PW_ID");
            dtGrdLstAttr.Columns.Add("Col1", "PW_REF");
            dtGrdLstAttr.Columns.Add("Col2", "PL_TYPE");
            dtGrdLstAttr.Columns.Add("Col3", "DOC_NO");

            dtGrdLstAttr.Columns.Add("Col4", "DOC_TYPE");
            dtGrdLstAttr.Columns.Add("Col5", "STATUS");
            dtGrdLstAttr.Columns.Add("Col6", "MODIFYBY");
            dtGrdLstAttr.Columns.Add("Col7", "COMMENTS");

            for (int vI = 0; vI < inDtTbl.Rows.Count ; vI++)
            {
                DataRow vDataRow = inDtTbl.Rows[vI];

                dtGrdLstAttr.Rows.Add();
                vStrVal = vDataRow["PW_ID"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = vStrVal;
                vStrVal = vDataRow["PW_REF"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vStrVal;
                vStrVal = vDataRow["PL_TYPE"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[2].Value = vStrVal;
                vStrVal = vDataRow["DOC_NO"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = vStrVal;
                vStrVal = vDataRow["DOC_TYPE"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vStrVal;
                vStrVal = vDataRow["STATUS"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[5].Value = vStrVal;

                vStrVal = vDataRow["MODIFYBY"].ToString();
                if (DateTime.TryParse(vStrVal, out vtmpDate))
                {
                    vStrVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                }
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[6].Value = vStrVal;
                vStrVal = vDataRow["COMMENTS"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[7].Value = vStrVal;
            }
        }

        private void btnSrch_Click(object sender, EventArgs e)
        {
            logNtry("WCTools", "SrchPW", string.Format("Search for PWNo:{0}", txtPWNo.Text), __LogSessId, "TRC");

            if ((txtPWNo.Text.Trim() == "") || (txtPWNo.Text.Trim() == "PW"))
            {
                MessageBox.Show("Enter the PW Number");
                txtPWNo.Focus();
                return;
            }

            dtGrdLstAttr.Rows.Clear();
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");

            __DbFile.ConnectToDatabase(3, vConnStr);
            if (__DbFile.Connected)
            {
                //20170324
                /*
                vConnStr = "SELECT TOP 20 [PW_ID] ,[PW_REF] ,[PL_TYPE] ,[DOC_NO] ,[DOC_TYPE] ,[STATUS] ,[MODIFYBY] ,[COMMENTS] " +
                            "FROM [GISAdmin].[GISWSL].[WA_PWLINK] " +
                            "where (PW_REF like '%{0}%')";
                */

                vConnStr = "SELECT TOP 20 [PW_ID] ,[PW_REF] ,[PL_TYPE] ,[DOC_NO] ,[DOC_TYPE] ,[STATUS] ,[MODIFYBY] ,[COMMENTS] " +
                            "FROM [GISAdmin].[GISWSL].[WA_PWLINK] ";
                if (cmbSrchType.SelectedIndex == 0)
                    vConnStr = vConnStr + "where (PW_REF like '%{0}%')";
                else
                    vConnStr = vConnStr + "where (DOC_NO like '%{0}%')";

                //20170324
                vConnStr = String.Format(vConnStr, txtPWNo.Text.ToString());
                DataTable vDtTbl = __DbFile.getDtTblRecs(vConnStr);

                using (ComReleaser vComReleaser = new ComReleaser())
                {

                    Listsload(vDtTbl);
                }
                vDtTbl = null;
            }
        }

        private void frmPWSrch_Load(object sender, EventArgs e)
        {
            cmbSrchType.SelectedIndex = 0; 
            loadMapLayers();
        }

        private void findFeatInLyr(string inLyrName, string inFltrCond)
        {
            ILayer vCurrLyr = null;
            vCurrLyr = __GISUtil.getLayerByName(inLyrName);

            //validation
            IFeatureLayer vFeatLyr = vCurrLyr as IFeatureLayer;
            
            int vFldIdx = -1;
            object vFldVal = -1;
            string vFldStrVal = "";

            vFldIdx = __GISUtil.getFieldIdx(vFeatLyr, "DMS_LINK");
            if (vFldIdx == -1)
                return;

            using (ComReleaser vComRel = new ComReleaser())
            {
                IFeatureCursor vFeatCursr = null;

                vComRel.ManageLifetime(vFeatCursr);
                vComRel.ManageLifetime(vCurrLyr);

                vFeatCursr = __GISUtil.getQryFltr(vFeatLyr, inFltrCond);

                IFeature vFeat = vFeatCursr.NextFeature();
                while (!(vFeat == null))
                {
                    dtGrdLyrVals.Rows.Add();
                    vFldIdx = __GISUtil.getFieldIdx(vFeat, "ObjectId");
                    if (!(vFldIdx == -1))
                    {
                        vFldVal = __GISUtil.getFieldValue(vFeat, "ObjectId");
                        vFldStrVal = vFldVal.ToString();
                        dtGrdLyrVals.Rows[dtGrdLyrVals.RowCount - 1].Cells[0].Value = vFldStrVal; 
                    }
                    vFldIdx = __GISUtil.getFieldIdx(vFeat, "GIS_Id");
                    if (!(vFldIdx == -1))
                    {
                        vFldVal = __GISUtil.getFieldValue(vFeat, "GIS_Id");
                        vFldStrVal = vFldVal.ToString();
                        dtGrdLyrVals.Rows[dtGrdLyrVals.RowCount - 1].Cells[1].Value = vFldStrVal;
                    }
                    dtGrdLyrVals.Rows[dtGrdLyrVals.RowCount - 1].Cells[2].Value = inLyrName;


                    vFeat = vFeatCursr.NextFeature();
                }
            }
        }

        private void btnUpdAttr_Click(object sender, EventArgs e)
        {
            dtGrdLyrVals.Rows.Clear();
            if (cmbLyrs.Text.Trim() == "")
            {
                MessageBox.Show("Select the layer");
                cmbLyrs.Focus();
                return;
            }
            if (!(dtGrdLstAttr.SelectedRows.Count > 0))
            {
                MessageBox.Show("Select an item in grid");
                return;
            }
            string vPWRefStr;
            vPWRefStr = dtGrdLstAttr.SelectedRows[0].Cells[1].Value.ToString();
            vPWRefStr = string.Format ( "DMS_LINK='{0}'" , vPWRefStr);

            dtGrdLyrVals.Columns.Add("Col0", "OBJECTID");
            dtGrdLyrVals.Columns.Add("Col1", "GIS_ID");
            dtGrdLyrVals.Columns.Add("Col2", "LAYERNAME");

            if (cmbLyrs.Text.ToUpper() == "ALL..")
            {
                this.Cursor = Cursors.WaitCursor;
                try
                {
                    for (int vI = 1; vI < cmbLyrs.Items.Count; vI++)
                    {
                        toolStripStatus.Text = "Searching..." + cmbLyrs.Items[vI].ToString();
                        System.Threading.Thread.Sleep(50);
                        Application.DoEvents();
                        findFeatInLyr(cmbLyrs.Items[vI].ToString(), vPWRefStr);
                    }
                }
                finally
                {
                    this.Cursor = Cursors.Default;
                    toolStripStatus.Text = "";
                }
            }
            else
                findFeatInLyr(cmbLyrs.Text, vPWRefStr);
        }

        private void zoomToToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!(dtGrdLyrVals.SelectedRows.Count > 0))
            {
                MessageBox.Show("Select an item in grid");
                return;
            }
            string vObjIdWhrStr;
            ILayer vCurrLyr = null;
            vObjIdWhrStr = dtGrdLyrVals.SelectedRows[0].Cells[2].Value.ToString();
            vCurrLyr = __GISUtil.getLayerByName(vObjIdWhrStr);
            IFeatureLayer vFeatLyr = vCurrLyr as IFeatureLayer;

            vObjIdWhrStr = dtGrdLyrVals.SelectedRows[0].Cells[0].Value.ToString();
            vObjIdWhrStr = "ObjectId=" + vObjIdWhrStr;

            //__GISUtil.SelectOnMap(__GISUtil.vAppDoc, vFeatLyr, vObjIdWhrStr);

            //IEnumFeature vEnmFeat = __GISUtil.getSelectedFeatures();
            IFeature vFeat = null;
            IFeatureCursor vFeatCur = __GISUtil.getFeaturesForCond(__GISUtil.vAppDoc, vFeatLyr, vObjIdWhrStr);
            try
            {
                //vEnmFeat.Reset();
                //vFeat = vEnmFeat.Next();
                vFeat = vFeatCur.NextFeature();
                __GISUtil.ZoomToFeature(vFeat, __GISUtil.vAppDoc);
                __GISUtil.SelectOnMap(__GISUtil.vAppDoc, vFeatLyr, vObjIdWhrStr);
            }
            finally
            {
                //Marshal.ReleaseComObject(vEnmFeat);
                Marshal.ReleaseComObject(vFeatCur);
                Marshal.ReleaseComObject(vCurrLyr);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
