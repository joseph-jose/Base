﻿define({
  label1: "我是一个演示widget。",
  label2: "这里可以配置。"
});
