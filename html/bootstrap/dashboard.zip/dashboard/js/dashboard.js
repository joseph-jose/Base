// load gallery in repective divs
$( document ).ready(function() {

  	$("#prod-gallery").load("dashboard/db-prd-gallery.html"); 
  	$("#test-gallery").load("dashboard/db-test-gallery.html"); 
  	$("#dev-gallery").load("dashboard/db-dev-gallery.html");
  	$("#db-links").load("dashboard/db-links.html");
   	$("#db-clipboard").load("dashboard/db-clipboard.html");

	url = window.location.host
	// if DEV
	if(url.indexOf("wsldctdgweb")>= 0){
		$('#v-pills-PROD').removeClass( "active show" );
		$('#v-pills-prod-tab').removeClass( "active show" );
  		$('#v-pills-DEV').addClass( "active show" );
   		$('#v-pills-dev-tab').addClass( "active show" );
	// if TEST
	}else if(url.indexOf("wsldcttgweb")>= 0){
		$('#v-pills-PROD').removeClass( "active show" );
		$('#v-pills-prod-tab').removeClass( "active show" );
  		$('#v-pills-TEST').addClass( "active show" );
   		$('#v-pills-test-tab').addClass( "active show" );
	// if PROD
	}else if(url.indexOf("wsldctpgweb" || "gisweb")>= 0){
		// do sweet jack all
	}
	// clipboard.js
	var clipboard = new Clipboard('.bt');

	clipboard.on('success', function(e) {
	    console.info('Action:', e.action);
	    console.info('Text:', e.text);
	    console.info('Trigger:', e.trigger);

	    e.clearSelection();
	});

	clipboard.on('error', function(e) {
	    console.error('Action:', e.action);
	    console.error('Trigger:', e.trigger);
	});

});


