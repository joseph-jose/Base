﻿define({
    unit: "כן_Unit_ש",
    style: "כן_Style_ש"
});