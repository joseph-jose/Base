//for documentation see: http://jira.tx.co.nz/confluence/display/tpp/How+the+Javascript+Component+Event+Model+works

/**
function addUIComponentEventListener(element, eventHandler, capturing) {

  if( element.addEventListener ) {

	for (var i = 0; i < eventHandler.eventTypes.length; i++) {
      element.addEventListener(eventHandler.eventTypes[i], eventHandler.handleEvent,capturing);
    }

  } else if ( element.attachEvent ) {

	for (var i = 0; i < eventHandler.eventTypes.length; i++) {
      element.attachEvent( 'on' + eventHandler.eventTypes[i], eventHandler.handleEvent);
    }

  }

}
*/


// JFUIComponentEvent
// The is the base javascript event object
function JFUIComponentEvent( source, eventID ) {
  this.source = source || "";
  this.eventID = eventID || "";
  this.attributes = new Array();
}

JFUIComponentEvent.prototype.setAttribute = function (attributeID, value ) {
  this.attributes[attributeID] = value;
}

JFUIComponentEvent.prototype.getAttribute = function (attributeID) {
  return this.attributes[attributeID];
}

JFUIComponentEvent.prototype.getSource = function () {
  return this.source;
}

JFUIComponentEvent.prototype.getEventID = function () {
  return this.eventID;
}

// JFUINotificationEvent
// These events are fired when a component performs some update or action
function JFUINotificationEvent( source, eventID ) {
  JFUIComponentEvent.call(this, source, eventID);
}

JFUINotificationEvent.prototype = new JFUIComponentEvent;


// JFUICommandEvent
// Command Events are dispatched to a JFUIComponent to communicate an action to be performed
function JFUICommandEvent( source, eventID ) {
  JFUIComponentEvent.call(this, source, eventID);
}

JFUICommandEvent.prototype = new JFUIComponentEvent;

// JFUIActionEvent
// Action Events are dispatched to the backend server to be processed by the module
function JFUIActionEvent( source, eventID ) {
  JFUIComponentEvent.call(this, source, eventID);
}

JFUIActionEvent.prototype = new JFUIComponentEvent;

// event listener
function JFUIEventListener() {
  this.eventHandlers = new Array();
}

JFUIEventListener.prototype.handleEvent = function (event) {

  for (var i=0; i<this.eventHandlers.length; i++) {
	  if (this.eventHandlers[i].supportsEvent(event)) {
  	    this.eventHandlers[i].processEvent(event);
	  }
  }

}

JFUIEventListener.prototype.addEventHandler = function (eventHandler) {
  this.eventHandlers.push(eventHandler);
}

// event handler
function JFUIEventHandler(eventTypes) {
  this.eventTypes = eventTypes || [];
  this.actions = new Array();
}


JFUIEventHandler.prototype.processEvent = function (event) {

  for (var i=0; i<this.actions.length; i++) {
    this.actions[i].processEvent(event);
  }

}

JFUIEventHandler.prototype.supportsEvent = function (event) {

  for (var i=0; i<this.eventTypes.length; i++) {
    if (this.eventTypes[i] == event.type) {
		return true;
    }
  }

  return false;

}

JFUIEventHandler.prototype.addAction = function (action) {
  this.actions.push(action);
}

// action
function JFUIAction (actionFunction) {
  this.processEvent = actionFunction;
}

// custom event for tree node
function FormEvent(srcElement, eventType) {
  this.srcElement = srcElement;
  this.type = eventType;
}
