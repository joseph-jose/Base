﻿define(
   ({
    enableUndoRedo: "สามารถ ยกเลิกและย้อนการกระทำได้",
    toolbarVisible: "แถบเครื่องมือที่สามารถมองเห็น",
    toolbarOptions: "ตัวเลือกแถบเครื่องมือ",
    mergeVisible: "ผสม",
    cutVisible: "ตัด",
    reshapeVisible: "แก้ไขรูป",
    back: "กลับ",
    label: "ชั้นข้อมูล",
    edit: "ที่สามารถแก้ไขได้",
    update: "ไม่สามารถอัพเดทเชิงเรขาคณิตได้",
    fields: "ฟิลด์",
    actions: "กระทำ",
    editpageName: "ชื่อ",
    editpageAlias: "นามแฝง",
    editpageVisible: "มองเห็น",
    editpageEditable: "ที่สามารถแก้ไขได้",
    noLayers: "ไม่สามารถแก้ไขชั้นข้อมูลฟีเจอร์ที่ปรากฏได้",
    configureFields: "ปรับแต่งฟิลด์ชั้นข้อมูล"
  })
);