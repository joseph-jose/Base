﻿define({
    left: "VENSTRE",
    right: "HØJRE",
    arrangement: "Fordeling",
    autoUpdate: "Opdater automatisk",
    respectCurrentMapScale: "Overhold kortets nuværende målestok"
});