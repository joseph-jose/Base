http://dojotoolkit.org/documentation/tutorials/1.10/dom_functions/index.html
https://dojotoolkit.org/reference-guide/1.7/dojo/attr.html
https://dojotoolkit.org/reference-guide/1.10/dojo/dom-attr.html
