﻿define(
   ({
    _widgetLabel: "Редактировать",
    title: "Выберите шаблон для создания объектов",
    pressStr: "Нажмите ",
    ctrlStr: " CTRL ",
    snapStr: " чтобы включить замыкание"
  })
);