## Deploy script viewer
## 
## FS Hand 30/07/2013                                   
## Eagle Technology                                     
## REQUIRES:
## install of pywin32
## need read / write access on target directory

## expected arguments builtFlexViewerLocation, targetDirectory, built configured GIS server, built configured Link server, built configured Search service server
## C:/Work/Clients/Watercare/FlexViewerUpgrade24042013/arcgis-viewer-flex-33/bin-release C:/Work/Clients/Watercare/FlexViewerUpgrade24042013/deploy svcs-demo.eagle.co.nz svcs-demo.eagle.co.nz mapws.aucklandcouncil.govt.nz
## Will process tags with the following syntax as per current Flex Viewer v3.3 + WSL config
## <layers gisserver="svcs-demo.eagle.co.nz" linkserver="svcs-demo.eagle.co.nz">
## <fieldsorting server="svcs-demo.eagle.co.nz">
## <qsfeatures server="svcs-demo.eagle.co.nz">
## <mapswitching server="svcs-demo.eagle.co.nz" mapswitchscale="1000">
## <links linkserver="svcs-demo.eagle.co.nz">
## <layers server="svcs-demo.eagle.co.nz">
## <service>http://mapws.aucklandcouncil.govt.nz/ServiceCentre/ARCSearchService.svc?wsdl
## <predictiveSearchLayers server="svcs-demo.eagle.co.nz">
## <url>http://sampleserver1.arcgisonline.com/ArcGIS/r
## <layer>http://sampleserver1.arcgisonline.com/Arc
## <taskurl>http://sampleserver6.arcgisonline.com/ArcG
## <layer type="tiled" url="http://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer"/>
## <layer label="Age statistics" url="http://server.arcg"
## <locator>http://geocode.arcgis.com/arcgis
## <taskurl>http://sampleserver1.arcgisonline.com/ArcGIS/rest/services/Demographics/ESRI_Population_World/GPServer/PopulationSummary</taskurl>
## <helpurl>http://sampleserver1.arcgisonline.com/arc
## <dataextractionservice>http://sampleserver4.arcgisonline.com/ArcGIS
## NOTE: Some variables will need to be configured below!

# arguments C:\Z_Dev1\Netview C:\Z_Dev1\Deployment\Releases wsldctgdw wsldctgdw wsldctgdw
import sys,io,traceback,os,uuid,datetime,json
import urllib2
import shutil
from shutil import copytree, ignore_patterns
import distutils
import subprocess
from contextlib import closing
from zipfile import ZipFile, ZIP_DEFLATED
# we need pywin32
import win32api,win32con
import glob
import fileinput
from xml.etree import ElementTree as ET

#params required - update for WSL environment - these will point to your servers in each environment
devGISServer = 'wsldctgdw'
devLinkServer = 'wsldctgdw'
devSearchServiceServer = 'wsldctgdw'
testGISServer = 'wsldctvgtw'
testLinkServer = 'wsldctvgtw'
testSearchServiceServer = 'wsldctvgtw'
prodGISServer = 'wsldctvgpw'
prodLinkServer = 'wsldctvgpw'
prodSearchServiceServer = 'wsldctvgpw'

#the viewer is configured against UAT internal (at 15022013) so we don't need to change any urls for it - only for prod.
# order here is important we are checking the index of configured against and will replace with item of same index
urls = {
        'prod':[prodGISServer,prodLinkServer,prodSearchServiceServer],
        'test':[testGISServer,testLinkServer,testSearchServiceServer],
        'dev':[devGISServer,devLinkServer,devSearchServiceServer]
    }

def zipdir(basedir, archivename):
    '''
    Zip up a viewer directory for copying
    Inputs: target directory
    Outputs: None - zips up directory to current target
    '''
    assert os.path.isdir(basedir)
    with closing(ZipFile(archivename, "w", ZIP_DEFLATED)) as z:
        for root, dirs, files in os.walk(basedir):
            #NOTE: ignore empty directories
            for fn in files:
                absfn = os.path.join(root, fn)
                zfn = absfn[len(basedir)+len(os.sep):] #XXX: relative path
                z.write(absfn, zfn)

def remove_readonly(fn, path, excinfo):
    '''
    When we are removing the exiting temp directory we will hit read only files.append
    Make then not ready to delete
    Inputs: File path and file info
    Outputs: None - tries to delete file
    '''
    #if the file is red only we will hit this. Just change attribute and delete
    win32api.SetFileAttributes(path, win32con.FILE_ATTRIBUTE_NORMAL)
    os.remove(path)

def writeSubTitle(el,env):
    check = ''
    if any(env.lower() == val for val in subtitles.keys()):
        el.text = subtitles[env.lower()]

def writeXMLElement(el,env):
    '''
    Rewrites an XML element (text) with current target env parameter
    '''
    if el.text is None:
        return 
    for t, e in zip(range(len(configuredagainst)), configuredagainst):
        if e.upper() in el.text.upper():
            el.text = (el.text.upper().replace(e.upper(),urls[env][t].upper())).lower()

def writeXMLAttribute(att,val):
    '''
    Rewrites an XML attribute (text) with current target env parameter
    '''
    if att is None:
        return att
    for t, e in zip(range(len(configuredagainst)), configuredagainst):
        if e.upper() in att.upper():
            return (att.upper().replace(e.upper(),val.upper())).lower()
    return att

'''
main routine
'''

if __name__ == '__main__':
    if not len(sys.argv) == 6:
        raise Exception("In correct argument count")

    projectDir = sys.argv[1]
    targetDir = sys.argv[2]
    currentGISServer = sys.argv[3]
    currentLinkServer = sys.argv[4]
    currentSearchServiceServer = sys.argv[5]

    configuredagainst = [currentGISServer,currentLinkServer,currentSearchServiceServer]

    deploydirs = { 'test':os.path.join(targetDir,r'Test'),
    'prod':os.path.join(targetDir,r'Production'),
    'dev':os.path.join(targetDir,r'Development')
    }

    subtitles = {'test':'Test',
                 'dev':'Dev',
                 'prod':''                 
                 }

    now = datetime.datetime.now()
    f = open(targetDir+'/'+str(now.year)+str(now.month)+str(now.day)+str(now.hour)+str(now.minute)+'.log','a')

    try:
        

        for env in deploydirs:
            dir = deploydirs[env]
            print dir
            if not os.path.exists(dir):
                os.makedirs(dir)
            else:
                shutil.rmtree(dir, onerror=remove_readonly)
                os.makedirs(dir)
            # copy files across from project directory - you can add to the ignore patterns to drop out any files you don't want / need
            shutil.copytree(projectDir,os.path.join(dir,'FlexViewer'),ignore=ignore_patterns('*.scc'))
            for root, dirs, files in os.walk(os.path.join(dir,'FlexViewer')):
                for x in glob.iglob(root+'/*.xml'):
                    f.write('----- parsing XML file ------>'+x+'\n')
                    win32api.SetFileAttributes(x, win32con.FILE_ATTRIBUTE_NORMAL)
                    tree = ET.parse(x)
                    f.write('<------ file ' + x + ' parsed ok\n')
                    # element tree only lets us do 1 predicate at a time. Could try lxml which has full xpath syntax
                    for aa in tree.findall(".//*[@gisserver]"):
                        #we just change the attr
                        f.write('\t\tprocessing attribute gisserver,'+aa.attrib["gisserver"]+' to '+urls[env][0]+'\n')
                        aa.attrib["gisserver"] = writeXMLAttribute(aa.attrib["gisserver"],urls[env][0])
                    for ab in tree.findall(".//*[@server]"):
                        f.write('\t\tprocessing attribute server,'+ab.attrib["server"]+' to '+urls[env][0]+'\n')
                        ab.attrib["server"] = writeXMLAttribute(ab.attrib["server"],urls[env][0])
                    for ac in tree.findall(".//*[@linkserver]"):
                        f.write('\t\tprocessing attribute linkserver'+ac.attrib["linkserver"]+' to '+urls[env][1]+'\n')
                        ac.attrib["linkserver"] = writeXMLAttribute(ac.attrib["linkserver"],urls[env][1])

                    for ad in tree.findall(".//*[@url]"):
                        f.write('\t\tprocessing url'+'\n')
                        for t, e in zip(range(len(configuredagainst)), configuredagainst):
                            # this will set the gis server first
                            f.write( '\t\tlooking for '+e+' in '+ad.attrib["url"]+'\n')
                            if e in ad.attrib["url"]:
                                f.write( '\t\t\tprocessing url:'+ad.attrib["url"]+' '+e+' to '+urls[env][t]+'\n')
                                ad.attrib["url"] = ad.attrib["url"].replace(e,urls[env][t])
                                break           

                    f.write('\t\tprocessing element service'+'\n')
                    for i in tree.findall(".//service"):
                        writeXMLElement(i,env)
                    f.write('\t\tprocessing element url'+'\n')
                    for i in tree.findall(".//url"):
                        writeXMLElement(i,env)
                    f.write('\t\tprocessing element layer'+'\n')
                    for i in tree.findall(".//layer"):
                        writeXMLElement(i,env)
                    f.write('\t\tprocessing element taskurl'+'\n')
                    for i in tree.findall(".//taskurl"):
                        writeXMLElement(i,env)
                    f.write('\t\tprocessing element locator'+'\n')
                    for i in tree.findall(".//locator"):
                        writeXMLElement(i,env)
                    f.write('\t\tprocessing element helpurl'+'\n')
                    for i in tree.findall(".//helpurl"):
                        writeXMLElement(i,env)
                    f.write('\t\tprocessing element dataextractionservice'+'\n')
                    for i in tree.findall(".//dataextractionservice"):
                        writeXMLElement(i,env)

                    f.write('\t\tprocessing element subtitle'+'\n')
                    for i in tree.findall(".//subtitle"):
                        writeSubTitle(i,env)

                    f.write('--------> trying to write xml file'+'\n')
                    tree.write(x)
                    f.write('<-------- file rewritten ok'+'\n')
            
            zipfilename = env+'_'+str(now.year)+str(now.month)+str(now.day)+str(now.hour)+str(now.minute)+'.zip'
            zipfile = os.path.join(targetDir,zipfilename)
            zipdir(os.path.join(dir,'FlexViewer'), zipfile)
            shutil.rmtree(dir, onerror=remove_readonly)
    except Exception,e:
        f.write(e.message)
    finally:
        f.close()

    print 'Done', now
