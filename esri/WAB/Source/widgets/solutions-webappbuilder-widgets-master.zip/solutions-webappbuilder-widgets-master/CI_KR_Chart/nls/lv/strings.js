﻿define({
    select: "ķ_Select_ū",
    results: "ķ_Results_ū",
    selectLayer: "ķ_Select from layer:_ū",
    selectDrawtool: "ķ_Select draw tool:_ū",
    result: "ķ_Result:_ū",
    noresult: "ķ_No query results to display chart._ū",
    nomedia: "ķ_There's no media in configuration!_ū",
    envelop: "ķ_Draw Rectangle_ū",
    circle: "ķ_Draw Circle_ū",
    ellipse: "ķ_Draw Ellipse_ū",
    polygon: "ķ_Draw Polygon_ū",
    freehand: "ķ_Draw Freehand Polygon_ū",
    clear:"ķ_Clear_ū"
});