import arcpy
import os

FCs = arcpy.GetParameterAsText(0)

arcpy.env.workspace = FCs

fieldname = "UniqueIDR"

if len(arcpy.ListFields(FCs, fieldname))>0:
	print "Field exist"
else:
	delimitedfield = arcpy.AddField_management(FCs, fieldname, "string")
