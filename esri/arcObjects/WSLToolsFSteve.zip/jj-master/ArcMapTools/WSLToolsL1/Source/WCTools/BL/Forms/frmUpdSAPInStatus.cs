﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmUpdSAPInStatus : Form
    {
        WCTools.BL.Classes.cDbSqlFile __DbFile;
        WCTools.BL.Classes.cUtilFile __UtilFile;
        WCTools.BL.Classes.cUtilGIS __GISUtil;
        private string __LogSessId = "";
        public string __LogSessionId { set { __LogSessId = value; } }


        public bool helpersActivate()
        {
            bool vBRes = true;
            __DbFile = new WCTools.BL.Classes.cDbSqlFile();
            __UtilFile = new WCTools.BL.Classes.cUtilFile();
            __GISUtil = new WCTools.BL.Classes.cUtilGIS();

            //20170510 Non GISEditor intimation
            //connDB();
            try
            {
                connDB();
            }
            catch (Exception e)
            {
                MessageBox.Show("Access to database couldn't be obtained");
                vBRes = false;
                return vBRes;
            }
            //20170510 Non GISEditor intimation
            logNtry("WCTools", "UpdSAPAttrChangeSession", "Start", __LogSessId, "TRC");
            return vBRes;
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "UpdSAPAttrChangeSession", "End", __LogSessId, "TRC");
            __DbFile.CleanUpDBConnection();
            __DbFile.Dispose();
            __DbFile = null;
            __GISUtil.Dispose();
            __GISUtil = null;

        }

        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

        public frmUpdSAPInStatus()
        {
            InitializeComponent();
        }

        ~frmUpdSAPInStatus()
        {
            helpersDeActivate();
        }

        public bool validateOnLoad()
        {
            return true;
        }
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            __UtilFile.logTxtNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public void UpdSAP(string inState = "", string inSAGIds = "")
        {
            //string vSqlStr = "Insert into GISADMin.giswsl.WA_AppLogs (CurrUsr, CmdType, LogType, Msg, Fld1, Fld10) values ('{0}','{1}','{2}','{3}','{4}','{5}')";
            string vSqlStr = "Update [GISAdmin].[GISWSL].[WAT_SAPGIS] set UpdatedDate=getDate(), UpdatedBy = '{0}', GisState = '{1}' where [SAG_ID] in {2}";

            vSqlStr = string.Format(vSqlStr, Environment.UserName.ToString(), inState, inSAGIds);

            if (!(__DbFile.Connected ))
            {
                connDB(); 
            }
            __DbFile.execQry(vSqlStr);
            ////Configuration vConfig = getConfig();
            ////string vConnStr = vConfig.ConnectionStrings.ConnectionStrings["GISAdminConnection"].ConnectionString.ToString();
            //string vConnStr = cUtlFile.getCfgFilePth();
            //vConnStr = cUtlFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDbP");
            //vConnStr = cUtlFile.ConnStrRectPssWrd(vConnStr); 

            //using ( WCTools.BL.Classes.cDbSqlFile vDbFile = new  WCTools.BL.Classes.cDbSqlFile())
            //{
            //    try
            //    {
            //        vDbFile.ConnectToDatabase(3, vConnStr);
            //        if (vDbFile.Connected)
            //        {
            //            vDbFile.execQry(vSqlStr);
            //        }
            //    }
            //    finally
            //    {
            //        vDbFile.Connected = false;
            //    }
            //}
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbGISState.Text == "")
            {
                MessageBox.Show("Select a GIS State");
                return;
            }
            if (txtGISId.Text == "")
            {
                MessageBox.Show("Enter the SAG-Id values");
                return;
            }
            string sagIdVal = "";
            sagIdVal = txtGISId.Text.ToString();
            //Match vRegMatch = Regex.Match(sagIdVal, "\\b(\\d\\,\\d\\,\\d)\\b", RegexOptions.Singleline);
            Match vRegMatch = Regex.Match(sagIdVal, "^[(][0-9]+(?:,[0-9]+)*[)]$", RegexOptions.Singleline);
            if (!(vRegMatch.Success))
            {
                MessageBox.Show ("Not a valid format- Should have the format (1,2,3)");
                return ;
            }
            try
            {
                UpdSAP(cmbGISState.Text, txtGISId.Text);
                MessageBox.Show("Updated");
            }
            catch(Exception ex)
            {
                MessageBox.Show("GPF -" + ex.Message.ToString());
            }
        }

        private void btnCncl_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmUpdSAP_Load(object sender, EventArgs e)
        {
            cmbGISState.SelectedIndex = 0;
        }

        private void cmbGISState_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void cmbGISState_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true ;
            return;
        }

        private void txtGISId_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }
    }
}
