﻿define({
    select: "Ĳ_Select_ä",
    results: "Ĳ_Results_ä",
    selectLayer: "Ĳ_Select from layer:_ä",
    selectDrawtool: "Ĳ_Select draw tool:_ä",
    result: "Ĳ_Result:_ä",
    noresult: "Ĳ_No query results to display chart._ä",
    nomedia: "Ĳ_There's no media in configuration!_ä",
    envelop: "Ĳ_Draw Rectangle_ä",
    circle: "Ĳ_Draw Circle_ä",
    ellipse: "Ĳ_Draw Ellipse_ä",
    polygon: "Ĳ_Draw Polygon_ä",
    freehand: "Ĳ_Draw Freehand Polygon_ä",
    clear:"Ĳ_Clear_ä"
});