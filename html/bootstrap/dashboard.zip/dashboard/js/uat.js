// due to the nature of iframes. All iframes will need to be preloaded. This javascript hides the inactive elements when user clicks on the pills menu.
$( document).ready(function() {

	$('#v-pills-dev-tab').click(function(){
		$('#v-pills-PROD').hide();
		$('#v-pills-AGOL').hide();
		$('#v-pills-TEST').hide();
		$('#v-pills-DEV').show();
	});

	$('#v-pills-test-tab').click(function(){
		$('#v-pills-PROD').hide();
		$('#v-pills-AGOL').hide();
		$('#v-pills-TEST').show();
		$('#v-pills-DEV').hide();
	});

	$('#v-pills-agol-tab').click(function(){
		$('#v-pills-PROD').hide();
		$('#v-pills-AGOL').show();
		$('#v-pills-TEST').hide();
		$('#v-pills-DEV').hide();
	});

	$('#v-pills-prod-tab').click(function(){
		$('#v-pills-PROD').show();
		$('#v-pills-AGOL').hide();
		$('#v-pills-TEST').hide();
		$('#v-pills-DEV').hide();
	});

});
