﻿define(
   ({
    _widgetLabel: "עריכה",
    title: "בחר תבנית בכדי ליצור ישויות",
    pressStr: "הקש על ",
    ctrlStr: " CTRL ",
    snapStr: " כדי להפעיל הצמדה"
  })
);