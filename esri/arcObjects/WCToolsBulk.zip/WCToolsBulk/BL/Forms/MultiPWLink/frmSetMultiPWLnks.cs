﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCToolsBulk.BL.Forms.MultiPWLink
{
    public partial class frmSetMultiPWLnks : Form
    {
        const int __cOldCKColIdx = 1;
        const int __cNewCKColIdx = 3;

        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }

        private string __LogSessId;
        public string __LogSessionId { set { __LogSessId = value; } }

        private WCToolsBulk.BL.Classes.cUtilFile __UtilFile;
        private WCToolsBulk.BL.Classes.cUtilGIS __GISUtil;
        private WCToolsBulk.BL.Classes.cDbSqlFile __DbFile;

        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            __UtilFile.logNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public void helpersActivate()
        {
            __GISUtil = new Classes.cUtilGIS();
            __GISUtil.vAppMap = __App;

            __UtilFile = new Classes.cUtilFile();
            __DbFile = new Classes.cDbSqlFile();
            logNtry("WCBulkTools", "SetMultiPWLinks", "Start", __LogSessId, "TRC");
        }

        public void helpersDeActivate()
        {
            logNtry("WCBulkTools", "SetMultiPWLinks", "End", __LogSessId, "TRC");
            __GISUtil.Dispose();
            __GISUtil = null;
            __UtilFile = null;

            __DbFile.Connected = false;
            __DbFile.Dispose();
            __DbFile = null;

            __App = null;
        }

        //Do any validations on the form
        public bool validateOnLoad()
        {
            return true;
        }


        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

        public frmSetMultiPWLnks()
        {
            InitializeComponent();
        }
        #region "OutsideFormCallFunctions"
        public void setLayerName(string inLyrName)
        {
            txtLyr.Text = inLyrName;
        }

        public void copyGridValsToPostForm(string inStr, DataGridView inFrDtGrdVw)
        {
            DataGridView vToGrdVw;
            if (inStr == "GRIDTOP")
                vToGrdVw = dtGrdCompKeys;
            else
                vToGrdVw = dtGrdVwItms;


            vToGrdVw.Rows.Clear();
            vToGrdVw.RowCount = inFrDtGrdVw.RowCount;
            for (int vI = 0; vI < inFrDtGrdVw.RowCount; vI++)
            {
                for (int vJ = 0; vJ < inFrDtGrdVw.ColumnCount; vJ++)
                {
                    vToGrdVw.Rows[vI].Cells[vJ].Value =
                                inFrDtGrdVw.Rows[vI].Cells[vJ].Value;
                }

            }
        }

        public bool popGrid()
        {
            bool vBoolRes = true;
            //string vStrVal = "";
            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges;

            for (int vCurrIdx = 0; vCurrIdx < WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges.Count; vCurrIdx++)
            {
                vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[vCurrIdx];
                //vBoolRes = __GISUtil.CheckIfFeaturesTouch(vAssetItemChanges.vOFeature, vAssetItemChanges.vNFeature);
                dtGrdCompKeys.Rows.Add();
                dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Cells[0].Value = vAssetItemChanges.vLyrName;
                dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Cells[1].Value = vAssetItemChanges.vOCompKey;
                dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Cells[2].Value = vAssetItemChanges.vODMSLink;
                dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Cells[3].Value = vAssetItemChanges.vNCompKey;
                dtGrdCompKeys.Rows[dtGrdCompKeys.RowCount - 1].Cells[4].Value = vAssetItemChanges.vNDMSLink;
            }
            return vBoolRes;
        }
        #endregion

        #region "BulkPostingDatabase"

        #region "DuplicatingData"
        private void postGrd(string inPwRef)
        {
            //string vPHType = "";
            string vPlTypeStr = "";
            string vDocNoStr = "";
            string vDOCTypeStr = "";
            string vComments = "";

            string vSqlStr = "";

            if (!(__DbFile.Connected))
            {
                connDB();
            }

            foreach (DataGridViewRow dvRow in dtGrdVwItms.Rows)
            {
                if (!(dvRow.Cells[6].Value.ToString() == "A"))
                {
                    //PL_TYPE
                    vPlTypeStr = dvRow.Cells[2].Value.ToString();
                    //DOC_NO
                    vDocNoStr = dvRow.Cells[3].Value.ToString();
                    //DOC Type
                    vDOCTypeStr = dvRow.Cells[4].Value.ToString();
                    //COMMENTS
                    vComments = dvRow.Cells[5].Value.ToString();

                    vSqlStr = getSqlStmnt("A", "", inPwRef, vPlTypeStr, vDocNoStr, vDOCTypeStr, vComments);
                    logNtry("WCBulkTools",
                        string.Format("Inserted record DOCNo={0}", vDocNoStr),
                        "TRC", __LogSessId, "TRC");
                    __DbFile.execQry(vSqlStr, true );
                    //MessageBox.Show(vSqlStr);

                }
            }
        }
        private string getSqlStmnt(string vInModType, string vPhIdStr, string inPWLnk, string vPlTypeStr, string vDocNoStr, string vDOCTypeStr, string vComments)
        {
            string vretRes = "";

            if (vInModType == "A")
            {
                vretRes = "Insert into GISWSL.WA_PWLINK (PW_REF, PL_TYPE, DOC_NO, DOC_TYPE, MODIFYBY, MODIFYDATE, COMMENTS, ADMIN_TMP) " +
                    " values ('{0}', '{1}', '{2}', '{3}', '{4}', {5}, '{6}', '{7}')";
                vretRes = string.Format(vretRes, inPWLnk, vPlTypeStr, vDocNoStr, vDOCTypeStr, Environment.UserName, "getdate()", vComments, "BulkTools");
            }
            else if (vInModType == "E")
            {
                vretRes = "Update GISWSL.WA_PWLINK set PW_REF = '{0}', PL_TYPE = '{1}', DOC_NO = '{2}', DOC_TYPE = '{3}', MODIFYBY = '{4}', MODIFYDATE = {5}, COMMENTS = '{6}' " +
                    " where (PW_ID = '{7}')";
                vretRes = string.Format(vretRes, inPWLnk, vPlTypeStr, vDocNoStr, vDOCTypeStr, Environment.UserName, "getdate()", vComments, vPhIdStr);
            }


            return vretRes;
        }
        ////Post old historical information into new PWLink
        //private void postDtTbl(DataTable vDtTbl, string inPwRef)
        //{
        //    if (!(__DbFile.Connected))
        //    {
        //        connDB();
        //    }
        //    string vPWId = "", vPWRef = "", vPLType = "", vDocNo = "", vDocType = "", vComm = "";
        //    string vSqlStr = "";
        //    foreach (DataRow dr in vDtTbl.Rows)
        //    {
        //        vPWId = dr["PW_ID"].ToString();
        //        vPWRef = dr["PW_REF"].ToString();
        //        vPLType = dr["PL_TYPE"].ToString();
        //        vDocNo = dr["DOC_NO"].ToString();
        //        vDocType = dr["DOC_TYPE"].ToString();
        //        vComm = dr["COMMENTS"].ToString();

        //        vSqlStr = getSqlStmnt("A", "", inPwRef, vPLType, vDocNo, vDocType, vComm);

        //        logNtry("WCBulkTools",
        //            string.Format("Inserted record DOCNO={0}", vDocNo),
        //            "TRC", __LogSessId, "TRC");

        //        __DbFile.execQry(vSqlStr );
        //        //MessageBox.Show(vSqlStr);
        //    }
        //}

        #endregion
        //Get new PW#
        public string getNewSeqNo()
        {
            int vSeqNo = 0;
            if (!(__DbFile.Connected))
            {
                connDB();
            }
            vSeqNo = __DbFile.getNewSeq("GISWSL.NextVal", "GISWSL.WA_PWLINK_SEQ",true );
            return "PW" + vSeqNo.ToString();
        }

        //Update teh value of PWLink in Grid
        private void setDMSinGrd(string inCompKey, string inDMSLink)
        {
            //MessageBox.Show(inCompKey + "," + inDMSLink);
            string vColVal = "";
            object vObjVal = null;

            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.findAssetItem(inCompKey);
            if (vAssetItemChanges.vNCompKey == inCompKey )
                vAssetItemChanges.vNDMSLink = inDMSLink;
            if (vAssetItemChanges.vOCompKey == inCompKey)
                vAssetItemChanges.vODMSLink = inDMSLink;

            for (int vCurrIdx = 0; vCurrIdx < dtGrdCompKeys.Rows.Count; vCurrIdx++)
            {
                vObjVal = dtGrdCompKeys.Rows[vCurrIdx].Cells[__cOldCKColIdx].Value;
                if (!(vObjVal == null))
                {
                    vColVal = vObjVal.ToString();
                    if (!(vColVal.Trim() == ""))
                    {
                        if (vColVal == inCompKey)
                        {
                            dtGrdCompKeys.Rows[vCurrIdx].Cells[__cOldCKColIdx + 1].Value = inDMSLink;
                            break;
                        }
                    }
                }
                vObjVal = dtGrdCompKeys.Rows[vCurrIdx].Cells[__cNewCKColIdx].Value;
                if (!(vObjVal == null))
                {
                    vColVal = vObjVal.ToString();
                    if (!(vColVal.Trim() == ""))
                    {
                        if (vColVal == inCompKey)
                        {
                            dtGrdCompKeys.Rows[vCurrIdx].Cells[__cNewCKColIdx + 1].Value = inDMSLink;
                            break;
                        }
                    }
                }
            }
        }
        ////Get details of oldPWLink
        //private DataTable getDetailsOfPWLink(string inPHLnk)
        //{
        //    //bool retRes = false;
        //    if (!(__DbFile.Connected))
        //    {
        //        connDB();
        //    }
        //    string vSqlStr = "SELECT * FROM [GISWSL].[WA_PWLINK] WHERE PW_REF = '{0}' ORDER BY MODIFYDATE DESC";
        //    vSqlStr = string.Format(vSqlStr, inPHLnk);
        //    //dtGrdVwItms.Rows.Clear();
        //    DataTable vDtTbl = __DbFile.getDtTblRecs(vSqlStr);

        //    return vDtTbl;
        //}

        //Main bulk function call
        private void createDupCompKey(string inOldCompKey, string inOldPWLnk, string inNewCompKey, string inNewPWLnk)
        {
            //DataTable vDtTbl = null;
            logNtry("WCBulkTools",
                string.Format("Posting new-OldCompKey={0}, OldPWLink={1}, NewCompKey={2}, NewPWLink={3}", inOldCompKey, inOldPWLnk, inNewCompKey, inNewPWLnk), 
                "TRC", __LogSessId, "TRC");
            string vNewPWLnk = "";
            try
            {
                if (inNewPWLnk == "")
                {
                    //if oldPWLnk and oldCompKey present
                    if (!(inOldCompKey == "") && !(inOldPWLnk==""))
                    {
                        logNtry("WCBulkTools",
                            string.Format("  Posting for new-NewCompKey={0}", inNewCompKey),
                            "TRC", __LogSessId, "TRC");

                        //NEWCOMPKEY- create duplicate PWLink
                        //  Get rows from old PWLink
                        //vDtTbl = getDetailsOfPWLink(inOldPWLnk);
                        //  create new PWLink
                        vNewPWLnk = getNewSeqNo();
                        //addDocsDtTbl(vDtTbl, dtGrdVwItms);
                        //  Attach old rows to new PWLink
                        //postDtTbl(vDtTbl, vNewPWLnk);
                        //Attach grid values to new PWLink
                        postGrd(vNewPWLnk);
                        //  Update in Grid
                        setDMSinGrd(inNewCompKey, vNewPWLnk);

                        logNtry("WCBulkTools",
                            string.Format("  Attaching doc for -OldCompKey={0}", inOldCompKey),
                            "TRC", __LogSessId, "TRC");
                        //OLDCOMPKEY- attach document to old PWLink
                        postGrd(inOldPWLnk);
                    }
                    if (inOldCompKey == "" && inOldPWLnk == "")
                    {
                        logNtry("WCBulkTools",
                            string.Format("  Posting for new-NewCompKey={0}", inNewCompKey),
                            "TRC", __LogSessId, "TRC");
                        //NEWCOMPKEY-create new PWLink
                        //  create new PWLink
                        vNewPWLnk = getNewSeqNo();
                        //  Attach grid values to new PWLink
                        postGrd(vNewPWLnk);
                        //  Update in Grid
                        setDMSinGrd(inNewCompKey, vNewPWLnk);
                    }
                    if (!(inOldCompKey == "") && (inOldPWLnk == ""))
                    {
                        logNtry("WCBulkTools",
                            string.Format("  Posting for new-NewCompKey={0}", inNewCompKey),
                            "TRC", __LogSessId, "TRC");
                        //NEWCOMPKEY-create new PWLink
                        //  create new PWLink
                        vNewPWLnk = getNewSeqNo();
                        //  Attach grid values to new PWLink
                        postGrd(vNewPWLnk);
                        //  Update in Grid
                        setDMSinGrd(inNewCompKey, vNewPWLnk);

                        logNtry("WCBulkTools",
                            string.Format("  Create a new PWLink and attach doc for -OldCompKey={0}", inOldCompKey),
                            "TRC", __LogSessId, "TRC");
                        //OLDCOMPKEY- create new PWLink & attach document to old PWLink
                        //  create new PWLink
                        vNewPWLnk = getNewSeqNo();
                        //  Attach grid values to new PWLink
                        postGrd(vNewPWLnk);
                        //  Update in Grid
                        setDMSinGrd(inOldCompKey, vNewPWLnk);
                    }

                }
            }
            finally
            {
                //vDtTbl = null;
            }
        }
        #endregion

        #region "UpdateFeatureAttributes"
        public void updFeatAttrVals(IFeature inFeature)
        {
            IWorkspaceEdit vWrkSpcEdt = null; //
            IFeature vFeat;
            string vNDMSLnk;
            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges;

            try
            {
                vWrkSpcEdt = __GISUtil.getWrkSpcFFeature(inFeature) as IWorkspaceEdit; //
                vWrkSpcEdt.StartEditOperation(); // 

                for (int vCurrIdx = 0; vCurrIdx < WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges.Count; vCurrIdx++)
                {
                    vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[vCurrIdx];
                    vFeat = vAssetItemChanges.vNFeature;
                    vNDMSLnk = vAssetItemChanges.vNDMSLink ;
                    if (!(vFeat == null))
                    {
                        __GISUtil.setFieldValue(vFeat, "DMS_Link", vNDMSLnk);
                        vFeat.Store();
                        logNtry("WCBulkTools",
                            string.Format("Setting DMSLink-CompKey={0}, DMS_Link={1}", vAssetItemChanges.vNCompKey, vNDMSLnk),
                            "TRC", __LogSessId, "TRC");
                    }

                    vFeat = vAssetItemChanges.vOFeature;
                    vNDMSLnk = vAssetItemChanges.vODMSLink;
                    if (!(vFeat == null))
                    {
                        if (__GISUtil.getFieldValue(vFeat, "DMS_Link").ToString() == "")
                        {
                            __GISUtil.setFieldValue(vFeat, "DMS_Link", vNDMSLnk);
                            vFeat.Store();
                            logNtry("WCBulkTools",
                                string.Format("Setting DMSLink-CompKey={0}, DMS_Link={1}", vAssetItemChanges.vOCompKey, vNDMSLnk),
                                "TRC", __LogSessId, "TRC");
                        }
                    }
                }
                vWrkSpcEdt.StopEditOperation();
            }
            finally
            {
                vFeat = null;
            }
        }
        #endregion

        private void btnFinish_Click(object sender, EventArgs e)
        {
            string vLyrName="", vOCKey = "", vOPWLnk = "", vNCKey = "", vNPWLnk = "";

            WCToolsBulk.BL.Classes.structAssetItemChanges vAssetItemChanges;
            IFeature vFeat =  null ;
            if (MessageBox.Show("Process starting....Continue?", "Confirm", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return ;
            }
            try
            {
                this.Cursor = Cursors.WaitCursor; 
                if (!(__DbFile.Connected))
                {
                    connDB();
                }
                __DbFile.Transstart();
                for (int vCurrIdx = 0; vCurrIdx < WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges.Count; vCurrIdx++)
                {
                    vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[vCurrIdx];
                    vLyrName = vAssetItemChanges.vLyrName;
                    vOCKey = vAssetItemChanges.vOCompKey;
                    vOPWLnk = vAssetItemChanges.vODMSLink;
                    vNCKey = vAssetItemChanges.vNCompKey;
                    vNPWLnk = vAssetItemChanges.vNDMSLink;
                    createDupCompKey(vOCKey, vOPWLnk, vNCKey, vNPWLnk);
                }

                //Update feature attributes
                vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[0];
                vFeat = vAssetItemChanges.vNFeature;
                updFeatAttrVals(vFeat);
                btnFinish.Enabled = false;
                __DbFile.TransCommit();
                MessageBox.Show("Posting complete....\n\rIf you are not saving the map,\n\r please ask for the created PWlinks to be removed"); 
            }
            catch (Exception eX)
            {
                MessageBox.Show("GPF-> " + eX.Message.ToString());
                __DbFile.TransRollback();
                logNtry("WCBulkTools", "SetMultiPWLinks", eX.Message.ToString(), __LogSessId, "TRC");
            }
            finally
            {
                for (int vCurrIdx = 0; vCurrIdx < WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges.Count; vCurrIdx++)
                {
                    vAssetItemChanges = WCToolsBulk.BL.Classes.cLstStructures.vLstAssetChanges[vCurrIdx];
                    if (!(vAssetItemChanges.vOFeature == null))
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(vAssetItemChanges.vOFeature);
                    if (!(vAssetItemChanges.vNFeature == null))
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(vAssetItemChanges.vNFeature);
                }
                this.Cursor = Cursors.Default;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
