﻿define(
   ({
    addDistance: "הוסף יחידת אורך",
    addArea: "הוסף יחידת שטח",
    label: "תווית",
    abbr: "קיצור",
    conversion: "המרה",
    actions: "פעולות",
    areaUnits: "יחידות שטח",
    distanceUnits: "יחידות אורך",
    kilometers: "קילומטרים",
    miles: "מיילים",
    meters: "מטרים",
    feet: "רגל",
    yards: "יארד",
    squareKilometers: "קילומטר מרובע",
    squareMiles: "מיילים מרובעים",
    acres: "אקרים",
    hectares: "הקטרים",
    squareMeters: "מ' מרובע",
    squareFeet: "רגל מרובע",
    squareYards: "יארדים מרובעים",
    distance: "מרחקים",
    area: "שטחים"
  })
);