﻿define(
   ({
    enableUndoRedo: "Activare Anulare/Repetare",
    toolbarVisible: "Bară de instrumente vizibilă",
    toolbarOptions: "Opţiuni pentru bara de instrumente",
    mergeVisible: "Unificare",
    cutVisible: "Decupare",
    reshapeVisible: "Remodelare",
    back: "Înapoi",
    label: "Strat tematic",
    edit: "Editabil",
    update: "Dezactivare actualizare geometrie",
    fields: "Câmpuri",
    actions: "Acţiuni",
    editpageName: "Nume",
    editpageAlias: "Pseudonim",
    editpageVisible: "Vizibil",
    editpageEditable: "Editabil",
    noLayers: "Nu sunt disponibile straturi tematice de obiecte spaţiale editabile",
    configureFields: "Configurare câmpuri strat tematic"
  })
);