Only for Level2 users
1. SetGISId Multi - not filtered by User names