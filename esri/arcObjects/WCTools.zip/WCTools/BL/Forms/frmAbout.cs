﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAbout_Load(object sender, EventArgs e)
        {
            Assembly vAssmbly = Assembly.GetExecutingAssembly();
            FileVersionInfo vFlVerInfo = FileVersionInfo.GetVersionInfo(vAssmbly.Location);

            lblFlVer.Text = "File version: " + vFlVerInfo.FileVersion;
            lblProdVer.Text = "Product version: " + vFlVerInfo.ProductVersion;
            lblComp.Text = "Company: " +vFlVerInfo.CompanyName;  
        }

        private void label1_DoubleClick(object sender, EventArgs e)
        {
            // TODO: Add cmdUpdSAPAttr.OnClick implementation
            //TODO - code not in production
            //20170926
            //Enhancement - Encrypment and decrypting string
            using (WCTools.BL.Forms.frmMnPwd vfrmMnPwd = new WCTools.BL.Forms.frmMnPwd())
            {
                if (!(vfrmMnPwd.helpersActivate()))
                {
                    return;
                }
                //20170510 Non GISEditor intimation
                int vEqpId = -1;
                try
                {
                    if ((!vfrmMnPwd.validateOnLoad()))
                    {
                        return;
                    }

                    vfrmMnPwd.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("GPF!  -> " + ex.Message.ToString());

                }
                finally
                {
                    vfrmMnPwd.helpersDeActivate();
                }
            }
            //20170926
        }
    }
}
