﻿define({
    select: "æ_Select_Â",
    results: "æ_Results_Â",
    selectLayer: "æ_Select from layer:_Â",
    selectDrawtool: "æ_Select draw tool:_Â",
    result: "æ_Result:_Â",
    noresult: "æ_No query results to display chart._Â",
    nomedia: "æ_There's no media in configuration!_Â",
    envelop: "æ_Draw Rectangle_Â",
    circle: "æ_Draw Circle_Â",
    ellipse: "æ_Draw Ellipse_Â",
    polygon: "æ_Draw Polygon_Â",
    freehand: "æ_Draw Freehand Polygon_Â",
    clear:"æ_Clear_Â"
});