﻿define(
   ({
    title: "Widget InfoSummary",
    helpText: "ÚKOL: text nápovědy InfoSummary",
    labels: {
      status: "Stav",
      result: "Výsledek"
    },
    _widgetLabel: "Shrnutí informací (Beta)"
  })
);