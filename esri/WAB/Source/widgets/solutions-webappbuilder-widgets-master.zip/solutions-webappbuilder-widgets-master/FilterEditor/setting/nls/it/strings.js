﻿define(
   ({
    enableUndoRedo: "Abilita Annulla/Ripeti",
    toolbarVisible: "Barra degli strumenti visibile",
    toolbarOptions: "Opzioni barra degli strumenti",
    mergeVisible: "Unisci",
    cutVisible: "Taglia",
    reshapeVisible: "Rimodella",
    back: "Indietro",
    label: "Layer",
    edit: "Modificabile",
    update: "Disabilita aggiornamento geometria",
    fields: "Campi",
    actions: "Azioni",
    editpageName: "Nome",
    editpageAlias: "Alias",
    editpageVisible: "Visibile",
    editpageEditable: "Modificabile",
    noLayers: "Non sono disponibili feature layer modificabili",
    configureFields: "Configura campi layer"
  })
);