﻿#
# Script.ps1
#
#// Start of script 
#// Get year and month for csv export file 
Add-PSSnapin Quest.ActiveRoles.ADManagement
Get-QADGroupMember Administrators | Select-Object samAccountName,email,PasswordStatus, Name

$DateTime = Get-Date -f "yyyy-MM" 
 
#// Set CSV file name 
$CSVFile = "C:\Joseph\Source\Official\powershell\listAllGroups\listAdGroups\AD_Groups"+$DateTime+".csv" 
 
#// Create emy array for CSV data 
$CSVOutput = @() 
 
#// Get all AD groups in the domain 
$ADGroups = Get-ADGroup -Filter * 
 
#// Set progress bar variables 
$i=0 
$tot = $ADGroups.count 
 
foreach ($ADGroup in $ADGroups) { 
    #// Set up progress bar 
    $i++ 
    $status = "{0:N0}" -f ($i / $tot * 100) 
    Write-Progress -Activity "Exporting AD Groups" -status "Processing Group $i of $tot : $status% Completed" -PercentComplete ($i / $tot * 100) 
 
    #// Ensure Members variable is empty 
    $Members = "" 
 
    #// Get group members which are also groups and add to string 
    $MembersArr = Get-ADGroup -filter {Name -eq $ADGroup.Name} | Get-ADGroupMember | where {$_.objectClass -eq "group"} | select Name 
    if ($MembersArr) { 
        foreach ($Member in $MembersArr) { 
            $Members = $Members + "," + $Member.Name 
        } 
        $Members = $Members.Substring(1,($Members.Length) -1) 
    } 
 
    #// Set up hash table and add values 
    $HashTab = $NULL 
    $HashTab = [ordered]@{ 
        "Name" = $ADGroup.Name 
        "Category" = $ADGroup.GroupCategory 
        "Scope" = $ADGroup.GroupScope 
        "Members" = $Members 
    } 
 
    #// Add hash table to CSV data array 
    $CSVOutput += New-Object PSObject -Property $HashTab 
} 
 
#// Export to CSV files 
$CSVOutput | Sort-Object Name | Export-Csv $CSVFile -NoTypeInformation 
 
#// End of script