function helpsearch() {
  document.getElementById("box").oninput=function(){
    var matcher = new RegExp(document.getElementById("box").value, "gi");
    for (var i=0;i<document.getElementsByClassName("card").length;i++) {
      if (matcher.test(document.getElementsByClassName("collapsed")[i].innerHTML) ) {
        document.getElementsByClassName("card")[i].style.display="";
      } else {
        document.getElementsByClassName("card")[i].style.display="none";
      }   
    }
  }}
          


