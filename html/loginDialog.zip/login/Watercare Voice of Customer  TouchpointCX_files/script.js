var ie6 = jQuery('html').hasClass('ie6') ? true : false;
var ie7 = jQuery('html').hasClass('ie7') ? true : false;

jQuery(window).load(function () {
    setErrorMsgBox();
    prettyDropdownInit();
    jQuery('.oiDateField').each(function () {
        jQuery(this).setPlaceholder('DD/MM/YYYY');
    });
    jQuery("form").submit(function () {
        jQuery(".placeholder").each(function () {
            jQuery(this).val("");
        });// removing placeholders on form submit so they are not saved as real values
    });

    if (jQuery('.oiFooter')[0] != null) {
        jQuery(window).resize(function () { // fixes footer issue
            jQuery('.oiFooter').hide().show();
        })
    }
});

function prettyDropdownInit() {
    if (ie6 || ie7) { // not supported for ie6 and ie7, fix style so it aligns well
        jQuery('.oiPrettyMe').css({
            'margin-top': '5px',
            'font-size': '15px',
            'line-height': '27px',
            'display': 'block',
            'height': '27px'
        });
    } else {
        var counter = 0; // used for setting IDs
        jQuery('.oiPrettyMe').each(function () { // creates custom dropdown for any dropdowns on the page
            if (jQuery('.oiPrettySelect', this).length <= 0) { // if pretty select is already created do not create another one in case of script double up
                var currentDropdown = jQuery('select', this);
                jQuery(currentDropdown).hide(); //hide real dropdown
                jQuery(currentDropdown).after(function () { //create fake dropdown
                    var options = '';
                    jQuery('option', this).each(function () {
                        options += '<li><a href="#" alt="' + jQuery(this).val() + '">' + jQuery(this).text() + '</a></li>';
                    });
                    return fakeSelect = '<div class="oiPrettySelect" id="oiPrettySelect' + counter + '">' +
                        '<a href="#" class="oiPrettySelectToggle"><span>' + jQuery('option:selected', currentDropdown).text() + '</span></a>' +
                        '<div class="oiPrettySelectSubNav"><ul>' + options + '</ul></div>' +
                        '</div>';
                });
                counter++;
                jQuery('.oiPrettySelectToggle', this).click(function () { // click event for init dropdown click
                    jQuery(this).siblings('.oiPrettySelectSubNav').show();
                    return false;
                });
                jQuery('body').on('mouseup touchend', function (e) { // when clicking outside the select and subnav create a blur like effect
                    var notInsideDropdown = (jQuery(e.target).closest(jQuery('.oiPrettySelectSubNav'), jQuery(currentDropdown).siblings('.oiPrettySelect')).length > 0) ? false : true;
                    if (notInsideDropdown) {
                        jQuery('.oiPrettySelectSubNav', jQuery(currentDropdown).siblings('.oiPrettySelect')).hide();
                    }
                });
                jQuery('.oiPrettySelectSubNav a', this).each(function () { // when links are clicked change hidden dropdown to reflect this
                    jQuery(this).click(function () {
                        jQuery(this).parents('.oiPrettySelectSubNav').hide(); // hide options like in real select
                        jQuery(currentDropdown).val(jQuery(this).attr('alt')); // set new value for original select
                        jQuery('.oiPrettySelectToggle span', jQuery(currentDropdown).siblings('.oiPrettySelect')).text(jQuery('option:selected', currentDropdown).text()); // set new value for fake select
                        jQuery(currentDropdown).trigger('change'); // triggers the onchange event of the original select
                        return false;
                    });
                });
                jQuery(currentDropdown).change(function () { // if real dropdown changes match the fake dropdown
                    jQuery('.oiPrettySelectToggle span', jQuery(this).siblings('.oiPrettySelect')).html(jQuery('option:selected', this).text());
                });
                //resize subnav to match the dropdown
                var widthDifference = jQuery('.oiPrettySelectSubNav', this).outerWidth() - jQuery('.oiPrettySelectToggle', this).outerWidth();

                if ((jQuery('.oiPrettySelectSubNav', this).width() - widthDifference) < 150) { // does not let the dropdown width go below 150px
                    jQuery('.oiPrettySelectSubNav', this).css('min-width', '250px');
                } else {
                    jQuery('.oiPrettySelectSubNav', this).width(jQuery('.oiPrettySelectSubNav', this).width() - widthDifference);
                }
                jQuery('.oiPrettySelectSubNav', this).css({'white-space': 'nowrap', 'width': 'auto'});
            }
        });
    }
}

function navigationInit() {
    if (jQuery('.oiNavigation') != null) {
        //ie6 fix for select boxes going over navigation
        if (ie6) {
            jQuery('<iframe class="oiNavigationIframe bgframe"frameborder="0"tabindex="-1"src="javascript:false;"style="filter:Alpha(Opacity=\'0\');top:auto;left:auto;width:expression(this.parentNode.offsetWidth+\'px\');height:expression(this.parentNode.offsetHeight+\'px\');"/>').insertBefore('.oiSecondLevelNavigation');
        }
        jQuery('.oiNested').children('a').on('mouseenter touchstart', function () {  // when user enters a nested navigation item the subnav must be positioned in the correct place and pull through all the sub nav items
            jQuery('.oiSecondLevelNavigation').removeAttr('style').html(jQuery(this).siblings('ul').html()).css('left', jQuery(this).parent().position().left + 'px').show();
            if (ie6) {
                //jQuery('.oiNavigationIframe').show();
                jQuery('.oiNavigationIframe').removeAttr('style').css({
                    'left': jQuery(this).parent().position().left + 'px',
                    'width': jQuery('.oiSecondLevelNavigation').outerWidth(),
                    'height': jQuery('.oiSecondLevelNavigation').outerHeight()
                });
            }
            if (jQuery(this).parent().attr('id') == 'oiSettings') {
                jQuery('.oiSecondLevelNavigation').removeAttr('style').css('right', '0').show();
                if (ie6) {
                    jQuery('.oiNavigationIframe').removeAttr('style').css({
                        'right': '0',
                        'width': jQuery('.oiSecondLevelNavigation').outerWidth(),
                        'height': jQuery('.oiSecondLevelNavigation').outerHeight()
                    }).show();
                }
            }
            jQuery('.oiOver').toggleClass('oiOver', false);
            jQuery(this).parent('li').toggleClass('oiOver', true);
        });
        jQuery('.oiSecondLevelNavigation, .oiNavigation').mouseleave(hideSubNav);
        jQuery('li').not('.oiNested').mouseenter(hideSubNav);
        jQuery('body').on('touchend', function (e) { // when clicking outside the select and subnav create a blur like effect
            var notInsideDropdown = (jQuery(e.target).closest(jQuery('.oiSecondLevelNavigation, .oiNavigation')).length > 0) ? false : true;
            if (notInsideDropdown) {
                hideSubNav();
            }
        });
    }
}

function showSubNav(e) {
    jQuery('.oiSecondLevelNavigation').html(jQuery(e.currentTarget).siblings('ul').html()).removeAttr('style').css('left', jQuery(e.currentTarget).parent().position().left + 'px').show();
    if (jQuery(e.currentTarget).parent().attr('id') == 'setting') {
        jQuery('.oiSecondLevelNavigation').removeAttr('style').css('right', '0').show();
    }
}

function hideSubNav() {
    jQuery('.oiSecondLevelNavigation').removeAttr('style').hide();
    if (ie6) {
        jQuery('.oiNavigationIframe').removeAttr('style').hide();
    }
    jQuery('.oiOver').toggleClass('oiOver', false);
}

function dataTableInit() {
    if (jQuery('.oiDataTable') != null) {
        jQuery('.oiDataTable tr').hover(function () {
            jQuery(this).toggleClass('oiHover', true);
        }, function () {
            jQuery(this).toggleClass('oiHover', false);
        });
    }
}

function preloaderOverlay(show) {
    if (jQuery('.oiOverlay').length <= 0) {
        jQuery('body').append('<div class="oiOverlay"></div><div class="oiOverlayWrapper"><div class="oiOverlayPreload">Please wait...</div></div>');
        jQuery(window).resize(function () { // move lightbox around when window is resized to fit screen
            jQuery('.oiOverlayWrapper').css('top', (jQuery(window).height()) / 2 + 'px');
        });
    } else {
        jQuery('.oiOverlayWrapper').html('<div class="oiOverlayPreload"><img src="/tpportal/images/loading.png"/></div>');
    }
    jQuery('.oiOverlay').css('filter', 'alpha(opacity=50)');
    show = typeof show !== 'undefined' ? show : true;
    if (show) {
        jQuery('.oiOverlayWrapper, .oiOverlay').show();
    } else {
        jQuery('.oiOverlayWrapper, .oiOverlay').remove();
    }
}

function overlayInit() {
    jQuery('body').append('<div class="oiOverlay"></div><div class="oiOverlayWrapper"><div class="oiOverlayContent"></div></div>');
    jQuery('a[rel]').click(function () {
        jQuery('.oiOverlayContent').html('<iframe src="' + jQuery(this).prop('href') + '" width="620" height="600" frameborder="0" marginheight="0" marginwidth="0"></iframe>'); // load iframe with link href
        jQuery('.oiOverlayContent iframe').load(function () { // change dimensions after iframe has loaded to fit lightbox
            var width = jQuery('iframe').contents().find('.oiMain').width() + 40;
            jQuery('.oiOverlayContent').css({'width': width + 5 + 'px', 'margin-left': '-' + width / 2 + 'px'});
            jQuery('.oiOverlayContent iframe').css({'width': width + 'px'});
            jQuery('.oiOverlayWrapper').css('top', (jQuery(window).height() - jQuery('.oiOverlayContent').height()) / 2 + 'px');
        });
        showLightbox();
        return false;
    });
    jQuery(window).resize(function () { // move lightbox around when window is resized to fit screen
        jQuery('.oiOverlayWrapper').css('top', (jQuery(window).height() - jQuery('.oiOverlayContent').height()) / 2 + 'px');
        ;
    })
}

function showPopup(url, showOverlay) {
    showPopupFixedSize(url, 960, 580, showOverlay);
}

function showPopupFixedSize(url, width, height, showOverlay, showClose) {
    if (height > 580) {
        height = 580;
    }
    if (jQuery('.oiOverlay') == null || jQuery('.oiOverlay').length <= 0) {
        jQuery('body').append('<div class="oiOverlay"></div><div class="oiOverlayWrapper" style="z-index:700;"><div class="oiOverlayContent"></div></div>');
        jQuery(window).resize(function () { // move lightbox around when window is resized to fit screen
            jQuery('.oiOverlayWrapper').css('top', (jQuery(window).height() - jQuery(".oiOverlayContent").height()) / 2 + 'px');
        });
    }
    jQuery('.oiOverlayContent').html('<iframe scrolling="no" src="' + url + '" width="' + width + '" height="' + height + '" frameborder="0" marginheight="0" marginwidth="0"></iframe>'); // load iframe with link href
    if (showClose) { //to show close button
        jQuery('.oiOverlayContent').prepend('<div class="oiOverlayClose">x</div>');
        jQuery('.oiOverlayClose').click(hideLightbox);
    }
    jQuery('.oiOverlayContent').css({
        'width': width + 5 + 'px',
        'margin-left': '-' + width / 2 + 'px',
        'height': height + 5 + 'px'
    });
    if (isMSIEOldBrowser()) {
        jQuery('.oiOverlayContent').css('border', '1px solid #ccc');
    }
    jQuery('.oiOverlayWrapper').css('top', (jQuery(window).height() - jQuery('.oiOverlayContent').height()) / 2 + 'px');

    showLightbox(showOverlay);
}

function showPopupUsingHTMLSource(src, width, height, showOverlay, showClose) {

    if (height > 580) {
        height = 580;
    }
    if (jQuery('.oiOverlay') == null || jQuery('.oiOverlay').length <= 0) {
        jQuery('body').append('<div class="oiOverlay"></div><div class="oiOverlayWrapper"><div class="oiOverlayContent"></div></div>');
        jQuery(window).resize(function () { // move lightbox around when window is resized to fit screen
            jQuery('.oiOverlayWrapper').css('top', (jQuery(window).height() - jQuery(".oiOverlayContent").height()) / 2 + 'px');
        });
    }
    jQuery('.oiOverlayContent').html('<iframe id = "iframepopup" scrolling="no" src="about:blank" width="' + width + '" height="' + height + '" frameborder="0" marginheight="0" marginwidth="0"></iframe>'); // load iframe with link href

    var doc = document.getElementById('iframepopup').contentWindow.document;
    doc.open();
    doc.write(src);
    doc.close();

    if (showClose) { //to show close button
        jQuery('.oiOverlayContent').prepend('<div class="oiOverlayClose">x</div>');
        jQuery('.oiOverlayClose').click(hideLightbox);
    }
    jQuery('.oiOverlayContent').css({
        'width': width + 5 + 'px',
        'margin-left': '-' + width / 2 + 'px',
        'height': height + 5 + 'px'
    });
    if (isMSIEOldBrowser()) {
        jQuery('.oiOverlayContent').css('border', '1px solid #ccc');
    }
    jQuery('.oiOverlayWrapper').css('top', (jQuery(window).height() - jQuery('.oiOverlayContent').height()) / 2 + 'px');

    showLightbox(showOverlay);
}

function resizePopupFrame(width, height) {
    jQuery('.oiMain').css('width', width - 40 + 'px');
    jQuery('.oiMain').css('height', height - 30 + 'px');
}

function showLightbox(showOverlay) {
    if (jQuery('html').hasClass('ie6')) { // IE hack to fix the position:fixed problem by moving the lightbox and overlay on scroll
        //jQuery('.oiOverlay').css('top',document.body.parentNode.scrollTop);
        var width = jQuery(window).width();
        var height = jQuery(window).height();
        var pageHeight = document.body.clientHeight;
        if (pageHeight > height) {
            height = pageHeight;
        }
        jQuery(".oiOverlay").css({width: width, height: height});	// resize overlay to screen size
        jQuery(window).resize(function () { // resize overlay on window resize
            var width = jQuery(window).width();
            var height = jQuery(window).height();
            var pageHeight = document.body.clientHeight;
            if (pageHeight > height) {
                height = pageHeight;
            }
            jQuery(".oiOverlay").css({width: width, height: height});
        })
    }
    if (showOverlay != false) {
        jQuery('.oiOverlay').css('filter', 'alpha(opacity=50)');
        jQuery('.oiOverlayWrapper, .oiOverlay').fadeIn('slow');
    } else {
        jQuery('.oiOverlayWrapper').fadeIn('slow');
    }
}
function hideLightbox() {
    jQuery('.oiOverlayWrapper, .oiOverlay').fadeOut('slow');
    if (jQuery('html').hasClass('ie6')) {
        jQuery(window).unbind('scroll'); // remove scroll event
    }
}

function createErrorMsgBox(msg) {
    if (jQuery('.errorMessageBG')[0] == null) {
        jQuery('body').prepend('<div class="errorMessageBG"><a href="#" id="closeError">x</a>' +
            '<ol><li id="errorMessage">' + msg + '<br>' +
            '</li></ol></div>');
    } else {
        jQuery('.errorMessageBG ol').html('<li id="errorMessage">' + msg + '<br/></li>');
        jQuery('.errorMessageBG').show().delay(11000).css('opacity', '1');
    }
    window.scrollTo(0, 0);
    setErrorMsgBox();
}

function setErrorMsgBox() {
    if (jQuery('.errorMessageBG')[0] != null) {
        jQuery('#closeError').click(function () {
            defaultFadeout.stop(); //stops current animation of fadeout
            jQuery('.errorMessageBG').fadeOut('fast', function () {
                jQuery(this).hide();
            });
        });
        var defaultFadeout = jQuery('.errorMessageBG').delay(10000).fadeOut('slow', function () {
            jQuery(this).hide();
        });
    }
}

function isSupported(tag) {
    var input = document.createElement("input");
    return (tag in input);
}

jQuery.fn.setPlaceholder = function (placeholder) {
    var supported = isSupported('placeholder');
    if (supported == true) { // if placeholder html5 tag is supported then use it
        jQuery(this).prop("placeholder", placeholder);
    } else { // otherwise use javascript to create placeholders intead
        if (jQuery(this).val() == "") {
            jQuery(this).val(placeholder).toggleClass("placeholder", true);
        } else if (jQuery(this).val() == placeholder) {
            jQuery(this).toggleClass("placeholder", true);
        }
        jQuery(this).focus(function () {
            jQuery(this).toggleClass("placeholder", false);
            if (jQuery(this).val() == placeholder) {
                jQuery(this).val("");
            }
        }).blur(function () {
            if (jQuery(this).val() == '') {
                jQuery(this).val(placeholder).toggleClass("placeholder", true);
            }
        });
    }
}

function replaceString(haystack, find, substitute) {
    return haystack.split(find).join(substitute);
}

function stripQuotes(value) {
    var result = replaceString(value, '\"', '');
    result = replaceString(result, '\'', '');
    return result;
}

function trim(stringToTrim) {
    return stringToTrim.replace(/^\s+|\s+$/g, "");
}

var JSON = JSON || {};
//implement JSON.stringify serialization
JSON.stringify = JSON.stringify || function (obj) {
        var t = typeof (obj);
        if (t != "object" || obj === null) {
            // simple data type
            if (t == "string")
                obj = '"' + obj + '"';
            return String(obj);
        } else {
            // recurse array or object
            var n, v, json = [], arr = (obj && obj.constructor == Array);
            for (n in obj) {
                v = obj[n];
                t = typeof (v);
                if (t == "string")
                    v = '"' + v + '"';
                else if (t == "object" && v !== null)
                    v = JSON.stringify(v);
                json.push((arr ? "" : '"' + n + '":') + String(v));
            }
            return (arr ? "[" : "{") + String(json) + (arr ? "]" : "}");
        }
    };

//case management script
function toggleOutcome() {
    var status = document.getElementById("status").value;
    if (status == 'C') {
        document.getElementById("outcome").disabled = false;
    } else {
        if (status == 'U') {
            assignTo_removeContent();
        }
        document.getElementById("outcome").disabled = true;
    }
}

function setHiddenDueDateValue() {
    if (jQuery('#dueDate') != null) {
        var due = jQuery('#dueDate').val();
        jQuery('#dueDateHidden').val(due);
    }
}

function submitSaveAndClose() {
    setHiddenDueDateValue();
    document.getElementById("saveCase").click();
}

function submitSaveOnly() {
    setHiddenDueDateValue();
    document.getElementById("saveAndRefresh").click();
}

function submitClose() {
    document.getElementById("closeCase").click();
}

function setCaseManagementPanel() {
    jQuery('select#priority').after('<div class="oiFormItemInput"><div class="oiReadonly">' + jQuery('select#priority option:selected').text() + '</div></div>').hide();
    jQuery('select#status').after('<div class="oiFormItemInput"><div class="oiReadonly">' + jQuery('select#status option:selected').text() + '</div></div>').hide();
    jQuery('select#outcome').after('<div class="oiFormItemInput"><div class="oiReadonly">' + jQuery('select#outcome option:selected').text() + '</div></div>').hide();
    jQuery('select#assignTo').css('border', 'none').prop('readonly', 'readonly');
    jQuery('select#reviewedBy').css('border', 'none').prop('readonly', 'readonly');
    jQuery('select#followUp').after('<div class="oiFormItemInput"><div class="oiReadonly">' + jQuery('select#followUp option:selected').text() + '</div></div>').hide();
    jQuery('#noteArea').prop('readonly', 'readonly');
}

/*function feedbackSummaryResults(id, data){
 console.log(data);
 var wrapper = jQuery('#' + id),
 content = '';
 if (data.summary instanceof Array) {
 for (var i = 0; i < data.summary.length; i++) {
 content += feedbackSummaryResult(data.summary[i]);
 }
 } else {
 content = feedbackSummaryResult(data.summary);
 }
 wrapper.html(content);
 }

 function feedbackSummaryResult(summary){
 var content = '';
 if(summary.type == 'score'){
 content += '<div class="oiResultRowScore">' +
 '<label class="oiLabel">' + summary.label + '</label>' +
 '<div class="oiScoreScaleWrapper">';
 content += '<ul class="oiScoreScale">';
 for (var ii = 0; ii < summary.range.length; ii++) {
 var selectClass = '';
 if(summary.value != null){
 if(ii == summary.value){
 var selectClass = 'category' + summary.category;
 }
 }
 content += '<li class="oiScoreNode ' + selectClass + '">' + summary.range[ii] + '</li>';
 }
 content += '</ul>';
 if(summary.na){
 content += '<div class="oiNaNode ';
 if( typeof summary.value === 'undefined'){
 content += 'oiNaSelected';
 }
 content += '">n/a</div><!-- /oiNaNode -->';
 }
 content += '</div>';
 content += '</div>';
 }
 if(summary.type == 'comment'){
 content += '<div class="oiResultRowComment">';
 content += '<label class="oiLabel">' + summary.label + '</label>';
 content += '<p>' + summary.value + '</p>';
 content += '</div>';
 }

 return content;
 };*/
var feedbackSummaryResults = {
        buildRelatedIssues: function () {
            var self = this,
                issuesContents = '<div class="oiRelatedIssues"><label class="oiLabel">Related Issues</label>';
            var hasrelatedissues = false;
            for (var i = 0; i < self.data.relatedissues.length; i++) {
                if (i % 10 == 0) {
                    issuesContents += "<br>";
                }
                issuesContents += '<a href="#" class="oiIssueLink" data-id="' + self.data.relatedissues[i].id + '">#' + self.data.relatedissues[i].code + '</a> &ndash; ' + self.data.relatedissues[i].value + ', ';
                hasrelatedissues = true;
            }
            if (hasrelatedissues) {
                issuesContents = issuesContents.slice(0, -2)
            }

            issuesContents += '</div>';
            self.relatedIssuesClickEvent();
            return issuesContents;
        },
        buildSummaryScore: function (summaryItem) {
            var scoreContents = '';
            scoreContents += '<div class="oiResultRowScore">' +
                '<label class="oiLabel">' + summaryItem.label + '</label>' +
                '<div class="oiScoreScaleWrapper">';
            scoreContents += '<ul class="oiScoreScale">';
            for (var i = 0; i < summaryItem.range.length; i++) {
                var selectClass = '';
                if (summaryItem.value != null) {
                    if (i == summaryItem.value) {
                        var selectClass = 'category' + summaryItem.category;
                    }
                }
                scoreContents += '<li class="oiScoreNode ' + selectClass + '">' + summaryItem.range[i] + '</li>';
            }
            scoreContents += '</ul>';
            scoreContents += '</div>' +
                '</div>';
            return scoreContents;
        },
        buildSummaryComment: function (summaryItem) {
            var commentContents = '';

            commentContents += '<div class="oiResultRowComment">' +
                '<label class="oiLabel">' + summaryItem.label + '</label>';

            if (summaryItem.actions != null && summaryItem.actions != undefined) {
                for (var i = 0; i < summaryItem.actions.length; i++) {
                    if (summaryItem.actions[i].type == 'raise') {
                        commentContents += '<div class="oiActionLink oiIssueLink2">' +
                            '<a href="#" class="oiRaiseIssueLink" data-id="' + summaryItem.actions[i].feedbackverbatimid + '">Raise Issue</a></div>';
                    } else if (summaryItem.actions[i].type == 'report') {
                        commentContents += '<div class="oiActionLink oiIssueLink2">' +
                            '<a href="' + summaryItem.actions[i].url + '" target="_blank" >Report Issue</a></div>';
                    }
                }
            }

            if (summaryItem.relatedissues != null && summaryItem.relatedissues != undefined) {
                var relatedIssues = '';
                for (var i = 0; i < summaryItem.relatedissues.length; i++) {
                    var url = '/tp/portal/issue/view-from-verbatim.html?parentsource=verbatim&id=' + summaryItem.relatedissues[i].id;
                    relatedIssues += '<a href="' + url + '" class="oiIssueLink" data-id="' + summaryItem.relatedissues[i].id + '" title="' + summaryItem.relatedissues[i].value + '">';
                    relatedIssues += '#' + summaryItem.relatedissues[i].code;
                    relatedIssues += '</a>';
                    if ((i + 1) < summaryItem.relatedissues.length) {
                        relatedIssues += ', ';
                    }
                }

                commentContents += '<div class="oiActionLink oiIssueLink1"><i>Related Issue(s)</i> ' + relatedIssues + '</div>';
            }

            commentContents += '<p>' + summaryItem.value + '</p>';

            commentContents += '</div>';

            return commentContents;
        },
        buildSummary: function () {
            var self = this;
            summaryContents = '';
            for (var i = 0; i < self.data.summary.length; i++) {
                if (self.data.summary[i].type == 'score' && self.data.summary[i].value != undefined) {
                    summaryContents += self.buildSummaryScore(self.data.summary[i]);
                } else if (self.data.summary[i].type == 'comment') {
                    summaryContents += self.buildSummaryComment(self.data.summary[i]);
                    self.raiseIssuesClickEvent();
                }
            }
            return summaryContents;
        },
        buildTabContents: function (displayrelatedissuesonly) {
            var self = this,
                tabContents = '';
            if (displayrelatedissuesonly == 'true') {
                if (self.data.relatedissues && self.data.relatedissues.length > 0) {
                    tabContents += self.buildRelatedIssues();
                }
            } else {
                tabContents += self.buildSummary();
            }
            self.CONFIG.summaryContainerSelector.html(tabContents);
        },
        raiseIssuesClickEvent: function () {
            this.CONFIG.summaryContainerSelector.on('click', '.oiRaiseIssueLink', function (e) {
                e.preventDefault();
                showPopupFixedSize('/tp/portal/verbatim/comment-issue-example.html?feedbackverbatimid=' + jQuery(this).data('id'), 700, 450, false);
            });
        },
        relatedIssuesClickEvent: function () {
            this.CONFIG.summaryContainerSelector.on('click', '.oiIssueLink', function (e) {
                e.preventDefault();
                showPopupFixedSize('/tp/portal/issue/view-from-verbatim.html?parentsource=verbatim&id=' + jQuery(this).data('id'), 960, 580, false);
            });
        },
        init: function (data, CONFIG, displayrelatedissuesonly) {
            this.data = data;
            this.CONFIG = CONFIG;
            this.buildTabContents(displayrelatedissuesonly);
        }
    },
    examplesTab = {
        ajaxCall: function (apiUrl) {
            return jQuery.ajax({
                type: "GET",
                url: apiUrl,
                cache: false
            }).promise();
        },
        buildFiltersSelect: function () {
            var self = this,
                optionsList = [];
            for (var i = 0; i < self.data.filters['respondent-types'].length; i++) {
                optionsList.push(jQuery('<option/>', {
                    'value': self.data.filters['respondent-types'][i].value,
                    'text': self.data.filters['respondent-types'][i].label,
                    'selected': self.data.filters['respondent-types'][i].selected
                }));
            }
            self.CONFIG.selectSelector.html(optionsList);
        },
        buildCommentList: function () {
            var self = this,
                comments = '';
            if (self.data.comments.length > 0) {
                for (var i = 0; i < self.data.comments.length; i++) {
                    comments += '<tr >' +
                        '<td>';
                    if (self.data.comments[i].score.value == undefined) {
                        comments += '<div class="oiVerbatimScore" title="">&ndash;</div>';
                    } else {
                        comments += '<div class="oiVerbatimScore color' + self.data.comments[i].score.category + '" title="' + self.data.comments[i].score.description + '">' + self.data.comments[i].score.value + '</div>';
                    }
                    comments += '<div style="white-space: normal; overflow: visible;">' +
                        '<div class="oiComments">' +
                        '<div class="oiTimeStamp">' + self.data.comments[i].age + '</div>' +
                        '<div class="oiQuestion">' + self.data.comments[i].question + '</div>' +
                        '<blockquote>' + self.data.comments[i].comment + '</blockquote>' +
                        '<a class="oiView" href="/tp/portal/verbatim/main?id=' + self.data.comments[i]['feedback-collection-id'] + '&feedbackresponseid=' + self.data.comments[i]['feedback-response-id'] + '&verbatimid=' + self.data.comments[i]['feedback-verbatim-id'] + '" target="_blank">View details</a>';
                    if (self.CONFIG.canRemove) {
                        comments += '<span class="oiRemoveWrapper"><a class="oiRemove" href="#">Remove</a><span class="oiRemoveConfirmationWrapper">?<span class="oiConfirmRemove" data-feedbackverbatimid="' + self.data.comments[i]['feedback-verbatim-id'] + '">Confirm</span><span class="oiCancelRemove">Cancel</span></span></span>';
                    }

                    comments += '</div>' +
                        '</div>' +
                        '</td>' +
                        '</tr>';
                }
            } else {
                comments += "<p>No results found</p>";
            }
            self.CONFIG.exampleContainerSelector.html(comments);
        },
        buildPagination: function () {
            jQuery('#commentsTotal').text(this.data.page['comments-total']);
            if (this.data.page['comments-total'] == 1) {
                jQuery('#commentsMeasurement').text('item');
            } else {
                jQuery('#commentsMeasurement').text('items');
            }
            if (this.data.page.total > 1) {
                jQuery('#current').text(this.data.page.current);
                jQuery('#total').text(this.data.page.total);
                jQuery('#firstPage, #prevPage, #lastPage, #nextPage')
                    .removeClass('disabled')
                    .addClass('enabled');
                if (this.data.page.current == 1) {
                    jQuery('#firstPage, #prevPage')
                        .addClass('disabled')
                        .removeClass('enabled');
                }
                if (this.data.page.current == this.data.page.total) {
                    jQuery('#lastPage, #nextPage')
                        .addClass('disabled')
                        .removeClass('enabled');
                }
                this.CONFIG.paginationTableSelector.show();
            } else {
                this.CONFIG.paginationTableSelector.hide();
            }
        },
        loadExamples: function (respondentTypeID, pageIndex) {
            var self = this,
                url = '/tp/portal/issue/examples/view.html';
            if (self.CONFIG.issueID > 0) {
                url += '?issueID=' + self.CONFIG.issueID;
            } else if (self.CONFIG.feedbackVerbatimID > 0) {
                url += '?feedbackVerbatimID=' + self.CONFIG.feedbackVerbatimID;
            }

            if (respondentTypeID !== null) {
                url += '&respondentTypeID=' + respondentTypeID;
            }
            if (respondentTypeID !== null) {
                url += '&pageIndex=' + pageIndex;
            }
            self.ajaxCall(url)
                .done(function (data) {
                    //console.log(data);
                    self.data = data;
                    self.buildFiltersSelect();
                    self.buildCommentList();
                    self.buildPagination();
                }).fail(function (errorThrown) {
                    //console.log(errorThrown);
                });
        },
        filterChangeEvent: function () {
            var self = this;
            self.CONFIG.selectSelector.on('change', function () {
                self.loadExamples(jQuery(this).val(), null);
            });
        },
        pageChangeEvent: function () {
            var self = this;
            self.CONFIG.examplesPaginationSelector.on('click', '.btn', function () {
                if (!jQuery(this).hasClass('disabled')) {
                    var id = jQuery(this).attr('id'),
                        selectedFilterNum = self.CONFIG.selectSelector.val(),
                        gotoPage;
                    if (id == 'firstPage') {
                        gotoPage = 1;
                    } else if (id == 'prevPage') {
                        gotoPage = self.data.page.current - 1;
                    } else if (id == 'nextPage') {
                        gotoPage = self.data.page.current + 1;
                    } else if (id == 'lastPage') {
                        gotoPage = self.data.page.total;
                    }
                    self.loadExamples(selectedFilterNum, gotoPage);
                }
            });
        },
        removeCommentEvent: function () {
            var self = this,
                confirmationWrapperHover = false;
            self.CONFIG.exampleContainerSelector.on('mouseenter', '.oiRemove, .oiRemoveConfirmationWrapper', function (e) {
                confirmationWrapperHover = true;
            });
            self.CONFIG.exampleContainerSelector.on('mouseleave', '.oiRemove, .oiRemoveConfirmationWrapper', function (e) {
                confirmationWrapperHover = false;
            });
            self.CONFIG.exampleContainerSelector.on('click', '.oiRemove', function (e) {
                e.preventDefault();
                self.CONFIG.exampleContainerSelector.find('.oiRemoveConfirmationWrapper').hide();
                self.CONFIG.exampleContainerSelector.find('.oiRemove').removeClass('oiOpen');
                jQuery(this).next('.oiRemoveConfirmationWrapper').show();
                jQuery(this).addClass('oiOpen');
            });
            self.CONFIG.exampleContainerSelector.on('click', '.oiConfirmRemove', function (e) {
                self.removeComment(jQuery(this).data('feedbackverbatimid'));
            });
            self.CONFIG.exampleContainerSelector.on('click', '.oiCancelRemove', function (e) {
                self.CONFIG.exampleContainerSelector.find('.oiRemoveConfirmationWrapper').hide();
                self.CONFIG.exampleContainerSelector.find('.oiRemove').removeClass('oiOpen');
            });
            jQuery('body').on('click', function () {
                if (!confirmationWrapperHover) {
                    self.CONFIG.exampleContainerSelector.find('.oiRemoveConfirmationWrapper').hide();
                    self.CONFIG.exampleContainerSelector.find('.oiRemove').removeClass('oiOpen');
                }
            });

        },
        removeComment: function (feedbackVerbatimId) {
            var self = this;
            self.ajaxCall('/tp/portal/issue/examples/remove.html?issueID=' + self.CONFIG.issueID + '&verbatimID=' + feedbackVerbatimId)
                .done(function (data) {
                    //console.log(data);
                    self.loadExamples(self.CONFIG.selectSelector.val(), self.data.page.current);
                }).fail(function (errorThrown) {
                    //console.log(errorThrown);
                });
        },
        init: function (CONFIG) {
            this.CONFIG = CONFIG;
            this.loadExamples();
            this.filterChangeEvent();
            this.pageChangeEvent();
            this.removeCommentEvent();
        }
    };


(function ($) {
    $.dateRangePicker = function () {
        ////////////////////////////////////
        // References
        ////////////////////////////////////
        var dateRangeMeta = {};
        var domReferences = {};
        var tempValues = {};
        var setDateRangeMeta = function (newDateRangeMeta) {
            dateRangeMeta = newDateRangeMeta;
        };
        var saveTempValues = function(){
            tempValues.periodAttribute = domReferences.selectors.periodAttributesSelect.val();
        };
        var revertToTempValues = function(){
            domReferences.selectors.periodAttributesSelect.val(tempValues.periodAttribute).trigger('change');
        };
        var getClasses = function () {
            return {
                startDateComponent: 'oiDpDatePickerStart',
                endDateComponent: 'oiDpDatePickerEnd',
                dropDownLabel: 'oiDpPeriodNavigationLabel',
                dropDownContainer: 'oiDpPeriodNavigation',
                dropDownContentsContainer: 'oiDpPeriodNavigationDropDown',
                dropDownContentsColumn1: 'oiDpClm1',
                dropDownContentsColumn2: 'oiDpClm2',
                dropDownContentsColumn3: 'oiDpClm3',
                presetsList: 'oiDpPresets',
                applyButton: 'oiDpApplyButton',
                dropDownLabelOpen: 'oiDpSelectedItemOpen',
                selectedState: 'oiDpSelected',
                dropDownSizeSmall: 'oiDpSizeSmall',
                dropDownSizeRegular: 'oiDpSizeRegular',
                periodAttributesSelect: 'oiPeriodAttributesList',
                periodAttributesSelectLabel: 'oiPeriodAttributesListLabel'
            };
        };
        var prefixSelectors = function (widgetWrapper, classes) {
            for (var key in classes) {
                if (classes.hasOwnProperty(key)) {
                    classes[key] = $(widgetWrapper).find('.' + classes[key]);
                }
            }
            return classes;
        };
        var setDomReferences = function (widgetWrapper, input) {
            domReferences = {
                classes: getClasses(),
                selectors: prefixSelectors(widgetWrapper, getClasses()),
                widgetId: $(widgetWrapper)
            };
            if(input !== undefined){
                domReferences.inputId =  $(input);
            }
        };
        var convertDateStringsToObjects = function () {
            dateRangeMeta.startDate = new Date(dateRangeMeta.startDate);
            dateRangeMeta.endDate = new Date(dateRangeMeta.endDate);
        };
        ////////////////////////////////////
        // HTML Builders
        ////////////////////////////////////
        var buildWidgetWrapper = function (input) {
            var inputID = $(input).attr('id');
            var widgetWrapperId = inputID + 'WidgetWrapper';
            $(input)
                //.css({'margin-left': '-200px', 'margin-top': '400px', 'width': '400px'})
                .hide()
                .wrap($('<div/>', {
                    id: widgetWrapperId
                }));
            return $('#' + widgetWrapperId);
        };
        var buildTemplate = function (alignment, dropDownSize) {
            var alignmentClass = 'oiDpRight';
            if (alignment == 'left') {
                alignmentClass = 'oiDpLeft';
            }
            var htmlTemplate = '<div class="' + domReferences.classes.dropDownContentsContainer + ' ' + alignmentClass + '">';
            htmlTemplate += '<label class="' + domReferences.classes.periodAttributesSelectLabel + '">Period';
            htmlTemplate += '<select class="' + domReferences.classes.periodAttributesSelect + '">';
            htmlTemplate += '</select>';
            htmlTemplate += '</label>';
            htmlTemplate += '<div class="' + domReferences.classes.dropDownContentsColumn1 + '">';
            htmlTemplate += '<h3>From</h3>';
            htmlTemplate += '<div class="' + domReferences.classes.startDateComponent + '" ></div>';
            htmlTemplate += '</div>';
            htmlTemplate += '<div class="' + domReferences.classes.dropDownContentsColumn2 + '">';
            htmlTemplate += '<h3>To</h3>';
            htmlTemplate += '<div class="' + domReferences.classes.endDateComponent + '" ></div>';
            htmlTemplate += '</div>';
            htmlTemplate += '<div class="' + domReferences.classes.dropDownContentsColumn3 + '">';
            htmlTemplate += '<h3>Preset</h3>';
            htmlTemplate += '<ul class="' + domReferences.classes.presetsList + '">';
            htmlTemplate += '</ul>';
            htmlTemplate += '</div>';
            htmlTemplate += '<div class="' + domReferences.classes.applyButton + '">Apply</div>';
            htmlTemplate += '</div>';
            htmlTemplate += '<div class="' + domReferences.classes.dropDownLabel + '"><span>&nbsp;</span></div>';
            var classString = domReferences.classes.dropDownContainer;
            if (dropDownSize == 'small') {
                classString += ' ' + domReferences.classes.dropDownSizeSmall;
            } else {
                classString += ' ' + domReferences.classes.dropDownSizeRegular;
            }
            domReferences.widgetId
                .addClass(classString)
                .append(htmlTemplate);
        };
        var getPresets = function(){
            for (var i = 0; i < dateRangeMeta.periodAttributes.length; i++) {
                if (dateRangeMeta.periodAttributes[i].isSelected) {
                    return dateRangeMeta.periodAttributes[i].presets;
                }
            }
            return null;
        };
        var buildPresetList = function () {
            var presets= getPresets();
            domReferences.selectors.presetsList.html('');
            for (var i = 0; i < presets.length; i++) {
                domReferences.selectors.presetsList.append($('<li/>', {
                    'data-index': i,
                    'text': presets[i].label
                }));
            }
            setPresetListSelectedClass();
        };
        var setPresetListSelectedClass = function () {
            var presets= getPresets();
            // Remove selected calls from all presets
            domReferences.selectors.dropDownContentsContainer.find('li').removeClass(domReferences.classes.selectedState);
            // Add class selected class to correct list item

            for (var i = 0; i < presets.length; i++) {
                if (presets[i].isSelected) {
                    domReferences.selectors.dropDownContentsContainer.find('li[data-index=' + i + ']').addClass(domReferences.classes.selectedState);
                }
            }
        };
        var buildPeriodAttributeList = function () {
            domReferences.selectors.periodAttributesSelect.html('');
            if(dateRangeMeta.periodAttributes.length <= 1){
                domReferences.selectors.periodAttributesSelectLabel.hide();
            } else {
                domReferences.selectors.periodAttributesSelectLabel.show();
            }
            for (var i = 0; i < dateRangeMeta.periodAttributes.length; i++) {
                domReferences.selectors.periodAttributesSelect.append($('<option/>', {
                    'value': dateRangeMeta.periodAttributes[i].value,
                    'text': dateRangeMeta.periodAttributes[i].label
                }));
            }
            setPresetPeriodAttributeList();
        };
        var setPresetPeriodAttributeList = function () {
            // Add class selected class to correct list item
            for (var i = 0; i < dateRangeMeta.periodAttributes.length; i++) {
                if (dateRangeMeta.periodAttributes[i].isSelected) {
                    domReferences.selectors.periodAttributesSelect.val(dateRangeMeta.periodAttributes[i].value);
                }
            }
        };
        var initDatePickers = function () {
            domReferences.selectors.startDateComponent
                .datepicker({
                    dateFormat: 'dd/mm/yy',
                    maxDate: '0d',
                    changeMonth: true,
                    changeYear: true,
                    numberOfMonths: 1
                });
            domReferences.selectors.endDateComponent
                .datepicker({
                    dateFormat: 'dd/mm/yy',
                    maxDate: '0d',
                    changeMonth: true,
                    changeYear: true,
                    numberOfMonths: 1
                });
            setPickerDates(dateRangeMeta.startDate, dateRangeMeta.endDate);
        };
        var setPickerDates = function (startDate, endDate) {
            domReferences.selectors.startDateComponent
                .datepicker('option', 'maxDate', endDate)
                .datepicker('setDate', startDate);
            domReferences.selectors.endDateComponent
                .datepicker('option', 'minDate', startDate)
                .datepicker('setDate', endDate);
        };
        var setDefaultLabel = function () {
            if (!dateRangeMeta.isCustomDateRange) {
                setPresetLabel();
                return;
            }
            setCustomLabel(dateRangeMeta.startDate, dateRangeMeta.endDate);
        };
        var getParameterByName = function (name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return results[2].replace(/\+/g, " ");
        };
        var buildRedirectUrl = function (startDateUnix, endDateUnix, periodAttribute) {
            var currentUrl = window.location.href;
            var dateParam = getParameterByName(tempValues.periodAttribute, currentUrl);
            var dates = startDateUnix + '%3A' + endDateUnix;
            var newUrl = currentUrl.replace(tempValues.periodAttribute, periodAttribute);
            return newUrl.replace(dateParam, dates);
        };
        var redirectToDateRange = function () {
            if (!dateRangeMeta.isCustomDateRange) {
                var presets= getPresets();
                for (var i = 0; i < presets.length; i++) {
                    if (presets[i].isSelected) {
                        window.location.replace(buildRedirectUrl(presets[i].startDate, presets[i].endDate, domReferences.selectors.periodAttributesSelect.val()));
                        return;
                    }
                }
                return;
            }
            window.location.replace(buildRedirectUrl($.datepicker.formatDate('@', dateRangeMeta.startDate), parseInt($.datepicker.formatDate('@', dateRangeMeta.endDate)) + 86399000, domReferences.selectors.periodAttributesSelect.val()));//86400 * 1000 - 1000  set end date to end of day
        };
        var setNewInputValue = function () {
            var presets = getPresets();
            if (!dateRangeMeta.isCustomDateRange) {
                for (var i = 0; i < presets.length; i++) {
                    if (presets[i].isSelected) {
                        setInputValue(presets[i].startDate, presets[i].endDate, domReferences.selectors.periodAttributesSelect.val());
                        return;
                    }
                }
                return;
            }
            setInputValue($.datepicker.formatDate('@', dateRangeMeta.startDate), parseInt($.datepicker.formatDate('@', dateRangeMeta.endDate)) + 86399000, domReferences.selectors.periodAttributesSelect.val());//86400 * 1000 - 1000  set end date to end of day
        };
        var setInputValue = function (startDateUnix, endDateUnix, periodAttribute) {
            domReferences.inputId
                .val(buildInputString(startDateUnix, endDateUnix, periodAttribute))
                .trigger('change');
        };
        var setCustomLabel = function (startDate, endDate) {
            var formatedStartDate = $.datepicker.formatDate('dd M yy', startDate),
                formatedEndDate = $.datepicker.formatDate('dd M yy', endDate);
            domReferences.selectors.dropDownLabel.find('span')
                .html(formatedStartDate + ' - ' + formatedEndDate);
            domReferences.selectors.startDateComponent
                .datepicker('option', 'maxDate', endDate);
            domReferences.selectors.endDateComponent
                .datepicker('option', 'minDate', startDate);
            domReferences.selectors.dropDownContentsContainer.find('li').removeClass(domReferences.classes.selectedState);
        };
        var setPresetLabel = function () {
            var presets= getPresets();
            for (var i = 0; i < presets.length; i++) {
                if (presets[i].isSelected) {
                    domReferences.selectors.dropDownLabel.find('span')
                        .html(presets[i].label);
                    return;
                }
            }
        };
        var buildInputString = function (startDateUnix, endDateUnix, periodAttribute) {
            return startDateUnix + ':' + endDateUnix + ':' + periodAttribute ;
        };
        var applyPeriodAttribute = function(){
            for (var i = 0; i < dateRangeMeta.periodAttributes.length; i++) {
                dateRangeMeta.periodAttributes[i].isSelected = (dateRangeMeta.periodAttributes[i].value == domReferences.selectors.periodAttributesSelect.val());
            }
        };
        var applyCustomRange = function (type) {
            // set dateRangeMeta
            var presets= getPresets();
            dateRangeMeta.isCustomDateRange = true;
            for (var i = 0; i < presets.length; i++) {
                presets[i].isSelected = false;
            }
            dateRangeMeta.startDate = domReferences.selectors.startDateComponent.datepicker('getDate');
            dateRangeMeta.endDate = domReferences.selectors.endDateComponent.datepicker('getDate');
            if(type == 'ajax'){
                setNewInputValue();
            } else if(type == 'refresh'){
                redirectToDateRange();
            }
            close();
        };
        var applyPresetRange = function (type, row) {
            // set dateRangeMeta
            var presets= getPresets();
            dateRangeMeta.isCustomDateRange = false;
            for (var i = 0; i < presets.length; i++) {
                presets[i].isSelected = (i == row.data('index'));
            }
            dateRangeMeta.startDate = (presets[row.data('index')].startDate + 1000);
            dateRangeMeta.endDate = (presets[row.data('index')].endDate);
            console.log(new Date(dateRangeMeta.startDate) + ' - ' + new Date(dateRangeMeta.endDate));
            convertDateStringsToObjects();
            setPickerDates(dateRangeMeta.startDate, dateRangeMeta.endDate);
            setPresetListSelectedClass();
            if(type == 'ajax') {
                setNewInputValue();
            } else if(type == 'refresh'){
                redirectToDateRange();
            }
            setDefaultLabel();
            close();
        };
        var toggleDropDownLabel = function () {
            domReferences.selectors.dropDownLabel.toggleClass(domReferences.classes.dropDownLabelOpen);
        };
        var open = function () {
            domReferences.selectors.dropDownContentsContainer.show();
            toggleDropDownLabel();
            setPresetPeriodAttributeList();
        };
        var close = function () {
            domReferences.selectors.dropDownContentsContainer.hide();
            toggleDropDownLabel();
        };
        var closeClear = function () {
            domReferences.selectors.dropDownContentsContainer.hide();
            revertToTempValues();
            setDefaultLabel();
            setPickerDates(dateRangeMeta.startDate, dateRangeMeta.endDate);
            toggleDropDownLabel();
        };
        var addEvents = function (type) {
            // Open Close
            domReferences.selectors.dropDownLabel
                .on('mousedown touchenter', function () {
                    if (domReferences.selectors.dropDownLabel.hasClass(domReferences.classes.dropDownLabelOpen)) {
                        closeClear();
                    } else {
                        open();
                        saveTempValues();
                    }
                });
            //on Apply Button
            domReferences.selectors.applyButton
                .on('mousedown touchenter', function () {
                    applyCustomRange(type);
                });
            //on selected Preset
            domReferences.selectors.presetsList
                .on('mousedown touchenter', 'li', function () {
                    applyPresetRange(type, $(this));
                });
            //on PeriodAttribute change
            domReferences.selectors.periodAttributesSelect
                .on('change', function () {
                    setCustomLabel(domReferences.selectors.startDateComponent.datepicker('getDate'), domReferences.selectors.endDateComponent.datepicker('getDate'));
                    applyPeriodAttribute();
                    buildPresetList();
                });
            //on calendar date change
            domReferences.selectors.startDateComponent.add(domReferences.selectors.endDateComponent)
                .on('change', function () {
                    setCustomLabel(domReferences.selectors.startDateComponent.datepicker('getDate'), domReferences.selectors.endDateComponent.datepicker('getDate'));
                });
            // Add click outside dropdown to close
            $(document).on('mouseup', function (e) {
                if (domReferences.selectors.dropDownLabel.hasClass(domReferences.classes.dropDownLabelOpen)) {
                    if (!domReferences.widgetId.is(e.target) && domReferences.widgetId.has(e.target).length === 0) {
                        closeClear();
                    }
                }
            });
        };
        return {
            INIT: function (self, settings) {
                setDateRangeMeta(settings.dateRangeMeta);
                convertDateStringsToObjects();
                // getDomReferences for classes
                if(settings.type == 'ajax') {
                    var widgetWrapper = buildWidgetWrapper(self);
                    setDomReferences(widgetWrapper, self);
                    buildTemplate(settings.alignment, settings.dropDownSize);
                    // refresh getDomReferences to capture rebuilt DOM
                    setDomReferences(widgetWrapper, self);
                    buildPeriodAttributeList();
                    setNewInputValue();
                    //setInputValue($.datepicker.formatDate('@', dateRangeMeta.startDate), parseInt($.datepicker.formatDate('@', dateRangeMeta.endDate)));
                } else if (settings.type == 'refresh'){
                    setDomReferences(self);
                    buildTemplate(settings.alignment, settings.dropDownSize);
                    // refresh getDomReferences to capture rebuilt DOM
                    setDomReferences(self);
                    buildPeriodAttributeList();
                }
                setDefaultLabel();
                initDatePickers();
                buildPresetList();
                addEvents(settings.type);
            }
        };
    };
    $.fn.dateRangePicker = function (options) {
        return this.each(function () {
            var settings = $.extend({
                type: 'ajax',
                dateRangeMeta: undefined,
                alignment: 'left',
                dropDownSize: 'regular'
            }, options);
            var datePicker = new $.dateRangePicker();
            datePicker.INIT(this, settings);
        });
    };

    $.measureSelector = function () {
        ////////////////////////////////////
        // References
        ////////////////////////////////////
        var meta = {};
        var domReferences = {
            classes: {
                functionLabel: 'oiDpFunctionLabel',
                attributeLabel: 'oiDpAttributeLabel',
                attributesList: 'oiDpattributes',
                column1: 'oiDpClm1',
                column2: 'oiDpClm2',
                column2Heading: 'oiDpClm2Heading',
                column2List: 'oiDpFunctions',
                column3: 'oiDpClm3',
                column3Heading: 'oiDpClm3Heading',
                column3List: 'oiDpOptions',
                functionListItem: 'oiDpFunctionListItem',
                optionListItem: 'oiDpOptionListItem',
                dropDownWrapper: 'oiDpMeasureWrapper',
                dropDownContainer: 'oiDropDownContainer',
                dropDownContentsContainer: 'oiDpPeriodNavigationDropDown',
                dropDownLabel: 'oiDpLabel',
                checkboxLabel: 'oiDpCheckboxLabel',
                dropDownSizeSmall: 'oiDpSizeSmall',
                dropDownSizeRegular: 'oiDpSizeRegular',
                showAllCheckbox: 'oiDpShowAll',
                selectedState: 'oiDpSelected',
                openState: 'oiDpOpen',
                applyBtn: 'oiDpRightApplyBtn',
                leftAlign: 'oiDpLeft',
                rightAlign: 'oiDpRight'

            }
        };
        var tempValues = {
            showAll: false
        };
        var setMeta = function (newMeta) {
            meta = newMeta;
        };
        var prefixSelectors = function (widgetWrapper, classes) {
            for (var key in classes) {
                if (classes.hasOwnProperty(key)) {
                    classes[key] = $(widgetWrapper).find('.' + classes[key]);
                }
            }
            return classes;
        };
        var saveSelectors = function () {
            domReferences.selectors = prefixSelectors(domReferences.widgetWrapper, $.extend({}, domReferences.classes));
        };
        ////////////////////////////////////
        // HTML Builders
        ////////////////////////////////////
        var buildWidgetWrapper = function (input, alignment, dropDownSize) {
            domReferences.input = $(input);
            var inputID = domReferences.input.attr('id');
            var widgetWrapperId = inputID + 'WidgetWrapper';
            var alignmentClass = domReferences.classes.rightAlign;
            if (alignment == 'left') {
                alignmentClass = domReferences.classes.leftAlign;
            }
            var wrapperClasses = ' ' + domReferences.classes.dropDownSizeRegular;
            if (dropDownSize == 'small') {
                wrapperClasses = ' ' + domReferences.classes.dropDownSizeSmall;
            }
            domReferences.input
                //.css({'margin-left': '-200px', 'width': '300px'})
                .hide()
                .wrap($('<div/>', {
                    'class': domReferences.classes.dropDownWrapper + ' ' + alignmentClass + ' ' + wrapperClasses,
                    id: widgetWrapperId
                }));
            domReferences.widgetWrapper = $('#' + widgetWrapperId);
        };
        var buildTemplate = function (alignment, dropDownSize) {
            var alignmentClass = domReferences.classes.rightAlign;
            if (alignment == 'left') {
                alignmentClass = domReferences.classes.leftAlign;
            }
            var wrapperClasses = ' ' + domReferences.classes.dropDownSizeRegular;
            if (dropDownSize == 'small') {
                wrapperClasses = ' ' + domReferences.classes.dropDownSizeSmall;
            }
            var html = '   <div class="' + domReferences.classes.dropDownContainer + ' ' + alignmentClass + ' ' + wrapperClasses + '">';
            html += '       <div class="' + domReferences.classes.dropDownLabel + '">';
            html += '           <div class="oiDpLabelSummary">';
            html += '               <span class="' + domReferences.classes.functionLabel + '"></span>';
            html += '               (<span class="' + domReferences.classes.attributeLabel + '"></span>)';
            html += '           </div>';
            html += '           <span class="oiDpArrow"></span>';
            html += '       </div>';
            html += '       <div class="' + domReferences.classes.dropDownContentsContainer + '">';
            html += '           <div class="' + domReferences.classes.column1 + '">';
            html += '               <div class="oiDplist">';
            html += '                   <h4>Attribute</h4>';
            html += '                   <ul class="' + domReferences.classes.attributesList + '">';
            html += '                   </ul>';
            html += '               </div>';
            html += '               <div class="oiDpcheckbox-wrapper">';
            html += '                   <label for="' + domReferences.classes.showAllCheckbox + '" class="oiDpcheckbox-label">';
            html += '                       <input type="checkbox" id="' + domReferences.classes.showAllCheckbox + '" class="' + domReferences.classes.showAllCheckbox + '">';
            html += '                       <span>Show All</span>';
            html += '                   </label>';
            html += '               </div>';
            html += '           </div>';
            html += '           <div class="' + domReferences.classes.column2 + '">';
            html += '               <div class="oiDplist">';
            html += '                   <h4 class="' + domReferences.classes.column2Heading + '"></h4>';
            html += '                   <ul class="' + domReferences.classes.column2List + '">';
            html += '                   </ul>';
            html += '               </div>';
            html += '           </div>';
            html += '           <div class="' + domReferences.classes.column3 + '">';
            html += '               <div class="oiDplist">';
            html += '                   <h4 class="' + domReferences.classes.column3Heading + '"></h4>';
            html += '                   <ul class="' + domReferences.classes.column3List + '">';
            html += '                   </ul>';
            html += '               </div>';
            html += '           </div>';
            html += '       </div>';
            html += '       <div class="oiDpbutton-wrapper">';
            html += '           <div class="' + domReferences.classes.applyBtn + '">Apply</div>';
            html += '       </div>';
            html += '   </div>';
            domReferences.widgetWrapper
                .append(html);
        };

        var setValues = function () {
            setTempValues();
            setLabel();
            setShowAllCheckbox();
            buildAttributesList();
            buildFunctionColumn();
            buildOptionColumn();
            showHideApplyBtn();
        };
        var getCurrentAttribute = function () {
            var currentAttribute;
            for (var i = 0; i < meta.length; i++) {
                if (meta[i].attributeID == tempValues.attributeID) {
                    currentAttribute = meta[i];
                }
            }
            return currentAttribute;
        };
        var getCurrentFunction = function () {
            var currentAttribute = getCurrentAttribute();
            var currentFunction;
            if (currentAttribute !== undefined) {
                for (var i = 0; i < currentAttribute.supportedFunctions.length; i++) {
                    if (currentAttribute.supportedFunctions[i].value == tempValues.supportedFunction) {
                        currentFunction = currentAttribute.supportedFunctions[i];
                    }
                }
            }
            return currentFunction;
        };
        var saveTempValues = function () {
            var inputString = tempValues.attributeID;
            inputString += ':' + tempValues.supportedFunction;
            if (tempValues.attributeOptions.length > 0) {
                inputString += ':';
                for (var i = 0; i < tempValues.attributeOptions.length; i++) {
                    if(i===0){
                        inputString += tempValues.attributeOptions[i];
                    } else {
                        inputString += '#' + tempValues.attributeOptions[i];
                    }
                }
            }
            domReferences.input
                .val(inputString)
                .trigger('change');
        };
        var setTempValues = function () {
            var inputValueSplit = domReferences.input.val().split(':');
            tempValues.attributeID = undefined;
            tempValues.supportedFunction = undefined;
            tempValues.attributeOptions = [];
            for (var i = 0; i < inputValueSplit.length; i++) {
                if (i === 0) {
                    tempValues.attributeID = inputValueSplit[i];
                } else if (i == 1) {
                    tempValues.supportedFunction = inputValueSplit[i];
                } else if (i == 2) {
                    var attributeOptions = inputValueSplit[i];
                    tempValues.attributeOptions = attributeOptions.split('#');
                }
            }
            var currentAttribute = getCurrentAttribute();
            if (!currentAttribute.primaryMeasureAttribute) {
                tempValues.showAll = true;
            }
        };
        var setLabel = function () {
            var currentAttribute = getCurrentAttribute();
            var currentFunction = getCurrentFunction();
            if (currentAttribute === undefined) {
                domReferences.selectors.attributeLabel.text('');
            } else {
                domReferences.selectors.attributeLabel.text(currentAttribute.label);
            }
            if (currentFunction === undefined) {
                domReferences.selectors.functionLabel.text('');
            } else {
                domReferences.selectors.functionLabel.text(currentFunction.label);
            }
        };
        var setShowAllCheckbox = function () {
            domReferences.selectors.showAllCheckbox.prop('checked', tempValues.showAll);
        };
        var buildAttributesList = function () {
            domReferences.selectors.attributesList.html('');
            var isAttributeSet = false;
            for (var i = 0; i < meta.length; i++) {
                if (tempValues.showAll || meta[i].primaryMeasureAttribute) {
                    if (meta[i].attributeID == tempValues.attributeID) {
                        domReferences.selectors.attributesList.append($('<li/>', {
                            'data-attribute-id': meta[i].attributeID,
                            'text': meta[i].label,
                            'class': domReferences.classes.selectedState
                        }));
                        isAttributeSet = true;
                    } else {
                        domReferences.selectors.attributesList.append($('<li/>', {
                            'data-attribute-id': meta[i].attributeID,
                            'text': meta[i].label
                        }));
                    }
                }
            }
            if (!isAttributeSet) {
                selectAttribute(domReferences.selectors.attributesList.find('li').first());
            }
        };
        var buildFunctionColumn = function () {
            domReferences.selectors.column2List.html('');
            var currentAttribute = getCurrentAttribute();
            buildSupportedFunctionList(currentAttribute);
        };
        var buildOptionColumn = function () {
            domReferences.selectors.column3List.html('');
            if (tempValues.supportedFunction === undefined) {
                showThirdColumn(false);
                return false;
            } else {
                var currentFunction = getCurrentFunction();
                if (currentFunction.attributeOptions.length > 0 && !currentFunction.attributeOptionsMandatory) {
                    buildAttributeOptionsList(currentFunction);
                    return true;
                } else {
                    showThirdColumn(false);
                    return false;
                }
            }
        };
        var setFunctionColumnLabel = function (label) {
            domReferences.selectors.column2Heading.html(label);
        };
        var setOptionColumnLabel = function (label) {
            domReferences.selectors.column3Heading.html(label);
        };
        var showThirdColumn = function (show) {
            if (show) {
                domReferences.widgetWrapper.addClass('oiDp3clms');
                domReferences.selectors.column1.addClass('oiDp33');
                domReferences.selectors.column2.addClass('oiDp33');
                domReferences.selectors.column3.show();
            } else {
                domReferences.widgetWrapper.removeClass('oiDp3clms');
                domReferences.selectors.column1.removeClass('oiDp33');
                domReferences.selectors.column2.removeClass('oiDp33');
                domReferences.selectors.column3.hide();
            }
        };
        var buildAttributeOptionsList = function (supportedFunction) {
            setOptionColumnLabel(supportedFunction.label);
            showThirdColumn(true);
            var classesString = '';
            for (var i = 0; i < supportedFunction.attributeOptions.length; i++) {
                classesString = domReferences.classes.optionListItem;
                if ($.inArray(supportedFunction.attributeOptions[i].value, tempValues.attributeOptions) != -1) {
                    classesString += ' ' + domReferences.classes.selectedState;
                }
                domReferences.selectors.column3List.append($('<li/>', {
                    'data-value': supportedFunction.attributeOptions[i].value,
                    'class': classesString,
                    'html': $('<label/>', {
                        'class': domReferences.classes.checkboxLabel,
                        'html': $('<input/>', {
                            'type': 'checkbox',
                            'checked': ($.inArray(supportedFunction.attributeOptions[i].value, tempValues.attributeOptions) != -1)
                        }).add($('<span/>', {
                            'html': supportedFunction.attributeOptions[i].label
                        }))
                    })
                }));
            }
        };
        var buildSupportedFunctionList = function (attribute) {
            setFunctionColumnLabel('Functions');
            var classesString = '';
            for (var i = 0; i < attribute.supportedFunctions.length; i++) {
                classesString = domReferences.classes.functionListItem;
                if (attribute.supportedFunctions[i].value == tempValues.supportedFunction) {
                    classesString += ' ' + domReferences.classes.selectedState;
                }
                domReferences.selectors.column2List.append($('<li/>', {
                    'data-value': attribute.supportedFunctions[i].value,
                    'html': attribute.supportedFunctions[i].label,
                    'class': classesString
                }));
            }
        };
        var showHideApplyBtn = function () {
            var currentFunction = getCurrentFunction();
            if (currentFunction !== undefined && !currentFunction.attributeOptionsMandatory &&
                currentFunction.attributeOptions.length > 0 &&
                tempValues.attributeOptions.length > 0
            ) {
                domReferences.selectors.applyBtn.show();
                return true;
            } else {
                domReferences.selectors.applyBtn.hide();
                return false;
            }
        };
        var open = function () {
            domReferences.selectors.dropDownContainer.addClass(domReferences.classes.openState);
        };
        var close = function () {
            domReferences.selectors.dropDownContainer.removeClass(domReferences.classes.openState);
        };
        var closeCancel = function () {
            setValues();
            close();
        };
        var closeSave = function () {
            saveTempValues();
            close();
        };
        var selectAttribute = function (self) {
            tempValues.attributeID = self.data('attribute-id');
            tempValues.attributeOptions = [];
            tempValues.supportedFunction = undefined;
            domReferences.selectors.attributesList.find('li').removeClass(domReferences.classes.selectedState);
            self.addClass(domReferences.classes.selectedState);
            buildFunctionColumn();
            buildOptionColumn();
            showHideApplyBtn();
            setLabel();
        };
        var selectFunction = function (self) {
            domReferences.selectors.column2List.find('li').removeClass(domReferences.classes.selectedState);
            self.addClass(domReferences.classes.selectedState);
            tempValues.supportedFunction = self.data('value');
            tempValues.attributeOptions = [];
            var currentFunction = getCurrentFunction();
            buildOptionColumn();
            showHideApplyBtn();
            setLabel();
            if (currentFunction.attributeOptions.length === 0 ||
                currentFunction.attributeOptionsMandatory) {//If is a preset or has no options
                if (currentFunction.attributeOptionsMandatory) {// if a preset add options to temp
                    for (var i = 0; i < currentFunction.attributeOptions.length; i++) {
                        tempValues.attributeOptions.push(currentFunction.attributeOptions[i].value);
                    }
                }
                closeSave();
            }
        };
        var selectSubset = function (self) {
            var listItem = self.parents('li');
            var attributeOption = listItem.data('value');
            if (self.prop('checked')) {
                tempValues.attributeOptions.push(attributeOption);
                listItem.addClass(domReferences.classes.selectedState);
            } else {
                var i = tempValues.attributeOptions.indexOf(attributeOption);
                listItem.removeClass(domReferences.classes.selectedState);
                if (i != -1) {
                    tempValues.attributeOptions.splice(i, 1);
                }
            }
            showHideApplyBtn();
        };
        var events = function () {
            // On Open/close
            domReferences.selectors.dropDownLabel
                .on('mousedown touchenter', function () {
                    if (domReferences.selectors.dropDownContainer.hasClass(domReferences.classes.openState)) {
                        closeCancel();
                    } else {
                        open();
                    }
                });

            // Click outside dropdown
            $(document).on('mouseup', function (e) {
                if (domReferences.selectors.dropDownContainer.hasClass(domReferences.classes.openState)) {
                    if (!domReferences.widgetWrapper.is(e.target) && domReferences.widgetWrapper.has(e.target).length === 0) {
                        closeCancel();
                    }
                }
            });

            // On apply
            domReferences.selectors.applyBtn.on('click', function () {
                closeSave();
            });

            // Show all checkbox onChange
            domReferences.selectors.showAllCheckbox.on('change', function () {
                tempValues.showAll = domReferences.selectors.showAllCheckbox.prop('checked');
                buildAttributesList();
            });

            // On select attribute
            domReferences.selectors.attributesList.on('click', 'li', function () {
                selectAttribute($(this));
            });

            // On select function
            domReferences.selectors.column2List.on('click', '.' + domReferences.classes.functionListItem, function () {
                selectFunction($(this));
            });

            // On select subset
            domReferences.selectors.column3List.on('change', 'input:checkbox', function () {
                selectSubset($(this));
            });

        };
        return {
            INIT: function (self, settings) {
                setMeta(settings.meta);
                buildWidgetWrapper(self, settings.alignment, settings.dropDownSize);
                buildTemplate(settings.alignment, settings.dropDownSize);
                saveSelectors();
                setValues();
                events();
            }
        };
    };
    $.fn.measureSelector = function (options) {
        return this.each(function () {
            var settings = $.extend({
                meta: undefined,
                alignment: 'left',
                dropDownSize: 'regular'
            }, options);
            var measureSelector = new $.measureSelector();
            measureSelector.INIT(this, settings);
        });
    };
})(jQuery);





























