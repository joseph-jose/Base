﻿define({
    left: "STÂNGA",
    right: "DREAPTA",
    arrangement: "Aranjament",
    autoUpdate: "Actualizare automată",
    respectCurrentMapScale: "Respectare scară actuală a hărţii"
});