﻿namespace WCTools.BL.Forms
{
    partial class frmFacDescSel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnCls = new System.Windows.Forms.Button();
            this.btnSel = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dtGrdLstAttr = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSrch = new System.Windows.Forms.TextBox();
            this.cmbFacDesc = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdLstAttr)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 417);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(590, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnCls);
            this.panel3.Controls.Add(this.btnSel);
            this.panel3.Location = new System.Drawing.Point(2, 349);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(587, 62);
            this.panel3.TabIndex = 7;
            // 
            // btnCls
            // 
            this.btnCls.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCls.Location = new System.Drawing.Point(500, 22);
            this.btnCls.Name = "btnCls";
            this.btnCls.Size = new System.Drawing.Size(75, 23);
            this.btnCls.TabIndex = 1;
            this.btnCls.Text = "Close";
            this.btnCls.UseVisualStyleBackColor = true;
            this.btnCls.Click += new System.EventHandler(this.btnCls_Click);
            // 
            // btnSel
            // 
            this.btnSel.Location = new System.Drawing.Point(404, 22);
            this.btnSel.Name = "btnSel";
            this.btnSel.Size = new System.Drawing.Size(75, 23);
            this.btnSel.TabIndex = 0;
            this.btnSel.Text = "Select";
            this.btnSel.UseVisualStyleBackColor = true;
            this.btnSel.Click += new System.EventHandler(this.btnSel_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dtGrdLstAttr);
            this.panel2.Location = new System.Drawing.Point(2, 81);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(587, 262);
            this.panel2.TabIndex = 6;
            // 
            // dtGrdLstAttr
            // 
            this.dtGrdLstAttr.AllowUserToAddRows = false;
            this.dtGrdLstAttr.AllowUserToDeleteRows = false;
            this.dtGrdLstAttr.AllowUserToResizeRows = false;
            this.dtGrdLstAttr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdLstAttr.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtGrdLstAttr.Location = new System.Drawing.Point(7, 3);
            this.dtGrdLstAttr.MultiSelect = false;
            this.dtGrdLstAttr.Name = "dtGrdLstAttr";
            this.dtGrdLstAttr.ReadOnly = true;
            this.dtGrdLstAttr.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGrdLstAttr.ShowEditingIcon = false;
            this.dtGrdLstAttr.Size = new System.Drawing.Size(572, 249);
            this.dtGrdLstAttr.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtSrch);
            this.panel1.Controls.Add(this.cmbFacDesc);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(2, 7);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(587, 68);
            this.panel1.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(485, 35);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(64, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Search :";
            // 
            // txtSrch
            // 
            this.txtSrch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSrch.Location = new System.Drawing.Point(222, 38);
            this.txtSrch.Name = "txtSrch";
            this.txtSrch.Size = new System.Drawing.Size(187, 20);
            this.txtSrch.TabIndex = 2;
            // 
            // cmbFacDesc
            // 
            this.cmbFacDesc.FormattingEnabled = true;
            this.cmbFacDesc.Items.AddRange(new object[] {
            "FAC_CODE",
            "FAC_DESC"});
            this.cmbFacDesc.Location = new System.Drawing.Point(95, 38);
            this.cmbFacDesc.Name = "cmbFacDesc";
            this.cmbFacDesc.Size = new System.Drawing.Size(121, 21);
            this.cmbFacDesc.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(415, 35);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Filter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmFacDescSel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCls;
            this.ClientSize = new System.Drawing.Size(590, 439);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.MaximizeBox = false;
            this.Name = "frmFacDescSel";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Select Facility Description";
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdLstAttr)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnCls;
        private System.Windows.Forms.Button btnSel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dtGrdLstAttr;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSrch;
        private System.Windows.Forms.ComboBox cmbFacDesc;
        private System.Windows.Forms.Button button2;
    }
}