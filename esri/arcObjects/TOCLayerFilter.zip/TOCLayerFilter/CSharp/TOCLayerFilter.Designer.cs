// Copyright 2010 ESRI
// 
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
// 
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
// 
// See the use restrictions at http://help.arcgis.com/en/sdk/10.0/usageRestrictions.htm
// 

namespace TOCLayerFilterCS
{
    partial class TOCLayerFilter
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tvwLayer = new System.Windows.Forms.TreeView();
            this.contextMenuDummy = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cboLayerType = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // tvwLayer
            // 
            this.tvwLayer.ContextMenuStrip = this.contextMenuDummy;
            this.tvwLayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvwLayer.Location = new System.Drawing.Point(0, 21);
            this.tvwLayer.Name = "tvwLayer";
            this.tvwLayer.Size = new System.Drawing.Size(224, 209);
            this.tvwLayer.TabIndex = 0;
            this.tvwLayer.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvwLayer_NodeMouseClick);
            // 
            // contextMenuDummy
            // 
            this.contextMenuDummy.Name = "contextMenuDummy";
            this.contextMenuDummy.Size = new System.Drawing.Size(61, 4);
            // 
            // cboLayerType
            // 
            this.cboLayerType.ContextMenuStrip = this.contextMenuDummy;
            this.cboLayerType.Dock = System.Windows.Forms.DockStyle.Top;
            this.cboLayerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLayerType.FormattingEnabled = true;
            this.cboLayerType.Items.AddRange(new object[] {
            "All Layer Type",
            "Feature Layers",
            "Raster Layers",
            "Data Layers"});
            this.cboLayerType.Location = new System.Drawing.Point(0, 0);
            this.cboLayerType.Name = "cboLayerType";
            this.cboLayerType.Size = new System.Drawing.Size(224, 21);
            this.cboLayerType.TabIndex = 1;
            this.cboLayerType.SelectedIndexChanged += new System.EventHandler(this.cboLayerType_SelectedIndexChanged);
            // 
            // TOCLayerFilter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tvwLayer);
            this.Controls.Add(this.cboLayerType);
            this.Name = "TOCLayerFilter";
            this.Size = new System.Drawing.Size(224, 230);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tvwLayer;
        private System.Windows.Forms.ComboBox cboLayerType;
        private System.Windows.Forms.ContextMenuStrip contextMenuDummy;
    }
}
