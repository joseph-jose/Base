﻿define(
   ({
    enableUndoRedo: "Włącz opcje Cofnij/Ponów",
    toolbarVisible: "Widoczny pasek narzędziowy",
    toolbarOptions: "Opcje paska narzędziowego",
    mergeVisible: "Połącz",
    cutVisible: "Wytnij",
    reshapeVisible: "Przekształć",
    back: "Wstecz",
    label: "Warstwa",
    edit: "Edytowalne",
    update: "Wyłącz aktualizację geometrii",
    fields: "Pola",
    actions: "Operacje",
    editpageName: "Nazwa",
    editpageAlias: "Alias",
    editpageVisible: "Widoczne",
    editpageEditable: "Edytowalne",
    noLayers: "Brak warstw obiektu możliwych do edycji",
    configureFields: "Skonfiguruj pola warstwy"
  })
);