﻿define({
    select: "选择",
    results: "结果",
    selectLayer: "从图层选择：",
    selectDrawtool: "选择绘制工具：",
    result: "结果：",
    noresult: "没有可以显示的结果。",
    nomedia: "没有配置任何图表！",
    envelop: "绘制矩形",
    circle: "绘制圆形",
    ellipse: "绘制椭圆",
    polygon: "绘制多边形",
    freehand: "手绘多边形",
    clear:"清空"
  });