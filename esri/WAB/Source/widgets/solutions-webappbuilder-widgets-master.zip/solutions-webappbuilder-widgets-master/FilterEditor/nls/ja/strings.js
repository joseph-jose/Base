﻿define(
   ({
    _widgetLabel: "編集",
    title: "作成するフィーチャのテンプレートを選択",
    pressStr: "押す ",
    ctrlStr: " Ctrl ",
    snapStr: " スナップを有効にします"
  })
);