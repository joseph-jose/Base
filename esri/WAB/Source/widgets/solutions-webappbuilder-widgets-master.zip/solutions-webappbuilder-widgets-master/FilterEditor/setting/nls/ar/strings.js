﻿define(
   ({
    enableUndoRedo: "تمكين التراجع/الإعادة",
    toolbarVisible: "شريط الأدوات المرئي",
    toolbarOptions: "خيارات شريط الأدوات",
    mergeVisible: "دمج",
    cutVisible: "قص",
    reshapeVisible: "إعادة تشكيل",
    back: "السابق",
    label: "طبقة",
    edit: "يمكن تحريره",
    update: "تعطيل تحديث هندسة الشكل",
    fields: "حقول",
    actions: "الأفعال",
    editpageName: "الاسم",
    editpageAlias: "اسم مستعار",
    editpageVisible: "مرئي",
    editpageEditable: "يمكن تحريره",
    noLayers: "لا تتوفر أي طبقات معالم يمكن تحريرها",
    configureFields: "تكوين حقول الطبقات"
  })
);