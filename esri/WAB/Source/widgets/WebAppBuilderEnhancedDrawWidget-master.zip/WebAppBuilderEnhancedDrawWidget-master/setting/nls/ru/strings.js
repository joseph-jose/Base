﻿define(
   ({
    addDistance: "Добавить единицы длины",
    addArea: "Добавить единицы площади",
    label: "Надпись",
    abbr: "Аббревиатура",
    conversion: "Конвертация",
    actions: "Действия",
    areaUnits: "Единицы площади",
    distanceUnits: "Единицы длины",
    kilometers: "Километры",
    miles: "Мили",
    meters: "Метры",
    feet: "Футы",
    yards: "Ярды",
    squareKilometers: "Квадратные километры",
    squareMiles: "Квадратные мили",
    acres: "Акры",
    hectares: "гектары",
    squareMeters: "Квадратные метры",
    squareFeet: "Квадратные футы",
    squareYards: "Квадратные ярды",
    distance: "Расстояния",
    area: "Площади"
  })
);