﻿namespace WCToolsNA.BL.Forms
{
    partial class frmCopyAttr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnUpdAttr = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtDest = new System.Windows.Forms.TextBox();
            this.txtSrc = new System.Windows.Forms.TextBox();
            this.dtGrdCompKeys = new System.Windows.Forms.DataGridView();
            this.colDFld = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDestVal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDiv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSrcField = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSrcVal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDataType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeys)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnUpdAttr);
            this.panel3.Controls.Add(this.btnClose);
            this.panel3.Location = new System.Drawing.Point(0, 410);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(618, 50);
            this.panel3.TabIndex = 9;
            // 
            // btnUpdAttr
            // 
            this.btnUpdAttr.Location = new System.Drawing.Point(389, 13);
            this.btnUpdAttr.Name = "btnUpdAttr";
            this.btnUpdAttr.Size = new System.Drawing.Size(75, 23);
            this.btnUpdAttr.TabIndex = 1;
            this.btnUpdAttr.Text = "Update";
            this.btnUpdAttr.UseVisualStyleBackColor = true;
            this.btnUpdAttr.Click += new System.EventHandler(this.btnUpdAttr_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(489, 13);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 463);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(619, 22);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(618, 50);
            this.panel1.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txtDest);
            this.panel2.Controls.Add(this.txtSrc);
            this.panel2.Controls.Add(this.dtGrdCompKeys);
            this.panel2.Location = new System.Drawing.Point(0, 56);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(618, 348);
            this.panel2.TabIndex = 11;
            // 
            // txtDest
            // 
            this.txtDest.Location = new System.Drawing.Point(109, 42);
            this.txtDest.Name = "txtDest";
            this.txtDest.Size = new System.Drawing.Size(100, 20);
            this.txtDest.TabIndex = 30;
            // 
            // txtSrc
            // 
            this.txtSrc.Location = new System.Drawing.Point(438, 42);
            this.txtSrc.Name = "txtSrc";
            this.txtSrc.Size = new System.Drawing.Size(100, 20);
            this.txtSrc.TabIndex = 29;
            // 
            // dtGrdCompKeys
            // 
            this.dtGrdCompKeys.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdCompKeys.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDFld,
            this.colDestVal,
            this.colDiv,
            this.cSrcField,
            this.colSrcVal,
            this.colDataType,
            this.colType});
            this.dtGrdCompKeys.Location = new System.Drawing.Point(3, 82);
            this.dtGrdCompKeys.Name = "dtGrdCompKeys";
            this.dtGrdCompKeys.Size = new System.Drawing.Size(610, 203);
            this.dtGrdCompKeys.TabIndex = 27;
            // 
            // colDFld
            // 
            this.colDFld.HeaderText = "Destination Field";
            this.colDFld.Name = "colDFld";
            this.colDFld.Width = 125;
            // 
            // colDestVal
            // 
            this.colDestVal.HeaderText = "Destination Value";
            this.colDestVal.Name = "colDestVal";
            this.colDestVal.Width = 125;
            // 
            // colDiv
            // 
            this.colDiv.HeaderText = "..";
            this.colDiv.Name = "colDiv";
            this.colDiv.Width = 25;
            // 
            // cSrcField
            // 
            this.cSrcField.HeaderText = "Source Field";
            this.cSrcField.Name = "cSrcField";
            this.cSrcField.Width = 125;
            // 
            // colSrcVal
            // 
            this.colSrcVal.HeaderText = "Source Value";
            this.colSrcVal.Name = "colSrcVal";
            this.colSrcVal.Width = 125;
            // 
            // colDataType
            // 
            this.colDataType.HeaderText = "DataType";
            this.colDataType.Name = "colDataType";
            this.colDataType.Visible = false;
            // 
            // colType
            // 
            this.colType.HeaderText = "Type";
            this.colType.Name = "colType";
            this.colType.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "Destination";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(373, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "Source";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(256, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "<---------";
            // 
            // frmCopyAttr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 485);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmCopyAttr";
            this.Text = "Copy Attributes";
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdCompKeys)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnUpdAttr;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtDest;
        private System.Windows.Forms.TextBox txtSrc;
        private System.Windows.Forms.DataGridView dtGrdCompKeys;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDFld;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDestVal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDiv;
        private System.Windows.Forms.DataGridViewTextBoxColumn cSrcField;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSrcVal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDataType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}