﻿define({
    left: "VLEVO",
    right: "VPRAVO",
    arrangement: "Uspořádání",
    autoUpdate: "Automatická aktualizace",
    respectCurrentMapScale: "Zohlednit současné měřítko mapy"
});