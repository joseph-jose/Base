﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string vSrvrName = "";
        //dynamic server switch
        vSrvrName = Request.ServerVariables["SERVER_NAME"].ToString();
        if (vSrvrName.Trim() == "localhost")
            vSrvrName = "wsldctdgweb";
        if (vSrvrName.Trim() == "giswebtest")
            vSrvrName = "wsldcttgweb";
        if (vSrvrName.Trim() == "wsldcttgweb")
            vSrvrName = "wsldcttgweb";
        if (vSrvrName.Trim() == "gisweb")
            vSrvrName = "wsldctpgweb";
        if (vSrvrName.Trim() == "wsldctpgweb")
            vSrvrName = "wsldctpgweb";		
        if (vSrvrName.Trim() == "wsldctdgweb")
            vSrvrName = "wsldctdgweb";
        if (vSrvrName.Trim() == "giswebdev")
            vSrvrName = "wsldctdgweb";
        txtSrvr.Text = vSrvrName;

        if (vSrvrName == "wsldctdgweb")
        {
            hlnkSrvrname.Text = "-(dev)";
        }
        else if (vSrvrName == "giswebdev")
        {
            hlnkSrvrname.Text = "-(dev)";
        }
        else if (vSrvrName == "wsldcttgweb")
        {
            hlnkSrvrname.Text = "-(test)";
        }
        else if (vSrvrName == "wsldctpgweb")
        {
            hlnkSrvrname.Text = "";
        }

        string vPgType = Request.QueryString["Type"];
        if (!(vPgType==null))
        {
            txtType.Text = vPgType; 
        }

    }


}