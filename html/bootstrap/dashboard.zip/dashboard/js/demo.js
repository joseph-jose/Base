// due to the nature of iframes. All iframes will need to be preloaded. This javascript hides the inactive elements when user clicks on the pills menu.

//console.log("steve is here");
//$('.demo').hide();


$('.buttondemo').click(function(){
	//console.log("steve is here -2");
		$('.demo').show();
	// 	$('#v-pills-AGOL').hide();
	// 	$('#v-pills-TEST').hide();
	// 	$('#v-pills-DEV').show();
	});

$('.buttondemo2').click(function(){
	//console.log("steve is here -2");
		$('.demo').hide();
	// 	$('#v-pills-AGOL').hide();
	// 	$('#v-pills-TEST').hide();
	// 	$('#v-pills-DEV').show();
	});

