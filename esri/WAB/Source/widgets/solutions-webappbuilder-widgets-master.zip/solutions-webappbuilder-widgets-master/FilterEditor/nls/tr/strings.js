﻿define(
   ({
    _widgetLabel: "Düzenle",
    title: "Detay oluşturmak için şablon seç",
    pressStr: "Bas ",
    ctrlStr: " CTRL ",
    snapStr: " yakalamayı etkinleştirmek için"
  })
);