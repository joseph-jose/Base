﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace WCToolsBulk.BL.Classes
{
    public class Attribute
    {
        public string ObjectId { get; set; }

        public string dataType { get; set; }
        public string type { get; set; }
        public string fieldName { get; set; }        
    }

    public class clsXmlMap
    {
        public string vStrSource { get; set; }
        public string vStrDBCondition { get; set; }
        public string vStrDestination { get; set; }
        public string vStrDestEqFld { get; set; }

        public IList<Attribute> vXmlCnfs { get; set; }

        public string getDbSqlStmt()
        {
            string vSqlStmt = "";
            foreach (Attribute vSess in vXmlCnfs)
            {
                if (!(vSqlStmt == ""))
                {
                    vSqlStmt = vSqlStmt + ", ";
                }
                vSqlStmt = vSqlStmt + vSess.fieldName;
            }

            vSqlStmt = string.Format("Select {0} from {1} where {2}", vSqlStmt, vStrSource, vStrDBCondition); 

            return vSqlStmt;
        }

        public bool getAllFields1(string inFilePath)
        {
            bool retRes = false;
            StreamReader vSRdr = new StreamReader(inFilePath);

            var vXmlMap = XDocument.Load((vSRdr));

            XElement vElem = vXmlMap.Root.Elements("Session").FirstOrDefault();
            var vFlds =
                from a in vElem.Elements()
                select new Attribute
                {
                    dataType = a.Attributes("dataType").FirstOrDefault().Value.ToString(),
                    type = a.Attributes("type").FirstOrDefault().Value.ToString(),
                    fieldName = a.Attributes("fieldName").FirstOrDefault().Value.ToString()
                };
            vXmlCnfs = vFlds.ToList();
            retRes = true;
            return retRes;
        }


        public bool getDsMappings(string inFilePath)
        {
            bool retRes = false;
            StreamReader vSRds = new StreamReader(inFilePath);
            var vXmlMap = XDocument.Load(vSRds );

            XElement vElem = vXmlMap.Root.Elements("Location").FirstOrDefault();

            vStrSource = vElem.Attributes("source").FirstOrDefault().Value.ToString();
            vStrDestination = vElem.Attributes("destination").FirstOrDefault().Value.ToString();
            vStrDBCondition = vElem.Attributes("DBCondition").FirstOrDefault().Value.ToString();
            vStrDestEqFld = vElem.Attributes("destinationFld").FirstOrDefault().Value.ToString();  
            retRes = true;
            return retRes;
        }
    }
}
