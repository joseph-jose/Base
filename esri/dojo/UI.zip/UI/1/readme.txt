

http://dojotoolkit.org/documentation/tutorials/1.10/dijit_layout/