#CompressSync.py

#Purpose:
#Syncronise ArcSDE Replicas automation.

#Susan Jones
#1 December 2010
#Updates Shaun Naidoo
#25-09-2014

#import modules
import arcgisscripting, sys, os, sys, datetime

try:

    #Banner
    print "***************************************************************"
    print " "   
    print "Compress and Synchronize Geodatabase Replication  " 
    print " "
    print "***************************************************************"

    #Collect parameters
    gdbMaster = sys.argv[1]
    gdbReplica = sys.argv[2]
    replicaName = sys.argv[3]

    lf = sys.argv[4]

    print "HOST GDB\n" + gdbMaster
    print "\nREPLICA\n" + replicaName
    print "\nREPLICA GDB\n" + gdbReplica

    #Open the file for writing
    print lf
    fs = open( str(lf), 'a')
    fs.write("****************************************************************************\n")
    fs.write("\n")
    fs.write(" Compress and Synchronise Geodatabase Replicas \n")
    fs.write(" Updating : " + replicaName + "\n\n")
    fs.write("\n")
    fs.write("****************************************************************************\n")
    fs.write("Date Run: " + str(datetime.datetime.now()) + "\n\n")

    #Create the gp
    gp = arcgisscripting.create(9.3)
    #Process
    print "\n******\nThe process"
	
	#***************************************************************************************************************************************************
    #Run the compress on gdbReplica
    print "\nStep 3. COMPRESSING " + gdbReplica + "...."
    fs.write("3. Compressing " + gdbReplica + "\n")
    try:
        gp.compress_management(gdbReplica)
        fs.write(gp.getmessage(gp.messagecount - 3) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 2) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 1) + "\n\n")
        print gp.getmessage(gp.messagecount - 3)
        print gp.getmessage(gp.messagecount - 2)
        print gp.getmessage(gp.messagecount - 1)
    except:
        fs.write(gp.getmessage(gp.messagecount - 3) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 2) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 1) + "\n\n")
        print gp.getmessage(gp.messagecount - 3)
        print gp.getmessage(gp.messagecount - 2)
        print gp.getmessage(gp.messagecount - 1)
    print "Compressed."

	#***************************************************************************************************************************************************
    #Run the syncronise tool
    print "\nStep 2. SYNCHRONISING " + replicaName + "...."
    fs.write("2. Synchronising " + replicaName + "\n")
    try:
        gp.synchronizechanges_management(gdbMaster,replicaName,gdbReplica,"FROM_GEODATABASE1_TO_2")
        fs.write(gp.getmessage(gp.messagecount - 3) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 2) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 1) + "\n\n")
        print gp.getmessage(gp.messagecount - 3)
        print gp.getmessage(gp.messagecount - 2)
        print gp.getmessage(gp.messagecount - 1)
    except:
        fs.write(gp.getmessage(gp.messagecount - 3) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 2) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 1) + "\n\n")
        print gp.getmessage(gp.messagecount - 3)
        print gp.getmessage(gp.messagecount - 2)
        print gp.getmessage(gp.messagecount - 1)
    print "Synchronised."
	
	#***************************************************************************************************************************************************
    #Run the compress on gdbReplica
    print "\nStep 1. COMPRESSING " + gdbMaster + "...."
    fs.write("1. Compressing " + gdbMaster + "\n")
    try:
        gp.compress_management(gdbMaster)
        fs.write(gp.getmessage(gp.messagecount - 3) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 2) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 1) + "\n\n")
        print gp.getmessage(gp.messagecount - 3)
        print gp.getmessage(gp.messagecount - 2)
        print gp.getmessage(gp.messagecount - 1)
    except:
        fs.write(gp.getmessage(gp.messagecount - 3) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 2) + "\n")
        fs.write(gp.getmessage(gp.messagecount - 1) + "\n\n")
        print gp.getmessage(gp.messagecount - 3)
        print gp.getmessage(gp.messagecount - 2)
        print gp.getmessage(gp.messagecount - 1)
    print "Compressed."
	#***************************************************************************************************************************************************
	
	
    #Completion Message
    print "\nLogfile written to " + lf
    fs.write("Successfully compressed and synchronised " + replicaName +  "\n")
    fs.write("================================================================================\n\n\n")

    #Notify the screen
    print "\n*****************"
    print "Susan is too cool"
    print "*****************"

except:
    #Notify
    print "error encountered"

finally:
    #cleanup
    print "Cleanup"
    fs.close()
    del gp
