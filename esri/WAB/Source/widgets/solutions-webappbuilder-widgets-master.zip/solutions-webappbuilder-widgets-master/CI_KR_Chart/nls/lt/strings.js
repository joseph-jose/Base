﻿define({
    select: "Į_Select_š",
    results: "Į_Results_š",
    selectLayer: "Į_Select from layer:_š",
    selectDrawtool: "Į_Select draw tool:_š",
    result: "Į_Result:_š",
    noresult: "Į_No query results to display chart._š",
    nomedia: "Į_There's no media in configuration!_š",
    envelop: "Į_Draw Rectangle_š",
    circle: "Į_Draw Circle_š",
    ellipse: "Į_Draw Ellipse_š",
    polygon: "Į_Draw Polygon_š",
    freehand: "Į_Draw Freehand Polygon_š",
    clear:"Į_Clear_š"
});