﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmMnPwd : Form
    {
        private WCTools.BL.Classes.cUtilFile vUtilFile;

        public bool helpersActivate()
        {
            bool vBoolRes;
            vBoolRes = false;
            vUtilFile = new Classes.cUtilFile();
            vBoolRes = true;
            return vBoolRes;

        }
        public void helpersDeActivate()
        {
            vUtilFile = null;
        }

        ~frmMnPwd()
        {
            helpersDeActivate(); 
        }

        public bool validateOnLoad()
        {
            return true;
        }

        public frmMnPwd()
        {
            InitializeComponent();
        }



        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnNcrypt_Click(object sender, EventArgs e)
        {
            txtNcryptStr.Text = vUtilFile.EncryptStr(txtDecryptStr.Text);

        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            txtDecryptStr.Text = vUtilFile.DeCryptStr(txtNcryptStr.Text); 

        }
    }
}
