﻿define(
   ({
    _widgetLabel: "Bewerken",
    title: "Selecteer template voor het maken van objecten",
    pressStr: "Druk op ",
    ctrlStr: " Ctrl ",
    snapStr: " om snapping in te schakelen"
  })
);