﻿define(
   ({
    title: "Logrīks InfoSummary",
    helpText: "TODO InfoSummary palīdzības teksts",
    labels: {
      status: "Statuss",
      result: "Rezultāts"
    },
    _widgetLabel: "Informācijas kopsavilkums (beta versija)"
  })
);