﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESRI.ArcGIS.Framework;

namespace WCTools.BL.Classes
{
    class cGisBase : cBase
    {
        private IApplication vApp;
        public IApplication vAppMap { get { return vApp; } set { vApp = value; } }

        #region "IDisposable Support "
        //'***************************************
        //'Clean up connection
        //'Always to be called before a connection is created
        //'***************************************
        public override void CleanUpDBConnection()
        {
            if (!(vApp == null ))
            {
                vApp = null;
            }
        }


        #endregion


    }
}
