﻿define(
   ({
    _widgetLabel: "تحرير",
    title: "تحديد قالب لإنشاء المعالم",
    pressStr: "اضغط ",
    ctrlStr: " CTRL ",
    snapStr: " لتمكين الالتقاط"
  })
);