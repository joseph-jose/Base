// load this function for all websites in order for the header and footer to load on each website
$(function(){
  $("#nav").load("shared/_nav.html"); 
  $("#footer").load("shared/_footer.html"); 
});