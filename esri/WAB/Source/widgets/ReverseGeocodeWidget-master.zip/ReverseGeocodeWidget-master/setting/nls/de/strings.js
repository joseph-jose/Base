﻿define({
    unit: "ä_Unit_Ü",
    style: "ä_Style_Ü"
});