﻿define(
   ({
    enableUndoRedo: "Leisti atšaukimą/grąžinimą",
    toolbarVisible: "Įrankių juosta matoma",
    toolbarOptions: "Įrankių juostos parinktys",
    mergeVisible: "Sulieti",
    cutVisible: "Kirpti",
    reshapeVisible: "Performuoti",
    back: "Atgal",
    label: "Sluoksnis",
    edit: "Redaguojama",
    update: "Išjungti geometrijos atnaujinimą",
    fields: "Laukai",
    actions: "Veiksmai",
    editpageName: "Pavadinimas",
    editpageAlias: "Pseudonimas",
    editpageVisible: "Matoma",
    editpageEditable: "Redaguojama",
    noLayers: "Galimų redaguoti elementų sluoksnių nėra",
    configureFields: "Konfigūruoti sluoksnio laukus"
  })
);