﻿define(
   ({
    _widgetLabel: "Editare",
    title: "Selectaţi un şablon pentru a crea obiecte spaţiale",
    pressStr: "Apăsaţi ",
    ctrlStr: " CTRL ",
    snapStr: " pentru a activa fixarea"
  })
);