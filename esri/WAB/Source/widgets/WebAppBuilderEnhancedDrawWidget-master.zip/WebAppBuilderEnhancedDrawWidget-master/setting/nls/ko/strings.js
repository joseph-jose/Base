﻿define(
   ({
    addDistance: "길이 단위 추가",
    addArea: "면적 단위 추가",
    label: "레이블",
    abbr: "약어",
    conversion: "변환",
    actions: "작업",
    areaUnits: "면적 단위",
    distanceUnits: "길이 단위",
    kilometers: "킬로미터",
    miles: "마일",
    meters: "미터",
    feet: "피트",
    yards: "야드",
    squareKilometers: "제곱킬로미터",
    squareMiles: "제곱마일",
    acres: "에이커",
    hectares: "헥타르",
    squareMeters: "제곱미터",
    squareFeet: "제곱피트",
    squareYards: "제곱야드",
    distance: "거리",
    area: "면적"
  })
);