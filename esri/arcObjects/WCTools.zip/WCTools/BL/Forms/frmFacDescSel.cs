﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmFacDescSel : Form
    {
        DataTable vDtTbl = null;

        public frmFacDescSel()
        {
            InitializeComponent();
        }


        public void iterateRows(DataRow[] inDataRows, int colLen)
        {
            DataRow vDtRow;
            string vFldVal;
            for (int i = 0; i < inDataRows.Count(); i++)
            {
                dtGrdLstAttr.Rows.Add();
                vDtRow = inDataRows[i];
                for (int j = 0; j < colLen; j++)
                {
                    vFldVal = vDtRow[j].ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.RowCount - 1].Cells[j].Value = vFldVal;
                }
            }
        }

        public Tuple<string, string> LoadFacDescSel(DataTable inDtTbl)
        {
            vDtTbl = inDtTbl;

            cmbFacDesc.SelectedIndex = 0;

            DataRow vDataRow = null;
            string vtmpStr = "";

            for (int i = 0; i < 3; i++)
            {
                vtmpStr = inDtTbl.Columns[i].ColumnName.ToString();
                dtGrdLstAttr.Columns.Add(vtmpStr, vtmpStr);
            }
            dtGrdLstAttr.Columns[2].Width = dtGrdLstAttr.Columns[2].Width * 3;

            DataRow[] vFltrDataRows = null;
            vFltrDataRows = inDtTbl.Select("FAC_ID>0");
            iterateRows(vFltrDataRows, 3);
            vFltrDataRows = null;

            var vFacility = new Tuple<string,  string> ("", "" );

            if (this.ShowDialog() == DialogResult.OK)
            {

                return Tuple.Create(dtGrdLstAttr.SelectedRows[0].Cells[1].Value.ToString(), dtGrdLstAttr.SelectedRows[0].Cells[2].Value.ToString());

                //vDataRow = (dtGrdLstAttr.CurrentRow.DataBoundItem as DataRowView).Row;
                //vDataRow = dtGrdLstAttr.CurrentRow;
            }
            else return Tuple.Create("", "");

        }

        private void btnSel_Click(object sender, EventArgs e)
        {
            if (dtGrdLstAttr.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select the facility");
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtSrch.Text == "")
            {
                MessageBox.Show("Please enter text to search");
                txtSrch.Focus();
                return;
            }

            dtGrdLstAttr.Rows.Clear();

            string vSrchParam = "";
            vSrchParam = string.Format("{0} like '%{1}%'", cmbFacDesc.Text, txtSrch.Text);


            DataRow[] vFltrDataRows = null;
            vFltrDataRows = vDtTbl.Select(vSrchParam);
            if (vFltrDataRows.Count() > 0)
            {
                iterateRows(vFltrDataRows, 3);
                vFltrDataRows = null;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dtGrdLstAttr.Rows.Clear();
            txtSrch.Clear();

            string vSrchParam = "FAC_ID>0";

            DataRow[] vFltrDataRows = null;
            vFltrDataRows = vDtTbl.Select(vSrchParam);
            if (vFltrDataRows.Count() > 0)
            {
                iterateRows(vFltrDataRows, 3);
                vFltrDataRows = null;
            }

        }

        private void btnCls_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
