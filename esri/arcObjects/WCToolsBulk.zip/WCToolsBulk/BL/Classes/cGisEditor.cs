﻿using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCToolsBulk.BL.Classes
{
    class cGisEditor : cGisBase 
    {
        public IWorkspaceEdit getWrkSpcFFeature(IFeature inFeature)
        {
            IDataset vDtSt;
            IWorkspaceEdit vWrkSpcEdt;
            try
            {
                vDtSt = inFeature.Table as IDataset;
                vWrkSpcEdt = vDtSt.Workspace as IWorkspaceEdit;
            }
            finally
            {
                vDtSt = null;
            }
            return vWrkSpcEdt;
        }

        #region "IDisposable Support "
        //'***************************************
        //'Clean up connection
        //'Always to be called before a connection is created
        //'***************************************
        public override void CleanUpDBConnection()
        {
        }
        #endregion
    }
}
