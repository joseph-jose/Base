﻿define(
   ({
    _widgetLabel: "Rediger",
    title: "Velg mal for å opprette geoobjekter",
    pressStr: "Trykk på ",
    ctrlStr: " CTRL ",
    snapStr: " for å aktivere festing"
  })
);