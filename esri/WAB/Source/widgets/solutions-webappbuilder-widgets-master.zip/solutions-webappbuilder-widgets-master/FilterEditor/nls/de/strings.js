﻿define(
   ({
    _widgetLabel: "Bearbeiten",
    title: "Vorlage zur Feature-Erstellung auswählen",
    pressStr: "Drücken Sie ",
    ctrlStr: " STRG ",
    snapStr: " , um die Fangfunktion zu aktivieren."
  })
);