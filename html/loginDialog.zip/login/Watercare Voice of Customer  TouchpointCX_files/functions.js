dojo.require("dijit.layout.BorderContainer");

dojo.require("dijit.layout.ContentPane");

/* Using Dojo do AJAX Call */
function getContent(objHolder, objUrl) {
	var targetNode = dojo.byId(objHolder);

	// The parameters to pass to xhrGet, the url, how to handle it, and the
	// callbacks.
	var xhrArgs = {
		url : objUrl,
		handleAs : "text",
		preventCache : true,
		load : function(data) {
			targetNode.innerHTML = data;
		},
		error : function(error) {
			targetNode.innerHTML = "An unexpected error occurred: " + error;
		}
	}

	// Call the asynchronous xhrGet
	var deferred = dojo.xhrGet(xhrArgs);
}

/*
function setWatermark(obj,event,initText,initClass,normalClass){
	var objInput = dojo.byId(obj);
	dojo.addClass(objInput,initClass);
	
	objInput.value = initText;
 	
	dojo.connect(objInput,event, function(evt){

		if (dojo.hasClass(objInput,initClass)) {
			objInput.value = "";
			dojo.removeClass(objInput,initClass)
			dojo.addClass(objInput,normalClass);	
		}
	});
}
*/

function printPage() { print(); }

function printIframe(id)
{
    var iframe = document.frames ? document.frames[id] : document.getElementById(id);
    var ifWin = iframe.contentWindow || iframe;
    iframe.focus();
    ifWin.printPage();
    return false;
}


// Change Dropdown's width which open it up
function dropDownAutoWidth(ddID)
{
    var maxlength = 0;
    var mySelect = document.getElementById(ddID);
    for (var i=0; i<mySelect.options.length;i++)
    {
        if (mySelect[i].text.length > maxlength)
        {
            maxlength = mySelect[i].text.length;
        }
    }
    mySelect.style.width = maxlength * 10;
}

function dropDownMouseEnter()
{
	dropDownSelectionChange();
}

function dropDownFocusOut(ddID,ddInitWidth)
{
    var mySelect = document.getElementById(ddID);
    mySelect.style.width = ddInitWidth;
}
function dropDownSelectionChange(ddID,ddInitWidth)
{
    var mySelect = document.getElementById(ddID);
    if(mySelect[mySelect.selectedIndex].text.length * 10 > 60)
        mySelect.style.width = mySelect[mySelect.selectedIndex].text.length * 10;
    else
        mySelect.style.width = ddInitWidth;
}

// Overlay loading 
function showLoading(ifShow) {
    var underlay = new dijit.DialogUnderlay({'class': 'loading'});
    if (ifShow == true)
    	underlay.show();
    else
    	underlay.hide();
}

function unformatDisplayCurrency(elementID) { //onfocus
	var amount = document.getElementById(elementID).value;
	if (amount.indexOf(".") > 0) {
		var decimal = amount.substr(amount.indexOf("."));
		if (decimal.length == 2) {
			amount += '0';
		}
	}
	document.getElementById(elementID + '_display').value = amount;
}

function formatDisplayCurrency(elementID, label, totalDecimals) { //onblur
	var inputAmount = document.getElementById(elementID + '_display').value;
	if (!inputAmount) {
		document.getElementById(elementID).value = '';
		return;
	}
	var amount = inputAmount.toString().replace(/\$|\,/g, '');
	var formattedValue = formatCurrency(amount, totalDecimals);
	document.getElementById(elementID + '_display').value = formattedValue;
	document.getElementById(elementID).value = formattedValue.toString()
			.replace(/\$|\,/g, '');
}

function formatCurrency(num, totalDecimals) {
	if (totalDecimals < 0)
		totalDecimals = 2;
	var decimals = Math.pow(10, totalDecimals);
	if (isNaN(num))
		return num;
	var sign = (num == (num = Math.abs(num)));
	num = Math.floor(num * decimals + 0.50000000001);
	var cents = num % decimals;
	num = Math.floor(num / decimals).toString();
	if (totalDecimals > 0) {
		cents = cents.toString();
	} else {
		cents = '';
	}
	var paddings = totalDecimals - cents.length;
	while (paddings > 0) {
		cents = "0" + cents;
		paddings--;
	}
	for ( var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
		num = num.substring(0, num.length - (4 * i + 3)) + ','
				+ num.substring(num.length - (4 * i + 3));
	return (((sign) ? '' : '-') + '$' + num + (cents ? ('.' + cents) : ''));
}


function allowRepeatExecution(btn, allowRepeating, maxInterval) {

    if (maxInterval == 0) {

        return true;
        
    } else if (clickingTimes[btn.id] == undefined || clickingTimes[btn.id] == 0) {

        clickingTimes[btn.id] = new Date().getTime();
        getInputValues();

        return true;

    } else if (! allowRepeating) {

        return false;

    } else {

        if (getInputValues()) {

            clickingTimes[btn.id] = new Date().getTime();

            return true;

        } else if ((new Date().getTime() - clickingTimes[btn.id]) > maxInterval * 1000) {

            clickingTimes[btn.id] = new Date().getTime();

            return true;

        } else {

            alert('Please wait for the current execution to complete before executing again.');

            return false;

        }

    }

}

/*Set indent to the text in dropdown.
obj			--> the ID of <select>
strSource	--> string to be replaced
strDest		--> string to be
intPos		--> number, the first X number of string
*/
function setDropDownTextIndent(obj,strSource, strDest, intPos){
	var objDropDown = dojo.byId(obj);
	var intLength = objDropDown.length;
	
	for(i=0;i<intLength;i++){
		if (objDropDown[i].text.substring(0,intPos)==strSource)
			objDropDown[i].innerHTML = objDropDown[i].text.replace(strSource,strDest);
	}
}

// Textarea Maxlength script. Fix maxlength attribute does not always work on all browsers on TextArea
function ismaxlength(obj){
	var mlength=obj.getAttribute? parseInt(obj.getAttribute("maxlength")) : ""
	if (obj.getAttribute && obj.value.length>mlength)
	obj.value=obj.value.substring(0,mlength)
	}
