import arcpy
import os
import datetime
from arcpy import env

#in_path = r"C:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication20180819.gdb"
#out_path = r"c:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication-Water.gdb"
#in_FC = r"swBridge"
in_path = arcpy.GetParameterAsText(0)
out_path = arcpy.GetParameterAsText(1)
in_FC = arcpy.GetParameterAsText(2)
out_FC = arcpy.GetParameterAsText(3)

arcpy.env.workspace = in_path


has_m = "DISABLED"
has_z = "DISABLED"

vin_FC = os.path.join(in_path, in_FC)
print vin_FC

#desc = arcpy.Describe(in_path + r"\\" + in_FC)
desc = arcpy.Describe(vin_FC)
print desc

if hasattr(desc, "spatialReference"):
    spaRef = desc.spatialReference
    geometry_type = desc.shapeType
    print geometry_type

    
    #arcpy.CreateFeatureclass_management(out_path, in_FC, geometry_type, has_m, has_z, spaRef)
    #arcpy.CreateFeatureclass_management(out_path, in_FC, geometry_type, in_FC, has_m, has_z, spaRef)
    #arcpy.CreateFeatureclass_management(out_path, in_FC, geometry_type, in_FC, spaRef)
    arcpy.CreateFeatureclass_management(out_path, out_FC, geometry_type, in_FC, has_m, has_z, spaRef,"", "0", "0", "0")
else:
    #geometry_type = desc.shapeType
    #print geometry_type
    print "No spatial ref"

for child in desc.children:
    print "\t%s = %s" % (child.name, child.dataType)
    



