﻿namespace WCTools.BL.Forms
{
    partial class frmMnPwd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.btnNcrypt = new System.Windows.Forms.Button();
            this.txtNcryptStr = new System.Windows.Forms.TextBox();
            this.txtDecryptStr = new System.Windows.Forms.TextBox();
            this.lblComp = new System.Windows.Forms.Label();
            this.lblProdVer = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnClose);
            this.panel3.Location = new System.Drawing.Point(0, 258);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(333, 50);
            this.panel3.TabIndex = 11;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(246, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnDecrypt);
            this.panel2.Controls.Add(this.btnNcrypt);
            this.panel2.Controls.Add(this.txtNcryptStr);
            this.panel2.Controls.Add(this.txtDecryptStr);
            this.panel2.Controls.Add(this.lblComp);
            this.panel2.Controls.Add(this.lblProdVer);
            this.panel2.Location = new System.Drawing.Point(0, 56);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(333, 196);
            this.panel2.TabIndex = 10;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(119, 121);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(75, 23);
            this.btnDecrypt.TabIndex = 6;
            this.btnDecrypt.Text = "Decrypt";
            this.btnDecrypt.UseVisualStyleBackColor = true;
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // btnNcrypt
            // 
            this.btnNcrypt.Location = new System.Drawing.Point(119, 62);
            this.btnNcrypt.Name = "btnNcrypt";
            this.btnNcrypt.Size = new System.Drawing.Size(75, 23);
            this.btnNcrypt.TabIndex = 5;
            this.btnNcrypt.Text = "Encrypt";
            this.btnNcrypt.UseVisualStyleBackColor = true;
            this.btnNcrypt.Click += new System.EventHandler(this.btnNcrypt_Click);
            // 
            // txtNcryptStr
            // 
            this.txtNcryptStr.Location = new System.Drawing.Point(119, 95);
            this.txtNcryptStr.Name = "txtNcryptStr";
            this.txtNcryptStr.Size = new System.Drawing.Size(209, 20);
            this.txtNcryptStr.TabIndex = 4;
            // 
            // txtDecryptStr
            // 
            this.txtDecryptStr.Location = new System.Drawing.Point(119, 36);
            this.txtDecryptStr.Name = "txtDecryptStr";
            this.txtDecryptStr.Size = new System.Drawing.Size(209, 20);
            this.txtDecryptStr.TabIndex = 3;
            // 
            // lblComp
            // 
            this.lblComp.AutoSize = true;
            this.lblComp.Location = new System.Drawing.Point(23, 39);
            this.lblComp.Name = "lblComp";
            this.lblComp.Size = new System.Drawing.Size(53, 13);
            this.lblComp.TabIndex = 2;
            this.lblComp.Text = "Password";
            // 
            // lblProdVer
            // 
            this.lblProdVer.AutoSize = true;
            this.lblProdVer.Location = new System.Drawing.Point(23, 98);
            this.lblProdVer.Name = "lblProdVer";
            this.lblProdVer.Size = new System.Drawing.Size(103, 13);
            this.lblProdVer.TabIndex = 0;
            this.lblProdVer.Text = "Encrypted password";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(333, 50);
            this.panel1.TabIndex = 9;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 306);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(336, 22);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // frmMnPwd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 328);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMnPwd";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMnPwd";
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblComp;
        private System.Windows.Forms.Label lblProdVer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button btnDecrypt;
        private System.Windows.Forms.Button btnNcrypt;
        private System.Windows.Forms.TextBox txtNcryptStr;
        private System.Windows.Forms.TextBox txtDecryptStr;
    }
}