import arcpy
import os
import datetime

FCs = arcpy.GetParameterAsText(0)
FCName = arcpy.GetParameterAsText(1)

#FCs = r"C:\Users\jejyjose1\AppData\Roaming\ESRI\Desktop10.5\ArcCatalog\atalgissdbu01.Ac.sde"
#FCName = r"AC.GISADMIN.NZ_Non_Primary_Parcels"

#FCs = r"C:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication20180819.gdb"
#FCName = r"swBankLining"

arcpy.env.workspace = FCs

#print(datetime.datetime.now())

result = arcpy.GetCount_management(FCName)
print('{} has {} records'.format(FCName, result[0]))

#print(datetime.datetime.now())

