﻿define(
   ({
    enableUndoRedo: "Geri Al/Yinele\'yi Etkinleştir",
    toolbarVisible: "Görünür Araç Çubuğu",
    toolbarOptions: "Araç Çubuğu Seçenekleri",
    mergeVisible: "Birleştir",
    cutVisible: "Kes",
    reshapeVisible: "Yeniden Şekillendir",
    back: "Geri",
    label: "Katman",
    edit: "Düzenlenebilir",
    update: "Geometriyi Güncellemeyi Devre Dışı Bırak",
    fields: "Alanlar",
    actions: "İşlemler",
    editpageName: "Ad",
    editpageAlias: "Takma Ad",
    editpageVisible: "Görünür",
    editpageEditable: "Düzenlenebilir",
    noLayers: "Düzenlenebilir detay katmanı yok",
    configureFields: "Katman Alanlarını Yapılandır"
  })
);