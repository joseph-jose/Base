﻿define(
   ({
    title: "InfoSummary-widget",
    helpText: "TODO InfoSummary-hjælpetekst",
    labels: {
      status: "Status",
      result: "Resultat"
    },
    _widgetLabel: "Info Summary (Beta)"
  })
);