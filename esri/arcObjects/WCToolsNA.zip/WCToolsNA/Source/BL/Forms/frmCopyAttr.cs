﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCToolsNA.BL.Classes;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase; 

namespace WCToolsNA.BL.Forms
{
    public partial class frmCopyAttr : Form
    {
        private IApplication vApp;
        public IApplication vAppMap { set { vApp = value; } }
        private string vLogSessId = "";
        public string vLogSessionId { set { vLogSessId = value; } }

        WCToolsNA.BL.Classes.cDbSqlFile vDbFile;
        WCToolsNA.BL.Classes.cUtilFile vUtilFile;
        WCToolsNA.BL.Classes.cUtilGIS vGISUtil;
        WCToolsNA.BL.Classes.clsXmlMapCopyAttr vXmlMap;


        private IFeature vfrmSelFeature;
        private IFeature vtoSelFeature;

        #region "CommonFunctions"
        public void helpersActivate()
        {
            vDbFile = new cDbSqlFile();
            vUtilFile = new cUtilFile();
            vGISUtil = new cUtilGIS();
            vXmlMap = new clsXmlMapCopyAttr();
            vGISUtil.vAppMap = vApp;

            connDB();
            logNtry("WCTools", "UpdSAPAttr", "Start", vLogSessId, "TRC");
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "UpdSAPAttr", "End", vLogSessId, "TRC");
            vDbFile.CleanUpDBConnection();
            vDbFile.Dispose();
            vDbFile = null;
            vGISUtil.Dispose();
            vGISUtil = null;

            vXmlMap.vLstXmlCnfs = null;
            vXmlMap = null;

            if (!(vfrmSelFeature == null))
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(vfrmSelFeature);
            }
            if (!(vtoSelFeature == null))
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(vtoSelFeature);
            }

        }

        public void connDB()
        {
            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            vDbFile.ConnectToDatabase(3, vConnStr);
        }

        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            vUtilFile.logNtry(vDbFile, inCmdType, inMsg, inFld1, inSessId, inLogType);
            //vUtilFile.logTxtNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public void setFeat(IFeature inFeat)
        {
            if (inFeat.Class.AliasName == vXmlMap.vStrSource)
            {
                vfrmSelFeature = inFeat ;
            }
            if (inFeat.Class.AliasName == vXmlMap.vStrDestination )
            {
                vtoSelFeature = inFeat ;
            }
        }

        public bool validateFeatAttrFlds(IFeature inFrmFeat, IFeature inToFeat)
        {
            bool vResFn = false;
            int vFldIdx = -1;
            object vobjFldVal;
            string vStrFldVal;

            WCToolsNA.BL.Classes.AttributeInfo vAttribute = null;
            for (int vI = 0; vI < vXmlMap.vLstXmlCnfs.Count ; vI++)
            {
                vAttribute = vXmlMap.vLstXmlCnfs[vI];

                vFldIdx = vGISUtil.getFieldIdx(inFrmFeat, vAttribute.sfieldName);
                if (vFldIdx == -1)
                {
                    MessageBox.Show(string.Format("Invalid configuration - Attribute {0} missing for feature {1}", vAttribute.sfieldName, inFrmFeat.Class.ToString()));
                    return vResFn;
                }
                else
                {
                    vobjFldVal = vGISUtil.getFieldValue(inFrmFeat, vAttribute.sfieldName);
                    if (vobjFldVal is System.DBNull)
                    {
                        vStrFldVal = "";
                    }
                    else
                    {
                        vStrFldVal = vobjFldVal.ToString();
                    }
                    vAttribute.sfieldValue = vStrFldVal;
                }

                vFldIdx = vGISUtil.getFieldIdx(inToFeat, vAttribute.dfieldName);
                if (vFldIdx == -1)
                {
                    MessageBox.Show(string.Format("Invalid configuration - Attribute {0} missing for feature {1}", vAttribute.dfieldName, inToFeat.Class.ToString()));
                    return vResFn;
                }
                else
                {
                    vobjFldVal = vGISUtil.getFieldValue(inToFeat, vAttribute.dfieldName);
                    if (vobjFldVal is System.DBNull)
                    {
                        vStrFldVal = "";
                    }
                    else
                    {
                        vStrFldVal = vobjFldVal.ToString();
                    }
                    vAttribute.dfieldValue  = vStrFldVal;
                }
            }
            vResFn = true;

            return vResFn;
        }

        public bool validateOnLoad()
        {
            bool vResFn = false;
            if (!(vGISUtil.getFeatureSelectCount() == 2))
            {
                MessageBox.Show("Minimum two features required to copy attributes");
                return vResFn;
            }
            loadFldMappings();

            //TODO to be changed
            IFeature vFeat;
            IEnumFeature vEnmFeat = vGISUtil.getSelectedFeatures();
            try
            {
                vEnmFeat.Reset();
                vFeat = vEnmFeat.Next();
                setFeat(vFeat);
                vFeat = vEnmFeat.Next();
                setFeat(vFeat);

                if ((vfrmSelFeature == null) || (vtoSelFeature == null))
                {
                    MessageBox.Show(string.Format("Invalid configuration - Copy attribute from and to Layers set as {0} and {1} ", vXmlMap.vStrSource, vXmlMap.vStrDestination));
                    return vResFn;
                }

                IWorkspaceEdit vWrkSpcEdit = vGISUtil.getWrkSpcFFeature(vfrmSelFeature);
                if (!(vWrkSpcEdit.IsBeingEdited()))
                {
                    MessageBox.Show(string.Format("Feature {0} not in edit mode", vfrmSelFeature.Class.ToString()));
                    return vResFn;
                }


                vWrkSpcEdit = vGISUtil.getWrkSpcFFeature(vtoSelFeature);
                if (!(vWrkSpcEdit.IsBeingEdited()))
                {
                    MessageBox.Show(string.Format("Feature {0} not in edit mode", vtoSelFeature.Class.ToString()));
                    return vResFn;
                }

                if (!(vGISUtil.CheckIfFeaturesTouch(vfrmSelFeature, vtoSelFeature)))
                {
                    MessageBox.Show("Selected features should touch");
                    return vResFn;
                }

                if (!(validateFeatAttrFlds(vfrmSelFeature, vtoSelFeature)))
                {
                    return vResFn;
                }
                fillGrid();
                hghlghtGrid();
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(vEnmFeat);
            }
            
            vResFn = true;
            return vResFn;
        }

        public bool loadFldMappings()
        {
            bool bRetRes = false;
            //cUtilFile vUtilFile = new cUtilFile();
            string vCfgFlPth = vUtilFile.getCfgFilePth("FeatCopyXMLPath");

            bRetRes = vXmlMap.getDsMappings(vCfgFlPth);
            bRetRes = vXmlMap.getAllFields1(vCfgFlPth);
            return bRetRes;
        }
        #endregion

        #region "GridFunctions"
        private void updGridCells()
        {
            string vCol1, vCol2;
            //log
            string vLogStr = "";
            this.Cursor = Cursors.WaitCursor;
            IWorkspaceEdit vWkrSpcEdt = vGISUtil.getWrkSpcFFeature(vtoSelFeature);
            vWkrSpcEdt.StartEditOperation();
            try
            {
                for (int i = 0; i < dtGrdCompKeys.RowCount; i++)
                {
                    if (dtGrdCompKeys[4, i].Value == null)
                        vCol2 = "";
                    else
                        vCol2 = dtGrdCompKeys[4, i].Value.ToString();
                    if (dtGrdCompKeys[1, i].Value == null)
                        vCol1 = "";
                    else
                        vCol1 = dtGrdCompKeys[1, i].Value.ToString();


                    if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                    {
                        if (!(vCol2 == ""))
                        {
                            vCol1 = dtGrdCompKeys[0, i].Value.ToString();
                            dtGrdCompKeys[1, i].Value = vCol2;
                            dtGrdCompKeys[2, i].Style.BackColor = Color.White;
                            vGISUtil.setFieldValue(vtoSelFeature, vCol1, vCol2);

                            //log
                            if (!(vLogStr == ""))
                            {
                                vLogStr = vLogStr + ",";
                            }
                            vLogStr = vLogStr + vCol1 + "=" + vCol2;
                        }
                    }
                    Application.DoEvents();
                }

                //log
                vCol2 = vGISUtil.getFieldValue(vtoSelFeature, "GIS_ID").ToString();
                vCol1 = "GIS_ID";
                vLogStr = vLogStr + "[" + vCol1 + "=" + vCol2 + "]";
                logNtry("WCTools", "UpdSAPAttr", vLogStr, vLogSessId, "TRC");

            }
            finally
            {
                vWkrSpcEdt.StopEditOperation();
                this.Cursor = Cursors.Default;
            }
        }

        private void hghlghtGrid()
        {
            string vCol1, vCol2;
            for (int i = 0; i < dtGrdCompKeys.RowCount; i++)
            {
                if (dtGrdCompKeys[4, i].Value == null)
                    vCol2 = "";
                else
                    vCol2 = dtGrdCompKeys[4, i].Value.ToString();
                if (dtGrdCompKeys[1, i].Value == null)
                    vCol1 = "";
                else
                    vCol1 = dtGrdCompKeys[1, i].Value.ToString();


                if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                {
                    dtGrdCompKeys[2, i].Style.BackColor = Color.Red;
                }
            }

        }

        public void fillGrid()
        {
            txtSrc.Text = vXmlMap.vStrSource;
            txtDest.Text = vXmlMap.vStrDestination;

            WCToolsNA.BL.Classes.AttributeInfo vAttribute = null;
            for (int vI = 0; vI < vXmlMap.vLstXmlCnfs.Count ; vI++)
            {
                vAttribute = vXmlMap.vLstXmlCnfs[vI];
                dtGrdCompKeys.Rows.Add(vAttribute.dfieldName, vAttribute.dfieldValue, "", vAttribute.sfieldName, vAttribute.sfieldValue , vAttribute.dataType, vAttribute.type);
            }
        }
        #endregion

        public frmCopyAttr()
        {
            InitializeComponent();
        }

        private void btnUpdAttr_Click(object sender, EventArgs e)
        {
            updGridCells();
        }
    }
}
