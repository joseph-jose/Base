/**
 * For the dropdown in VerbatimDetail (Comments Popup)
 */
function prettyDropDown(id) {
    var realSelect = jQuery(id),
        realSelectDefault = realSelect.find('option:selected'),
        // add wrapper dive to the dom
        wrapperDiv = realSelect.wrap(jQuery("<div>", {
            'class': 'oiPrettyDropdownFilter'
        })).parent(),
        // create fake input
        /* This logic doesn't work with jQuery 1.8.0
        fakeInput = jQuery('<div>', {
            'class': function() {
                if (realSelectDefault.val() == 'all') {
                    return 'oiSelectedItem oiDefaultValue';
                } else {
                    return 'oiSelectedItem';
                }
            },
            'html': jQuery('<div>', {
                'class': 'oiInnerBox',
                'html' : jQuery('<div>', {
                    'class': 'oiTextWrapper',
                    'text': realSelectDefault.text()
                })
            })
        }),
        */
        fakeInputClass = (realSelectDefault.val() == 'all') ? 'oiSelectedItem oiDefaultValue' : 'oiSelectedItem',
        fakeInput = jQuery('<div>', {
            'class': fakeInputClass,
            'html': jQuery('<div>', {
                'class': 'oiInnerBox',
                'html' : jQuery('<div>', {
                    'class': 'oiTextWrapper',
                    'text': realSelectDefault.text()
                })
            })
        }),
        // create fake dropdown
        fakeSelectList = jQuery('<ul>'),
        // builds object of select options
        selectObj = realSelect.find('option').map(function() {
            var opt = {};
            opt[jQuery(this).val()] = jQuery(this).text();
            return opt;
        }).get(),
        mouse_is_inside = false;

    // Loop out select options into list items
    for (var i = 0; i < selectObj.length; i++) {
        for (key in selectObj[i]) {
            fakeSelectList.append(jQuery('<li>', {
                'data-value': key,
                'text': selectObj[i][key]
            }));
        }
    }

    // Append fake dropdown to wrapper div
    wrapperDiv.append(fakeInput, fakeSelectList);

    // Show hide dropdown
    fakeInput.on('click', function() {
        if (fakeSelectList.is(':visible')) {
            fakeSelectList.hide();
        } else {
            fakeSelectList.show();
        }
    });

    // Change selection
    fakeSelectList.find('li').on('click', function() {
        var thisLi = jQuery(this),
            selectedValue = thisLi.data('value');
        fakeSelectList.hide()
            .find('li').removeClass('oiSelected');
        thisLi.addClass('oiSelected');
        fakeInput.find('.oiTextWrapper').html(thisLi.html());
        realSelect.val(selectedValue).trigger('change');
        if (selectedValue == 'all') {
            fakeInput.addClass('oiDefaultValue');
        } else {
            fakeInput.removeClass('oiDefaultValue');
        }
    });

    // check to see if hovering over select
    jQuery(wrapperDiv ).hover( function() {
        mouse_is_inside = true;
    }, function() {
        mouse_is_inside = false;
    });

    // Hide dropdown if mouse up outside of fake select
    jQuery("html").on('mouseup', function() {
        if (!mouse_is_inside) {
            fakeSelectList.hide();
        }
    });
}

function dashboardTabs(id) {
	var tabGroup =  jQuery('#' + id ),
		subMenuHoverState = false;
	tabGroup.find('.oiMoreBtn').on('click', function(){
		if(tabGroup.find('.oiMoreSubTabs').is(":visible")){
			tabGroup.find('.oiMoreSubTabs').hide();
		} else {
			tabGroup.find('.oiMoreSubTabs').show();
		}
	});
	
	// check to see if hovering over submenu
	tabGroup.find('.oiMoreSubTabs, .oiMoreBtn').hover( function() {
		subMenuHoverState  = true;
	}, function() {
		subMenuHoverState = false;
	});
	
	// Hide dropdown if mouse up outside of fake select
	jQuery("html").on('mouseup', function() {
		if (!subMenuHoverState) {
			tabGroup.find('.oiMoreSubTabs').hide();
		}
	});
}