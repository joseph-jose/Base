import arcpy, json, urllib, urllib2, sys, os, getpass, pprint, string
sys.path.append('C:/Python27/Portalpy/')
import portalpy

def getAllItemsFUser(inUser, inTotal, inStart=1, inNxtStart=11):
    if inStart > inNxtStart:
        print inStart

def readResponse(inLineStr):
    vArrItems = vLineStr.split(',')
    #print len(vArrItems)

    for vI in range(1,10,1):
        vArrItem = vArrItems[vI]
        if string.find(vArrItem, "total") <> -1:
            vStrTotal = vArrItem
        if string.find(vArrItem, "start") <> -1:
            vStrStart = vArrItem
        if string.find(vArrItem, "nextStart") <> -1:
            vStrnextStart = vArrItem

    print vStrTotal.split(":")[1]
    print vStrStart.split(":")[1]
    print vStrnextStart.split(":")[1]

    vOutVal = dict()
    vOutVal['vTotal'] = vStrTotal.split(":")[1]
    vOutVal['vStrStart'] = vStrStart.split(":")[1]
    vOutVal['vStrnextStart'] = vStrnextStart.split(":")[1]
    return vOutVal


dir = r"C:\Joseph\Task\TASK_PreProdRefresh\Py\readCSV"
# Create csv file and write the header in csv
log_path = os.path.join(dir, 'AllItemsInPortal.csv')
print log_path
logger = open(log_path,"r")

for vLine in logger:
    print(vLine)
    


logger.close()
