﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmSetGISIdMulti : Form
    {
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }

        private IFeatureLayer __FeatLyr;
        private string __gisIdFld;

        private string vLogSessId;
        public string vLogSessionId { set { vLogSessId = value; } }

        private WCTools.BL.Classes.cUtilFile vUtilFile;
        private WCTools.BL.Classes.cUtilGIS vGISUtil;
        private WCTools.BL.Classes.cDbSqlFile vGisDb;

        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            vUtilFile.logNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public bool helpersActivate()
        {
            bool vBRes = true;
            vGISUtil = new Classes.cUtilGIS();
            vGISUtil.vAppMap = __App;


            vUtilFile = new Classes.cUtilFile();
            vGisDb = new Classes.cDbSqlFile();

            //20170510 Non GISEditor intimation
            try
            {
                connDB();
            }
            catch (Exception e)
            {
                MessageBox.Show("Access to database couldn't be obtained");
                vBRes = false;
                return vBRes;
            }
            //20170510 Non GISEditor intimation
            logNtry("WCTools", "SetGISIdMulti", "Start", vLogSessId, "TRC");
            return vBRes;
        }

        public void helpersDeActivate()
        {
            logNtry("WCTools", "SetGISIdMulti", "End", vLogSessId, "TRC");
            vGISUtil.Dispose();
            vGISUtil = null;
            vUtilFile = null;

            vGisDb.CleanUpDBConnection();
            vGisDb.Connected = false;
            vGisDb.Dispose();
            vGisDb = null;

            __FeatLyr = null;
            __App = null;
        }

        //Connect to database
        private bool connDB()
        {
            bool resFn = false;

            string vConnStr = "";
            vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_MstrDb");
            vGisDb.ConnectToDatabase(3, vConnStr);

            resFn = true;
            return resFn;
        }

        //Disconnect from database
        private void DbDisConn()
        {
            vGisDb.Connected = false;
        }

        //Get the sequence # from db
        public int getSeqNo()
        {
            int resVal = -1;
            if (vGisDb.Connected)
            {
                DataTable vDtTbl = vGisDb.getDtTblRecs("select next value for GISNet1.giswsl.gisid_seq");

                object vSeqVal = vDtTbl.Rows[0][0].ToString();
                if (!(Convert.IsDBNull(vSeqVal)))
                {
                    resVal = Convert.ToInt32(vSeqVal);
                }
            }
            return resVal;
        }

        private void LoadFeatCur(IFeatureCursor inFeatCur)
        {
            IFeature vFeat;
            object vFldVal;
            string vFldValStr = "";
            int vFldIdx = -1;
            try
            {

                vFeat = inFeatCur.NextFeature();
                while (!(vFeat == null))
                {
                    dtGrdLst.Rows.Add();
                    vFldVal = vGISUtil.getFieldValue(vFeat, "OBJECTID");
                    vFldValStr = "";
                    if (!(vFldVal == null))
                    {
                        vFldValStr = vFldVal.ToString();
                    }
                    dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colObjId"].Value = vFldValStr;
                    vFldVal = null;
                    //20160920 new Netview
                    //if (__gisIdFld == "GIS_ID")
                    //{

                    //    vFldIdx = vGISUtil.getFieldIdx(vFeat, "EQUIP_ID");
                    //    if (!(vFldIdx == -1))
                    //    {
                    //        vFldVal = vGISUtil.getFieldValue(vFeat, "EQUIP_ID");
                    //    }
                    //}
                    //else
                    //{
                    //    vFldIdx = vGISUtil.getFieldIdx(vFeat, "COMPKEY");
                    //    if (!(vFldIdx == -1))
                    //    {
                    //        vFldVal = vGISUtil.getFieldValue(vFeat, "COMPKEY");
                    //    }
                    //}
                    //vFldValStr = "";
                    //if (!(vFldVal == null))
                    //{
                    //    vFldValStr = vFldVal.ToString();
                    //}
                    //dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colEqpId"].Value = vFldValStr;
                    //20160920 new Netview
                    vFldIdx = vGISUtil.getFieldIdx(vFeat, "EQUIP_ID");
                    if (!(vFldIdx == -1))
                    {
                        vFldVal = vGISUtil.getFieldValue(vFeat, "EQUIP_ID");
                        vFldValStr = "";
                        if (!(vFldVal == null))
                        {
                            vFldValStr = vFldVal.ToString();
                        }
                        dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colEqpId"].Value = vFldValStr;
                    }
                    vFldIdx = vGISUtil.getFieldIdx(vFeat, "COMPKEY");
                    if (!(vFldIdx == -1))
                    {
                        vFldVal = vGISUtil.getFieldValue(vFeat, "COMPKEY");
                        vFldValStr = "";
                        if (!(vFldVal == null))
                        {
                            vFldValStr = vFldVal.ToString();
                        }
                        dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colCompKey"].Value = vFldValStr;
                    }

                    vFldVal = vGISUtil.getFieldValue(vFeat, "CREATEBY");
                    dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colCrtby"].Value = vFldVal as string;
                    vFldVal = vGISUtil.getFieldValue(vFeat, "MODIFYBY");
                    dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colModby"].Value = vFldVal as string;
                    vFldVal = vGISUtil.getFieldValue(vFeat, "CREATEDATE");
                    vFldValStr = "";
                    if (!(vFldVal == null))
                    {
                        vFldValStr = vFldVal.ToString();
                        DateTime vDtTm;
                        if (DateTime.TryParse(vFldValStr, out vDtTm))
                        {
                            vFldValStr = string.Format("{0:dd/MM/yyyy}", vFldValStr);
                        }
                    }
                    dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colCrtDt"].Value = vFldValStr;

                    vFldVal = vGISUtil.getFieldValue(vFeat, __gisIdFld);
                    vFldValStr = "";
                    if (!(vFldVal == null))
                    {
                        vFldValStr = vFldVal as string;
                    }
                    dtGrdLst.Rows[dtGrdLst.RowCount - 1].Cells["colGISId"].Value = vFldValStr;

                    vFeat = inFeatCur.NextFeature();
                }
            }
            finally
            {
                vFeat = null;
            }
        }

        //Do any validations on the form
        public bool validateOnLoad(out string fldPresent)
        {
            bool vResFn = false;
            fldPresent = "";

            ILayer vLyr;
            //IFeatureLayer vFeatLyr ;

            IWorkspaceEdit vWrkSpcEdit;
            try
            {
                vLyr = vGISUtil.getSelItemInTOC();
                if (!(vLyr is IFeatureLayer))
                {
                    MessageBox.Show("Select a feature layer");
                    return vResFn;
                }
                __FeatLyr = vLyr as IFeatureLayer;
                //jjose 20150301    BugFix for people running GISId tool in personal database
                //vWrkSpcEdt = vDtSt.Workspace as IWorkspaceEdit;
                if (__FeatLyr.DataSourceType.ToString().IndexOf("SDE") == -1)
                {
                    MessageBox.Show("Layer selected should belong to a geodatabase");
                    return vResFn;
                }
                //jjose 20150301
                vWrkSpcEdit = vGISUtil.getWrkSpcFLayer(__FeatLyr) as IWorkspaceEdit;


                if (!(vWrkSpcEdit.IsBeingEdited()))
                {
                    MessageBox.Show("Layer not in edit mode");
                    return vResFn;
                }

                //object vObjVal;
                int vFldIdx;
                vFldIdx = vGISUtil.getFieldIdx(__FeatLyr, "GIS_ID");
                if (vFldIdx == -1)
                {
                    MessageBox.Show("Attribute GIS_ID missing for feature class");
                    return vResFn;
                    //vFldIdx = vGISUtil.getFieldIdx(__FeatLyr, "RGIS_ID");
                    //if (vFldIdx == -1)
                    //{
                    //    MessageBox.Show("Attribute GIS_ID missing for feature class");
                    //    return vResFn;
                    //}
                    //else
                    //{
                    //    fldPresent = "RGIS_ID";
                    //    __gisIdFld = "RGIS_ID";
                    //}
                }
                else
                {
                    __gisIdFld = "GIS_ID";
                    fldPresent = "GIS_ID";
                }

            }
            finally
            {
                vLyr = null;
                //vFeatLyr = null;
                vWrkSpcEdit = null;

            }

            vResFn = true;
            return vResFn;

        }

        //Load any null features into the Grid
        public void loadNullFeatures(string inFldPresent)
        {
            //ILayer vLyr;
            //IFeatureLayer vFeatLyr;
            IFeatureCursor vFeatCur = null;

            try
            {
                //vLyr = vGISUtil.getSelItemInTOC();
                //if (!(vLyr is IFeatureLayer))
                //{
                //    MessageBox.Show("Select a feature layer");
                //}
                //vFeatLyr = vLyr as IFeatureLayer;

                dtGrdLst.Columns.Add("colObjId", "ObjectId");
                //20160922 new Netview
                //if (__gisIdFld == "GIS_ID")
                //{
                //    dtGrdLst.Columns.Add("colEqpId", "Equip_Id");
                //}
                //else
                //{
                //    dtGrdLst.Columns.Add("colEqpId", "CompKey");
                //}
                dtGrdLst.Columns.Add("colEqpId", "Equip_Id");
                dtGrdLst.Columns.Add("colCompKey", "CompKey");
                //20160922
                dtGrdLst.Columns.Add("colCrtby", "Createby");
                dtGrdLst.Columns.Add("colModby", "Modifyby");
                dtGrdLst.Columns.Add("colCrtDt", "CreateDate");
                dtGrdLst.Columns.Add("colGISId", "GIS_Id");

                //20160920 new Netview
                //vFeatCur = vGISUtil.getQryFltr(__FeatLyr, "(" + inFldPresent + " is null) and (Modifyby='" + Environment.UserName + "')");
                vFeatCur = vGISUtil.getQryFltr(__FeatLyr, "(" + inFldPresent + " = 0) and (Modifyby='" + Environment.UserName + "')");
                //20160920
                LoadFeatCur(vFeatCur);

            }
            finally
            {
                //vLyr = null;
                //vFeat = null ;
                //vFeatLyr = null;
                System.Runtime.InteropServices.Marshal.ReleaseComObject(vFeatCur);
                vFeatCur = null;
            }
        }


        public frmSetGISIdMulti()
        {
            InitializeComponent();
        }

        ~frmSetGISIdMulti()
        {
            helpersDeActivate();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Update the Grid values
        private void updGrdVals(string inObjIdx, int inVal)
        {
            foreach (DataGridViewRow vRow in dtGrdLst.Rows)
            {
                if (vRow.Cells["colObjId"].Value.ToString().Trim() == inObjIdx.Trim())
                {
                    vRow.Cells["colGISId"].Value = inVal.ToString();
                    logNtry("WCTools", "SetGISIdMulti", "GIS_ID=" + inVal.ToString(), vLogSessId, "TRC");
                    break;
                }
            }
        }

        //Generate the GIS ids
        private void btnGen_Click(object sender, EventArgs e)
        {
            IFeatureCursor vFeatCur = null;
            IWorkspaceEdit vWrkSpcEdt = null; //
            IFeature vFeat;
            int vSeqNo;
            object vObjVal;

            try
            {
                vWrkSpcEdt = vGISUtil.getWrkSpcFLayer(__FeatLyr) as IWorkspaceEdit; //
                vWrkSpcEdt.StartEditOperation(); // 

                //20160920
                //vFeatCur = vGISUtil.getQryFltrFUpd(__FeatLyr, "(" + __gisIdFld  + " is null) and (Modifyby='" + Environment.UserName + "')" );
                vFeatCur = vGISUtil.getQryFltrFUpd(__FeatLyr, "(" + __gisIdFld + " = 0) and (Modifyby='" + Environment.UserName + "')");
                //20160920

                //int vgisFldIdx = __FeatLyr.FeatureClass.FindField(__gisIdFld);

                connDB();
                vFeat = vFeatCur.NextFeature();
                while (!(vFeat == null))
                {
                    //20160920 Net netview

                    ////if (vFeat.get_Value(vgisFldIdx) ==  
                    //if (vGISUtil.getFieldValue(vFeat, __gisIdFld) is System.DBNull)
                    //{
                    //    vSeqNo = getSeqNo();
                    //    vGISUtil.setFieldValue(vFeat, __gisIdFld, vSeqNo);

                    //    object vFldVal = vGISUtil.getFieldValue(vFeat, "ObjectId");
                    //    updGrdVals(vFldVal.ToString(), vSeqNo);

                    //    vFeatCur.UpdateFeature(vFeat);
                    //}

                    vObjVal = vGISUtil.getFieldValue(vFeat, __gisIdFld);
                    if (!(vObjVal is System.DBNull))
                    {
                        int vGisId = (Int32)vObjVal;
                        if (vGisId == 0)
                        {
                            vSeqNo = getSeqNo();
                            vGISUtil.setFieldValue(vFeat, __gisIdFld, vSeqNo);

                            object vFldVal = vGISUtil.getFieldValue(vFeat, "ObjectId");
                            updGrdVals(vFldVal.ToString(), vSeqNo);

                            vFeatCur.UpdateFeature(vFeat);

                        }
                    }

                    //20160920

                    vFeat = vFeatCur.NextFeature();
                }
                DbDisConn();
                //vFeatCur.Flush();
                //dtGrdLst.Rows.Clear();

                vWrkSpcEdt.StopEditOperation();
                //LoadFeatCur(vUpdFeatCur);
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(vFeatCur);
                vFeatCur = null;
                vFeat = null;

                btnGen.Enabled = false;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
