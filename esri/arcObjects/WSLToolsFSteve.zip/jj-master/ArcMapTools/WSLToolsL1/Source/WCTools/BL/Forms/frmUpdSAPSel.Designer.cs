﻿namespace WCTools.BL.Forms
{
    partial class frmUpdSAPSel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.wATSAPBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gISNet1DataSet = new WCTools.GISNet1DataSet();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnCls = new System.Windows.Forms.Button();
            this.btnSel = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.wAT_SAPTableAdapter = new WCTools.GISNet1DataSetTableAdapters.WAT_SAPTableAdapter();
            this.dtGrdLstAttr = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wATSAPBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gISNet1DataSet)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdLstAttr)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(587, 68);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dtGrdLstAttr);
            this.panel2.Location = new System.Drawing.Point(0, 75);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(587, 287);
            this.panel2.TabIndex = 1;
            // 
            // wATSAPBindingSource
            // 
            this.wATSAPBindingSource.DataMember = "WAT_SAP";
            this.wATSAPBindingSource.DataSource = this.gISNet1DataSet;
            // 
            // gISNet1DataSet
            // 
            this.gISNet1DataSet.DataSetName = "GISNet1DataSet";
            this.gISNet1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnCls);
            this.panel3.Controls.Add(this.btnSel);
            this.panel3.Location = new System.Drawing.Point(0, 368);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(587, 62);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // btnCls
            // 
            this.btnCls.Location = new System.Drawing.Point(500, 22);
            this.btnCls.Name = "btnCls";
            this.btnCls.Size = new System.Drawing.Size(75, 23);
            this.btnCls.TabIndex = 1;
            this.btnCls.Text = "Close";
            this.btnCls.UseVisualStyleBackColor = true;
            this.btnCls.Click += new System.EventHandler(this.btnCls_Click);
            // 
            // btnSel
            // 
            this.btnSel.Location = new System.Drawing.Point(404, 22);
            this.btnSel.Name = "btnSel";
            this.btnSel.Size = new System.Drawing.Size(75, 23);
            this.btnSel.TabIndex = 0;
            this.btnSel.Text = "Select";
            this.btnSel.UseVisualStyleBackColor = true;
            this.btnSel.Click += new System.EventHandler(this.button1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 433);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(587, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // wAT_SAPTableAdapter
            // 
            this.wAT_SAPTableAdapter.ClearBeforeFill = true;
            // 
            // dtGrdLstAttr
            // 
            this.dtGrdLstAttr.AllowUserToAddRows = false;
            this.dtGrdLstAttr.AllowUserToDeleteRows = false;
            this.dtGrdLstAttr.AllowUserToResizeRows = false;
            this.dtGrdLstAttr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdLstAttr.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtGrdLstAttr.Location = new System.Drawing.Point(7, 19);
            this.dtGrdLstAttr.MultiSelect = false;
            this.dtGrdLstAttr.Name = "dtGrdLstAttr";
            this.dtGrdLstAttr.ReadOnly = true;
            this.dtGrdLstAttr.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGrdLstAttr.ShowEditingIcon = false;
            this.dtGrdLstAttr.Size = new System.Drawing.Size(572, 249);
            this.dtGrdLstAttr.TabIndex = 1;
            // 
            // frmUpdSAPSel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 455);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmUpdSAPSel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "SAP Attribute Select";
            this.Load += new System.EventHandler(this.frmUpdSAPSel_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.wATSAPBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gISNet1DataSet)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdLstAttr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button btnSel;
        private GISNet1DataSet gISNet1DataSet;
        private System.Windows.Forms.BindingSource wATSAPBindingSource;
        private GISNet1DataSetTableAdapters.WAT_SAPTableAdapter wAT_SAPTableAdapter;
        private System.Windows.Forms.Button btnCls;
        private System.Windows.Forms.DataGridView dtGrdLstAttr;
    }
}