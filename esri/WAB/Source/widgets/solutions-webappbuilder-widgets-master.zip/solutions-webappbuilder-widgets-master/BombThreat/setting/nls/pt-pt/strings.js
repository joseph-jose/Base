﻿define({
    left: "ã_LEFT_Ç",
    right: "ã_RIGHT_Ç",
    arrangement: "Pré-definição",
    autoUpdate: "Atualização Automática",
    respectCurrentMapScale: "Respeitar Atual Escala do Mapa"
});