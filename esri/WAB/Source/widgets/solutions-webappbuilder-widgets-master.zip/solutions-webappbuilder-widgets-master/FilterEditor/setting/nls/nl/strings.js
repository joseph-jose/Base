﻿define(
   ({
    enableUndoRedo: "Ongedaan maken/opnieuw uitvoeren inschakelen",
    toolbarVisible: "Werkbalk zichtbaar",
    toolbarOptions: "Werkbalkopties",
    mergeVisible: "Samenvoegen",
    cutVisible: "Knippen",
    reshapeVisible: "Vorm wijzigen",
    back: "Vorige",
    label: "Kaartlaag",
    edit: "Bewerkbaar",
    update: "Geometrie bijwerken uitschakelen",
    fields: "Velden",
    actions: "Acties",
    editpageName: "Naam",
    editpageAlias: "Alias",
    editpageVisible: "Zichtbaar",
    editpageEditable: "Bewerkbaar",
    noLayers: "Er zijn geen bewerkbare objectlagen beschikbaar",
    configureFields: "Laagvelden configureren"
  })
);