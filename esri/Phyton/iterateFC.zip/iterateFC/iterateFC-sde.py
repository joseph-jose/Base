import arcpy
import os
import datetime

FCs = r"C:\Users\jejyjose1\AppData\Roaming\ESRI\Desktop10.5\ArcCatalog\atalgissdbu01.Ac.sde"
arcpy.env.workspace = FCs
#fcList = arcpy.ListFeatureClasses('sde."AC.GISADMIN.AC".*', "", "")
fcList = arcpy.ListFeatureClasses()
#fcList = arcpy.ListFeatureClasses('"AC.GISADMIN.AC".*', "", "")
print(datetime.datetime.now())
for fc in fcList:
    #print(fc)
    fullName = arcpy.ParseTableName(fc)
    nameList = fullName.split(",")
    fcName = nameList[2]
    fcStr = str(fcName)
    print(fcStr)
    #print(fullName)
    result = arcpy.GetCount_management(fcStr)
    count = int(result.getOutput())
    print(count)
print(datetime.datetime.now())


