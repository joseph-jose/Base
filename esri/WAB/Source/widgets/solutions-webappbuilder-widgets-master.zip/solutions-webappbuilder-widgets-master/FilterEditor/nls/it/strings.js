﻿define(
   ({
    _widgetLabel: "Modifica",
    title: "Selezionare un modello per creare le feature",
    pressStr: "Premere ",
    ctrlStr: " CTRL ",
    snapStr: " per abilitare lo snap"
  })
);