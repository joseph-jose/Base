﻿define(
   ({
    enableUndoRedo: "אפשר ביטול שינויים/ביצוע מחדש",
    toolbarVisible: "סרגל כלים ניראה",
    toolbarOptions: "אפשרויות סרגל כלים",
    mergeVisible: "חיבור",
    cutVisible: "גזור",
    reshapeVisible: "עצב מחדש",
    back: "חזור",
    label: "שכבה",
    edit: "ניתן לעריכה",
    update: "חסום עדכון גיאומטריה",
    fields: "שדות",
    actions: "פעולות",
    editpageName: "שם",
    editpageAlias: "שם נוסף",
    editpageVisible: "ניראה",
    editpageEditable: "ניתן לעריכה",
    noLayers: "שכבות ישויות הניתנות לעריכה אינן זמינות",
    configureFields: "הגדר שדות שכבה"
  })
);