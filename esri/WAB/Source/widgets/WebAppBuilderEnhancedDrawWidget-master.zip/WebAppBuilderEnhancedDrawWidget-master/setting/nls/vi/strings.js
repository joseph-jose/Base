﻿define(
   ({
    addDistance: "Thêm Đơn vị Độ dài",
    addArea: "Thêm Đơn vị Diện tích",
    label: "Nhãn",
    abbr: "Viết tắt",
    conversion: "Chuyển đổi",
    actions: "Các hành động",
    areaUnits: "Đơn vị Diện tích",
    distanceUnits: "Đơn vị Độ dài",
    kilometers: "Kilômét",
    miles: "Dặm",
    meters: "Mét",
    feet: "Feet",
    yards: "Thước",
    squareKilometers: "Kilômét vuông",
    squareMiles: "Dặm vuông",
    acres: "Mẫu Anh",
    hectares: "Hecta",
    squareMeters: "Mét vuông",
    squareFeet: "Feet vuông",
    squareYards: "Thước vuông",
    distance: "Khoảng cách",
    area: "Diện tích"
  })
);