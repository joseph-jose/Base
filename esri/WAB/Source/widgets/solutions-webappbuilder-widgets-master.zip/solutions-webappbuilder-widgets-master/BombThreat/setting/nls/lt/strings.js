﻿define({
    left: "Į_LEFT_š",
    right: "Į_RIGHT_š",
    arrangement: "Išdėstymas",
    autoUpdate: "Automatinis atnaujinimas",
    respectCurrentMapScale: "Atsižvelgti į dabartinio žemėlapio mastelį"
});