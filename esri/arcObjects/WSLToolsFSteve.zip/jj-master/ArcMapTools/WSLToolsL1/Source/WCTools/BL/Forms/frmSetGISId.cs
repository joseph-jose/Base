﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using ESRI.ArcGIS.ArcMap; 
using ESRI.ArcGIS.ArcMapUI; 
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;

namespace WCTools.BL.Forms
{
    public partial class frmSetGISId : Form
    {
        private IApplication vApp;
        public IApplication vAppMap { set {vApp = value ;}}

        private string vLogSessId="";
        public string vLogSessionId {set {vLogSessId = value ;} }
        private IFeature vSelFeat;


        private WCTools.BL.Classes.cUtilFile vUtilFile;
        private WCTools.BL.Classes.cUtilGIS vGISUtil;
        public frmSetGISId()
        {
            InitializeComponent();
        }
        public void helpersActivate()
        {
            vGISUtil = new Classes.cUtilGIS();
            vGISUtil.vAppMap = vApp; 

            vUtilFile = new Classes.cUtilFile();
            logNtry("WCTools", "SetGISId", "Start", vLogSessId, "TRC");
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "SetGISId", "End", vLogSessId, "TRC");
            vGISUtil.Dispose();
            vGISUtil = null;
            vUtilFile = null;
        }


        ~frmSetGISId()
        {
            helpersDeActivate();
        }

        //Logging values to the database
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            vUtilFile.logNtry(inCmdType, inMsg, inFld1, inSessId, inLogType );
        }

        //Get the sequence 3
        public int getSeqNo()
        {
            int resVal = -1;
            Classes.cDbSqlFile vGisDb = new Classes.cDbSqlFile()  ;
            Classes.cUtilFile vUtilFl = new Classes.cUtilFile();


            string vConnStr = "";
            //vConnStr = vConfig.ConnectionStrings.ConnectionStrings["GIS_Connection"].ConnectionString.ToString();
            vConnStr = vUtilFl.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_MstrDb"); 

            try
            {
                //vGisDb.__SqlSrvrInitCatalog = vPrvdrNm;
                //vGisDb.ConnectToDatabase(3, vConnStr, "", "", "");
                vGisDb.ConnectToDatabase(3, vConnStr); 
                if (vGisDb.Connected)
                {
                    DataTable vDtTbl = vGisDb.getDtTblRecs("select next value for GISNet1.giswsl.gisid_seq");

                    object vSeqVal = vDtTbl.Rows[0][0].ToString();
                    if (!(Convert.IsDBNull(vSeqVal)))
                    {
                        resVal = Convert.ToInt32(vSeqVal);
                    }
                }
                return resVal;
            }
            finally
            {
                vGisDb.Connected = false;
                vGisDb.Dispose();
                vGisDb = null;
                vUtilFl = null;
            }
        }

        //Set the field value
        //Set the GIS_ID or RGIS_ID
        public void setFldVal( int inVal)
        {
            //IFeature vFeat;
            //vFeat = vGisSelection.getSelectedFeatures().Next();
            IWorkspaceEdit vWrkSpcEdt = vGISUtil.getWrkSpcFFeature (vSelFeat);
            vWrkSpcEdt.StartEditOperation();

            int vFldIdx = vGISUtil.getFieldIdx(vSelFeat, "GIS_ID");
            if (vFldIdx == -1)
            {
                MessageBox.Show("GIS_ID field not present"); 
                //vFldIdx = vGISUtil.getFieldIdx(vSelFeat, "RGIS_ID");
                //if (!(vFldIdx == -1))
                //{
                //    vGISUtil.setFieldValue(vSelFeat, "RGIS_ID", inVal);
                //    logNtry("WCTools", "SetGISId", "RGIS_ID=" + inVal.ToString(), vLogSessId, "TRC");
                //}
            }
            else
            {
                vGISUtil.setFieldValue(vSelFeat, "GIS_ID", inVal);
                logNtry("WCTools", "SetGISId", "GIS_ID=" + inVal.ToString(), vLogSessId, "TRC");
            }

            vWrkSpcEdt.StopEditOperation();

        }

        //Load any validations
        public bool validateOnLoad()
        {
            bool vResFn = false;
            if (!(vGISUtil.getFeatureSelectCount() == 1))
            {
                MessageBox.Show("Select single feature");
                return vResFn;
            }
            IFeature vFeat;
            IEnumFeature vEnmFeat = vGISUtil.getSelectedFeatures();
            vEnmFeat.Reset();
            vFeat = vEnmFeat.Next();
            IWorkspaceEdit vWrkSpcEdit = vGISUtil.getWrkSpcFFeature(vFeat);
            if (!(vWrkSpcEdit.IsBeingEdited()))
            {
                MessageBox.Show("Feature not in edit mode");
                return vResFn;
            }

            IDataset vDtSet = null;
            vDtSet = vFeat.Table as IDataset;
            if (vDtSet.Category.ToString().IndexOf("SDE") == -1)
            {
                MessageBox.Show("Layer selected should belong to a geodatabase");
                return vResFn;
            }

            object vObjVal ;
            int vFldIdx;
            vFldIdx = vGISUtil.getFieldIdx(vFeat, "GIS_ID");
            if (!(vFldIdx == -1))
            {
                //vFldIdx = vGISUtil.getFieldIdx(vFeat, "GIS_ID");
                //if (vFldIdx == -1)
                //{
                //    MessageBox.Show("Attribute GIS_ID missing for feature");
                //    return vResFn;
                //}
                vObjVal = vGISUtil.getFieldValue(vFeat, "GIS_ID");
            }
            else
            {
                MessageBox.Show("Attribute GIS_ID missing for feature");
                return vResFn;
                //vFldIdx = vGISUtil.getFieldIdx(vFeat, "RGIS_ID");
                //if (vFldIdx == -1)
                //{
                //    MessageBox.Show("Attribute GIS_ID missing for feature");
                //    return vResFn;
                //}
                //else
                //    vObjVal = vGISUtil.getFieldValue(vFeat, "RGIS_ID");
            }
            if (!(vObjVal is System.DBNull))
            {
                int vGisId = (Int32)vObjVal;
                if (vGisId > 0)
                {
                    MessageBox.Show("Attribute GIS-Id already set for feature");
                    return vResFn;
                }
            }
            vSelFeat = vFeat;

            vResFn = true;
            return vResFn;
        }

        public void setLblMsg(string inStr)
        {
            lblMsg.Text = inStr;
        }

        private void frmSetGISId_Load(object sender, EventArgs e)
        {
            txtGISId.Text = DateTime.Now.ToLongDateString();  
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void btnSetId_Click(object sender, EventArgs e)
        {
        }
    }
}
