﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace LabBackOffice
{
    public partial class FrmDataMain : Form
    {
        string cUrlStr = "";
        public FrmDataMain()
        {
            InitializeComponent();

        }

        private void FrmDataMain_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void downloadFile(string inUrl, string inFlLoc)
        {
            using (WebClient vWClnt = new WebClient())
            {
                vWClnt.Proxy = WebRequest.DefaultWebProxy;
                vWClnt.Proxy.Credentials = CredentialCache.DefaultCredentials;
                //Get request
                vWClnt.DownloadFile(inUrl, inFlLoc);
            }
        }

        private string delLocationObj(int inVal)
        {
            string vUrlStr = cUrlStr + "deleteFeatures?objectIds={0}&f=pjson";
            vUrlStr = string.Format(cUrlStr, inVal);
            using (HttpClientHandler vClntHndlr = new HttpClientHandler())
            {
                vClntHndlr.Proxy = WebRequest.DefaultWebProxy;
                vClntHndlr.Proxy.Credentials = CredentialCache.DefaultCredentials;
                using (var client = new HttpClient(vClntHndlr))
                {
                    var urlParams = new Dictionary<string, string>
                    {
                        { "objectIds" , inVal.ToString() },
                        { "f" , "pjson"}
                    };
                    var vUrlContd = new FormUrlEncodedContent(urlParams);

                    System.Threading.Tasks.Task<HttpResponseMessage> vTskRespMsg = client.DeleteAsync(vUrlStr);


                    HttpResponseMessage vHttpResp = vTskRespMsg.Result;

                    return vHttpResp.ToString();
                }
            }
        }
        private void xtrctMainCont()
        {
            LstBxStat.Items.Add("Starting pooling....");

            WebClient vWClnt = new WebClient();
            vWClnt.Proxy = WebRequest.DefaultWebProxy;
            vWClnt.Proxy.Credentials = CredentialCache.DefaultCredentials;
            //Get request
            string vRetStr = vWClnt.DownloadString(txtJsonPath.Text + txtDwnldCond.Text);
            textBox2.Text = vRetStr;
            LstBxStat.Items.Add("User attribute extraction...Success");

            //Extract it to hash table
            Hashtable vHshtable = (Hashtable)Procurios.Public.JSON.JsonDecode(vRetStr);
            //Get the features node
            ArrayList vFeatItms = (ArrayList)vHshtable["features"];

            DateTime vUnxDtTime;
            double vUnxDbl;
            //for each feature
            for (int i = 0; i < vFeatItms.Count; i++)
            {
                Hashtable vFeature = (Hashtable)vFeatItms[i];
                //get the attributes
                Hashtable vAttrItms = (Hashtable)vFeature["attributes"];
                //extract each attribute
                string vObjId = (vAttrItms["OBJECTID"] == null) ? "" : vAttrItms["OBJECTID"].ToString();
                string vMethaneReading = (vAttrItms["MethaneReading"] == null) ? "" : vAttrItms["MethaneReading"].ToString();
                string vUniqueID = (vAttrItms["UniqueID"] == null) ? "" : vAttrItms["UniqueID"].ToString();
                string vMisc = (vAttrItms["Misc"] == null) ? "" : vAttrItms["Misc"].ToString();
                //string vEditDate = (vAttrItms["EditDate"] == null) ? "" : vAttrItms["EditDate"].ToString();
                string vEditDate = "";
                if (!(vAttrItms["EditDate"] == null))
                {
                    double.TryParse(vAttrItms["EditDate"].ToString(), out vUnxDbl);
                    vUnxDtTime = Procurios.Public.JSON.UnixTimeStampToDateTime2(vUnxDbl);
                    vEditDate = vUnxDtTime.ToString("dd-mmm-yyyy");
                }
                string vEditor = (vAttrItms["Editor"] == null) ? "" : vAttrItms["Editor"].ToString();
                string vCreationDate = (vAttrItms["CreationDate"] == null) ? "" : vAttrItms["CreationDate"].ToString();
                string vDescription = (vAttrItms["Description"] == null) ? "" : vAttrItms["Description"].ToString();
                string vObservation = (vAttrItms["Observation"] == null) ? "" : vAttrItms["Observation"].ToString();
                string vCreator = (vAttrItms["Creator"] == null) ? "" : vAttrItms["Creator"].ToString();
                string vGlobalId = (vAttrItms["GlobalID"] == null) ? "" : vAttrItms["GlobalID"].ToString();
                //get the geometry
                vAttrItms = (Hashtable)vFeature["geometry"];
                //extract geometry
                string vx = (vAttrItms["x"] == null) ? "" : vAttrItms["x"].ToString();
                string vy = (vAttrItms["y"] == null) ? "" : vAttrItms["y"].ToString();

                switch (vObservation)
                {
                    case "0":
                        vObservation = "None";
                        break;
                    case "1":
                        vObservation = "Biosolids exposure or leachate outbreak";
                        break;
                    case "2":
                        vObservation = "Cracking/subsidence/erosion";
                        break;
                    case "3":
                        vObservation = "Dead vegetation";
                        break;
                    case "4":
                        vObservation = "Ponding/evidence of surface water";
                        break;
                    case "5":
                        vObservation = "Soft ground";
                        break;
                }

                dataGridView1.Rows.Add(vObjId, vUniqueID, vMethaneReading, vObservation, vDescription, vMisc, vx, vy, vEditDate, vEditor, vCreationDate, vCreator, vGlobalId);

            }

            LstBxStat.Items.Add("Deconstructing User attribute ...Success");

        }

        private void xtrctAttchData()
        {
            string vObjIds = "";
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                if (!(vObjIds == ""))
                {
                    vObjIds = vObjIds + ",";
                }
                vObjIds = vObjIds + dataGridView1.Rows[i].Cells[0].Value.ToString();
            }

            //string vUrlStr = cUrlStr + "queryAttachments?objectIds={0}&f=pjson&token=";
            string vUrlStr = cUrlStr + txtAttchCond.Text;

            vUrlStr = string.Format(vUrlStr, vObjIds);
            textBox3.Text = vUrlStr; 

            LstBxStat.Items.Add("Formatting photo attribute...Success");


            Queue<object> vQAttchInfo = new Queue<object>();

            WebClient vWbClnt2 = new WebClient();
            vWbClnt2.Proxy = WebRequest.DefaultWebProxy;
            vWbClnt2.Proxy.Credentials = CredentialCache.DefaultCredentials;
            textBox4.Text = vWbClnt2.DownloadString(textBox3.Text);
            LstBxStat.Items.Add("Extracting photo attribute...Success");

            Hashtable vHshtable = (Hashtable)Procurios.Public.JSON.JsonDecode(textBox4.Text);
            //Get the features node
            ArrayList vFeatItms = (ArrayList)vHshtable["attachmentGroups"];

            //for each feature
            for (int i = 0; i < vFeatItms.Count; i++)
            {
                Hashtable vFeature = (Hashtable)vFeatItms[i];
                //get the attributes
                string vParObjId = (vFeature["parentObjectId"] == null) ? "" : vFeature["parentObjectId"].ToString();

                ArrayList vAttchArrInfo = (ArrayList)vFeature["attachmentInfos"];

                Hashtable vAttchInfo = (Hashtable)vAttchArrInfo[0];
                //extract each attribute
                string vId = (vAttchInfo["id"] == null) ? "" : vAttchInfo["id"].ToString();
                vQAttchInfo.Enqueue(new Tuple<string, string>(vParObjId, vId));

                //LstBxStat.Items.Add(vParObjId + ";" + vId);


                if (vAttchArrInfo.Count > 1)
                {
                   vAttchInfo = (Hashtable)vAttchArrInfo[1];
                    //extract each attribute
                    vId = (vAttchInfo["id"] == null) ? "" : vAttchInfo["id"].ToString();
                    vQAttchInfo.Enqueue(new Tuple<string, string>(vParObjId, vId));

                    //LstBxStat.Items.Add(vParObjId + ";" + vId);

                }
            }
            LstBxStat.Items.Add("Deconstructing photo attribute...Success");
            populategrid(vQAttchInfo);
            vQAttchInfo.Clear();
            vQAttchInfo = null;
            LstBxStat.Items.Add("Populating photo attribute...Success");
        }

        private void xtrctLocations()
        {
            LstBxStat.Items.Add("Starting pooling, Locations....");


            WebClient vWClnt = new WebClient();
            vWClnt.Proxy = WebRequest.DefaultWebProxy;
            vWClnt.Proxy.Credentials = CredentialCache.DefaultCredentials;
            //Get request
            string vRetStr = vWClnt.DownloadString(txtWalkPath.Text);

            textBox2.Text = vRetStr;
            //Extract it to hash table
            Hashtable vHshtable = (Hashtable)Procurios.Public.JSON.JsonDecode(vRetStr);
            //Get the features node
            ArrayList vFeatItms = (ArrayList)vHshtable["features"];
            LstBxStat.Items.Add("Location attribute extraction...Success");

            //for each feature
            for (int i = 0; i < vFeatItms.Count; i++)
            {
                Hashtable vFeature = (Hashtable)vFeatItms[i];
                //get the attributes
                Hashtable vAttrItms = (Hashtable)vFeature["attributes"];
                //extract each attribute
                string vObjId = (vAttrItms["OBJECTID"] == null) ? "" : vAttrItms["OBJECTID"].ToString();



                //get the geometry
                vAttrItms = (Hashtable)vFeature["geometry"];
                //extract geometry
                string vx = (vAttrItms["x"] == null) ? "" : vAttrItms["x"].ToString();
                string vy = (vAttrItms["y"] == null) ? "" : vAttrItms["y"].ToString();

                dataGridView2.Rows.Add(vObjId, vx, vy);
            }
            LstBxStat.Items.Add("Deconstructing Location attribute ...Success");

        }

        //TODO - only first photo being saved
        private void populategrid(Queue<object> inQueue)
        {
            string vObjId = "";
            string vPhtStr = "";
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                vObjId = dataGridView1.Rows[i].Cells[0].Value.ToString();
                foreach (object v in inQueue)
                {
                    string p1 = ((Tuple<string, string>)v).Item1.ToString();
                    string p2 = ((Tuple<string, string>)v).Item2.ToString();
                    if (p1 == vObjId)
                    {
                        if (dataGridView1.Rows[i].Cells[13].Value  == null)
                        {
                            dataGridView1.Rows[i].Cells[13].Value = p1;
                            dataGridView1.Rows[i].Cells[14].Value = p2;
                            vPhtStr = cUrlStr + "{0}/attachments/{1}";
                            vPhtStr = string.Format(vPhtStr, p1, p2);

                            dataGridView1.Rows[i].Cells[15].Value = vPhtStr;
                        }
                        else
                        {
                            if (dataGridView1.Columns.Count == 16)
                            {
                                dataGridView1.Columns.Add("Column17", "Photo2Id");
                                dataGridView1.Columns.Add("Column18", "Photo2Val");
                                dataGridView1.Columns.Add("Column19", "Photo2Url");
                            }
                            dataGridView1.Rows[i].Cells[dataGridView1.Columns.Count - 3].Value = p1;
                            dataGridView1.Rows[i].Cells[dataGridView1.Columns.Count - 2].Value = p2;
                            vPhtStr = cUrlStr + "{0}/attachments/{1}";
                            vPhtStr = string.Format(vPhtStr, p1, p2);


                            dataGridView1.Rows[i].Cells[dataGridView1.Columns.Count - 1].Value = vPhtStr;

                        }
                        break;
                    }
                }
            }
        }

        private void setupFrm()
        {
            //dataGridView1.Columns[0].HeaderText = "ObjectID";
            //dataGridView1.Columns[0].Visible = false;
            //dataGridView1.Columns[1].HeaderText = "MethaneReading";
            //dataGridView1.Columns[2].HeaderText = "UniqueID";
            //dataGridView1.Columns[3].HeaderText = "Misc";
            //dataGridView1.Columns[4].HeaderText = "EditDate";
            ////dataGridView1.Columns[4].Visible = false;
            //dataGridView1.Columns[5].HeaderText = "Editor";
            ////dataGridView1.Columns[5].Visible = false;
            //dataGridView1.Columns[6].HeaderText = "CreationDate";
            ////dataGridView1.Columns[6].Visible = false;
            //dataGridView1.Columns[7].HeaderText = "Description";
            //dataGridView1.Columns[8].HeaderText = "Observation";
            //dataGridView1.Columns[9].HeaderText = "Creator";
            ////dataGridView1.Columns[9].Visible = false;
            //dataGridView1.Columns[10].HeaderText = "GlobalId";
            ////dataGridView1.Columns[10].Visible = false;
            //dataGridView1.Columns[11].HeaderText = "X";
            //dataGridView1.Columns[12].HeaderText = "Y";
            //dataGridView1.Columns[13].HeaderText = "parentObjectId";
            ////dataGridView1.Columns[13].Visible = false;
            //dataGridView1.Columns[14].HeaderText = "PhotoId";
            ////dataGridView1.Columns[14].Visible = false;
            //dataGridView1.Columns[15].HeaderText = "Url";
            dataGridView1.Columns[0].HeaderText = "ObjectID";
            //dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].HeaderText = "UniqueID";
            dataGridView1.Columns[2].HeaderText = "MethaneReading";
            dataGridView1.Columns[3].HeaderText = "Observation";
            dataGridView1.Columns[4].HeaderText = "Description";
            dataGridView1.Columns[5].HeaderText = "Misc";
            dataGridView1.Columns[6].HeaderText = "X";
            dataGridView1.Columns[7].HeaderText = "Y";
            dataGridView1.Columns[8].HeaderText = "EditDate";
            //dataGridView1.Columns[8].Visible = false;
            dataGridView1.Columns[9].HeaderText = "Editor";
            //dataGridView1.Columns[9].Visible = false;
            dataGridView1.Columns[10].HeaderText = "CreationDate";
            //dataGridView1.Columns[10].Visible = false;
            dataGridView1.Columns[11].HeaderText = "Creator";
            //dataGridView1.Columns[11].Visible = false;
            dataGridView1.Columns[12].HeaderText = "GlobalId";
            //dataGridView1.Columns[12].Visible = false;
            dataGridView1.Columns[13].HeaderText = "parentObjectId";
            //dataGridView1.Columns[13].Visible = false;
            dataGridView1.Columns[14].HeaderText = "PhotoId";
            dataGridView1.Columns[14].Visible = false;
            dataGridView1.Columns[15].HeaderText = "Url";
            dataGridView1.Columns[15].Visible = false;

            dataGridView2.Columns[0].HeaderText = "ObjectID";
            dataGridView2.Columns[1].HeaderText = "X";
            dataGridView2.Columns[2].HeaderText = "Y";

        }

        private void FrmDataMain_Load(object sender, EventArgs e)
        {
            setupFrm();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnXtrct_Click(object sender, EventArgs e)
        {
            if (txtJsonPath.Text == "")
            {
                LstBxStat.Items.Add("JSON path not specified");
                return;
            }
            cUrlStr = txtJsonPath.Text; 
            this.Cursor = Cursors.WaitCursor;

            LstBxStat.Items.Clear();
            dataGridView1.Rows.Clear();

            LstBxStat.Items.Add(string.Format("STARTING PROCESS..:{0}", DateTime.Now.ToString("dd/MMM/yyyy,hh:mm:ss")));
            try
            {
                xtrctMainCont();
                xtrctAttchData();
                xtrctLocations();

                btnXtrct.Enabled = false ;
                btnDwnld.Enabled = true; 
            }
            catch (Exception ex)
            {
                LstBxStat.Items.Add(string.Format( "EXCEPTIONS ENCOUNTERED..{0}:{1}" , ex.Message.ToString(), DateTime.Now.ToString("dd/MMM/yyyy,hh:mm:ss")));
            }
            finally
            {
                LstBxStat.Items.Add(string.Format("FINISHING PROCESS..:{0}", DateTime.Now.ToString("dd/MMM/yyyy,hh:mm:ss")));
                this.Cursor = Cursors.Default; 
            }        

        }

        private void DwnLoadAttchmnet(string inFilePath)
        {
            string vItemId = "";
            string vFlname = "";
            if (!(Directory.Exists(inFilePath + "\\images\\")))
            {
                Directory.CreateDirectory(inFilePath + "\\images\\");
            }

            for (int vI = 0; vI < dataGridView1.Rows.Count; vI++)
            {
                vItemId = (dataGridView1.Rows[vI].Cells[15].Value == null) ? "" : dataGridView1.Rows[vI].Cells[15].Value.ToString();
                vFlname = (dataGridView1.Rows[vI].Cells[1].Value == null) ? "" : dataGridView1.Rows[vI].Cells[1].Value.ToString();
                vFlname = inFilePath + "\\images\\" + vFlname + ".jpg";
                if (!(vItemId == ""))
                {
                    downloadFile(vItemId, vFlname);
                    Application.DoEvents();
                    Thread.Sleep(3000);
                }
            }
        }
        private void DwnloadOutput(string inFilePath)
        {
            string colSep = txtColSep.Text;

            string vFileLoc = inFilePath + string.Format("\\ExportedCSV-{0}.txt", DateTime.Now.ToString("yyyyMMMdd"));
            using (StreamWriter vStrmWrtr = new StreamWriter(vFileLoc))
            {
                string vFlContds = "";
                for (int vJ = 0; vJ < dataGridView1.Columns.Count; vJ++)
                {
                    if (dataGridView1.Columns[vJ].Visible == true)
                    {
                        if (!(vFlContds == ""))
                        {
                            vFlContds = vFlContds + colSep;
                        }
                        vFlContds = vFlContds + dataGridView1.Columns[vJ].HeaderText;
                    }
                }
                //LstBxStat.Items.Add(vFlContds);
                vStrmWrtr.WriteLine(vFlContds);

                vFlContds = "";
                string itemVal = "";
                for (int vI = 0; vI < dataGridView1.Rows.Count; vI++)
                {
                    vFlContds = "";
                    for (int vJ = 0; vJ < dataGridView1.Columns.Count; vJ++)
                    {
                        if (dataGridView1.Columns[vJ].Visible == true)
                        {
                            itemVal = (dataGridView1.Rows[vI].Cells[vJ].Value == null) ? "" : dataGridView1.Rows[vI].Cells[vJ].Value.ToString();
                            if (!(vFlContds == ""))
                            {
                                vFlContds = vFlContds + colSep;
                            }
                            vFlContds = vFlContds + itemVal;
                            //string vObjId = (vAttrItms["OBJECTID"] == null) ? "" : vAttrItms["OBJECTID"].ToString();
                        }
                    }
                    //LstBxStat.Items.Add(vFlContds);
                    vStrmWrtr.WriteLine(vFlContds);
                }
                vStrmWrtr.Close();
            }
        }

        private void btnDwnld_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                using (FolderBrowserDialog vFldrDlg = new FolderBrowserDialog())
                {
                    vFldrDlg.Description = "Select directory";
                    vFldrDlg.RootFolder = Environment.SpecialFolder.MyComputer;
                    if (vFldrDlg.ShowDialog() == DialogResult.OK)
                    {
                    DwnloadOutput(vFldrDlg.SelectedPath);
                    DwnLoadAttchmnet(vFldrDlg.SelectedPath);
                    }
                    MessageBox.Show("Export completed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exceptions occured-" + ex.Message.ToString());
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void txtColSep_MouseHover(object sender, EventArgs e)
        {
        }
    }
}
