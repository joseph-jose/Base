﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace WCToolsNA.BL.Classes
{
    class cUtilFile 
    {
        public Configuration getConfig()
        {   
            System.Configuration.ExeConfigurationFileMap vFileMap = new ExeConfigurationFileMap();            
            vFileMap.ExeConfigFilename = this.GetType().Assembly.Location + ".config";
            Configuration vConfig = ConfigurationManager.OpenMappedExeConfiguration(vFileMap, ConfigurationUserLevel.None);
            return vConfig;
            //ExeConfigurationFilemap vFlMap
        }

        private void ConfigWrite(string inCfgPath, string inCfgStr, string inCfgVal)
        {
            //'Dim __vCfgFname As String = Path.GetDirectoryName(Application.ExecutablePath) + "\EFL.config"
            string __vCfgFname = inCfgPath;    //+ "\EFL.config";
            ExeConfigurationFileMap __vCfgFlMap = new ExeConfigurationFileMap();
            __vCfgFlMap.ExeConfigFilename = __vCfgFname;
            Configuration __vCfg = ConfigurationManager.OpenMappedExeConfiguration(__vCfgFlMap, ConfigurationUserLevel.None);
            if ((__vCfg.AppSettings.Settings[inCfgStr] == null))
            {
                __vCfg.AppSettings.Settings.Add(inCfgStr, inCfgVal);
                __vCfg.Save(ConfigurationSaveMode.Modified);
            }
            else
            {
                __vCfg.AppSettings.Settings[inCfgStr].Value = inCfgVal;
                __vCfg.Save(ConfigurationSaveMode.Modified);
            }
        }

        public string ConfigRead(string inCfgPath, string inCfgStr)
        {
            string __ResStr = "";

            //'Dim __vCfgFname As String = Path.GetDirectoryName(Application.ExecutablePath) + "\EFL.config"
            string __vCfgFname = inCfgPath;    //+ "\EFL.config";
            ExeConfigurationFileMap __vCfgFlMap = new ExeConfigurationFileMap();
            __vCfgFlMap.ExeConfigFilename = __vCfgFname;
            Configuration __vCfg = ConfigurationManager.OpenMappedExeConfiguration(__vCfgFlMap, ConfigurationUserLevel.None);
            if (!(__vCfg.AppSettings.Settings[inCfgStr] == null))
            {
                __ResStr = __vCfg.AppSettings.Settings[inCfgStr].Value;
            }
            return __ResStr;
        }

        public string ConfigDbRead(string inCfgPath, string inCfgStr)
        {
            string __ResStr = "";

            //'Dim __vCfgFname As String = Path.GetDirectoryName(Application.ExecutablePath) + "\EFL.config"
            string __vCfgFname = inCfgPath;    //+ "\EFL.config";
            ExeConfigurationFileMap __vCfgFlMap = new ExeConfigurationFileMap();
            __vCfgFlMap.ExeConfigFilename = __vCfgFname;
            Configuration __vCfg = ConfigurationManager.OpenMappedExeConfiguration(__vCfgFlMap, ConfigurationUserLevel.None);
            if (!(__vCfg.ConnectionStrings.ConnectionStrings[inCfgStr] == null))
            {
                __ResStr = __vCfg.ConnectionStrings.ConnectionStrings[inCfgStr].ConnectionString.ToString();
            }
            return __ResStr;
        }

        public string getCfgFilePth()
        {
            string resStr = "";
            Configuration vCfg = getConfig();
            resStr = vCfg.AppSettings.Settings["ConfigPath"].Value;

            return resStr;
        }

        public string getCfgFilePth(string keyName)
        {
            string resStr = "";
            Configuration vCfg = getConfig();
            resStr = vCfg.AppSettings.Settings[keyName].Value;
            return resStr;
        }

        public void logNtry(string inCmdType, string inMsg = "", string inFld1 = "", string inSessId = "", string inLogType = "")
        {
            string vSqlStr = "Insert into GISADMin.giswsl.WA_AppLogs (CurrUsr, CmdType, LogType, Msg, Fld1, Fld10) values ('{0}','{1}','{2}','{3}','{4}','{5}')";
            vSqlStr = string.Format(vSqlStr, Environment.UserName.ToString(), inCmdType, inLogType, inMsg, inFld1, inSessId);

            //Configuration vConfig = getConfig();
            //string vConnStr = vConfig.ConnectionStrings.ConnectionStrings["GISAdminConnection"].ConnectionString.ToString();
            string vConnStr = getCfgFilePth();
            vConnStr = ConfigDbRead(vConnStr, "GIS_Connection_RepDb");

            using (cDbSqlFile vDbFile = new cDbSqlFile())
            {
                try
                {
                    vDbFile.ConnectToDatabase(3, vConnStr);
                    if (vDbFile.Connected)
                    {
                        vDbFile.execQry(vSqlStr);
                    }
                }
                finally
                {
                    vDbFile.Connected = false;
                }
            }
        }

        public bool logNtry(cDbFile inDbFile, string inCmdType, string inMsg = "", string inFld1 = "", string inSessId = "", string inLogType = "")
        {
            bool retRes = false;
            string vSqlStr = "Insert into GISADMin.giswsl.WA_AppLogs (CurrUsr, CmdType, LogType, Msg, Fld1, Fld10) values ('{0}','{1}','{2}','{3}','{4}','{5}')";
            vSqlStr = string.Format(vSqlStr, Environment.UserName.ToString(), inCmdType, inLogType, inMsg, inFld1, inSessId);

            if (inDbFile.Connected)
            {
                inDbFile.execQry(vSqlStr);
                retRes = true;
            }
            return retRes;
        }

        public bool logTxtNtry(string inCmdType, string inMsg = "", string inFld1 = "", string inSessId = "", string inLogType = "")
        {
            bool retRes = false;

            string vFlPath = getCfgFilePth();
            vFlPath = ConfigRead(vFlPath, "LogPath");

            string vSqlStr = "(CurrUsr, CmdType, LogType, Msg, Fld1, Fld10) values ('{0}','{1}','{2}','{3}','{4}','{5}')";
            vSqlStr = string.Format(vSqlStr, Environment.UserName.ToString(), inCmdType, inLogType, inMsg, inFld1, inSessId);

            if (!(System.IO.Directory.Exists(vFlPath)))
                System.IO.Directory.CreateDirectory(vFlPath);
            vFlPath = vFlPath + "\\Logs" + DateTime.Today.ToString("yyyyMMdd") + ".txt";


            System.IO.StreamWriter vStrmWrtr = new System.IO.StreamWriter(vFlPath,true );
            vStrmWrtr.WriteLine(vSqlStr);
            vStrmWrtr.Close();
            vStrmWrtr.Dispose();

            retRes = true;
            return retRes;
        }

        public string ConnStrRectPssWrd(string inConnStr)
        {
            string vPsswrdStr = inConnStr.Split(';')[3];
            vPsswrdStr = vPsswrdStr.Substring(vPsswrdStr.IndexOf("=") + 1);

            string vModPsswrdStr = DeCryptStr(vPsswrdStr); // +"modified";
            inConnStr = inConnStr.Replace(vPsswrdStr, vModPsswrdStr);

            return inConnStr;
        }

        public string DeCryptStr(string inStr)
        {
            Byte[] vBytes = Convert.FromBase64String(inStr);
            //Byte[] vPsswrd = ProtectedData.Unprotect(vBytes, null, DataProtectionScope.LocalMachine);
            Byte[] vPsswrd = vBytes;
            return System.Text.Encoding.Unicode.GetString(vPsswrd);
        }

        public string EncryptStr(string inStr)
        {
            Byte[] vbytes = System.Text.Encoding.Unicode.GetBytes(inStr);
            //Byte[] vPsswrd = ProtectedData.Protect(vbytes, null, DataProtectionScope.LocalMachine);
            Byte[] vPsswrd = vbytes;
            return Convert.ToBase64String(vPsswrd);
        }

    }
}
