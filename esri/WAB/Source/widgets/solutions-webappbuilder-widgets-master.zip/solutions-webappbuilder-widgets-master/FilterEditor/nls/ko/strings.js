﻿define(
   ({
    _widgetLabel: "편집",
    title: "피처를 생성할 템플릿 선택",
    pressStr: "Ctrl을 ",
    ctrlStr: " 눌러 ",
    snapStr: " 스내핑 활성화"
  })
);