﻿define({
    left: "שמאל",
    right: "ימין",
    arrangement: "סידור",
    autoUpdate: "עדכונים אוטומטים",
    respectCurrentMapScale: "התחשב בקנה המידה הנוכחי של המפה"
});