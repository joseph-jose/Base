﻿using ESRI.ArcGIS.ADF;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace WCToolsBulk.BL.Classes
{
    class cUtilGIS : cGisBase 
    {
        public IMxDocument vAppDoc { get { return (IMxDocument)vAppMap.Document; } }

        #region "IDisposable Support "
        //'***************************************
        //'Clean up connection
        //'Always to be called before a connection is created
        //'***************************************
        public override void CleanUpDBConnection()
        {
        }
        #endregion

        #region "Selection"
        public int getFeatureSelectCount()
        {
            int resCnt = 0;

            resCnt =  vAppDoc.FocusMap.SelectionCount;

            return resCnt;
        }

        public IEnumFeature getSelectedFeatures()
        {
            IEnumFeature vEnmFeatures;

            vEnmFeatures = (IEnumFeature)vAppDoc.FocusMap.FeatureSelection;

            return vEnmFeatures;
        }

        public void SelectOnMap(IMxDocument pArcMxDocument , IFeatureLayer pArcFeatureLayer , string strSearch )
        {
            IFeatureSelection pArcFeatureSelection = null;
            IQueryFilter pArcQueryFilter = null;
            IActiveView pArcActiveView = null;
            IMap pArcMap = null;
            try
            {
                pArcMap = pArcMxDocument.FocusMap;
                pArcActiveView = pArcMxDocument.ActiveView ;

                pArcFeatureSelection = pArcFeatureLayer as IFeatureSelection;
                pArcQueryFilter = new QueryFilter();
                pArcQueryFilter.WhereClause = strSearch;

                pArcActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeoSelection, null, null);
                pArcFeatureSelection.SelectFeatures(pArcQueryFilter, esriSelectionResultEnum.esriSelectionResultNew, false);
                pArcActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeoSelection, null, null);
            }
            finally
            {
                Marshal.ReleaseComObject(pArcQueryFilter); 
            }

        }
        #endregion

        #region  "IWorkspaceEdit"
        public IWorkspaceEdit getWrkSpcFFeature(IFeature inFeature)
        {
            IDataset vDtSt;
            IWorkspaceEdit vWrkSpcEdt;
            try
            {
                vDtSt = inFeature.Table as IDataset;
                vWrkSpcEdt = vDtSt.Workspace as IWorkspaceEdit;
            }
            finally
            {
                vDtSt = null;
            }
            return vWrkSpcEdt;
        }
        //public IWorkspaceEdit getWrkSpcFLayer(IFeatureLayer inLyr)
        public IWorkspaceEdit getWrkSpcFLayer(IFeatureLayer inLyr)
        {
            IDataset vDtSt;
            IWorkspaceEdit vWrkSpcEdt;
            IFeatureClass vFeatCls;
            try
            {                
                vFeatCls = inLyr.FeatureClass;
                vDtSt = vFeatCls.FeatureDataset;
                //jjose 20150301    BugFix for people running GISId tool in personal database
                //vWrkSpcEdt = vDtSt.Workspace as IWorkspaceEdit;
                vWrkSpcEdt = null;
                if (!(vDtSt == null))
                {
                    vWrkSpcEdt = vDtSt.Workspace as IWorkspaceEdit;
                }
                //jjose 20150301
            }
            finally
            {
                vDtSt = null;
                vFeatCls = null;
            }
            return vWrkSpcEdt;
        }
        #endregion

        #region  "Attributes"
        public int getFieldIdx(IFeatureLayer inLyr, string inFldName)
        {
            ITable vTbl;
            int vFldIdx = -1;
            try
            {
                vTbl = inLyr.FeatureClass as ITable ;
                //vDtSt.
                if (!(vTbl == null))
                {
                    vFldIdx = vTbl.Fields.FindField(inFldName);
                }
            }
            finally
            {
                vTbl = null;
            }
            return vFldIdx;

        }
        public int  getFieldIdx(IFeature inFt, string inFldName)
        {
            return inFt.Fields.FindField(inFldName);
        }

        //public object getFieldValue(IFeatureLayer inLyr, string inFldName)
        //{
        //    object vretObj;

        //    //IRow vRow = inFt;
        //    //vretObj = vRow.Value[inFt.Fields.FindField(inFldName)];
        //    //return vretObj;

        //    ITable vTbl;
        //    int vFldIdx = -1;
        //    try
        //    {
        //        vTbl = inLyr.FeatureClass as ITable;
        //        if (!(vTbl == null))
        //        {
        //            vretObj = vTbl.Fields.  vRow.Value[vTbl.FindField(inFldName)]; 
        //        }
        //    }
        //    finally
        //    {
        //        vTbl = null;
        //    }

        //}
        public object getFieldValue(IFeature inFt, string inFldName)
        {
            object vretObj;
            IRow vRow = inFt;
            vretObj = vRow.Value[inFt.Fields.FindField(inFldName)];
            return vretObj;
        }

        //20150720  Domain check
        public void setFieldValue(IFeature inFt, string inFldName, object inObjVal)
        {
            //object vretObj;
            IRow vRow = inFt;

            vRow.Value[inFt.Fields.FindField(inFldName)] = inObjVal;
            vRow.Store();

        }

        public int setFieldWDomCheckValue(IFeature inFt, string inFldName, object inObjVal)
        {
            //object vretObj;
            int vResFn = -1;

            IRow vRow = inFt;

            //vRow.Value[inFt.Fields.FindField(inFldName)] = inObjVal;            

            int vCurrFldIdx = 0;
            vCurrFldIdx =  inFt.Fields.FindField(inFldName);
            if (!(vCurrFldIdx == -1))
            {
                IField vCurrFld = null;
                vCurrFld = inFt.Fields.Field[vCurrFldIdx];
                if (vCurrFld.Domain == null)
                {
                    vRow.Value[vCurrFldIdx] = inObjVal;
                    vRow.Store();
                    vResFn = 0;
                }
                else
                {
                    int vObjVal = 0;
                    if (!(vCurrFld.Domain.FieldType == esriFieldType.esriFieldTypeString))
                    {
                        vObjVal = Convert.ToInt32(inObjVal);
                        if (vCurrFld.Domain.MemberOf(vObjVal) == true)
                        {
                            vRow.Value[vCurrFldIdx] = vObjVal;
                            vRow.Store();
                            vResFn = 0;
                        }
                        else
                            vResFn = -3;
                    }
                    else
                    {
                        if (vCurrFld.Domain.MemberOf(inObjVal) == true)
                        {
                            vRow.Value[vCurrFldIdx] = inObjVal;
                            vRow.Store();
                            vResFn = 0;
                        }
                        else
                            vResFn = -3;
                    }
                }
            }
            else
            {
                vResFn = -2;
            }
            return vResFn ;
        }

        //20150720

        #endregion

        #region "AttributeSelect"
        public ICursor getQryFltr(ITable vTbl, string vStr)
        {
            ICursor vCursr;

            IQueryFilter vQryFltr = null;

            try
            {
                vQryFltr = new QueryFilter();
                vQryFltr.WhereClause = vStr;

                vCursr = vTbl.Search(vQryFltr, false);
            }
            finally
            {
                Marshal.ReleaseComObject(vQryFltr);
            }
            return vCursr;

        }

        public IFeatureCursor getQryFltr(IFeatureLayer vLyr, string vStr)
        {
            IFeatureCursor vFtCursr;

            IQueryFilter vQryFltr = null ;
            IFeatureClass vFtCls =  null ;

            try
            {
                vQryFltr = new QueryFilter();
                vQryFltr.WhereClause = vStr;
                vFtCls = vLyr.FeatureClass;

                vFtCursr = vFtCls.Search(vQryFltr, false);
            }
            finally
            {
                //vQryFltr = null;
                //vFtCls = null;
                Marshal.ReleaseComObject(vQryFltr);
                Marshal.ReleaseComObject(vFtCls);
            }
            return vFtCursr;
    
        }
        public IFeatureCursor getQryFltrFUpd(IFeatureLayer vLyr, string vStr)
        {
            IFeatureCursor vFtCursr;

            IQueryFilter vQryFltr = null;
            IFeatureClass vFtCls = null;

            try
            {
                vQryFltr = new QueryFilter();
                vQryFltr.WhereClause = vStr;
                vFtCls = vLyr.FeatureClass;

                vFtCursr = vFtCls.Update(vQryFltr, false);
            }
            finally
            {
                vQryFltr = null;
                vFtCls = null;
            }
            return vFtCursr;

        }
        public ICursor getQryJoin(IFeatureWorkspace inFeatWrkSpc, string inJoinTbls, string inJoinSelect, string inJoinCond)
        {
            ICursor vCursr = null;
            IQueryDef vQryDef = null;
            try
            {
                vQryDef = inFeatWrkSpc.CreateQueryDef();
                vQryDef.Tables = inJoinTbls;
                vQryDef.SubFields = inJoinSelect;
                vQryDef.WhereClause = inJoinCond;

                vCursr = vQryDef.Evaluate();
            }
            finally
            {
                Marshal.ReleaseComObject(vQryDef); 
            }
            return vCursr;
        }

        public ICursor getQryTbl(IFeatureWorkspace inFeatWrkSpc, string inTbl, string inFlds, string inWhrCond)
        {
            ICursor vCursr = null;
            IQueryFilter vQryFltr = null;
            try
            {
                    ITable vTbl ;
                    vTbl = inFeatWrkSpc.OpenTable(inTbl);

                    vQryFltr = new QueryFilter();
                    vQryFltr.WhereClause = inWhrCond;
                    vQryFltr.SubFields = inFlds;

                    vCursr = vTbl.Search(vQryFltr, false);
            }
            finally
            {
                Marshal.ReleaseComObject(vQryFltr);
            }
            return vCursr;
//Sub QryTbl()

//    Dim vDoc As IMxDocument
//    Set vDoc = ThisDocument
 
//    Dim vVw As IActiveView
//    Set vVw = vDoc.activeView
    
//    ' Get the TOC
//    Dim vIContentsView As IContentsView
//    Set vIContentsView = vDoc.CurrentContentsView
    
//    Dim layer As ILayer
//    If (TypeOf vIContentsView.selectedItem Is IFeatureLayer) Then
//        Set layer = vIContentsView.selectedItem
//        MsgBox layer.Name
//    End If
    
//    Dim featureWorkspace As IFeatureWorkspace

//    Dim vFeatLyr As IFeatureLayer
//    Set vFeatLyr = layer
//    Set featureWorkspace = vFeatLyr.FeatureClass.FeatureDataset.Workspace
    
//    Dim vTbl As ITable
//    Set vTbl = featureWorkspace.OpenTable("GISWSL.WAT_SAP")
    
//    Dim vQryFltr As IQueryFilter
//    Set vQryFltr = New QueryFilter
//    vQryFltr.WhereClause = "WAT_SAP.GISREF='PR11039'"
//    vQryFltr.SubFields = " GISWSL.WAT_SAP.Equipment, GISWSL.WAT_SAP.Equidescr, GISWSL.WAT_SAP.FACILITY, , GISWSL.WAT_SAP.PROCESS, , GISWSL.WAT_SAP.GROUPCODE, , GISWSL.WAT_SAP.DATEACQUIRED, , GISWSL.WAT_SAP.SAP_NOM_DIA_MM_TMP, SAP_STATUS_TMP, GIS_REF"
    
//    Dim vCrsr As ICursor
//    Set vCrsr = vTbl.Search(vQryFltr, False)
    
    
//    Dim altnameNameIndex, altEqpIdx As Integer
//    altnameNameIndex = vCrsr.FindField("Equidescr")
//    altEqpIdx = vCrsr.FindField("Equipment")
//'    Dim altnameTypeIndex As Integer
//'    altnameTypeIndex = cursor.FindField("GISWSL.WT_Pipe.ObjectId")
//    ' Use the cursor to step through the results, displaying the names and altnames of each
//    ' street.
    
//    Dim vEqpIdxs As String
    
//    Dim row As IRow
//    Set row = Nothing
//    Set row = vCrsr.NextRow()


//    Do While Not row Is Nothing
//        'Console.WriteLine("Street name: {0} {1}. - Alt. name: {2} {3}.", row.Value(streetsNameIndex), row.Value(streetsTypeIndex), row.Value(altnameNameIndex), row.Value(altnameTypeIndex))
//        'MsgBox row.Value(altnameNameIndex) 'row.Value(streetsNameIndex) + row.Value(streetsTypeIndex) + row.Value(altnameNameIndex) + row.Value(altnameTypeIndex)
//        If Not (vEqpIdxs = "") Then
//            vEqpIdxs = vEqpIdxs + ","
//        End If
//        vEqpIdxs = vEqpIdxs + CStr(row.Value(altEqpIdx))
//        Set row = vCrsr.NextRow()
//    Loop
    
//    vEqpIdxs = "EquipmentId in (" + vEqpIdxs + ")"
//    MsgBox vEqpIdxs
        }

        #endregion

        #region "Geometry"
        public IGeometry getBufferedGeom(IGeometry inGeom, double inBuff)
        {
            IGeometry vRetGeom = null;
            ITopologicalOperator vTpOprtr;
            vTpOprtr = null;
            try
            {
                vTpOprtr = inGeom as ITopologicalOperator;
                vRetGeom = vTpOprtr.Buffer(inBuff);
                return vRetGeom;
            }
            finally
            {
                Marshal.ReleaseComObject(vTpOprtr);
            }
        }
        #endregion

        #region Feature
        public bool CheckIfFeaturesTouch(IFeature inFeat1, IFeature inFeat2)
        {
            bool retVal = false;

            IGeometry vGeom1, vGeom2;
            vGeom1 = inFeat1.Shape  ;
            vGeom2 = inFeat2.Shape  ;

            IRelationalOperator vRelOp = null ;
            vRelOp = vGeom1 as IRelationalOperator ;
            if (vRelOp.Touches(vGeom2))
            {
                retVal = true ;
            }
            vRelOp = null;
            vGeom1 = null;
            vGeom2 = null;

            return retVal;
        }
        public bool CheckIfFeaturesTouchWTolerance(IFeature inFeat1, IFeature inFeat2, double inBuff)
        {
            bool retVal = false;

            IGeometry vGeom1, vGeom2, vBuffGeom;
            vGeom1 = inFeat1.Shape;
            vGeom2 = inFeat2.Shape;
            vBuffGeom = getBufferedGeom(vGeom1, 10);
            IRelationalOperator vRelOp = null;
            try
            {
                vRelOp = vBuffGeom as IRelationalOperator;
                if (vRelOp.Contains(vGeom2))
                {
                    retVal = true;
                }
            }
            finally
            {
                vGeom1 = null;
                vGeom2 = null;
                Marshal.ReleaseComObject(vRelOp);
            }


            return retVal;
        }

        #endregion

        #region Zoom


        public void ZoomToFeature(IFeature pArcFeature , IMxDocument pArcMxDocument )
        {
            //Applicable only to line and polygon features.For point features the map will recenter based on the feature.
            IDisplayTransformation pArcDisplayTransformation = null;
            IActiveView  pArcActiveView = null;
            IEnvelope pArcEnvelope = null;
            double dWidth , dHeight ;
            try
            {
                if (!(pArcFeature == null))
                {
                    pArcEnvelope = pArcFeature.Extent;
                    dWidth = pArcEnvelope.Width;
                    dHeight = pArcEnvelope.Height;
                    pArcActiveView = pArcMxDocument.ActiveView ; // .FocusMap;   //      'QI
                    pArcDisplayTransformation = pArcActiveView.ScreenDisplay.DisplayTransformation;
                    if ((dWidth == 0) || (dHeight == 0))
                    {
                        IPoint pPoint;
                        pPoint = pArcEnvelope.UpperLeft;
                        pArcEnvelope = pArcDisplayTransformation.VisibleBounds;
                        pArcEnvelope.CenterAt(pPoint);
                        pArcDisplayTransformation.VisibleBounds = pArcEnvelope;
                    }
                    else
                    {
                        pArcEnvelope.Expand(1.5, 1.5, true);
                        pArcActiveView.Extent = pArcEnvelope;
                    }
                    pArcActiveView.ScreenDisplay.Invalidate(pArcEnvelope, true, (short) esriScreenCache.esriAllScreenCaches);
                    //esriScreenCache.esriAllScreenCaches
                }
            }
            finally
            {
            }
        }
        #endregion

        #region "Layers"
        public ILayer getLayerByIdx(int inLyrIdx)
        {
            IMap vMap = null;

            IActiveView vActVw = vAppDoc.ActiveView;

            vMap = vActVw.FocusMap;
            return vMap.Layer[inLyrIdx];
 
        }

        public int getLayerIdxByName(string inLyrName)
        {
            IMap vMap = null;

            IActiveView vActVw = vAppDoc.ActiveView;
            int retIdx = -1;

            vMap = vActVw.FocusMap;
            for (int vI = 0; vI < vMap.LayerCount; vI++)
            {
                if (vMap.Layer[vI].Name.ToString() == inLyrName)
                {
                    retIdx = vI;
                }
            }
            return retIdx;

            //int vCurrIdx = 0;
            //IEnumLayer vLyrsInToc = getLyrsInTOC();
            //try
            //{
            //    ILayer vCurrLyr = null;

            //    vLyrsInToc.Reset();
            //    vCurrLyr = vLyrsInToc.Next();
            //    while (!(vCurrLyr == null))
            //    {
            //        if (vCurrLyr is IFeatureLayer)
            //        {
            //            if (vCurrLyr.Name == inLyrName)
            //            {
            //                break ;
            //            }
            //        }
            //        vCurrIdx = vCurrIdx + 1;
            //        vCurrLyr = vLyrsInToc.Next();
            //    }
            //    return vCurrIdx;
            //}
            //finally
            //{
            //    Marshal.ReleaseComObject(vLyrsInToc);
            //}
        }


        public ILayer getLayerByName(string inLyrName)
        {
            IEnumLayer vLyrsInToc = getLyrsInTOC();
            try
            {
                ILayer vCurrLyr = null;

                vLyrsInToc.Reset();
                vCurrLyr = vLyrsInToc.Next();
                while (!(vCurrLyr == null))
                {
                    if (vCurrLyr is IFeatureLayer)
                    {
                        if (vCurrLyr.Name == inLyrName)
                        {
                            break;
                        }
                    }
                    vCurrLyr = vLyrsInToc.Next();
                }
                return vCurrLyr;
            }
            finally
            {
                Marshal.ReleaseComObject(vLyrsInToc);
            }
        }

        public ILayer getSelItemInTOC()
        {
                ILayer vlayer = null ;
                IActiveView vActVw = vAppDoc.ActiveView;

                IContentsView IContentsView = vAppDoc.CurrentContentsView;
                System.Object  vSelItm = IContentsView.SelectedItem;
                if (vSelItm is ILayer)
                {
                    vlayer = vSelItm as ILayer;
                }
                return vlayer;
        }

        public IEnumLayer getLyrsInTOC()
        {
            IEnumLayer vEnumlayer = null;
            IMap vMap = null;

            IActiveView vActVw = vAppDoc.ActiveView;
            vMap = vActVw.FocusMap;
            vEnumlayer = vMap.get_Layers();

            return vEnumlayer;

            //if (layerIndex < map.LayerCount && map.get_Layer(layerIndex) is ESRI.ArcGIS.Carto.IFeatureLayer)
            //{
            //    return (ESRI.ArcGIS.Carto.IFeatureLayer)activeView.FocusMap.get_Layer(layerIndex); // Explicit Cast
            //}
            //else
            //{
            //    return null;
            //}
        }
        #endregion
    }
}
