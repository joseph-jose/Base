﻿define({
    select: "å_Select_ø",
    results: "å_Results_ø",
    selectLayer: "å_Select from layer:_ø",
    selectDrawtool: "å_Select draw tool:_ø",
    result: "å_Result:_ø",
    noresult: "å_No query results to display chart._ø",
    nomedia: "å_There's no media in configuration!_ø",
    envelop: "å_Draw Rectangle_ø",
    circle: "å_Draw Circle_ø",
    ellipse: "å_Draw Ellipse_ø",
    polygon: "å_Draw Polygon_ø",
    freehand: "å_Draw Freehand Polygon_ø",
    clear:"å_Clear_ø"
});