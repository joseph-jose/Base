﻿define({
    unit: "بيت_Unit_لاحقة",
    style: "بيت_Style_لاحقة"
});