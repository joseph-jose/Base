﻿define({
    left: "左",
    right: "右",
    arrangement: "配置",
    autoUpdate: "自動更新",
    respectCurrentMapScale: "現在のマップ縮尺に従う"
});