﻿define(
   ({
    _widgetLabel: "Edytuj",
    title: "Wybierz szablon, aby utworzyć obiekty",
    pressStr: "Naciśnij przycisk ",
    ctrlStr: " CTRL ",
    snapStr: " , aby włączyć dociąganie."
  })
);