define({
    root: {
        tabBombLocation: "Bomb Location",
        tabResults: "Results",
        selectType: "Select Bomb Type",
        drawPoint: "Draw Explosion Location",
        labelSolve: "Execute",
        labelClear: "Clear",
        labelSelectBombLocation: "Select Bomb Location",
        labelSelectCategoryType: "Select Category Type",
        noresult: "No query results to display"
    },
    "zh-cn": true
});