﻿define(
   ({
    _widgetLabel: "Koordinēt",
    hintMessage: "Noklikšķiniet uz kartes, lai iegūtu koordinātes",
    defaultLabel: "Noklusējums",
    realtimeLabel: "Pārvietojiet peli, lai iegūtu koordinātas",
    computing: "Notiek datu apstrāde...",
    latitudeLabel: "Platums",
    longitudeLabel: "Garums",
    loading: "notiek ielāde...",
    enableClick: "Noklikšķiniet, lai iespējotu klikšķināšanu kartē koordinātu iegūšanai",
    disableClick: "Noklikšķiniet, lai atspējotu klikšķināšanu kartē koordinātu iegūšanai",

    Default: "Noklusējums",
    Inches: "Collas",
    Foot: "Pēdas",
    Yards: "Jardi",
    Miles: "Jūdzes",
    Nautical_Miles: "Jūras jūdzes",
    Millimeters: "Milimetri",
    Centimeters: "Centimetri",
    Meter: "Metri",
    Kilometers: "Kilometri",
    Decimeters: "Decimetri",
    Decimal_Degrees: "Grādi",
    Degree_Minutes_Seconds: "Grādi minūtes sekundes",
    MGRS: "MGRS",
    USNG: "USNG"
  })
);
