﻿define(
   ({
    addDistance: "Legg til lengdeenhet",
    addArea: "Legg til arealenhet",
    label: "Etikett",
    abbr: "Forkortelse",
    conversion: "Konvertering",
    actions: "Handlinger",
    areaUnits: "Arealenheter",
    distanceUnits: "Lengdeenheter",
    kilometers: "Kilometer",
    miles: "Miles",
    meters: "Meter",
    feet: "Fot",
    yards: "Yards",
    squareKilometers: "Kvadratkilometer",
    squareMiles: "Kvadratmiles",
    acres: "Acre",
    hectares: "Hektar",
    squareMeters: "Kvadratmeter",
    squareFeet: "Kvadratfot",
    squareYards: "Kvadratyard",
    distance: "Avstander",
    area: "Areas"
  })
);