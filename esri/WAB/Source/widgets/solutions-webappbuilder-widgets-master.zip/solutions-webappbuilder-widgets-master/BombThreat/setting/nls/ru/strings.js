﻿define({
    left: "LEFT",
    right: "RIGHT",
    arrangement: "Расположение",
    autoUpdate: "Автообновление",
    respectCurrentMapScale: "Учитывать текущий масштаб карты"
});