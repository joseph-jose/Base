﻿define({
    left: "SOL",
    right: "SAĞ",
    arrangement: "Yerleştirme",
    autoUpdate: "Otomatik Güncelle",
    respectCurrentMapScale: "Geçerli Harita Ölçeğine Öncelik Ver"
});