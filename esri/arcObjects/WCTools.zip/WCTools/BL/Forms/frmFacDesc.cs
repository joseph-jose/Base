﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using WCTools.BL.Classes;



namespace WCTools.BL.Forms
{
    public partial class frmFacDesc : Form
    {
        private IApplication vApp;
        public IApplication vAppMap { set { vApp = value; } }
        private string vLogSessId = "";
        public string vLogSessionId { set { vLogSessId = value; } }

        WCTools.BL.Classes.cDbSqlFile vDbFile ;
        WCTools.BL.Classes.cUtilFile vUtilFile ;
        WCTools.BL.Classes.cUtilGIS vGISUtil;
        WCTools.BL.Classes.cDbSqlFile vDbNet1File;

        private IFeature vSelFeature;
        private DataRow vSelDataRow;

        public bool helpersActivate()
        {
            bool vBRes = true;
            vDbFile = new cDbSqlFile();
            vUtilFile = new cUtilFile();
            vGISUtil = new cUtilGIS() ;
            vDbNet1File = new cDbSqlFile();
            vGISUtil.vAppMap = vApp;

            //20170510 Non GISEditor intimation
            //connDB();
            try
            {
                connDB();
            }
            catch (Exception e)
            {
                MessageBox.Show("Access to database couldn't be obtained");
                vBRes = false;
                return vBRes;
            }
            //20170510 Non GISEditor intimation
            logNtry("WCTools", "UpdFacDesc", "Start", vLogSessId, "TRC");
            return vBRes;
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "UpdFacDesc", "End", vLogSessId, "TRC");
            vDbFile.CleanUpDBConnection();
            vDbFile.Dispose();
            vDbFile = null ;

            vDbNet1File.CleanUpDBConnection();
            vDbNet1File.Dispose();
            vDbNet1File = null;

            vGISUtil.Dispose();
            vGISUtil = null;
            vUtilFile = null;
            vSelFeature = null;
            vSelDataRow = null;
        }
        
        public void connDB()
        {
            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            vDbFile.ConnectToDatabase(3, vConnStr);

            vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_MstrDb");
            vDbNet1File.ConnectToDatabase(3, vConnStr);
        }

        public void logNtry()
        {
        }

        ~frmFacDesc()
        {
            vSelFeature = null;
            vSelDataRow = null;
            vApp = null;
        }
        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            //20150722
            //vUtilFile.logNtry(vDbFile, inCmdType, inMsg, inFld1, inSessId, inLogType);
            vUtilFile.logTxtNtry(inCmdType, inMsg, inFld1, inSessId, inLogType);
            //20150722
        }
        public frmFacDesc()
        {
            InitializeComponent();
        }

        public bool validateOnLoad(out string outEqpId)
        {
            bool vResFn = false;
            outEqpId = "";
            if (!(vGISUtil.getFeatureSelectCount() == 1))
            {
                MessageBox.Show("Select single feature");
                return vResFn;
            }
            IFeature vFeat;
            IEnumFeature vEnmFeat = vGISUtil.getSelectedFeatures();
            vEnmFeat.Reset();
            vFeat = vEnmFeat.Next();
            IWorkspaceEdit vWrkSpcEdit = vGISUtil.getWrkSpcFFeature(vFeat);
            if (!(vWrkSpcEdit.IsBeingEdited()))
            {
                MessageBox.Show("Feature not in edit mode");
                return vResFn;
            }

            int vFldIdx;

            vFldIdx = vGISUtil.getFieldIdx(vFeat, "FAC_CODE");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute FAC_CODE missing for feature");
                return vResFn;
            }
            else
            {
                object vobjEqpFld = vGISUtil.getFieldValue(vFeat, "FAC_CODE");
                if (vobjEqpFld is System.DBNull)
                {
                    MessageBox.Show("Attribute GIS_ID missing for feature");
                    return vResFn;
                }
                else
                {
                    outEqpId = (string)vobjEqpFld;
                }
            }

            vFldIdx = vGISUtil.getFieldIdx(vFeat, "FAC_DESC");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute FAC_DESC missing for feature");
                return vResFn;
            }

            vSelFeature = vFeat;

            vResFn = true;
            return vResFn;
        }



        #region GridUtilities

        private void setFldValue(string inFeatFldName, string inSAPFldName)
        {
            string vTmpVal = "";
            DateTime vtmpDate;

            if (!(vGISUtil.getFieldIdx(vSelFeature, inFeatFldName) == -1))
            {
                dtGrdLstAttr.Rows.Add();

                //if (vSelDataRow[inSAPFldName].GetType() is System.DateTime)
                //{
                //    if (DateTime.TryParse(vGISUtil.getFieldValue(vSelFeature, inFeatFldName).ToString(), out vtmpDate))
                //    {
                //        vTmpVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                //    }
                //}
                //else
                //    vTmpVal = vGISUtil.getFieldValue(vSelFeature, inFeatFldName).ToString();
                if (vGISUtil.getFieldType(vSelFeature, inFeatFldName) == esriFieldType.esriFieldTypeDate)
                {
                    if (DateTime.TryParse(vGISUtil.getFieldValue(vSelFeature, inFeatFldName).ToString(), out vtmpDate))
                    {
                        vTmpVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                    }
                }
                else
                    vTmpVal = vGISUtil.getFieldValue(vSelFeature, inFeatFldName).ToString();

                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = inFeatFldName;
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                if (!(vSelDataRow == null))
                {
                    if (vSelDataRow[inSAPFldName].GetType() is System.DateTime)
                    {
                        if (DateTime.TryParse(vTmpVal = vSelDataRow[inSAPFldName].ToString(), out vtmpDate))
                        {
                            vTmpVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                        }
                    }
                    else
                        vTmpVal = vSelDataRow[inSAPFldName].ToString();
                }
                else
                    vTmpVal = "";

                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = inSAPFldName;
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;
            }
        }

        private void setGridVals()
        {
            setFldValue("FAC_CODE", "FAC_CODE");
            setFldValue("FAC_DESC", "FAC_DESC");

            //setFldValue("GRP_CODE", "GROUPCODE");
            //setFldValue("INSTALLED", "DATEACQUIRED");
            //setFldValue("CP_ID", "MPA_005_CP_SITE_ID");
            //setFldValue("NOM_DIA_MM", "SAP_NOM_DIA_MM_TMP");
            //setFldValue("MODIFYREF", "GIS_REF");
            //setFldValue("STATUS", "SAP_STATUS_TMP");
            //setFldValue("MATERIAL", "MATERIAL");
        }

        private void updGridCells()
        {
            string vCol1, vCol2;
            //log
            int vResFnSetDomChk = -1;
            string vLogStr = "";
            this.Cursor = Cursors.WaitCursor;
            IWorkspaceEdit vWkrSpcEdt = vGISUtil.getWrkSpcFFeature(vSelFeature);
            vWkrSpcEdt.StartEditOperation();
            try
            {
                for (int i = 0; i < dtGrdLstAttr.RowCount; i++)
                {
                    if (dtGrdLstAttr[4, i].Value == null)
                        vCol2 = "";
                    else
                        vCol2 = dtGrdLstAttr[4, i].Value.ToString();
                    if (dtGrdLstAttr[1, i].Value == null)
                        vCol1 = "";
                    else
                        vCol1 = dtGrdLstAttr[1, i].Value.ToString();


                    if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                    {
                        if (!(vCol2 == ""))
                        {
                            vCol1 = dtGrdLstAttr[0, i].Value.ToString();
                            dtGrdLstAttr[1, i].Value = vCol2;
                            dtGrdLstAttr[2, i].Style.BackColor = Color.White;
                            vGISUtil.setFieldValue(vSelFeature, vCol1, vCol2);


                            //log
                            if (!(vLogStr == ""))
                            {
                                vLogStr = vLogStr + ",";
                            }
                            vLogStr = vLogStr + vCol1 + "=" + vCol2;
                        }
                    }
                    Application.DoEvents();
                }

                //log
                vCol2 = vGISUtil.getFieldValue(vSelFeature, "GIS_ID").ToString();
                vCol1 = "GIS_ID";
                vLogStr = vLogStr + "[" + vCol1 + "=" + vCol2 + "]";
                logNtry("WCTools", "UpdFacDesc", vLogStr, vLogSessId, "TRC");

            }
            finally
            {
                vWkrSpcEdt.StopEditOperation();
                this.Cursor = Cursors.Default;
            }
        }
        private void hghlghtGrid()
        {
            string vCol1, vCol2;
            for (int i = 0; i < dtGrdLstAttr.RowCount; i++)
            {
                if (dtGrdLstAttr[4, i].Value == null)
                    vCol2 = "";
                else
                    vCol2 = dtGrdLstAttr[4, i].Value.ToString();
                if (dtGrdLstAttr[1, i].Value == null)
                    vCol1 = "";
                else
                    vCol1 = dtGrdLstAttr[1, i].Value.ToString();


                if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                {
                    dtGrdLstAttr[2, i].Style.BackColor = Color.Red;
                }
            }

        }
        #endregion

        public bool LoadFacDesc(string inFacCode)
        {
            bool resFn = false;
            //Configuration vConfig = vUtilFile.getConfig();
            //string vConnStr = vConfig.ConnectionStrings.ConnectionStrings["GIS_Connection"].ConnectionString.ToString();
            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_MstrDb");



            vDbNet1File.ConnectToDatabase(3, vConnStr);
            if (vDbNet1File.Connected)
            {
                DataTable vDtTbl = vDbNet1File.getDtTblRecs(string.Format("Select * from [GISNet1].[GISWSL].[WA_FACILITY] where FAC_CODE = '{0}'", inFacCode));

                if (vDtTbl.Rows.Count > 0)
                {
                    vSelDataRow = vDtTbl.Rows[0];
                    //if (!(vSelDataRow == null))
                    //{
                    //    setGridVals();
                    //    hghlghtGrid();
                    //    resFn = true;
                    //}
                }
                setGridVals();
                hghlghtGrid();
                resFn = true;

                vDtTbl = null;
            }
            return resFn;
        }

        private void frmFacDesc_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdAttr_Click(object sender, EventArgs e)
        {
            updGridCells();
            btnUpdAttr.Enabled = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public bool LoadSAPAttr(out string outFacCode, out string outFacDesc )
        {
            bool resFn = false;
            outFacCode = "";
            outFacDesc = "";

            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_MstrDb");

            vDbNet1File.ConnectToDatabase(3, vConnStr);
            if (vDbNet1File.Connected)
            {
                DataTable vDtTbl = vDbNet1File.getDtTblRecs("Select * from [GISNet1].[GISWSL].[WA_FACILITY]");

                using (WCTools.BL.Forms.frmFacDescSel vfrmFacDescSel = new frmFacDescSel())
                {
                    var vFacility = vfrmFacDescSel.LoadFacDescSel(vDtTbl);

                    outFacCode = vFacility.Item1;
                    outFacDesc = vFacility.Item2;

                    if (!(vFacility.Item1 == ""))
                    {
                        resFn = true;
                    }

                    //this.Text = vFacility.Item1 + "/" + vFacility.Item2;
                    //resFn = true;
                    //vSelDataRow = vfrmFacDescSel.LoadFacDescSel(vDtTbl);
                    //if (!(vSelDataRow == null))
                    //{
                    //    //setGridVals();
                    //    hghlghtGrid();
                    //    resFn = true;
                    //}
                }
                //vSelDataRow = vDtTbl.Rows[0];
            }
            return resFn;
        }

        private void btnChg_Click(object sender, EventArgs e)
        {
            string vFacCode;
            string vFacDesc;
            if (LoadSAPAttr(out vFacCode, out vFacDesc))
            {
                dtGrdLstAttr.Rows[0].Cells[4].Value = vFacCode;
                dtGrdLstAttr.Rows[1].Cells[4].Value = vFacDesc;
                hghlghtGrid();
            }
        }
    }
}
