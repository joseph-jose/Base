﻿define({
    left: "ķ_LEFT_ū",
    right: "ķ_RIGHT_ū",
    arrangement: "Vienošanās",
    autoUpdate: "Automātiska atjaunināšana",
    respectCurrentMapScale: "Saglabāt pašreizējo kartes mērogu"
});