﻿define({
    left: "GAUCHE",
    right: "DROITE",
    arrangement: "Disposition",
    autoUpdate: "Mise à jour automatique",
    respectCurrentMapScale: "Respecter l’échelle cartographique actuelle"
});