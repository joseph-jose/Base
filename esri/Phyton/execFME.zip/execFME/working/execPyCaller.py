import sys
import os

sys.path.append(r"C:\Program Files\FME\fmeobjects\python27")

os.chdir(r"C:\Program Files\FME")
import fmeobjects
# initiate FMEWorkspaceRunner Class 
runner = fmeobjects.FMEWorkspaceRunner() 
# Full path to Workspace, example comes from the FME 2014 Training Full Dataset
#workspace = 'C:\Joseph\Task\FUP\Snitch\Work\execFME\execFME\execFME\LoadSnitchDifferences_Final.fmw'
workspace = r'C:\Joseph\Task\FUP\Snitch\Work\execFME\execFME\execFME\execFME\PyCaller1.fmw'
# Set workspace parameters by creating a dictionary of name value pairs
print sys.argv[1]
parameters = {}
parameters["MTH_PREV"] = sys.argv[1]
parameters["MTH_CURR"] = sys.argv[2]


print('Starting.....')
#parameters['DestDataset_ACAD'] = 'C:\FMEData2014\Output\Training\Zones.dwg' 
# Use Try so we can get FME Exception
try:
    # Run Workspace with parameters set in above directory
    print('Running....')
    runner.runWithParameters(workspace, parameters)
    #runner.run(workspace)
    # or use promptRun to prompt for published parameters
    #runner.promptRun(workspace)
except fmeobjects.FMEException, err:
    # Print out FME Exception if workspace failed
    #print fmeobjects.FMEException.message
    print "FME Exception : %s" % err
else:
    #Tell user the workspace ran
    print("The Workspace %s ran successfully".format(workspace))
# get rid of FMEWorkspace runner so we don't leave an FME process running
running = None
