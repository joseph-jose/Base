﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCToolsNA.BL.Classes
{
    class Class1
    {
    }
}
