import arcpy
import os
import datetime
import time

#Start the clock 
start = datetime.datetime.now()
print start
startTime = time.clock()

arcpy.env.overwriteOutput = True
tbx = arcpy.ImportToolbox(\
    r'G:\Projects\2017\PR17035_WatermainBreakRateAnalysisTool\Toolbox\BreakRateAnalysis.tbx')
tbx_models = tbx.__all__ # List of modules in toolbox
# Toolbox alias is 'TBX'
try:
    print 'Export from SDE...'
    arcpy.SupermainBreaksPart1_TBX()
    print 'Supermain pipe lengths...'
    arcpy.SupermainBreaksPart2_TBX()
    print 'Watermain breaks statistics...'
    arcpy.SupermainBreaksPart3_TBX()
##    print 'Watermain breaks sorted statistics...'
##    arcpy.SupermainBreaksPart4_TBX()
##    print 'Delete existing data from project...'
##    arcpy.SupermainBreaksPart5_TBX()
##    print 'Copy new data to project...'
##    arcpy.SupermainBreaksPart6_TBX()
##    print 'Delete temp gdb...'
##    arcpy.SupermainBreaksPart7_TBX()
    print 'Finished.'

except arcpy.ExecuteError:
    print 'Geoprocessing tool error occurred'
    print arcpy.GetMessages(0)
    
    
stopTime = time.clock()
elapsedTime = stopTime - startTime
print 'elapsed time = ' + str(round(elapsedTime/60, 2)) + ' minutes'
