﻿define({
    left: "Š_LEFT_ä",
    right: "Š_RIGHT_ä",
    arrangement: "Korraldamine",
    autoUpdate: "Uuenda automaatselt",
    respectCurrentMapScale: "Säilita praegune kaardi mõõtkava"
});