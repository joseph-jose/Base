import arcpy 
from arcpy import env
import os


try:
    sFC = arcpy.GetParameterAsText(0)
    env.workspace = sFC 

    fcList = arcpy.ListFeatureClasses()

    for featCls in fcList:
        print featCls
except Exception as err:
    arcpy.AddError(err)
    print err 