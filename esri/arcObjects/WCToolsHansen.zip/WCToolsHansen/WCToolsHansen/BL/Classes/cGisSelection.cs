﻿using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCToolsHansen.BL.Classes
{
    class cGisSelection : cGisBase
    {
        private IMxDocument vDoc;
        public IMxDocument vAppDoc { get {return (IMxDocument)vAppMap.Document;}}
        public int getFeatureSelectCount()
        {
            int resCnt = 0;

            resCnt = vAppDoc.FocusMap.SelectionCount;
                //for (int i = 0; i < vMap.LayerCount ; i++)
                //{
                //    cmbLyrs.Items.Add(vMap.Layer[i].Name.ToString());
                //}

            return resCnt;
        }

        public IEnumFeature getSelectedFeatures()
        {
            IEnumFeature vEnmFeatures;

            vEnmFeatures = (IEnumFeature)vAppDoc.FocusMap.FeatureSelection;

            return vEnmFeatures;
        }

        #region "IDisposable Support "
        //'***************************************
        //'Clean up connection
        //'Always to be called before a connection is created
        //'***************************************
        public override void CleanUpDBConnection()
        {
            vDoc = null;
        }


        #endregion

    }
}
