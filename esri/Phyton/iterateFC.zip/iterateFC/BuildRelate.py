import arcpy
import os

FCs = arcpy.GetParameterAsText(0)



arcpy.env.workspace = FCs

inFeature = "ObservePoints__ATTACH"
fieldname = "UniqueIDR"
jointable = "ObservePoints"
joinField = "UniqueID"

arcpy.AddJoin_management(inFeature, fieldname, jointable, joinField)

fields = arcpy.ListFields("C:\Temp\tmpPy\LabCollector.gdb/ObservePoints__ATTACH")

for field in fields:
    print("{0} is a type of {1} with a length of {2}"
          .format(field.name, field.type, field.length))

