﻿namespace WCTools.BL.Forms
{
    partial class frmPHLst
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnVw = new System.Windows.Forms.Button();
            this.tbCtrlMod = new System.Windows.Forms.TabControl();
            this.tbNew = new System.Windows.Forms.TabPage();
            this.tbEdt = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPhLnk = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdt = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCnfrm = new System.Windows.Forms.Button();
            this.btnCncl = new System.Windows.Forms.Button();
            this.btnVer = new System.Windows.Forms.Button();
            this.BtnCls = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtGrdVwItms = new System.Windows.Forms.DataGridView();
            this.PHId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PHLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPHType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFlName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFldr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDtTkn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModifyBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModifyDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colComm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chgBit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fldrBrw = new System.Windows.Forms.FolderBrowserDialog();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.tbCtrlMod.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdVwItms)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnVw);
            this.panel1.Controls.Add(this.tbCtrlMod);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtPhLnk);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnEdt);
            this.panel1.Location = new System.Drawing.Point(3, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(505, 381);
            this.panel1.TabIndex = 0;
            // 
            // btnVw
            // 
            this.btnVw.Location = new System.Drawing.Point(238, 44);
            this.btnVw.Name = "btnVw";
            this.btnVw.Size = new System.Drawing.Size(59, 23);
            this.btnVw.TabIndex = 22;
            this.btnVw.Text = "View";
            this.btnVw.UseVisualStyleBackColor = true;
            this.btnVw.Visible = false;
            this.btnVw.Click += new System.EventHandler(this.btnVw_Click);
            // 
            // tbCtrlMod
            // 
            this.tbCtrlMod.Controls.Add(this.tbNew);
            this.tbCtrlMod.Controls.Add(this.tbEdt);
            this.tbCtrlMod.Location = new System.Drawing.Point(3, 3);
            this.tbCtrlMod.Name = "tbCtrlMod";
            this.tbCtrlMod.SelectedIndex = 0;
            this.tbCtrlMod.Size = new System.Drawing.Size(497, 25);
            this.tbCtrlMod.TabIndex = 21;
            this.tbCtrlMod.TabStop = false;
            this.tbCtrlMod.SelectedIndexChanged += new System.EventHandler(this.tbCtrlMod_SelectedIndexChanged);
            // 
            // tbNew
            // 
            this.tbNew.Location = new System.Drawing.Point(4, 22);
            this.tbNew.Name = "tbNew";
            this.tbNew.Padding = new System.Windows.Forms.Padding(3);
            this.tbNew.Size = new System.Drawing.Size(489, 0);
            this.tbNew.TabIndex = 0;
            this.tbNew.Text = "New";
            this.tbNew.UseVisualStyleBackColor = true;
            // 
            // tbEdt
            // 
            this.tbEdt.Location = new System.Drawing.Point(4, 22);
            this.tbEdt.Name = "tbEdt";
            this.tbEdt.Padding = new System.Windows.Forms.Padding(3);
            this.tbEdt.Size = new System.Drawing.Size(489, 0);
            this.tbEdt.TabIndex = 1;
            this.tbEdt.Text = "Edit";
            this.tbEdt.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "PH Link";
            // 
            // txtPhLnk
            // 
            this.txtPhLnk.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPhLnk.Location = new System.Drawing.Point(64, 44);
            this.txtPhLnk.Name = "txtPhLnk";
            this.txtPhLnk.ReadOnly = true;
            this.txtPhLnk.Size = new System.Drawing.Size(155, 20);
            this.txtPhLnk.TabIndex = 0;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(8, 353);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(34, 23);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdt
            // 
            this.btnEdt.Location = new System.Drawing.Point(43, 353);
            this.btnEdt.Name = "btnEdt";
            this.btnEdt.Size = new System.Drawing.Size(37, 23);
            this.btnEdt.TabIndex = 3;
            this.btnEdt.Text = "Edit";
            this.btnEdt.UseVisualStyleBackColor = true;
            this.btnEdt.Click += new System.EventHandler(this.btnEdt_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 534);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(510, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnCnfrm);
            this.panel2.Controls.Add(this.btnCncl);
            this.panel2.Controls.Add(this.btnVer);
            this.panel2.Controls.Add(this.BtnCls);
            this.panel2.Location = new System.Drawing.Point(3, 455);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(505, 76);
            this.panel2.TabIndex = 2;
            // 
            // btnCnfrm
            // 
            this.btnCnfrm.Location = new System.Drawing.Point(327, 24);
            this.btnCnfrm.Name = "btnCnfrm";
            this.btnCnfrm.Size = new System.Drawing.Size(75, 23);
            this.btnCnfrm.TabIndex = 0;
            this.btnCnfrm.Text = "Update";
            this.btnCnfrm.UseVisualStyleBackColor = true;
            this.btnCnfrm.Click += new System.EventHandler(this.btnCnfrm_Click);
            // 
            // btnCncl
            // 
            this.btnCncl.Location = new System.Drawing.Point(86, 24);
            this.btnCncl.Name = "btnCncl";
            this.btnCncl.Size = new System.Drawing.Size(52, 23);
            this.btnCncl.TabIndex = 3;
            this.btnCncl.Text = "Clear";
            this.btnCncl.UseVisualStyleBackColor = true;
            this.btnCncl.Click += new System.EventHandler(this.btnCncl_Click);
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(10, 24);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(70, 23);
            this.btnVer.TabIndex = 2;
            this.btnVer.Text = "Link";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.btnSav_Click);
            // 
            // BtnCls
            // 
            this.BtnCls.Location = new System.Drawing.Point(418, 24);
            this.BtnCls.Name = "BtnCls";
            this.BtnCls.Size = new System.Drawing.Size(75, 23);
            this.BtnCls.TabIndex = 1;
            this.BtnCls.Text = "Close";
            this.BtnCls.UseVisualStyleBackColor = true;
            this.BtnCls.Click += new System.EventHandler(this.BtnCls_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dtGrdVwItms);
            this.panel3.Location = new System.Drawing.Point(3, 150);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(505, 270);
            this.panel3.TabIndex = 3;
            // 
            // dtGrdVwItms
            // 
            this.dtGrdVwItms.AllowUserToAddRows = false;
            this.dtGrdVwItms.AllowUserToDeleteRows = false;
            this.dtGrdVwItms.AllowUserToResizeRows = false;
            this.dtGrdVwItms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGrdVwItms.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PHId,
            this.PHLink,
            this.colPHType,
            this.colFlName,
            this.colFldr,
            this.colDtTkn,
            this.ModifyBy,
            this.ModifyDate,
            this.colComm,
            this.chgBit});
            this.dtGrdVwItms.Location = new System.Drawing.Point(9, 17);
            this.dtGrdVwItms.MultiSelect = false;
            this.dtGrdVwItms.Name = "dtGrdVwItms";
            this.dtGrdVwItms.ReadOnly = true;
            this.dtGrdVwItms.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGrdVwItms.ShowEditingIcon = false;
            this.dtGrdVwItms.ShowRowErrors = false;
            this.dtGrdVwItms.Size = new System.Drawing.Size(490, 250);
            this.dtGrdVwItms.TabIndex = 1;
            // 
            // PHId
            // 
            this.PHId.Frozen = true;
            this.PHId.HeaderText = "PH Id";
            this.PHId.Name = "PHId";
            this.PHId.ReadOnly = true;
            this.PHId.Width = 75;
            // 
            // PHLink
            // 
            this.PHLink.HeaderText = "PH Link";
            this.PHLink.Name = "PHLink";
            this.PHLink.ReadOnly = true;
            this.PHLink.Visible = false;
            // 
            // colPHType
            // 
            this.colPHType.HeaderText = "PH Type";
            this.colPHType.Name = "colPHType";
            this.colPHType.ReadOnly = true;
            this.colPHType.Width = 75;
            // 
            // colFlName
            // 
            this.colFlName.HeaderText = "File Name";
            this.colFlName.Name = "colFlName";
            this.colFlName.ReadOnly = true;
            // 
            // colFldr
            // 
            this.colFldr.HeaderText = "Folder";
            this.colFldr.Name = "colFldr";
            this.colFldr.ReadOnly = true;
            this.colFldr.Width = 50;
            // 
            // colDtTkn
            // 
            dataGridViewCellStyle1.Format = "d";
            dataGridViewCellStyle1.NullValue = null;
            this.colDtTkn.DefaultCellStyle = dataGridViewCellStyle1;
            this.colDtTkn.HeaderText = "Date Taken";
            this.colDtTkn.Name = "colDtTkn";
            this.colDtTkn.ReadOnly = true;
            // 
            // ModifyBy
            // 
            this.ModifyBy.HeaderText = "Modify By";
            this.ModifyBy.Name = "ModifyBy";
            this.ModifyBy.ReadOnly = true;
            this.ModifyBy.Visible = false;
            // 
            // ModifyDate
            // 
            this.ModifyDate.HeaderText = "Modify Date";
            this.ModifyDate.Name = "ModifyDate";
            this.ModifyDate.ReadOnly = true;
            this.ModifyDate.Visible = false;
            // 
            // colComm
            // 
            this.colComm.HeaderText = "Comments";
            this.colComm.Name = "colComm";
            this.colComm.ReadOnly = true;
            this.colComm.Width = 200;
            // 
            // chgBit
            // 
            this.chgBit.HeaderText = "chgBit";
            this.chgBit.Name = "chgBit";
            this.chgBit.ReadOnly = true;
            this.chgBit.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.chgBit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.chgBit.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Location = new System.Drawing.Point(3, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(505, 66);
            this.panel4.TabIndex = 15;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // frmPHLst
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 556);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPHLst";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Photo Link";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tbCtrlMod.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtGrdVwItms)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.FolderBrowserDialog fldrBrw;
        private System.Windows.Forms.Button BtnCls;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdt;
        private System.Windows.Forms.TextBox txtPhLnk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnCncl;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.DataGridView dtGrdVwItms;
        private System.Windows.Forms.Button btnCnfrm;
        private System.Windows.Forms.DataGridViewTextBoxColumn PHId;
        private System.Windows.Forms.DataGridViewTextBoxColumn PHLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPHType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFlName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFldr;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDtTkn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModifyBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModifyDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComm;
        private System.Windows.Forms.DataGridViewTextBoxColumn chgBit;
        private System.Windows.Forms.TabControl tbCtrlMod;
        private System.Windows.Forms.TabPage tbNew;
        private System.Windows.Forms.TabPage tbEdt;
        private System.Windows.Forms.Button btnVw;
    }
}

