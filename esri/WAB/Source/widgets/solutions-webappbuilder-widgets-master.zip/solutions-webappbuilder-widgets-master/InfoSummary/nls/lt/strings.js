﻿define(
   ({
    title: "InfoSummary valdiklis",
    helpText: "UŽDUOTIS InfoSummary pagalbos tekstas",
    labels: {
      status: "Būsena",
      result: "Rezultatas"
    },
    _widgetLabel: "Informacijos suvestinė (beta)"
  })
);