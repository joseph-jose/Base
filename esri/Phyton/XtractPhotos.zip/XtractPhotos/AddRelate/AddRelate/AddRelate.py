import arcpy
import os

try:

	FCs = arcpy.GetParameterAsText(0)
	arcpy.env.workspace = FCs

	inFeature = "ObservePoints__ATTACH"
	fieldname = "REL_GLOBALID"
	jointable = "ObservePoints"
	joinField = "GLOBALID"

        def addRelate():
	        arcpy.JoinField_management(inFeature, fieldname, jointable, joinField)
	        print "Join created successfully"

        addRelate()

except Exception as err:
	arcpy.AddError(err)
	print err

#with arcpy.da.UpdateCursor(inFeature, ["UniqueId", "CONTENT_TYPE"]) as cursor:
#    for row in cursor:
#		row[0] = row[1]
#		cursor.updateRow(row)

#with arcpy.UpdateCursor(inFeature) as cursor:
#    for row in cursor:
#		row[7] = row[3]
#		rows.updateRow(row)

#fields = arcpy.ListFields("ObservePoints__ATTACH")

#for field in fields:
#    print("{0} is a type of {1} with a length of {2}"
#          .format(field.name, field.type, field.length))

#rows = arcpy.UpdateCursor(inFeature)

#for row in rows:
#	inFldVal = row.getValue("UniqueID")
#	print(inFl) 
#    #row.setValue("UniqueIDR", row.getValue("UniqueID") )
#    #rows.updateRow(row)

#with arcpy.da.SearchCursor(inFeature, "*") as cursor:
#    for row in cursor:
#        print('{0}, {1}, {2}'.format(row[0], row[1], row[2]))