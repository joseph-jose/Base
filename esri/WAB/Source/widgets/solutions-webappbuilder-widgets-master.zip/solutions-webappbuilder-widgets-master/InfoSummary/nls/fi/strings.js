﻿define(
   ({
    title: "InfoSummary-pienoisohjelma",
    helpText: "Tehtävien InfoSummary-ohjeteksti",
    labels: {
      status: "Tila",
      result: "Tulos"
    },
    _widgetLabel: "Tietojen yhteenveto (beeta)"
  })
);