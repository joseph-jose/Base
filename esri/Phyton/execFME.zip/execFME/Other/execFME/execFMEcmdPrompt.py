import sys 
sys.path.append("C:\\apps\\FME\\fmeobjects\\python27")
import fmeobjects
# initiate FMEWorkspaceRunner Class 
runner = fmeobjects.FMEWorkspaceRunner() 
# Full path to Workspace, example comes from the FME 2014 Training Full Dataset
workspace = 'C:\Joseph\Source\Official\Fme\FME-gdbToXlInCoord\filegdb2none.fmw'
# Set workspace parameters by creating a dictionary of name value pairs
parameters = {}
#parameters['SourceDataset_MITAB'] ='C:\FMEData2014\Data\Zoning\Zones.tab'
#parameters['DestDataset_ACAD'] = 'C:\FMEData2014\Output\Training\Zones.dwg' 
# Use Try so we can get FME Exception
try:
    # Run Workspace with parameters set in above directory
    # runner.runWithParameters(workspace, parameters)
    runner.run(workspace)
    # or use promptRun to prompt for published parameters
    #runner.promptRun(workspace)
except fmeobjects.FMEException as ex:
    # Print out FME Exception if workspace failed
    print ex.message
else:
    #Tell user the workspace ran
    print('The Workspace %s ran successfully'.format(workspace))
# get rid of FMEWorkspace runner so we don't leave an FME process running
running = None