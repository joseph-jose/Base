﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCTools.BL.Forms
{
    public partial class frmUpdSAPSel : Form
    {
        public frmUpdSAPSel()
        {
            InitializeComponent();
        }

        public DataRow LoadUpdSAPSel(DataTable inDtTbl)
        {
            DataRow vDataRow = null ;

            dtGrdLstAttr.DataSource = inDtTbl;
            dtGrdLstAttr.ClearSelection();
            try
            {
                if (this.ShowDialog() == DialogResult.OK)
                {
                    vDataRow = (dtGrdLstAttr.CurrentRow.DataBoundItem as DataRowView).Row;
                    //vDataRow = dtGrdLstAttr.CurrentRow;
                }
            }
            finally
            {
                //vDataRow = inDtTbl.Rows[0];

            }
            return vDataRow;
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dtGrdLstAttr.SelectedRows.Count==0)
            {
                MessageBox.Show("Select row to update ");
                return;
            }
            if (dtGrdLstAttr.SelectedRows[0].Cells[0].Value.ToString().Trim()  == "")
            {
                MessageBox.Show("GIS_REF missing for selected update");
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void frmUpdSAPSel_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gISNet1DataSet.WAT_SAP' table. You can move, or remove it, as needed.
            //this.wAT_SAPTableAdapter.Fill(this.gISNet1DataSet.WAT_SAP);

        }

        private void btnCls_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void dtGrdLstAttr_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
