﻿using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCTools.BL.Classes; 


namespace WCTools.BL.Forms
{
    public partial class frmWWAssetUpd : Form
    {
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }

        //private IFeatureLayer __FeatLyr;
        private IFeature __SelFeat;
        //private string __gisIdFld;

        private string vLogSessId;
        public string vLogSessionId { set { vLogSessId = value; } }

        private WCTools.BL.Classes.cUtilFile vUtilFile;
        private WCTools.BL.Classes.cUtilGIS vGISUtil;
        private WCTools.BL.Classes.cDbSqlFile vGisDb;
        private WCTools.BL.Classes.clsXmlMap vXmlMap;

        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            vUtilFile.logNtry(vGisDb, inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public void helpersActivate()
        {
            vGISUtil = new Classes.cUtilGIS();
            vGISUtil.vAppMap = __App;

            vUtilFile = new Classes.cUtilFile();
            vGisDb = new Classes.cDbSqlFile();
            vXmlMap = new Classes.clsXmlMap();

            connDB();
            logNtry("WCTools", "SetGISIdMulti", "Start", vLogSessId, "TRC");
        }
        public void helpersDeActivate()
        {
            logNtry("WCTools", "SetGISIdMulti", "End", vLogSessId, "TRC");
            vGISUtil.Dispose();
            vGISUtil = null;
            vUtilFile = null;
            vXmlMap = null;

            vGisDb.Connected = false;
            vGisDb.Dispose();
            vGisDb = null;

            //__FeatLyr = null;
            __App = null;
        }
        private bool DbConn()
        {
            bool resFn = false;

            string vConnStr = "";
            vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_MstrDb");
            vGisDb.ConnectToDatabase(3, vConnStr);

            resFn = true;
            return resFn;
        }

        public void connDB()
        {
            string vConnStr = vUtilFile.getCfgFilePth();
            vConnStr = vUtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            vGisDb.ConnectToDatabase(3, vConnStr);
        }

        private void DbDisConn()
        {
            vGisDb.Connected = false;
        }

        public bool validateOnLoad()
        {
            bool vresFn = false;

            //IWorkspaceEdit vWrkSpcEdt= null;
            //ILayer vLyr = null;
            try
            {
                if (!(vGISUtil.getFeatureSelectCount() == 1))
                {
                    MessageBox.Show("Select single feature");
                    return vresFn;
                }

                //IFeature vFeat;
                IEnumFeature vEnumFeats = vGISUtil.getSelectedFeatures();
                vEnumFeats.Reset();
                __SelFeat = vEnumFeats.Next();
                IWorkspaceEdit vWrkSpcEdt = vGISUtil.getWrkSpcFFeature(__SelFeat);
                if (!(vWrkSpcEdt.IsBeingEdited()))
                {
                    MessageBox.Show("Feature not in edit mode");
                    return vresFn;
                }

                //vSelFeat 
            }
            finally
            {
                //vLyr = null;
            }

            vresFn = true;

            return vresFn;
        }

        public frmWWAssetUpd()
        {
            InitializeComponent();
        }

        public void updAttr(string inFldName, object inFldVal, Type inType)
        {
            IWorkspaceEdit vWrkSpcEdt = vGISUtil.getWrkSpcFFeature(__SelFeat)  ;
            vWrkSpcEdt.StartEditOperation();

            int inFldIdx = vGISUtil.getFieldIdx(__SelFeat, inFldName);
            if (!(inFldIdx == -1))
            {
                vGISUtil.setFieldValue(__SelFeat, inFldName, inFldVal); 
            }

            vWrkSpcEdt.StopEditOperation(); 
        }

        private DataTable getDbRecord(string inSqlStmt)
        {
            
            string vCfgFlPth = vUtilFile.getCfgFilePth();
            string vDbConnStr = vUtilFile.ConfigDbRead(vCfgFlPth, "GIS_Connection_MstrDb");

            string vSqlStr;
            //vSqlStr = "Select * from [GISAdmin].[GISWSL].[Tmp_JJ_WLPipe] where Equip_Id = {0}";
            vSqlStr = vXmlMap.vStrDestEqFld;
            if (vGISUtil.getFieldIdx(__SelFeat, vSqlStr) == -1)
            {
                return null;
            }
            else
            {
                vSqlStr = vGISUtil.getFieldValue(__SelFeat, vSqlStr).ToString(); 
            }

            vSqlStr = string.Format(inSqlStmt, vSqlStr);
            //vSqlStr = string.Format(vSqlStr, "10046438");

            DataTable vDtTbl = null;
            try
            {
                vGisDb.ConnectToDatabase(3, vDbConnStr);
                if (vGisDb.Connected)
                {
                    vDtTbl = vGisDb.getDtTblRecs(vSqlStr);
                }
            }
            finally
            {
                vGisDb.Connected = false;
            }
            return vDtTbl;
        }

        public bool updAttributes()
        {
            bool bRetRes = false;
            int vIntFldIdx = -1;
            IWorkspaceEdit vWrkSpcEdt = vGISUtil.getWrkSpcFFeature(__SelFeat);  
            cUtilFile vUtilFile = new cUtilFile();
            string vCfgFlPth = vUtilFile.getCfgFilePth("WWAssetUpdXMLPath");

            bRetRes = vXmlMap.getDsMappings(vCfgFlPth);
            bRetRes = vXmlMap.getAllFields1(vCfgFlPth);

            vCfgFlPth = vXmlMap.getDbSqlStmt();
            DataTable vRecDtTbl;
            vRecDtTbl = getDbRecord(vCfgFlPth);
            if (vRecDtTbl.Rows.Count == 0)
            {
                MessageBox.Show("Updates for feature not found");
                return false;
            }
            vWrkSpcEdt.StartEditOperation();

            vCfgFlPth = "";
            try
            {
                foreach (DataColumn vDtCol in vRecDtTbl.Columns)
                {
                    //listBox1.Items.Add(vDtCol.ColumnName + ":" + vDtCol.DataType.ToString() + ":" + vRecDtTbl.Rows[0][vDtCol]);
                    object vAttrVal = vRecDtTbl.Rows[0][vDtCol];
                    if (vAttrVal is DBNull)
                    {
                        continue;
                    }
                    if (vDtCol.DataType is System.String )
                    {
                        if (vAttrVal.ToString().Trim() == "")
                        {
                            continue;
                        }
                    }
                    if ((vDtCol.DataType is System.Int16) || (vDtCol.DataType is System.Int32) || (vDtCol.DataType is System.Int64))
                    {
                        if (Convert.ToInt32(vAttrVal) == 0)
                        {
                            continue;
                        }
                    }

                    vIntFldIdx = vGISUtil.getFieldIdx(__SelFeat, vDtCol.ColumnName);
                    if (!(vIntFldIdx == -1))
                    {
                        vGISUtil.setFieldValue(__SelFeat, vDtCol.ColumnName, vRecDtTbl.Rows[0][vDtCol]);
                    }
                    else
                    {
                        if (vCfgFlPth.Trim() == "")
                        {
                            vCfgFlPth = vCfgFlPth + ",";
                        }
                        vCfgFlPth = vCfgFlPth + vDtCol.ColumnName;
                    }
                }
            }
            finally
            {
                vWrkSpcEdt.StopEditOperation();
                Marshal.ReleaseComObject(vWrkSpcEdt); 
            }

            if (!(vCfgFlPth.Trim() == ""))
            {
                MessageBox.Show("Fields not updated : " + vCfgFlPth);
                return false;
            }

            //listBox1.Items.Add(vFilePath);
            bRetRes = true;
            return bRetRes;
        }

        private void frmWWAssetUpd_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            updAttributes();
        }
    }
}
