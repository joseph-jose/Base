// datatables api
$(document).ready(function() {
    $('#myTable').DataTable( {
        // onload sort asc
        "order": [[ 2, "asc" ]],
        "columnDefs": [
          // disable columns that are orderable
          { "orderable": false, "targets": [3,4,5,6,7,8,9,10]},
          // disable columns that are searchable
          { "bSearchable": false, "aTargets": [ 1,2,3,4,5,6,7,8,9,10] }
        ],
        "iDisplayLength":25,
        "scrollX": false,
        "scrolly": true
    } );
} );


