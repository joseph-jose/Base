﻿define(
   ({
    addDistance: "Ajouter une unité de longueur",
    addArea: "Ajouter une unité de surface",
    label: "Etiquette",
    abbr: "Abréviation",
    conversion: "Conversion",
    actions: "Actions",
    areaUnits: "Unités de surface",
    distanceUnits: "Unités de longueur",
    kilometers: "Kilomètres",
    miles: "Miles",
    meters: "Mètres",
    feet: "Pieds",
    yards: "Yards",
    squareKilometers: "Kilomètres carrés",
    squareMiles: "Miles carrés",
    acres: "Acres",
    hectares: "Hectares",
    squareMeters: "Mètres carrés",
    squareFeet: "Pieds carrés",
    squareYards: "Yards carrés",
    distance: "Distances",
    area: "Surfaces"
  })
);