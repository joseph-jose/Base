﻿define(
   ({
    _widgetLabel: "Muokkaa",
    title: "Luo kohteita valitsemalla malli",
    pressStr: "Paina ",
    ctrlStr: " CTRL ",
    snapStr: " ja ota käyttöön tartunta"
  })
);