﻿define({
    root:{
      title: "Reverse Geocoding Widget",
      helpText:  "Click on Map to Identify the Address",
      labels: {
	      status: "Status",
	      result: "Result"
      }
    },
	  "ar": false,
	  "cs": false,
	  "da": false,
	  "de": false,
	  "es": false,
	  "et": false,
	  "fi": false,
	  "fr": false,
	  "he": false,
	  "it": false,
	  "ja": false,
	  "ko": false,
	  "lt": false,
	  "lv": false,
	  "nb": false,
	  "nl": false,
	  "pl": false,
	  "pt-BR": false,
	  "pt-PT": false,
	  "ro": false,
	  "ru": false,
	  "sv": false,
	  "th": false,
	  "tr": false,
	  "zh-cn": false
});
