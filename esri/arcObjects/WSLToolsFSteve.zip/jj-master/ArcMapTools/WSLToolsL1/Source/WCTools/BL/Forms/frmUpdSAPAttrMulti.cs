﻿using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCTools.BL.Classes;

namespace WCTools.BL.Forms
{
    public partial class frmUpdSAPAttrMulti : Form
    {
        private IApplication __App;
        public IApplication __AppMap { set { __App = value; } }
        private string __LogSessId = "";
        public string __LogSessionId { set { __LogSessId = value; } }

        WCTools.BL.Classes.cDbSqlFile __DbFile;
        WCTools.BL.Classes.cUtilFile __UtilFile;
        WCTools.BL.Classes.cUtilGIS __GISUtil;

        private IEnumFeature __SelEnmFeat;
        private DataTable __SelDtTbl;

        public frmUpdSAPAttrMulti()
        {
            InitializeComponent();
        }

        ~frmUpdSAPAttrMulti()
        {
            Marshal.ReleaseComObject(__SelEnmFeat);
            __UtilFile = null;
            __App = null;
        }

        public void helpersActivate()
        {
            __DbFile = new cDbSqlFile();
            __UtilFile = new cUtilFile();
            __GISUtil = new cUtilGIS();
            __GISUtil.vAppMap = __App;
            connDB();
            logNtry("WCTools", "UpdSAPAttrMulti", "Start", __LogSessId, "TRC");
        }

        public void helpersDeActivate()
        {
            logNtry("WCTools", "UpdSAPAttrMulti", "End", __LogSessId, "TRC");
            if (!(__SelEnmFeat == null))
            {
                Marshal.ReleaseComObject(__SelEnmFeat);
            }
            __SelDtTbl = null;
            __DbFile.CleanUpDBConnection();
            __DbFile.Dispose();
            __DbFile = null;
            __GISUtil.Dispose();
            __GISUtil = null;
            __SelDtTbl = null;
        }

        public void logNtry(string inCmdType, string inMsg, string inFld1, string inSessId, string inLogType)
        {
            __UtilFile.logNtry(__DbFile, inCmdType, inMsg, inFld1, inSessId, inLogType);
        }

        public void connDB()
        {
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");
            __DbFile.ConnectToDatabase(3, vConnStr);
        }

        public bool validateOnLoad(out string outEqpIds)
        {
            bool vResFn = false;
            outEqpIds = "";
            object vobjEqpFld;

            int vTmpInt = __GISUtil.getFeatureSelectCount();
            if (vTmpInt == 0)
            {
                MessageBox.Show("Select the feature for update");
                return vResFn;
            }
            if (vTmpInt > 10)
            {
                MessageBox.Show("Select a maximum of 10 features");
                return vResFn;
            }

            IFeature vFeat;
            IEnumFeature vEnmFeat = __GISUtil.getSelectedFeatures();
            vEnmFeat.Reset();
            vFeat = vEnmFeat.Next();

            IWorkspaceEdit vWrkSpcEdit = __GISUtil.getWrkSpcFFeature(vFeat);
            if (!(vWrkSpcEdit.IsBeingEdited()))
            {
                MessageBox.Show("Feature not in edit mode");
                return vResFn;
            }

            int vFldIdx = __GISUtil.getFieldIdx(vFeat, "FAC_CODE");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute FAC_CODE missing for feature");
                return vResFn;
            }
            vFldIdx = __GISUtil.getFieldIdx(vFeat, "INSTALLED");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute INSTALLED missing for feature");
                return vResFn;
            }
            vFldIdx = __GISUtil.getFieldIdx(vFeat, "MODIFYREF");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute NOM_DIA_MM missing for feature");
                return vResFn;
            }
            vFldIdx = __GISUtil.getFieldIdx(vFeat, "STATUS");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute STATUS missing for feature");
                return vResFn;
            }

            vFldIdx = __GISUtil.getFieldIdx(vFeat, "EQUIP_ID");
            if (vFldIdx == -1)
            {
                MessageBox.Show("Attribute EQUIP_ID missing for feature");
                return vResFn;
            }

            string vFeatName = vFeat.Class.AliasName.ToString();
            while (!(vFeat == null))
            {
                if (!(vFeatName == vFeat.Class.AliasName.ToString()))
                {
                    MessageBox.Show("Selected features should be of same type");
                    return vResFn;
                }
                //Build comma delimited text

                vobjEqpFld = __GISUtil.getFieldValue(vFeat, "EQUIP_ID");
                if (vobjEqpFld is System.DBNull)
                {
                    MessageBox.Show("Attribute EQUIP_ID missing for feature");
                    return vResFn;
                }
                else
                {
                    vTmpInt = (int)vobjEqpFld;
                }
                if (!(outEqpIds == ""))
                {
                    outEqpIds = outEqpIds + ",";
                }
                outEqpIds = outEqpIds + vTmpInt;


                vFeat = vEnmFeat.Next();
            }


            __SelEnmFeat = vEnmFeat;
            //Marshal.ReleaseComObject(vFeat);
            //Marshal.ReleaseComObject(vEnmFeat);

            vResFn = true;
            return vResFn;
        }

        #region GridUtitlities
            private void hghlghtGrid()
            {
                string vCol1, vCol2;
                for (int i = 0; i < dtGrdLstAttr.RowCount; i++)
                {
                    if (dtGrdLstAttr[4, i].Value == null)
                        vCol2 = "";
                    else
                        vCol2 = dtGrdLstAttr[4, i].Value.ToString();
                    if (dtGrdLstAttr[1, i].Value == null)
                        vCol1 = "";
                    else
                        vCol1 = dtGrdLstAttr[1, i].Value.ToString();


                    if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                    {
                        dtGrdLstAttr[2, i].Style.BackColor = Color.Red;
                    }
                }

            }
            private IFeature getFeatureFId(string inFeatId)
            {
                IFeature vResFt = null;

                object vObjEqpId = null;
                int vIntEqpId = -1;

                __SelEnmFeat.Reset();
                vResFt = __SelEnmFeat.Next();
                while (!(vResFt == null))
                {
                    vObjEqpId = __GISUtil.getFieldValue(vResFt, "EQUIP_ID");
                    vIntEqpId = (int)vObjEqpId;
                    if (vIntEqpId.ToString() == inFeatId.Trim())
                    {
                        break;
                    }
                    vResFt = __SelEnmFeat.Next();
                }

                return vResFt;
            }

            private DataRow getDataRow(string inFeatId)
            {
                DataRow vDataRow = null;

                DataRow[] vSrchRows = null;

                
                if (__SelDtTbl.Rows.Count>0)
                {                 
                    string vStrFltrCond = string.Format("Equipment={0}", inFeatId);
                    vSrchRows = __SelDtTbl.Select(vStrFltrCond);
                    if (vSrchRows.Length > 0)
                        vDataRow = vSrchRows[0];
                }
                return vDataRow;
            }
            private void setGridVals(IFeature inFeat, DataRow inDataRow)
            {
                string vTmpVal;

                dtGrdLstAttr.Rows.Clear();
                dtGrdLstAttr.Rows.Add();
                vTmpVal = __GISUtil.getFieldValue(inFeat, "FAC_CODE").ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "FAC_CODE";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                vTmpVal = inDataRow["FACILITY"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "FACILITY";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;

                if (!(__GISUtil.getFieldIdx(inFeat, "PROC_CODE") == -1))
                {
                    dtGrdLstAttr.Rows.Add();
                    vTmpVal = __GISUtil.getFieldValue(inFeat, "PROC_CODE").ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "PROC_CODE";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                    vTmpVal = inDataRow["PROCESS"].ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "PROCESS";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;
                }

                if (!(__GISUtil.getFieldIdx(inFeat, "GRP_CODE") == -1))
                {
                    dtGrdLstAttr.Rows.Add();
                    vTmpVal = __GISUtil.getFieldValue(inFeat, "GRP_CODE").ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "GRP_CODE";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                    vTmpVal = inDataRow["GROUPCODE"].ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "GROUPCODE";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;
                }

                dtGrdLstAttr.Rows.Add();

                vTmpVal = "";
                DateTime vtmpDate;
                if (DateTime.TryParse(__GISUtil.getFieldValue(inFeat, "INSTALLED").ToString(), out vtmpDate))
                {
                    vTmpVal = string.Format("{0:dd/MM/yyyy}", vtmpDate);
                }
                //vTmpVal =vGISUtil.getFieldValue(vSelFeature, "INSTALLED").ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "INSTALLED";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;

                vTmpVal = inDataRow["DATEACQUIRED"].ToString();


                vTmpVal = string.Format("{0:dd/MM/yyyy}", inDataRow["DATEACQUIRED"]);
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "DATEACQUIRED";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;

                //dtGrdLstAttr.Rows.Add();
                //vTmpVal = vGISUtil.getFieldValue(vSelFeature, "OWNER").ToString();
                //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "OWNER";
                //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                //vTmpVal = vSelDataRow["MPA_001_OWNER"].ToString();
                //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "MPA_001_OWNER";
                //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;

                if (!(__GISUtil.getFieldIdx(inFeat, "CP_ID") == -1))
                {
                    dtGrdLstAttr.Rows.Add();
                    vTmpVal = __GISUtil.getFieldValue(inFeat, "CP_ID").ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "CP_ID";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                    vTmpVal = inDataRow["MPA_005_CP_SITE_ID"].ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "MPA_005_CP_SITE_ID";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;
                }

                if (!(__GISUtil.getFieldIdx(inFeat, "NOM_DIA_MM") == -1))
                {
                    dtGrdLstAttr.Rows.Add();
                    vTmpVal = __GISUtil.getFieldValue(inFeat, "NOM_DIA_MM").ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "NOM_DIA_MM";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                    vTmpVal = inDataRow["SAP_NOM_DIA_MM_TMP"].ToString();
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "SAP_NOM_DIA_MM_TMP";
                    dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;
                }

                dtGrdLstAttr.Rows.Add();
                vTmpVal = __GISUtil.getFieldValue(inFeat, "STATUS").ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "STATUS";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                //vTmpVal = vSelDataRow["SYSSTATUS"].ToString();
                //dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "SYSSTATUS";
                vTmpVal = inDataRow["SAP_STATUS_TMP"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "SAP_STATUS_TMP";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;

                dtGrdLstAttr.Rows.Add();
                vTmpVal = __GISUtil.getFieldValue(inFeat, "MODIFYREF").ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = "MODIFYREF";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[1].Value = vTmpVal;
                vTmpVal = inDataRow["GIS_REF"].ToString();
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[3].Value = "GIS_REF";
                dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[4].Value = vTmpVal;



                //for (int i = 0; i < inDtTbl.Columns.Count; i++)
                //{
                //    DataColumn vDtCol = inDtTbl.Columns[i];
                //    string vColName = vDtCol.ColumnName;

                //    string vColVal = inDtTbl.Rows[0][i].ToString();

                //    if ((vColName.ToUpper() == "GIS_REF") || (vColName.ToUpper() == "DATEACQUIRED") || (vColName.ToUpper() == "SYSSTATUS") || (vColName.ToUpper() == "FACILITY"))
                //    {
                //        dtGrdLstAttr.Rows.Add();
                //        dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[0].Value = vColName;

                //        dtGrdLstAttr.Rows[dtGrdLstAttr.Rows.Count - 1].Cells[2].Value = vColVal;
                //    }

                //}
            }

            private void updGridCells(IFeature inFeat)
            {
                string vCol1, vCol2;
                //log
                string vLogStr = "";
                this.Cursor = Cursors.WaitCursor;
                IWorkspaceEdit vWkrSpcEdt = __GISUtil.getWrkSpcFFeature(inFeat);
                vWkrSpcEdt.StartEditOperation();
                try
                {
                    for (int i = 0; i < dtGrdLstAttr.RowCount; i++)
                    {
                        if (dtGrdLstAttr[4, i].Value == null)
                            vCol2 = "";
                        else
                            vCol2 = dtGrdLstAttr[4, i].Value.ToString();
                        if (dtGrdLstAttr[1, i].Value == null)
                            vCol1 = "";
                        else
                            vCol1 = dtGrdLstAttr[1, i].Value.ToString();


                        if (!(vCol1.ToUpper() == vCol2.ToUpper()))
                        {
                            if (!(vCol2 == ""))
                            {
                                dtGrdLstAttr[1, i].Value = vCol2;
                                vCol1 = dtGrdLstAttr[0, i].Value.ToString();
                                dtGrdLstAttr[2, i].Style.BackColor = Color.White;
                                __GISUtil.setFieldWDomCheckValue(inFeat, vCol1, vCol2);

                                //log
                                if (!(vLogStr == ""))
                                {
                                    vLogStr = vLogStr + ",";
                                }
                                vLogStr = vLogStr + vCol1 + "=" + vCol2;
                            }
                        }
                        Application.DoEvents();
                    }

                    //log
                    vCol2 = __GISUtil.getFieldValue(inFeat, "GIS_ID").ToString();
                    vCol1 = "GIS_ID";
                    vLogStr = vLogStr + "[" + vCol1 + "=" + vCol2 + "]";
                    logNtry("WCTools", "UpdSAPAttrMulti", vLogStr, __LogSessId, "TRC");

                }
                finally
                {
                    vWkrSpcEdt.StopEditOperation();
                    this.Cursor = Cursors.Default;
                }
            }

        #endregion

        public bool LoadSAPAttr(string inEqpIds)
        {
            bool resFn = false;
            //Configuration vConfig = vUtilFile.getConfig();
            //string vConnStr = vConfig.ConnectionStrings.ConnectionStrings["GIS_Connection"].ConnectionString.ToString();
            string vConnStr = __UtilFile.getCfgFilePth();
            vConnStr = __UtilFile.ConfigDbRead(vConnStr, "GIS_Connection_RepDb");



            __DbFile.ConnectToDatabase(3, vConnStr);
            if (__DbFile.Connected)
            {
                __SelDtTbl = __DbFile.getDtTblRecs(string.Format("Select * from [GISAdmin].[GISWSL].[WAT_SAPGIS] where Equipment in ({0}) and GISSTATE = '{1}' order by UpdatedDate", inEqpIds, "In Progress"));
            }
            resFn = true;
            return resFn;
        }

        public bool LoadSAPEqpIds()
        {
            bool resFn = false;

            IFeature vCurrFeat;
            object vObjEqpId = null;
            int vIntEqpId = -1;

            __SelEnmFeat.Reset();
            vCurrFeat = __SelEnmFeat.Next();
            while (!(vCurrFeat == null))
            {
                vObjEqpId = __GISUtil.getFieldValue(vCurrFeat, "EQUIP_ID");
                vIntEqpId = (int)vObjEqpId;

                dtGrdEqp.Rows.Add();
                dtGrdEqp.Rows[dtGrdEqp.RowCount - 1].Cells[0].Value = vIntEqpId.ToString(); 

                vCurrFeat = __SelEnmFeat.Next();
            }

            //Marshal.ReleaseComObject(vCurrFeat); 
            resFn = true;
            return resFn;
        }

        private void btnUpdAttr_Click(object sender, EventArgs e)
        {
            if (dtGrdEqp.Rows.Count > 1)
            {
                MessageBox.Show("Confirm select the equipment that needs update");
                return ;
            }
            try
            {
                string vCurrEqpId = dtGrdEqp.CurrentCell.Value.ToString();
                IFeature vCurrFeat = null;
                vCurrFeat = getFeatureFId(vCurrEqpId);

                updGridCells(vCurrFeat);
                btnUpdAttr.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("GPF!  -> " + ex.Message.ToString());
                logNtry("WCTools", "UpdSAPAttrMulti", ex.Message.ToString(), __LogSessId , "EXP");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtGrdEqp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtGrdEqp_SelectionChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Select Changed");
            dtGrdLstAttr.Rows.Clear();
            string vSelCellValue = "";
            if (dtGrdEqp.SelectedRows.Count > 0)
            {
                vSelCellValue = dtGrdEqp.SelectedRows[0].Cells[0].Value.ToString();
                IFeature vSelFeat;
                DataRow vDataRow;
                vSelFeat = getFeatureFId(vSelCellValue);
                vDataRow = getDataRow(vSelCellValue);
                if (vDataRow == null)
                {
                    MessageBox.Show("Updates for feature not found");
                }
                else
                {
                    setGridVals(vSelFeat, vDataRow);
                }
            }
        }

        private void dtGrdEqp_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("Row enter"); 
        }

        private void frmUpdSAPAttrMulti_Load(object sender, EventArgs e)
        {
            //LoadSAPEqpIds();
        }
    }
}
