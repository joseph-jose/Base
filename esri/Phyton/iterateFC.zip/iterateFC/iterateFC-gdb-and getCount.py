import arcpy
import os
import datetime

#FCs = r"C:\Users\jejyjose1\AppData\Roaming\ESRI\Desktop10.5\ArcCatalog\atalgissdbu01.Ac.sde"
FCs = r"C:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication20180819.gdb"
arcpy.env.workspace = FCs
fcList = arcpy.ListFeatureClasses()
print(datetime.datetime.now())
for fc in fcList:
    #print(fc)
    fullName = arcpy.ParseTableName(fc)
    nameList = fullName.split(",")
    fcName = nameList[2]
    fcStr = str(fcName)
    #print(fullName)
    fcStr = fcStr.strip()
    print(fcStr)
    
    result = arcpy.GetCount_management(fcStr)
    print('{} has {} records'.format(fcStr, result[0]))
    
print(datetime.datetime.now())


