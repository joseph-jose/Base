﻿define({
    select: "한_Select_빠",
    results: "한_Results_빠",
    selectLayer: "한_Select from layer:_빠",
    selectDrawtool: "한_Select draw tool:_빠",
    result: "한_Result:_빠",
    noresult: "한_No query results to display chart._빠",
    nomedia: "한_There's no media in configuration!_빠",
    envelop: "한_Draw Rectangle_빠",
    circle: "한_Draw Circle_빠",
    ellipse: "한_Draw Ellipse_빠",
    polygon: "한_Draw Polygon_빠",
    freehand: "한_Draw Freehand Polygon_빠",
    clear:"한_Clear_빠"
});