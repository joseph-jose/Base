﻿define({
    select: "بيت_Select_لاحقة",
    results: "بيت_Results_لاحقة",
    selectLayer: "بيت_Select from layer:_لاحقة",
    selectDrawtool: "بيت_Select draw tool:_لاحقة",
    result: "بيت_Result:_لاحقة",
    noresult: "بيت_No query results to display chart._لاحقة",
    nomedia: "بيت_There's no media in configuration!_لاحقة",
    envelop: "بيت_Draw Rectangle_لاحقة",
    circle: "بيت_Draw Circle_لاحقة",
    ellipse: "بيت_Draw Ellipse_لاحقة",
    polygon: "بيت_Draw Polygon_لاحقة",
    freehand: "بيت_Draw Freehand Polygon_لاحقة",
    clear:"بيت_Clear_لاحقة"
});