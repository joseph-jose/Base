﻿define(
   ({
    enableUndoRedo: "Aktivera Ångra/Upprepa",
    toolbarVisible: "Verktygsfält synligt",
    toolbarOptions: "Alternativ för verktygsfält",
    mergeVisible: "Sammanfoga",
    cutVisible: "Beskär",
    reshapeVisible: "Omforma",
    back: "Bakåt",
    label: "Lager",
    edit: "Redigerbar",
    update: "Inaktivera Uppdatera geometri",
    fields: "Fält",
    actions: "Åtgärder",
    editpageName: "Namn",
    editpageAlias: "Alias",
    editpageVisible: "Synlig",
    editpageEditable: "Redigerbar",
    noLayers: "Inga redigerbara geoobjektslager är tillgängliga",
    configureFields: "Konfigurera lagerfält"
  })
);