﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.AccountManagement;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace getAllUsers
{
    public partial class Form1 : Form
    {
        PrincipalContext insPrincipalContext;
        public Form1()
        {
            InitializeComponent();
        }

        private void SearchGroups(GroupPrincipal parGroupPrincipal)
        {
            lbGroups.Items.Clear();
            PrincipalSearcher insPrincipalSearcher = new PrincipalSearcher();
            insPrincipalSearcher.QueryFilter = parGroupPrincipal;
            PrincipalSearchResult<Principal> results = insPrincipalSearcher.FindAll();
            foreach (Principal p in results)
            {
                lbGroups.Items.Add(p);
            }
        }
        //private void SearchUsers(UserPrincipal parUserPrincipal)
        //{
        //    lbUsers.Items.Clear();
        //    PrincipalSearcher insPrincipalSearcher = new PrincipalSearcher();
        //    insPrincipalSearcher.QueryFilter = parUserPrincipal;
        //    PrincipalSearchResult<principal> results = insPrincipalSearcher.FindAll();
        //    foreach (Principal p in results)
        //    {
        //        lbUsers.Items.Add(p);
        //    }
        //}
        private void ListGroups()
        {
            GroupPrincipal insGroupPrincipal = new GroupPrincipal(insPrincipalContext);
            insGroupPrincipal.Name = "*";
            SearchGroups(insGroupPrincipal);
        }
        //private void ListUsers()
        //{
        //    UserPrincipal insUserPrincipal = new UserPrincipal(insPrincipalContext);
        //    insUserPrincipal.Name = "*";
        //    SearchUsers(insUserPrincipal);
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            //PrincipalContext insPrincipalContext =
            //  new PrincipalContext(ContextType.Machine);
            //Connecting to local computer.
            //PrincipalContext insPrincipalContext = new PrincipalContext(ContextType.Domain, "MyDomain",
            //                                       "DC=MyDomain,DC=com");
            ////Connecting to Active Directory
            //PrincipalContext insPrincipalContext = new PrincipalContext(ContextType.Machine, "TAMERO",
            //                                       "administrator", "password");
            ////Connecting to local computer 
            ////with credentials of an user

            //insPrincipalContext =
            //  new PrincipalContext(ContextType.Machine);//Connecting to local computer.
            insPrincipalContext = new PrincipalContext(ContextType.Domain, "water.internal",
                                                   "DC=water.internal,DC=com");


            ListGroups();

            insPrincipalContext = null;
        }
    }
}
