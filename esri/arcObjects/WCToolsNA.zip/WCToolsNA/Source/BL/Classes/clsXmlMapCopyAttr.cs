﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace WCToolsNA.BL.Classes
{
    public class AttributeInfo
    {
        public string ObjectId { get; set; }

        public string dataType { get; set; }
        public string sfieldName { get; set; }
        public string sfieldValue { get; set; }
        public string dfieldName { get; set; }
        public string dfieldValue { get; set;}
        public string type { get; set; }
    }

    public class clsXmlMapCopyAttr
    {
        public string vStrSource { get; set; }
        public string vStrDestination { get; set; }

        public IList<AttributeInfo> vLstXmlCnfs { get; set; }

        public bool getAllFields1(string inFilePath)
        {
            bool retRes = false;
            StreamReader vSRdr = new StreamReader(inFilePath);

            var vXmlMap = XDocument.Load((vSRdr));

            XElement vElem = vXmlMap.Root.Elements("Location").FirstOrDefault();

            //XElement vElem = vXmlMap.Element("root/Location/Session");
            vElem = vElem.Element("Session");

            var vFlds =
                from a in vElem.Elements()
                select new AttributeInfo
                {
                    dataType = a.Attributes("dataType").FirstOrDefault().Value.ToString(),
                    sfieldName = a.Attributes("sfieldName").FirstOrDefault().Value.ToString(),
                    dfieldName = a.Attributes("dfieldName").FirstOrDefault().Value.ToString(),
                    type = a.Attributes("type").FirstOrDefault().Value.ToString(),
                };
            vLstXmlCnfs = vFlds.ToList();
            retRes = true;
            return retRes;
        }


        public bool getDsMappings(string inFilePath)
        {
            bool retRes = false;
            StreamReader vSRds = new StreamReader(inFilePath);
            var vXmlMap = XDocument.Load(vSRds );

            XElement vElem = vXmlMap.Root.Elements("Location").FirstOrDefault();

            vStrSource = vElem.Attributes("source").FirstOrDefault().Value.ToString();
            vStrDestination = vElem.Attributes("destination").FirstOrDefault().Value.ToString();
            retRes = true;
            return retRes;
        }
    }
}
