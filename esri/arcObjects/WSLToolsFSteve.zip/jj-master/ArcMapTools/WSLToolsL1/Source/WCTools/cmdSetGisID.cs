using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.Geodatabase;

namespace WCTools
{
    /// <summary>
    /// Summary description for cmdSetGisID.
    /// </summary>
    [Guid("8fa72d90-2063-40c9-87b7-7a61894a715c")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("WCTools.cmdSetGisID")]
    public sealed class cmdSetGisID : BaseCommand
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            MxCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IApplication m_application;
        public cmdSetGisID()
        {
            //
            // TODO: Define values for the public properties
            //
            base.m_category = "WCTools"; //localizable text
            base.m_caption = "WCTools.SetGISId";  //localizable text
            base.m_message = "WCTools.SetGISId";  //localizable text 
            base.m_toolTip = "Set GISId";  //localizable text 
            base.m_name = "WCTools.cmdfrmSetGISId";   //unique id, non-localizable (e.g. "MyCategory_ArcMapCommand")

            try
            {
                //
                // TODO: change bitmap name if necessary
                //
                string bitmapResourceName = GetType().Name + ".bmp";
                base.m_bitmap = new Bitmap(GetType(), bitmapResourceName);


            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.Message, "Invalid Bitmap");
            }
        }

        #region Overridden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook == null)
                return;

            m_application = hook as IApplication;

            //Disable if it is not ArcMap
            if (hook is IMxApplication)
                base.m_enabled = true;
            else
                base.m_enabled = false;

            // TODO:  Add other initialization code
        }

        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            // TODO: Add cmdSetGisID.OnClick implementation
            using (WCTools.BL.Forms.frmSetGISId vfrmSetGisId = new WCTools.BL.Forms.frmSetGISId())
            {
                string vLogCurrSessId = DateTime.Now.ToString("yyyyMMdd:hhmmss");
                try
                {

                    vfrmSetGisId.vLogSessionId = vLogCurrSessId;
                    vfrmSetGisId.vAppMap = m_application;
                    vfrmSetGisId.helpersActivate();



                    //int vFeatCnt = vfrmSetGisId.getFeaturesSelectCount();                    
                    //if (!(vFeatCnt == 1))
                    //{
                    //    MessageBox.Show("Select single feature");
                    //}
                    //else
                    //{
                    //    IFeature vFeature = vfrmSetGisId.getSelFeature();
                    //    int vGisId = vfrmSetGisId.getSeqNo();
                    //    ;
                    //    if (!(vfrmSetGisId.valdateFeature(vFeature)))
                    //    {
                    //        return;
                    //    }
                    //    vfrmSetGisId.setFldVal(vFeature, vGisId);

                    //}
                    if (vfrmSetGisId.validateOnLoad())
                    {
                        int vGisId = vfrmSetGisId.getSeqNo();
                        vfrmSetGisId.setFldVal(vGisId);
                    }
                }
                catch  (Exception e)
                {
                    MessageBox.Show("GPF!  -> "+ e.Message.ToString() );
                    vfrmSetGisId.logNtry("WCTools", "SetGISId", e.Message.ToString(), vLogCurrSessId, "EXP");
                }
                finally
                {
                     vfrmSetGisId.helpersDeActivate(); 
                }
            }
        }

        #endregion
    }
}
