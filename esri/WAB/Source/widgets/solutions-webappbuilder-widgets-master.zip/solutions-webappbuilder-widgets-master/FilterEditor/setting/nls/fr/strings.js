﻿define(
   ({
    enableUndoRedo: "Annuler/Répéter",
    toolbarVisible: "Barre d’outils visible",
    toolbarOptions: "Options de la barre d’outils",
    mergeVisible: "Combiner",
    cutVisible: "Couper",
    reshapeVisible: "Remodeler",
    back: "Retour",
    label: "Couche",
    edit: "Modifiable",
    update: "Désactiver la mise à jour de la géométrie",
    fields: "Champs",
    actions: "Actions",
    editpageName: "Nom",
    editpageAlias: "Alias",
    editpageVisible: "Visible",
    editpageEditable: "Modifiable",
    noLayers: "Aucune couche d\'entités modifiable n\'est disponible",
    configureFields: "Configurer les champs de couche"
  })
);