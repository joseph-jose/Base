import arcpy
import os
import datetime
from arcpy import env

in_path = r"C:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication20180819.gdb"
out_path = r"c:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication-Water.gdb"
in_FC = r"swBridge"

arcpy.env.workspace = in_path


#out_name = "swBridge_Copy"
#geometry_type = "POLYGON"
#template = "swBridge"
has_m = "DISABLED"
has_z = "DISABLED"

#desc = arcpy.Describe("C:\Joseph\Task\TASK_Data\FME\SDE_Connections\Publication20180819.gdb\swBridge")
desc = arcpy.Describe(in_path + r"\\" + in_FC)
if hasattr(desc, "spatialReference"):
    spaRef = desc.spatialReference
    geometry_type = desc.shapeType
    print geometry_type
    #print "Name=" + spaRef

arcpy.CreateFeatureclass_management(out_path, in_FC, geometry_type, in_FC, has_m, has_z, spaRef)










