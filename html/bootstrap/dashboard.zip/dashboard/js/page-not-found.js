
$( document).ready(function() {

	// parses gvalue of query string variable
	function getQueryVariable(variable) {
	    var query = window.location.search.substring(1);
	    // split by "&" chracter in query string
	    var vars = query.split('&');
	    for (var i = 0; i < vars.length; i++) {
	        var pair = vars[i].split('=');
	        console.log(pair);
	        if (decodeURIComponent(pair[0]) == variable) {
	            return decodeURIComponent(pair[1]);
	        }
	    }
	}

	// runs getQueryVariable(), replaces text in target with result
	function displayQuery(v,target){
		pageType = getQueryVariable(v);
		console.log(pageType);
		// display result in targeted element
		$(target).text('"' + pageType + '"');
	}

	// excute  function 
	displayQuery("Page",".page");

});

