﻿define({
    unit: "ก้_Unit_ษฺ",
    style: "ก้_Style_ษฺ"
});