﻿define({
    select: "Ж_Select_Я",
    results: "Ж_Results_Я",
    selectLayer: "Ж_Select from layer:_Я",
    selectDrawtool: "Ж_Select draw tool:_Я",
    result: "Ж_Result:_Я",
    noresult: "Ж_No query results to display chart._Я",
    nomedia: "Ж_There's no media in configuration!_Я",
    envelop: "Ж_Draw Rectangle_Я",
    circle: "Ж_Draw Circle_Я",
    ellipse: "Ж_Draw Ellipse_Я",
    polygon: "Ж_Draw Polygon_Я",
    freehand: "Ж_Draw Freehand Polygon_Я",
    clear:"Ж_Clear_Я"
});