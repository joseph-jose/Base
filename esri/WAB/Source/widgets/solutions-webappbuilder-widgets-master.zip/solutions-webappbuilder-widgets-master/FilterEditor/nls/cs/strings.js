﻿define(
   ({
    _widgetLabel: "Upravit",
    title: "Zvolte šablonu, podle které chcete vytvářet prvky.",
    pressStr: "Stisknutím ",
    ctrlStr: " CTRL ",
    snapStr: " aktivujete přichytávání."
  })
);