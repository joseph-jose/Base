﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WCToolsBulk.BL.Forms.MultiPWLink
{
    public partial class frmPWDet : Form
    {
        public frmPWDet()
        {
            InitializeComponent();

            Dictionary<string, string> vPWType = new Dictionary<string, string>();
            vPWType.Add("MFL", "Multi Feature Link");
            vPWType.Add("SFL", "Single Feature Link");

            cmbPlType.DataSource = new BindingSource(vPWType, null);
            cmbPlType.DisplayMember = "Value";
            cmbPlType.ValueMember = "Key";
        }

        public DialogResult setNewMode(ref string inPlType, ref string inDocNo, ref string inType, ref string inComm)
        {
            DialogResult vDlgRes = DialogResult.Cancel;
            //txtPwRef.Text = "";
            cmbPlType.Text = "";
            txtDocNo.Text = "";
            cmbType.Text = "";
            txtFldComm.Text = "";
            if (this.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //inPWRef = txtPwRef.Text;
                inPlType = ((KeyValuePair<string, string>)cmbPlType.SelectedItem).Key.ToString();
                //inPlType = cmbPlType.Text;
                inDocNo = txtDocNo.Text;
                inType = cmbType.Text;
                inComm = txtFldComm.Text;
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        public DialogResult setEdtMode(ref string inPlType, ref string inDocNo, ref string inType, ref string inComm)
        {
            DialogResult vDlgRes = DialogResult.Cancel;

            //txtPwRef.Text = inPWRef;
            //cmbPlType.Text = inPlType;
            cmbPlType.SelectedValue = inPlType;
            txtDocNo.Text = inDocNo;
            cmbType.Text = inType;
            txtFldComm.Text = inComm;

            if (this.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //inPWRef = txtPwRef.Text;
                inPlType = ((KeyValuePair<string, string>)cmbPlType.SelectedItem).Key.ToString();
                //inPlType = cmbPlType.Text;
                inDocNo = txtDocNo.Text;
                inType = cmbType.Text;
                inComm = txtFldComm.Text;
                vDlgRes = DialogResult.OK;
            }
            return vDlgRes;
        }

        private bool ValidateControls()
        {
            bool bretRes = false;

            if (cmbPlType.Text.Trim() == "")
            {
                MessageBox.Show("Select type");
                cmbPlType.Focus();
                return bretRes;
            }
            if (txtDocNo.Text.Trim() == "")
            {
                MessageBox.Show("Enter document #");
                txtDocNo.Focus();
                return bretRes;
            }
            if (cmbType.Text == "")
            {
                MessageBox.Show("Enter document Type");
                cmbType.Focus();
                return bretRes;
            }

            bretRes = true;
            return bretRes;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (ValidateControls() == false)
                return;
            //if (!(validateDocNo()))
            //    return;

            this.DialogResult = System.Windows.Forms.DialogResult.OK;

        }

        private void btnCncl_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;

        }
    }
}
