﻿define({
    select: "Å_Select_ö",
    results: "Å_Results_ö",
    selectLayer: "Å_Select from layer:_ö",
    selectDrawtool: "Å_Select draw tool:_ö",
    result: "Å_Result:_ö",
    noresult: "Å_No query results to display chart._ö",
    nomedia: "Å_There's no media in configuration!_ö",
    envelop: "Å_Draw Rectangle_ö",
    circle: "Å_Draw Circle_ö",
    ellipse: "Å_Draw Ellipse_ö",
    polygon: "Å_Draw Polygon_ö",
    freehand: "Å_Draw Freehand Polygon_ö",
    clear:"Å_Clear_ö"
});