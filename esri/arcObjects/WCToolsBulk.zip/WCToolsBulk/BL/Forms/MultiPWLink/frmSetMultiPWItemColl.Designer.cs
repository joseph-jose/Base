﻿namespace WCToolsBulk.BL.Forms.MultiPWLink
{
    partial class frmSetMultiPWItemColl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtNewCKey = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtOCompKey = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnCncl = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 275);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(332, 22);
            this.statusStrip1.TabIndex = 29;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(330, 57);
            this.panel1.TabIndex = 31;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtNewCKey);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txtOCompKey);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(0, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(330, 152);
            this.panel2.TabIndex = 30;
            // 
            // txtNewCKey
            // 
            this.txtNewCKey.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNewCKey.Location = new System.Drawing.Point(117, 78);
            this.txtNewCKey.MaxLength = 15;
            this.txtNewCKey.Name = "txtNewCKey";
            this.txtNewCKey.Size = new System.Drawing.Size(200, 20);
            this.txtNewCKey.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "New Comp Key";
            // 
            // txtOCompKey
            // 
            this.txtOCompKey.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtOCompKey.Location = new System.Drawing.Point(116, 29);
            this.txtOCompKey.MaxLength = 15;
            this.txtOCompKey.Name = "txtOCompKey";
            this.txtOCompKey.Size = new System.Drawing.Size(200, 20);
            this.txtOCompKey.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 30;
            this.label5.Text = "Old CompKey";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnCncl);
            this.panel3.Controls.Add(this.btnOk);
            this.panel3.Location = new System.Drawing.Point(1, 224);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(330, 51);
            this.panel3.TabIndex = 32;
            // 
            // btnCncl
            // 
            this.btnCncl.Location = new System.Drawing.Point(241, 14);
            this.btnCncl.Name = "btnCncl";
            this.btnCncl.Size = new System.Drawing.Size(75, 23);
            this.btnCncl.TabIndex = 1;
            this.btnCncl.Text = "&Cancel";
            this.btnCncl.UseVisualStyleBackColor = true;
            this.btnCncl.Click += new System.EventHandler(this.btnCncl_Click);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(160, 14);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "&OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // frmSetMultiPWItemColl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 297);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.statusStrip1);
            this.Name = "frmSetMultiPWItemColl";
            this.Text = "frmSetMultiPWItemColl";
            this.Load += new System.EventHandler(this.frmSetMultiPWItemColl_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtNewCKey;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOCompKey;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnCncl;
        private System.Windows.Forms.Button btnOk;
    }
}