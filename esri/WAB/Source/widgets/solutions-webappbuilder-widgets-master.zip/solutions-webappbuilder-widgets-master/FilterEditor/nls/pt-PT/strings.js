﻿define(
   ({
    _widgetLabel: "Editar",
    title: "Escolha um template para criar elementos",
    pressStr: "Pressione ",
    ctrlStr: " CTRL ",
    snapStr: " para ativar o ajuste automático"
  })
);