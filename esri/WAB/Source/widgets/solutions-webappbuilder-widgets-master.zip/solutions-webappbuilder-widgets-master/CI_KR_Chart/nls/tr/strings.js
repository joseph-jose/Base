﻿define({
    select: "ı_Select_İ",
    results: "ı_Results_İ",
    selectLayer: "ı_Select from layer:_İ",
    selectDrawtool: "ı_Select draw tool:_İ",
    result: "ı_Result:_İ",
    noresult: "ı_No query results to display chart._İ",
    nomedia: "ı_There's no media in configuration!_İ",
    envelop: "ı_Draw Rectangle_İ",
    circle: "ı_Draw Circle_İ",
    ellipse: "ı_Draw Ellipse_İ",
    polygon: "ı_Draw Polygon_İ",
    freehand: "ı_Draw Freehand Polygon_İ",
    clear:"ı_Clear_İ"
});