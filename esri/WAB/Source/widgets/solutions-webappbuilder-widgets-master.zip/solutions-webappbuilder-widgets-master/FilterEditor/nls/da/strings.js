﻿define(
   ({
    _widgetLabel: "Redigér",
    title: "Vælg en skabelon til at oprette objekter med",
    pressStr: "Tryk ",
    ctrlStr: " CTRL ",
    snapStr: " for at aktivere snapping"
  })
);