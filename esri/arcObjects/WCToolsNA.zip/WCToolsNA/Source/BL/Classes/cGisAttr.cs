﻿using ESRI.ArcGIS.Geodatabase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCToolsNA.BL.Classes
{
    class cGisAttr: cGisBase 
    {
        public int getFieldIdx(IFeature inFt, string inFldName)
        {
            return inFt.Fields.FindField(inFldName); 
        }

        public object getFieldValue(IFeature inFt, string inFldName)
        {
            object vretObj;
            IRow vRow = inFt;
            vretObj = vRow.Value[inFt.Fields.FindField(inFldName)];
            return vretObj ;
        }
        public void setFieldValue(IFeature inFt, string inFldName, object inObjVal)
        {
            //object vretObj;
            IRow vRow = inFt;

            vRow.Value[inFt.Fields.FindField(inFldName)] = inObjVal;
            vRow.Store();

        }

        #region "IDisposable Support "
        //'***************************************
        //'Clean up connection
        //'Always to be called before a connection is created
        //'***************************************
        public override void CleanUpDBConnection()
        {
        }
        #endregion
    }
}
