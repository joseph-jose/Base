﻿define({
    left: "VENSTRE",
    right: "HØYRE",
    arrangement: "Plassering",
    autoUpdate: "Automatisk oppdatering",
    respectCurrentMapScale: "Respekter gjeldende kartmålestokk"
});